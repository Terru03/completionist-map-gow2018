@echo off
setlocal
cd /d "%~dp0"
echo ========================================================
echo   God of War (2018) - Completionist Map Mod Installer
echo ========================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1" %*
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Installation did not finish successfully (exit code %ERRORLEVEL%).
    pause
    exit /b %ERRORLEVEL%
)
echo.
pause
