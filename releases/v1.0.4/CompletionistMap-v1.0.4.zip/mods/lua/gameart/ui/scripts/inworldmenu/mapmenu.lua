local classlib = require("core.class")
local tablex = require("core.tablex")
local animationUtil = require("ui.animationUtil")
local buttonUtil = require("ui.buttonUtil")
local colors = require("ui.colors")
local consts = require("ui.consts")
local fsm = require("ui.fsm")
local lamsConsts = require("ui.lamsConsts")
local list = require("ui.list")
local mapConsts = require("ui.mapConsts")
local mapSummaryCard = require("ui.mapSummaryCard")
local mapUtil = require("ui.mapUtil")
local menu = require("ui.menu")
local pickupUtil = require("ui.pickupUtil")
local questConsts = require("ui.questConsts")
local questUtil = require("ui.questUtil")
local util = require("ui.util")
local tutorialUtil = require("ui.tutorialUtil")
local tutorials = require("ui.tutorials")
local Audio = game.Audio
local Camera = game.Camera
local Level = game.Level
local Map = game.Map
local Player = game.Player
local UI = game.UI
local CALDERA_MAP_POSITION = engine.Vector.New(-0.336, 0, 0.921)
local enabledShowOnCompassMarkerFlags = {
  consts.COMPASS_MARKER_TYPE_VENDOR,
  consts.COMPASS_MARKER_TYPE_FAST_TRAVEL,
  consts.COMPASS_MARKER_TYPE_AREA_ENTRANCE,
  consts.COMPASS_MARKER_TYPE_FIGHT_LOCATION,
  consts.COMPASS_MARKER_TYPE_CHISEL_ENTRANCE,
  consts.COMPASS_MARKER_TYPE_DOCK_POINT,
  consts.COMPASS_MARKER_TYPE_VALKYRIE
}
local markerStates = {
  tweaks.eTokenState.kDiscovered,
  tweaks.eTokenState.kDiscoveredButLocked
}
-- Completionist Map v0.10.1
--
-- Map side:
--   Create a genuinely separate duplicate of a SAFE DISCOVERED DockPoint icon,
--   move the duplicate ROOT to the Raven map coordinate, and intercept only
--   collision with that exact duplicate. This gives us boat artwork without
--   hijacking the original dock.
--
-- HUD side:
--   While the map is open and Add to Compass is pressed, create a SECOND safe
--   DockPoint duplicate, detach it from the map hierarchy, and hand it to the
--   MainHUD script. MainHUD reparents that visual beneath Compass and moves it
--   across the strip using the already-proven Raven bearing math.
--
-- No marker state, quest state, collectible state, or save data is changed.
_G.CompletionistMapV100NornirRegistry = _G.CompletionistMapV100NornirRegistry or {}

print("[CompletionistMap v0.10.1] MAP_SCRIPT_LOADED")

if _G.CompletionistMapV100PlayerMarkerVisible == nil then
  _G.CompletionistMapV100PlayerMarkerVisible = true
end

_G.CompletionistMapV100Target = _G.CompletionistMapV100Target or {
  active = false,
  collected = false,
  type = "Raven",
  realm = "Midgard",
  regionQuest = "RegionSummary_VF_Raven_Parent",
  x = -64.850898742676,
  y = 12.987384796143,
  z = 787.30694580078,
  mapX = 3.2117712497711,
  mapZ = 0.8695997595787
}

local CompletionistMapV100_GetNornirRegistry
local CompletionistMapV100_ApplyZoomAdaptiveIconScale

local COMPLETIONIST_RAVEN_WORLD_X = -64.850898742676
local COMPLETIONIST_RAVEN_WORLD_Y = 12.987384796143
local COMPLETIONIST_RAVEN_WORLD_Z = 787.30694580078
local COMPLETIONIST_RAVEN_MAP_X = 3.2117712497711
local COMPLETIONIST_RAVEN_MAP_Z = 0.8695997595787

local COMPLETIONIST_ICON_ROOT = "mods/completionist-map/icons/generated"
local completionistMapV100IconApiLogged = {}

local function CompletionistMapV100_IconPath(family, size)
  return COMPLETIONIST_ICON_ROOT .. "/" .. tostring(size) .. "/" ..
    tostring(family) .. ".png"
end

local function CompletionistMapV100_GetCallable(container, name)
  if container == nil then return nil end
  local ok, value = pcall(function() return container[name] end)
  if ok and type(value) == "function" then
    return value
  end
  return nil
end

local function CompletionistMapV100_LogIconCapabilities(go, family)
  if go == nil then return end
  if completionistMapV100IconApiLogged[family] then return end
  completionistMapV100IconApiLogged[family] = true

  local goMethods = {
    "SetTexture",
    "SetTextureName",
    "SetImage",
    "SetImagePath",
    "SetSprite",
    "SetMaterialSwap"
  }
  local uiMethods = {
    "SetTexture",
    "SetTextureName",
    "SetImage",
    "SetImagePath",
    "SetSprite"
  }

  local goCaps = {}
  for _, name in ipairs(goMethods) do
    goCaps[#goCaps + 1] = name .. "=" .. tostring(
      CompletionistMapV100_GetCallable(go, name) ~= nil
    )
  end

  local uiCaps = {}
  for _, name in ipairs(uiMethods) do
    uiCaps[#uiCaps + 1] = name .. "=" .. tostring(
      CompletionistMapV100_GetCallable(UI, name) ~= nil
    )
  end

  print("[CompletionistMap v0.10.1] ICON_CAPS" ..
    " family=" .. tostring(family) ..
    " go={" .. table.concat(goCaps, ",") .. "}" ..
    " ui={" .. table.concat(uiCaps, ",") .. "}" ..
    " path=" .. CompletionistMapV100_IconPath(family, 32))
end

local function CompletionistMapV100_TryDirectIconBind(go, family)
  if go == nil then return false end
  CompletionistMapV100_LogIconCapabilities(go, family)

  local path = CompletionistMapV100_IconPath(family, 32)
  local attempts = {
    {owner = go, ownerName = "GO", name = "SetTexture"},
    {owner = go, ownerName = "GO", name = "SetTextureName"},
    {owner = go, ownerName = "GO", name = "SetImage"},
    {owner = go, ownerName = "GO", name = "SetImagePath"},
    {owner = UI, ownerName = "UI", name = "SetTexture", passGO = true},
    {owner = UI, ownerName = "UI", name = "SetTextureName", passGO = true},
    {owner = UI, ownerName = "UI", name = "SetImage", passGO = true},
    {owner = UI, ownerName = "UI", name = "SetImagePath", passGO = true}
  }

  for _, attempt in ipairs(attempts) do
    local fn = CompletionistMapV100_GetCallable(attempt.owner, attempt.name)
    if fn ~= nil then
      local ok, err = pcall(function()
        if attempt.passGO then
          fn(go, path)
        else
          fn(go, path)
        end
      end)

      print("[CompletionistMap v0.10.1] ICON_BIND_ATTEMPT" ..
        " family=" .. tostring(family) ..
        " api=" .. tostring(attempt.ownerName) .. "." .. tostring(attempt.name) ..
        " ok=" .. tostring(ok) ..
        " error=" .. tostring(err) ..
        " path=" .. tostring(path))

      if ok then
        return true
      end
    end
  end

  print("[CompletionistMap v0.10.1] ICON_BIND_RESULT" ..
    " family=" .. tostring(family) ..
    " direct=false" ..
    " fallback=DockPointProxy")
  return false
end

local function CompletionistMapV100_NornirIconFamily(keyType)
  if keyType == "Breakable" then return "nornir_seal" end
  if keyType == "Bell" then return "nornir_bell" end
  if keyType == "MemoryChest" then return "nornir_mechanism" end
  return "remaining_collectible"
end

local function CompletionistMapV100_IsRavenCollected()
  if _G.CompletionistMapV100TargetRavenKilled == true then
    return true
  end

  local stateOK, state = pcall(function()
    return game.QuestManager.GetQuestState(
      "RegionSummary_VF_Raven_Parent"
    )
  end)

  if stateOK and tostring(state) == "Complete" then
    _G.CompletionistMapV100TargetRavenKilled = true
    return true
  end

  return false
end

local function CompletionistMapV100_IsTargetCollected()
  local target = _G.CompletionistMapV100Target
  if target == nil then return false end

  if target.type == "NornirPuzzle" or target.type == "NornirChest" then
    if not _G.CompletionistMapV100TargetCollectedNornirLogged then
      _G.CompletionistMapV100TargetCollectedNornirLogged = true
      print("[CompletionistMap v0.10.1] NORNIR_TARGET_STATE_CHECK" ..
        " type=" .. tostring(target.type) ..
        " registryKey=" .. tostring(target.registryKey) ..
        " helperScope=local_forward_declared")
    end

    local registry = CompletionistMapV100_GetNornirRegistry()
    local entry = registry and registry[target.registryKey] or nil
    if entry ~= nil then
      if target.type == "NornirChest" then
        target.collected = entry.opened == true
      else
        local key = entry.keys and entry.keys[target.keyIndex] or nil
        if entry.challengeComplete == true or entry.opened == true then
          target.collected = true
        elseif entry.keyType == "Breakable" then
          target.collected = key ~= nil and key.broken == true
        else
          target.collected = false
        end
      end
    end
    if target.collected then target.active = false end
    return target.collected == true
  end

  if _G.CompletionistMapV100TargetRavenKilled == true then
    target.collected = true
  end
  if not target.collected and target.regionQuest ~= nil then
    local stateOK, state = pcall(function()
      return game.QuestManager.GetQuestState(target.regionQuest)
    end)
    if stateOK and tostring(state) == "Complete" then
      target.collected = true
      _G.CompletionistMapV100TargetRavenKilled = true
    end
  end
  if target.collected then target.active = false end
  return target.collected
end

local function CompletionistMapV100_LogMapCalibration(self)
  if self.currRealmName ~= "Midgard" or self.playerIconGO == nil then
    return
  end

  local player = game.Player.FindPlayer()
  if player == nil then
    return
  end

  local worldOK, worldPos = pcall(function()
    return player:GetWorldPosition()
  end)

  local mapOK, mapPos = pcall(function()
    return self.playerIconGO:GetWorldPosition()
  end)

  if not worldOK or worldPos == nil or
      not mapOK or mapPos == nil then
    return
  end

  local last = _G.CompletionistMapV100LastCalibration
  local shouldLog = last == nil

  if last ~= nil then
    local dx = worldPos.x - last.x
    local dz = worldPos.z - last.z
    shouldLog = dx * dx + dz * dz >= 400
  end

  if not shouldLog then
    return
  end

  _G.CompletionistMapV100LastCalibration = {
    x = worldPos.x,
    z = worldPos.z
  }

  print("[CompletionistMap v0.10.1] MAP_CALIBRATION" ..
    " realm=" .. tostring(self.currRealmName) ..
    " worldX=" .. tostring(worldPos.x) ..
    " worldY=" .. tostring(worldPos.y) ..
    " worldZ=" .. tostring(worldPos.z) ..
    " mapX=" .. tostring(mapPos.x) ..
    " mapY=" .. tostring(mapPos.y) ..
    " mapZ=" .. tostring(mapPos.z))
end

local completionistMapV100PreferredDockIds = {
  "2924516555722838670",
  "3015224018432851104",
  "-8580963607903916635",
  "-8580963607903813648",
  "-8580963607903819882",
  "-8580963607903820923",
  "-8580963607903817804",
  "-8580963607903818837",
  "-8580963607903824038",
  "3665597207158594306",
  "-7682859529157234129",
  "2012662071676473320",
  "-1367314585613671475",
  "-5774578489664548484",
  "1998313177983296660",
  "674850249950444597"
}

local function CompletionistMapV100_BuildBackingDockPool(self)
  if type(self.completionistMapV100BackingDockPool) == "table" and
      #self.completionistMapV100BackingDockPool > 0 then
    return self.completionistMapV100BackingDockPool
  end

  local byId = {}
  for i = 1, #self.realmMarkerInfo do
    local markerInfo = self.realmMarkerInfo[i]
    local safeOK, safe = pcall(function()
      return markerInfo.State == tweaks.eTokenState.kDiscovered and
        Map.MarkerHasAnyFlag(
          markerInfo.Id,
          {consts.COMPASS_MARKER_TYPE_DOCK_POINT}
        )
    end)

    if safeOK and safe then
      markerInfo.regionId = markerInfo.regionId or
        select(2, Map.FindRegionFromMarker(markerInfo.Id))
      byId[tostring(markerInfo.Id)] = markerInfo
    end
  end

  local pool = {}
  local used = {}

  for _, idString in ipairs(completionistMapV100PreferredDockIds) do
    local markerInfo = byId[idString]
    if markerInfo ~= nil and not used[idString] then
      pool[#pool + 1] = markerInfo
      used[idString] = true
    end
  end

  local remaining = {}
  for idString, markerInfo in pairs(byId) do
    if not used[idString] then
      remaining[#remaining + 1] = markerInfo
    end
  end

  table.sort(remaining, function(a, b)
    return tostring(a.Id) < tostring(b.Id)
  end)

  for _, markerInfo in ipairs(remaining) do
    pool[#pool + 1] = markerInfo
  end

  self.completionistMapV100BackingDockPool = pool

  local ids = {}
  for i = 1, math.min(#pool, 12) do
    ids[#ids + 1] = tostring(pool[i].Id)
  end

  print("[CompletionistMap v0.10.1] BACKING_POOL" ..
    " count=" .. tostring(#pool) ..
    " first=" .. table.concat(ids, ","))

  return pool
end

local function CompletionistMapV100_FindBackingDock(self, slot)
  local pool = CompletionistMapV100_BuildBackingDockPool(self)
  if type(pool) ~= "table" or #pool == 0 then
    return nil
  end

  slot = math.max(1, tonumber(slot) or 1)
  local index = ((slot - 1) % #pool) + 1
  local markerInfo = pool[index]

  self.completionistMapV100BackingSlotLog =
    self.completionistMapV100BackingSlotLog or {}

  if not self.completionistMapV100BackingSlotLog[slot] then
    self.completionistMapV100BackingSlotLog[slot] = true
    print("[CompletionistMap v0.10.1] BACKING_ASSIGN" ..
      " slot=" .. tostring(slot) ..
      " id=" .. tostring(markerInfo.Id) ..
      " region=" .. tostring(markerInfo.regionId))
  end

  return markerInfo
end


local function CompletionistMapV100_WorldToMidgardMap(x, z)
  return
    0.004 * z + 0.0625431,
    -0.004 * x + 0.6101961
end

CompletionistMapV100_GetNornirRegistry = function()
  local uiRegistry = _G.CompletionistMapV100NornirRegistry
  if type(uiRegistry) == "table" and next(uiRegistry) ~= nil then
    if not _G.CompletionistMapV100RegistryLogged then
      _G.CompletionistMapV100RegistryLogged = true
      print("[CompletionistMap v0.10.1] NORNIR_REGISTRY" ..
        " source=ui_call_event")
    end
    return uiRegistry, "ui_call_event"
  end

  -- One verified parent location remains as a bootstrap so the known chest
  -- can appear before its gameplay script publishes live state. Puzzle child
  -- pins are deliberately NOT created from this fallback because persisted
  -- per-seal state would be unknown.
  local registryKey =
    "known_breakable|-43.904609680176|748.57946777344"
  local fallback = {}
  fallback[registryKey] = {
    registryKey = registryKey,
    name = "chest_locked_parent",
    keyType = "Breakable",
    opened = false,
    challengeComplete = false,
    keysUsed = nil,
    x = -43.904609680176,
    y = 14.5,
    z = 748.57946777344,
    source = "verified_parent_fallback",
    keys = {}
  }

  if not _G.CompletionistMapV100FallbackLogged then
    _G.CompletionistMapV100FallbackLogged = true
    print("[CompletionistMap v0.10.1] NORNIR_FALLBACK" ..
      " parentOnly=true chest=chest_locked_parent" ..
      " ignoresStockSummary=true")
  end

  return fallback, "verified_parent_fallback"
end

local function CompletionistMapV100_IsNornirKeyRemaining(pin)
  if pin == nil then
    return false
  end

  local registry = CompletionistMapV100_GetNornirRegistry()
  local entry = registry and registry[pin.registryKey] or nil
  if entry == nil or entry.opened == true or entry.challengeComplete == true then
    return false
  end

  local key = entry.keys and entry.keys[pin.keyIndex] or nil
  if key == nil then
    return false
  end

  if entry.keyType == "Breakable" then
    return key.broken ~= true
  end

  -- Bell and MemoryChest actors remain relevant until the whole timed/rotator
  -- challenge completes. Their transient runeVisual disabled state is not a
  -- collected state.
  return true
end

local function CompletionistMapV100_DestroyNornirPins(self)
  if self.completionistMapV100NornirPins ~= nil then
    for _, pin in ipairs(self.completionistMapV100NornirPins) do
      if pin.iconGO ~= nil then
        pcall(function()
          Map.RecycleIcon(pin.iconGO)
        end)
      end
    end
  end

  self.completionistMapV100NornirPins = {}
  self.completionistMapV100NornirSelected = nil
  self.completionistMapV100NornirLastHitFrame = nil
end

local function CompletionistMapV100_NornirReticle(self, currState, pin)
  self.currQuestID = nil
  self.currMarkerID = nil
  self.clickedMarkerInfo = nil
  self.clickedPlayer = false
  self.completionistMapV100Selected = false
  self.completionistMapV100NornirChestSelected = nil

  local title = "Nornir Puzzle " .. tostring(pin.keyIndex)
  local description = "Nornir puzzle element - Completionist Map"
  if pin.keyType == "Breakable" then
    title = "Nornir Seal " .. tostring(pin.keyIndex)
    description = "Unbroken rune seal - Completionist Map"
  elseif pin.keyType == "Bell" then
    title = "Nornir Bell " .. tostring(pin.keyIndex)
    description = "Timed Nornir bell - Completionist Map"
  elseif pin.keyType == "MemoryChest" then
    title = "Nornir Rune Mechanism " .. tostring(pin.keyIndex)
    description = "Rune rotator - Completionist Map"
  end

  local target = _G.CompletionistMapV100Target
  if target ~= nil and
      target.type == "NornirPuzzle" and
      target.registryKey == pin.registryKey and
      target.keyIndex == pin.keyIndex and
      target.active then
    description = description .. " - tracked"
  end

  self:SetReticleInfo(currState, title, description)
  self:UpdateFooterButtonPrompt(currState.menu, false, false)
end

local function CompletionistMapV100_DestroyNornirChestPins(self)
  if type(self.completionistMapV100NornirChestPins) == "table" then
    for _, pin in ipairs(self.completionistMapV100NornirChestPins) do
      if pin.iconGO ~= nil then
        pcall(function() Map.RecycleIcon(pin.iconGO) end)
      end
    end
  end
  self.completionistMapV100NornirChestPins = {}
  self.completionistMapV100NornirChestSelected = nil
end

local function CompletionistMapV100_IsNornirChestRemaining(pin)
  if pin == nil then return false end
  local registry = CompletionistMapV100_GetNornirRegistry()
  local entry = registry and registry[pin.registryKey] or nil
  return entry ~= nil and entry.opened ~= true
end

local function CompletionistMapV100_NornirChestReticle(self, currState, pin)
  self.currQuestID = nil
  self.currMarkerID = nil
  self.clickedMarkerInfo = nil
  self.clickedPlayer = false
  self.completionistMapV100Selected = false
  self.completionistMapV100NornirSelected = nil

  local registry = CompletionistMapV100_GetNornirRegistry()
  local entry = registry and registry[pin.registryKey] or nil
  local title = "Nornir Chest"
  local description = "Incomplete Nornir Chest - Completionist Map"
  if entry ~= nil then
    if entry.challengeComplete == true and entry.opened ~= true then
      description = "Unlocked Nornir Chest - open it to complete"
    elseif entry.keyType == "Breakable" then
      description = "Nornir Chest - break the remaining rune seals"
    elseif entry.keyType == "Bell" then
      description = "Nornir Chest - ring the three timed bells"
    elseif entry.keyType == "MemoryChest" then
      description = "Nornir Chest - solve the rune mechanisms"
    end
  end

  self:SetReticleInfo(currState, title, description)
  self:UpdateFooterButtonPrompt(currState.menu, false, false)
end

local function CompletionistMapV100_CreateNornirChestPins(self, currState)
  CompletionistMapV100_DestroyNornirChestPins(self)
  if self.currRealmName ~= "Midgard" then return end

  local registry, registrySource = CompletionistMapV100_GetNornirRegistry()

  local mapY = 0
  local playerYOK, playerMapPos = pcall(function()
    return self.playerIconGO:GetWorldPosition()
  end)
  if playerYOK and playerMapPos ~= nil then mapY = playerMapPos.y end

  local chestOrdinal = 0
  for registryKey, entry in pairs(registry or {}) do
    if entry ~= nil and entry.opened ~= true and
        entry.x ~= nil and entry.z ~= nil then
      chestOrdinal = chestOrdinal + 1
      local backing =
        CompletionistMapV100_FindBackingDock(self, 2 + chestOrdinal - 1)
      if backing == nil then
        print("[CompletionistMap v0.10.1] NORNIR_CHEST_PIN" ..
          " ok=false reason=safe_dock_not_found" ..
          " registryKey=" .. tostring(registryKey))
      else
        local mapX, mapZ =
          CompletionistMapV100_WorldToMidgardMap(entry.x, entry.z)
        local createOK, iconOrErr = pcall(function()
          return Map.CreateMarkerIcon(backing.Id, backing.regionId, "")
        end)
      if createOK and iconOrErr ~= nil then
        local pin = {
          registryKey = registryKey,
          keyType = entry.keyType,
          worldX = entry.x, worldY = entry.y, worldZ = entry.z,
          mapX = mapX, mapY = mapY, mapZ = mapZ,
          iconGO = iconOrErr, frames = 0
        }
        local ok = pcall(function()
          pin.iconGO:SetWorldPosition(engine.Vector.New(mapX, mapY, mapZ))
          pin.iconGO:Show()
          UI.SetIsClickable(pin.iconGO)
          CompletionistMapV100_ApplyZoomAdaptiveIconScale(pin.iconGO)
          CompletionistMapV100_TryDirectIconBind(pin.iconGO, "nornir_chest")
        end)
        if ok then
          table.insert(self.completionistMapV100NornirChestPins, pin)
          print("[CompletionistMap v0.10.1] NORNIR_CHEST_PIN" ..
            " ok=true source=" .. tostring(registrySource) ..
            " registryKey=" .. tostring(registryKey) ..
            " backingId=" .. tostring(backing.Id) ..
            " mapX=" .. tostring(mapX) ..
            " mapZ=" .. tostring(mapZ))
        else
          pcall(function() Map.RecycleIcon(pin.iconGO) end)
        end
      end
      end
    end
  end
end

local function CompletionistMapV100_FindNornirChestCollision(self, collisionGameObjectTable)
  if type(collisionGameObjectTable) ~= "table" or
      type(self.completionistMapV100NornirChestPins) ~= "table" then
    return nil
  end
  for _, collGO in ipairs(collisionGameObjectTable) do
    for _, pin in ipairs(self.completionistMapV100NornirChestPins) do
      if pin.iconGO == collGO and
          CompletionistMapV100_IsNornirChestRemaining(pin) then
        return pin
      end
    end
  end
  return nil
end

local function CompletionistMapV100_RefreshNornirChestPins(self)
  if type(self.completionistMapV100NornirChestPins) ~= "table" then return end
  for i = #self.completionistMapV100NornirChestPins, 1, -1 do
    local pin = self.completionistMapV100NornirChestPins[i]
    pin.frames = (pin.frames or 0) + 1
    if pin.frames <= 60 and pin.iconGO ~= nil then
      pcall(function()
        pin.iconGO:SetWorldPosition(
          engine.Vector.New(pin.mapX, pin.mapY or 0, pin.mapZ)
        )
        UI.SetIsClickable(pin.iconGO)
      end)
    end
    if not CompletionistMapV100_IsNornirChestRemaining(pin) then
      if pin.iconGO ~= nil then
        pcall(function() Map.RecycleIcon(pin.iconGO) end)
      end
      if self.completionistMapV100NornirChestSelected == pin then
        self.completionistMapV100NornirChestSelected = nil
      end
      table.remove(self.completionistMapV100NornirChestPins, i)
      print("[CompletionistMap v0.10.1] NORNIR_CHEST_PIN_REMOVE" ..
        " registryKey=" .. tostring(pin.registryKey))
    end
  end
end

local function CompletionistMapV100_CreateNornirPins(self, currState)
  CompletionistMapV100_DestroyNornirPins(self)

  if self.currRealmName ~= "Midgard" then
    return
  end

  local registry, registrySource =
    CompletionistMapV100_GetNornirRegistry()

  if registrySource ~= "ui_call_event" then
    print("[CompletionistMap v0.10.1] NORNIR_MAP" ..
      " count=0 reason=live_state_required")
    return
  end

  local mapY = 0
  local playerYOK, playerMapPos = pcall(function()
    return self.playerIconGO:GetWorldPosition()
  end)
  if playerYOK and playerMapPos ~= nil then
    mapY = playerMapPos.y
  end

  local created = 0
  for registryKey, entry in pairs(registry) do
    if entry ~= nil and
        entry.opened ~= true and
        entry.challengeComplete ~= true and
        type(entry.keys) == "table" then
      for i = 1, 3 do
        local key = entry.keys[i]
        local shouldCreate = key ~= nil and
          key.x ~= nil and key.z ~= nil

        if shouldCreate and entry.keyType == "Breakable" then
          shouldCreate = key.broken ~= true
        end

        if shouldCreate then
          local backing =
            CompletionistMapV100_FindBackingDock(self, 10 + created)
          if backing == nil then
            print("[CompletionistMap v0.10.1] NORNIR_PIN_CREATE" ..
              " ok=false index=" .. tostring(i) ..
              " reason=safe_dock_not_found")
          else
            local mapX, mapZ =
              CompletionistMapV100_WorldToMidgardMap(key.x, key.z)
            local createOK, iconOrErr = pcall(function()
              return Map.CreateMarkerIcon(backing.Id, backing.regionId, "")
            end)

            if createOK and iconOrErr ~= nil then
            local pin = {
              registryKey = registryKey,
              keyIndex = i,
              keyType = entry.keyType,
              worldX = key.x,
              worldY = key.y,
              worldZ = key.z,
              mapX = mapX,
              mapY = mapY,
              mapZ = mapZ,
              iconGO = iconOrErr,
              frames = 0,
              broken = key.broken == true
            }
            local setOK, setErr = pcall(function()
              pin.iconGO:SetWorldPosition(
                engine.Vector.New(mapX, mapY, mapZ)
              )
              pin.iconGO:Show()
              UI.SetIsClickable(pin.iconGO)
              CompletionistMapV100_ApplyZoomAdaptiveIconScale(pin.iconGO)
              CompletionistMapV100_TryDirectIconBind(
                pin.iconGO,
                CompletionistMapV100_NornirIconFamily(entry.keyType)
              )
            end)
            if setOK then
              table.insert(self.completionistMapV100NornirPins, pin)
              created = created + 1
              print("[CompletionistMap v0.10.1] NORNIR_PIN_CREATE" ..
                " ok=true registryKey=" .. tostring(registryKey) ..
                " keyType=" .. tostring(entry.keyType) ..
                " index=" .. tostring(i) ..
                " backingId=" .. tostring(backing.Id) ..
                " mapX=" .. tostring(mapX) ..
                " mapZ=" .. tostring(mapZ))
            else
              pcall(function() Map.RecycleIcon(pin.iconGO) end)
              print("[CompletionistMap v0.10.1] NORNIR_PIN_CREATE" ..
                " ok=false index=" .. tostring(i) ..
                " error=" .. tostring(setErr))
            end
            end
          end
        end
      end
    end
  end

  print("[CompletionistMap v0.10.1] NORNIR_MAP" ..
    " count=" .. tostring(created) ..
    " source=" .. tostring(registrySource))
end

local function CompletionistMapV100_FindNornirCollision(
  self,
  collisionGameObjectTable
)
  if type(collisionGameObjectTable) ~= "table" or
      type(self.completionistMapV100NornirPins) ~= "table" then
    return nil
  end

  for _, collGO in ipairs(collisionGameObjectTable) do
    for _, pin in ipairs(self.completionistMapV100NornirPins) do
      if pin.iconGO == collGO and
          CompletionistMapV100_IsNornirKeyRemaining(pin) then
        return pin
      end
    end
  end

  return nil
end

local function CompletionistMapV100_RefreshNornirPins(self)
  if type(self.completionistMapV100NornirPins) ~= "table" then
    return
  end

  for i = #self.completionistMapV100NornirPins, 1, -1 do
    local pin = self.completionistMapV100NornirPins[i]

    pin.frames = (pin.frames or 0) + 1
    if pin.frames <= 60 and pin.iconGO ~= nil then
      pcall(function()
        pin.iconGO:SetWorldPosition(
          engine.Vector.New(
            pin.mapX,
            pin.mapY or 0,
            pin.mapZ
          )
        )
        pin.iconGO:Show()
        UI.SetIsClickable(pin.iconGO)
      end)
    end

    if not CompletionistMapV100_IsNornirKeyRemaining(pin) then
      if pin.iconGO ~= nil then
        pcall(function()
          Map.RecycleIcon(pin.iconGO)
        end)
      end

      if self.completionistMapV100NornirSelected == pin then
        self.completionistMapV100NornirSelected = nil
      end

      table.remove(self.completionistMapV100NornirPins, i)

      print("[CompletionistMap v0.10.1] NORNIR_PIN_REMOVE" ..
        " registryKey=" .. tostring(pin.registryKey) ..
        " index=" .. tostring(pin.keyIndex))
    elseif pin.frames == 30 and pin.iconGO ~= nil then
      local posOK, actual = pcall(function()
        return pin.iconGO:GetWorldPosition()
      end)

      print("[CompletionistMap v0.10.1] NORNIR_PIN_VERIFY" ..
        " index=" .. tostring(pin.keyIndex) ..
        " expectedX=" .. tostring(pin.mapX) ..
        " expectedZ=" .. tostring(pin.mapZ) ..
        " actual=" .. (
          posOK and actual ~= nil and
          ("x=" .. tostring(actual.x) ..
           ",y=" .. tostring(actual.y) ..
           ",z=" .. tostring(actual.z))
          or "<unavailable>"
        ))
    end
  end
end

local function CompletionistMapV100_Description()
  local target = _G.CompletionistMapV100Target
  if target ~= nil and target.type == "Raven" and target.active then
    return "Remaining collectible - tracked on custom compass"
  end
  return "Remaining collectible - Completionist Map"
end

local function CompletionistMapV100_ClearStockCompass(self, reason)
  if self.currShownMarkerID == nil then
    return
  end

  local oldId = self.currShownMarkerID
  local hideOK, hideErr = pcall(function()
    game.Compass.HideMarker(oldId)
  end)

  self.currShownMarkerID = nil

  print("[CompletionistMap v0.10.1] STOCK_COMPASS_CLEAR" ..
    " reason=" .. tostring(reason) ..
    " id=" .. tostring(oldId) ..
    " ok=" .. tostring(hideOK) ..
    " error=" .. tostring(hideErr))
end

local function CompletionistMapV100_ShowReticle(self, currState)
  self.currQuestID = nil
  self.currMarkerID = nil
  self.clickedMarkerInfo = nil
  self.clickedPlayer = false

  self:SetReticleInfo(
    currState,
    "Odin's Raven",
    CompletionistMapV100_Description()
  )

  self:UpdateFooterButtonPrompt(
    currState.menu,
    false,
    false
  )
end

local function CompletionistMapV100_DestroyMapPin(self)
  if self.completionistMapV100MapIconGO ~= nil then
    pcall(function()
      Map.RecycleIcon(self.completionistMapV100MapIconGO)
    end)
  end

  self.completionistMapV100MapIconGO = nil
  self.completionistMapV100BackingMarker = nil
  self.completionistMapV100Selected = false
  self.completionistMapV100Frame = 0
  self.completionistMapV100CurrState = nil
  self.completionistMapV100LastHitFrame = nil
  self.completionistMapV100LastSnapFrame = nil
  self.completionistMapV100CollisionState = false
end

local function CompletionistMapV100_CreateMapPin(self, currState)
  if self.currRealmName ~= "Midgard" then
    return
  end

  CompletionistMapV100_DestroyMapPin(self)

  if CompletionistMapV100_IsRavenCollected() then
    print("[CompletionistMap v0.10.1] MAP_PIN_SKIP reason=raven_collected")
    return
  end

  local backing = CompletionistMapV100_FindBackingDock(self, 1)
  if backing == nil then
    print("[CompletionistMap v0.10.1] MAP_PIN_CREATE" ..
      " ok=false reason=safe_dock_not_found")
    return
  end

  local createOK, iconOrErr = pcall(function()
    return Map.CreateMarkerIcon(
      backing.Id,
      backing.regionId,
      ""
    )
  end)

  if not createOK or iconOrErr == nil then
    print("[CompletionistMap v0.10.1] MAP_PIN_CREATE" ..
      " ok=false reason=duplicate_create_failed" ..
      " error=" .. tostring(iconOrErr))
    return
  end

  local iconGO = iconOrErr
  self.completionistMapV100MapIconGO = iconGO
  self.completionistMapV100BackingMarker = backing
  self.completionistMapV100CurrState = currState
  self.completionistMapV100Frame = 0
  self.completionistMapV100Selected = false
  self.completionistMapV100LastHitFrame = 0
  self.completionistMapV100LastSnapFrame = -9999
  self.completionistMapV100CollisionState = false

  local originalOK, original = pcall(function()
    return iconGO:GetWorldPosition()
  end)

  local mapY = originalOK and original ~= nil and original.y or 0

  local playerYOK, playerPos = pcall(function()
    return self.playerIconGO:GetWorldPosition()
  end)
  if playerYOK and playerPos ~= nil then
    mapY = playerPos.y
  end

  local setOK, setErr = pcall(function()
    iconGO:SetWorldPosition(
      engine.Vector.New(
        COMPLETIONIST_RAVEN_MAP_X,
        mapY,
        COMPLETIONIST_RAVEN_MAP_Z
      )
    )
    iconGO:Show()
    UI.SetIsClickable(iconGO)
    CompletionistMapV100_ApplyZoomAdaptiveIconScale(iconGO)
    CompletionistMapV100_TryDirectIconBind(iconGO, "raven")
  end)

  local afterOK, after = pcall(function()
    return iconGO:GetWorldPosition()
  end)

  print("[CompletionistMap v0.10.1] MAP_PIN_CREATE" ..
    " ok=" .. tostring(setOK) ..
    " error=" .. tostring(setErr) ..
    " backingId=" .. tostring(backing.Id) ..
    " region=" .. tostring(backing.regionId) ..
    " visual=DockPointRoot" ..
    " actual=" .. (afterOK and after ~= nil and
      ("x=" .. tostring(after.x) ..
       ",y=" .. tostring(after.y) ..
       ",z=" .. tostring(after.z))
      or "<error>"))

end

local function CompletionistMapV100_GetZoomAdaptiveIconScale()
  -- Keep temporary DockPoint-backed custom markers at native marker scale.
  -- Magnetic attraction is handled separately at the map-camera level.
  return 1.0, 1.0
end

CompletionistMapV100_ApplyZoomAdaptiveIconScale = function(go)
  if go == nil then return end
  local iconScale = CompletionistMapV100_GetZoomAdaptiveIconScale()
  pcall(function()
    UI.SetGOScale(
      go,
      engine.Vector.New(iconScale, iconScale, iconScale)
    )
  end)
end

local function CompletionistMapV100_UpdateSnapTuning(self)
  local iconScale, cursorScale =
    CompletionistMapV100_GetZoomAdaptiveIconScale()

  local bucket = math.floor(iconScale * 10 + 0.5)
  if self.completionistMapV100SnapScaleBucket ~= bucket then
    self.completionistMapV100SnapScaleBucket = bucket
    print("[CompletionistMap v0.10.1] SNAP_TUNING" ..
      " mode=native_scale_no_camera_snap" ..
      " customIconScale=" .. tostring(iconScale))
  end

  CompletionistMapV100_ApplyZoomAdaptiveIconScale(
    self.completionistMapV100MapIconGO
  )

  for _, pin in ipairs(self.completionistMapV100NornirChestPins or {}) do
    CompletionistMapV100_ApplyZoomAdaptiveIconScale(pin.iconGO)
  end

  for _, pin in ipairs(self.completionistMapV100NornirPins or {}) do
    CompletionistMapV100_ApplyZoomAdaptiveIconScale(pin.iconGO)
  end
end

local function CompletionistMapV100_SetCustomCursorSelected(selected)
  local goCursorRefnode = util.GetUiObjByName("MapCursor")
  if goCursorRefnode ~= nil then
    animationUtil.SetCursorSelected(goCursorRefnode, selected == true)
  end

  if selected then
    Audio.PlaySound("SND_UX_Pause_Menu_Screen_Map_Region_Hover_Tick")
  end
end

local function CompletionistMapV100_ReinforceRavenPin(self)
  local go = self.completionistMapV100MapIconGO
  if go == nil or CompletionistMapV100_IsRavenCollected() then
    return
  end

  local mapY = 0
  local playerOK, playerMapPos = pcall(function()
    return self.playerIconGO:GetWorldPosition()
  end)
  if playerOK and playerMapPos ~= nil then
    mapY = playerMapPos.y
  end

  pcall(function()
    go:SetWorldPosition(
      engine.Vector.New(
        COMPLETIONIST_RAVEN_MAP_X,
        mapY,
        COMPLETIONIST_RAVEN_MAP_Z
      )
    )
    go:Show()
    UI.SetIsClickable(go)
  end)

  self.completionistMapV100RavenPinFrames =
    (self.completionistMapV100RavenPinFrames or 0) + 1

  local activeTarget = _G.CompletionistMapV100Target
  if activeTarget ~= nil and
      activeTarget.active == true and
      activeTarget.type ~= "Raven" and
      self.completionistMapV100RavenIndependentTargetType ~= activeTarget.type then
    self.completionistMapV100RavenIndependentTargetType = activeTarget.type
    print("[CompletionistMap v0.10.1] RAVEN_PIN_INDEPENDENT" ..
      " activeTargetType=" .. tostring(activeTarget.type) ..
      " mapX=" .. tostring(COMPLETIONIST_RAVEN_MAP_X) ..
      " mapZ=" .. tostring(COMPLETIONIST_RAVEN_MAP_Z))
  end

  if self.completionistMapV100RavenPinFrames == 30 then
    local ok, actual = pcall(function() return go:GetWorldPosition() end)
    print("[CompletionistMap v0.10.1] RAVEN_PIN_VERIFY" ..
      " expectedX=" .. tostring(COMPLETIONIST_RAVEN_MAP_X) ..
      " expectedZ=" .. tostring(COMPLETIONIST_RAVEN_MAP_Z) ..
      " activeTargetType=" .. tostring(
        _G.CompletionistMapV100Target and
        _G.CompletionistMapV100Target.type or "<nil>"
      ) ..
      " actual=" .. (
        ok and actual ~= nil and
        ("x=" .. tostring(actual.x) ..
         ",y=" .. tostring(actual.y) ..
         ",z=" .. tostring(actual.z))
        or "<unavailable>"
      ))
  end
end

local COMPLETIONIST_FILTER = -101
local RAVEN_FILTER = -102
local NORNIR_CHEST_FILTER = -103
local NORNIR_PUZZLE_FILTER = -104

local completionistFilterLabels = {
  [COMPLETIONIST_FILTER] = "COMPLETIONIST",
  [RAVEN_FILTER] = "RAVENS",
  [NORNIR_CHEST_FILTER] = "NORNIR CHESTS",
  [NORNIR_PUZZLE_FILTER] = "NORNIR PUZZLE"
}

local function CompletionistMapV100_GetFilterKind(self)
  if self.filterButtonMapping == nil then return 1 end
  return self.filterButtonMapping[self.filterIndex] or 1
end

local function CompletionistMapV100_SetGOVisible(go, visible)
  if go == nil then return end
  pcall(function()
    if visible then go:Show() else go:Hide() end
  end)
end

local function CompletionistMapV100_RefreshCustomPins(self)
  CompletionistMapV100_UpdateSnapTuning(self)

  local filter = CompletionistMapV100_GetFilterKind(self)
  local showRaven = filter == 1 or
    filter == COMPLETIONIST_FILTER or filter == RAVEN_FILTER
  local showChest = filter == 1 or
    filter == COMPLETIONIST_FILTER or filter == NORNIR_CHEST_FILTER
  local showPuzzle = filter == NORNIR_PUZZLE_FILTER
  local registry = CompletionistMapV100_GetNornirRegistry()

  CompletionistMapV100_ReinforceRavenPin(self)

  CompletionistMapV100_SetGOVisible(
    self.completionistMapV100MapIconGO,
    showRaven and not CompletionistMapV100_IsRavenCollected()
  )

  for _, pin in ipairs(self.completionistMapV100NornirChestPins or {}) do
    CompletionistMapV100_SetGOVisible(pin.iconGO, showChest)
  end

  if not self.completionistMapV100AliasCheckLogged then
    self.completionistMapV100AliasCheckLogged = true
    local raven = self.completionistMapV100MapIconGO

    for _, chestPin in ipairs(self.completionistMapV100NornirChestPins or {}) do
      print("[CompletionistMap v0.10.1] ALIAS_CHECK" ..
        " pair=raven_chest" ..
        " sameGO=" .. tostring(
          raven ~= nil and raven == chestPin.iconGO
        ))
    end

    local pins = self.completionistMapV100NornirPins or {}
    for i = 1, #pins do
      if raven ~= nil then
        print("[CompletionistMap v0.10.1] ALIAS_CHECK" ..
          " pair=raven_puzzle" ..
          " index=" .. tostring(pins[i].keyIndex) ..
          " sameGO=" .. tostring(raven == pins[i].iconGO))
      end

      for j = i + 1, #pins do
        print("[CompletionistMap v0.10.1] ALIAS_CHECK" ..
          " pair=puzzle_puzzle" ..
          " a=" .. tostring(pins[i].keyIndex) ..
          " b=" .. tostring(pins[j].keyIndex) ..
          " sameGO=" .. tostring(pins[i].iconGO == pins[j].iconGO))
      end
    end
  end

  for _, pin in ipairs(self.completionistMapV100NornirPins or {}) do
    local entry = registry and registry[pin.registryKey] or nil
    local revealInShowAll =
      filter == 1 and
      entry ~= nil and
      entry.puzzleRevealed == true and
      entry.challengeComplete ~= true and
      entry.opened ~= true

    CompletionistMapV100_SetGOVisible(
      pin.iconGO,
      showPuzzle or revealInShowAll
    )
  end

  if not showRaven then self.completionistMapV100Selected = false end
  if not showChest then self.completionistMapV100NornirChestSelected = nil end

  if self.completionistMapV100NornirSelected ~= nil then
    local selectedPin = self.completionistMapV100NornirSelected
    local selectedEntry =
      registry and registry[selectedPin.registryKey] or nil

    local selectedPuzzleVisible =
      showPuzzle or
      (
        filter == 1 and
        selectedEntry ~= nil and
        selectedEntry.puzzleRevealed == true and
        selectedEntry.challengeComplete ~= true and
        selectedEntry.opened ~= true
      )

    if not selectedPuzzleVisible then
      self.completionistMapV100NornirSelected = nil
    end
  end

  if self.completionistMapV100LastVisibilityFilter ~= filter then
    self.completionistMapV100LastVisibilityFilter = filter
    print("[CompletionistMap v0.10.1] FILTER_CUSTOM_VISIBILITY" ..
      " filter=" .. tostring(filter) ..
      " raven=" .. tostring(showRaven) ..
      " chest=" .. tostring(showChest) ..
      " puzzleFilter=" .. tostring(showPuzzle) ..
      " puzzleAfterAttempt=" .. tostring(filter == 1))
  end
end

local function CompletionistMapV100_CollisionContainsPin(
  self,
  collisionGameObjectTable
)
  if type(collisionGameObjectTable) ~= "table" or
      self.completionistMapV100MapIconGO == nil then
    return false
  end

  for _, collGO in ipairs(collisionGameObjectTable) do
    if collGO == self.completionistMapV100MapIconGO then
      return true
    end
  end

  return false
end
local alwaysOnMarkerFlags = {
  "PrimaryQuest",
  "SecondaryQuest"
}
local fastTravelMarkerFlags = {
  consts.COMPASS_MARKER_TYPE_FAST_TRAVEL,
  consts.COMPASS_MARKER_TYPE_FAST_TRAVEL_NO_TRACK
}
local markerFilters = {
  {
    name = 44102,
    markerIncludeFlags = {
      consts.COMPASS_MARKER_TYPE_VENDOR,
      consts.COMPASS_MARKER_TYPE_VENDOR_NO_TRACK,
      consts.COMPASS_MARKER_TYPE_FAST_TRAVEL,
      consts.COMPASS_MARKER_TYPE_FAST_TRAVEL_NO_TRACK,
      consts.COMPASS_MARKER_TYPE_DOCK_POINT,
      consts.COMPASS_MARKER_TYPE_AREA_ENTRANCE,
      consts.COMPASS_MARKER_TYPE_CHISEL_ENTRANCE,
      consts.COMPASS_MARKER_TYPE_CHISEL_ENTRANCE_NO_TRACK,
      consts.COMPASS_MARKER_TYPE_FIGHT_LOCATION,
      consts.COMPASS_MARKER_TYPE_FIGHT_LOCATION_NO_TRACK,
      consts.COMPASS_MARKER_TYPE_INFO_ONLY,
      consts.COMPASS_MARKER_TYPE_VALKYRIE
    }
  },
  {
    name = 44103,
    markerIncludeFlags = {
      consts.COMPASS_MARKER_TYPE_VENDOR,
      consts.COMPASS_MARKER_TYPE_VENDOR_NO_TRACK
    }
  },
  {name = 44104, markerIncludeFlags = fastTravelMarkerFlags},
  {
    name = 44105,
    markerIncludeFlags = {
      consts.COMPASS_MARKER_TYPE_DOCK_POINT
    }
  },
  {
    name = 44101,
    markerIncludeFlags = {
      consts.COMPASS_MARKER_TYPE_AREA_ENTRANCE,
      consts.COMPASS_MARKER_TYPE_CHISEL_ENTRANCE,
      consts.COMPASS_MARKER_TYPE_CHISEL_ENTRANCE_NO_TRACK
    }
  },
  {
    name = 44106,
    markerIncludeFlags = {
      consts.COMPASS_MARKER_TYPE_FIGHT_LOCATION,
      consts.COMPASS_MARKER_TYPE_FIGHT_LOCATION_NO_TRACK
    }
  },
  {
    name = 37166,
    markerIncludeFlags = {
      consts.COMPASS_MARKER_TYPE_VALKYRIE
    }
  }
}
local map_camera
map_camera = tweaks.tMapCamera.New({
  Name = "MapMenuCam",
  CollisionRoot = "Midgard_collision",
  OnSkillTree = false,
  HorizontalControlSpeed = 0.1,
  VerticalControlSpeed = 0.1,
  ZoomControlSpeed = 3.2,
  ZoomSpeedScale = 3,
  HorizontalPosition = 0,
  VerticalPosition = 0,
  ZoomPosition = 5,
  Pitch = 35,
  Yaw = 0,
  Roll = 0,
  MaxLeft = -4.9,
  MaxRight = 4,
  MaxUp = -3.7,
  MaxDown = 4.5,
  MaxIn = 2.5,
  MaxOut = 10,
  CursorSnap_Enabled = 0,
  CursorSnap_Strength = 0.0,
  CursorGOName = "MapCursor",
  ScaleMapCursorBasedOnZoom = true,
  CursorScale_Min = 0.05,
  CursorScale_Max = 0.85,
  Tofu = "never"
})
local MapMenu = classlib.Class("MapMenu", fsm.UIState)
local MapOff = MapMenu:StateClass("MapOff", fsm.UIState)
local MapOn = MapMenu:StateClass("MapOn", fsm.UIState)
local Midgard = MapMenu:StateClass("Midgard", fsm.UIState)
local Alfheim = MapMenu:StateClass("Alfheim", fsm.UIState)
local Helheim = MapMenu:StateClass("Helheim", fsm.UIState)
local Jotunheim = MapMenu:StateClass("Jotunheim", fsm.UIState)
local Niflheim = MapMenu:StateClass("Niflheim", fsm.UIState)
local Muspelheim = MapMenu:StateClass("Muspelheim", fsm.UIState)
local Svartalheim = MapMenu:StateClass("Svartalheim", fsm.UIState)
local Vanaheim = MapMenu:StateClass("Vanaheim", fsm.UIState)
local Asgard = MapMenu:StateClass("Asgard", fsm.UIState)
local mapMenu = MapMenu.New("mapMenu", {
  MapOff,
  MapOn,
  {
    Midgard,
    Alfheim,
    Helheim,
    Jotunheim,
    Niflheim,
    Muspelheim,
    Svartalheim,
    Vanaheim,
    Asgard
  }
})
function MapMenu:Enter()
  self:WantPadEvents(true)
  self:turnoff()
end
function MapMenu:Exit()
end
function MapMenu:turnoff()
  self:Goto("MapOff")
end
MapMenu.EVT_GAME_OVER = MapMenu.turnoff
MapMenu.EVT_Restart = MapMenu.turnoff
function MapOff:Setup()
  self.mapOn = self:GetState("MapOn")
end
function MapOff:Enter()
end
function MapOff:Exit()
end
function MapOff:EVT_TURN_ON_MAP_MENU(instructionEntries, instructionArgs)
  self.mapOn.menu:set_instructionEntries(instructionEntries)
  self.mapOn.menu:set_instructionArgs(instructionArgs)
  if #instructionEntries == 0 then
    self.mapOn.menu:AddInstructionEntry({
      StateName = "MapOn",
      ListName = consts.inworldMenu_SubmenuList,
      Item = mapUtil.GetPlayerRealm()
    })
  end
  self:Goto("MapOn")
end
function MapOn:Setup()
  self.mapOff = self:GetState("MapOff")
  self.currRealmName = nil
  self.currQuestID = nil
  self.currMarkerID = nil
  self.currShownMarkerID = nil
  self.clickedMarkerInfo = nil
  self.clickedPlayer = false
  self.currMarkerPlayerIcon = false
  self.fastTravelPointSelected = false
  self.fastTravelCancelled = false
  self.realmMarkerInfo = {}
  self.filterIndex = 1
  self.filterButtonMapping = {1}
  self.alwaysOnMarkers = {}
  self.markers = {}
  util.ShowRecursive("mapScene")
  self:HideAllMaps()
  util.Hide("AllMaps")
  self.goFilter = util.GetUiObjByName("SortList")
  self.goFilterList = self.goFilter:FindSingleGOByName("list")
  self.goFilterLabelContainer = self.goFilter:FindSingleGOByName("LabelContainer")
  self.goFilterLabel = self.goFilterLabelContainer:FindSingleGOByName("Label")
  self.thFilterLabel = UI.TextObject(self.goFilterLabel)
  self.goFilterIndicatorPrev = self.goFilter:FindSingleGOByName("IndicatorPrev")
  UI.SetTextIsClickable(util.GetTextHandle(self.goFilterIndicatorPrev))
  self.goFilterIndicatorNext = self.goFilter:FindSingleGOByName("IndicatorNext")
  UI.SetTextIsClickable(util.GetTextHandle(self.goFilterIndicatorNext))
  self.goFilterButtons = {
    1,
    2,
    3,
    4,
    5,
    6,
    7
  }
  self.goFilterButtonPositions = {
    engine.Vector.New(-13.939, -48.295, 1.351),
    engine.Vector.New(-13.539, -48.295, 1.351),
    engine.Vector.New(-13.139, -48.295, 1.351),
    engine.Vector.New(-12.739, -48.295, 1.351),
    engine.Vector.New(-12.339, -48.295, 1.351),
    engine.Vector.New(-11.939, -48.295, 1.351),
    engine.Vector.New(-11.539, -48.295, 1.351)
  }
  for i = 1, 7 do
    self.goFilterButtons[i] = self.goFilterList:FindSingleGOByName("Button" .. tostring(i)):FindSingleGOByName("button")
    UI.SetIsClickable(self.goFilterButtons[i])
  end
  self.menu = menu.Menu.New(self, {})
  self.menu:SetupSubmenuList(consts.inworldMenu_SubmenuList, {
    "EVT_Left_Release"
  }, {
    "EVT_Right_Release"
  })
  local goRefnode = util.GetUiObjByName("MapCursor")
  local goRefnodeChild = goRefnode:FindSingleGOByName("Root")
  goRefnode:Show()
  goRefnodeChild:Show()
  local goRegionSummaryCard = util.GetUiObjByName("mapSummary_Region")
  self.mapSummaryCard_Region = mapSummaryCard.MapSummaryCard.New(goRegionSummaryCard)
  self.mapSummaryCard_Region:Init("Region")
  local goRealmSummaryCard = util.GetUiObjByName("mapSummary_Realm")
  self.mapSummaryCard_Realm = mapSummaryCard.MapSummaryCard.New(goRealmSummaryCard)
  self.mapSummaryCard_Realm:Init("Realm")
  local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
  self._goCursorTextGroup_Top = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
  self._goCursorTextGroup_Bottom = goMapCursorText:FindSingleGOByName("CursorInfo_Bottom")
  self.playerIconGO = util.GetUiObjByName("MapIconPlayer")
  UI.SetIsClickable(self.playerIconGO)
  assert(self.playerIconGO ~= nil, "The player indicator gameObject was not found.")
  tutorialUtil.RegisterDesaturationObject("MapSortList", self.goFilter)
  tutorialUtil.RegisterDesaturationObject("MapCursor", goRefnode)
  tutorialUtil.RegisterDesaturationObject("MapCursorInfo", goMapCursorText)
end
function MapOn:UpdateAccessibilityScaling()
  self.mapSummaryCard_Realm:UpdateAccessibilityScaling()
  self.mapSummaryCard_Region:UpdateAccessibilityScaling()
end
function MapOn:Enter()
  local instructionArgs = self.menu:get_instructionArgs()
  self.markerIdHashToSelectOnOpen = instructionArgs.markerIdHashToSelectOnOpen
  self.isOpenedForFastTravel = instructionArgs.openForFastTravel
  self.menu:Activate()
  self:UpdateAccessibilityScaling()
  self.fastTravelPointSelected = false
  self.fastTravelCancelled = false
  self.clickedMarkerInfo = nil
  self.clickedPlayer = false
  util.Show("AllMaps", "Map", "MapCursor", "mapDepthBlur")
  self:HideSummary()
  Audio.PlaySound("SND_UX_Pause_Menu_Map_Cursor_LP")
  local submenuList = self.menu:GetList(consts.inworldMenu_SubmenuList)
  local newItemArray = self:GetSubStateNames()
  local showList = true
  local useOnGainFocus = not self.menu:HasInstructionEntryForMenuState()
  local itemDetermineFocusabilityFunc, getDisplayNameFunc
  self.menu:RefreshSubmenuList(submenuList, newItemArray, showList, useOnGainFocus, itemDetermineFocusabilityFunc, getDisplayNameFunc)
  self.filterIndex = 1
  self.jumpToMarkerIndex = 0
  self:ClearMarkers(true)
  self:GetRealmMarkerInfo()
  if self.isOpenedForFastTravel then
    local hideList = true
    local clearButtons = false
    submenuList:Deactivate(hideList, clearButtons)
    self.markerIncludeFlags = fastTravelMarkerFlags
    self:GetAlwaysOnMarkers()
    self:GetMarkers()
  else
    self.markerIncludeFlags = markerFilters[self.filterIndex].markerIncludeFlags
    self:GetAlwaysOnMarkers()
    self:GetMarkers()
    util.Show("XPandHS")
    self.goFilter:Show()
    self.goFilterList:Show()
    self.goFilterLabelContainer:Show()
    self.goFilterLabel:Show()
    self.goFilterIndicatorPrev:Show()
    self.goFilterIndicatorNext:Show()
    local instant = true
    self.mapSummaryCard_Region:ShowCard()
    self.mapSummaryCard_Region:SetOnScreen(false, instant)
    self.mapSummaryCard_Realm:ShowCard()
    self.mapSummaryCard_Realm:SetOnScreen(true, instant)
    self:CheckForTutorial()
  end
  self:UpdateIcons()
  local compassMarkers = game.Compass.FindMarkersByIconClass(enabledShowOnCompassMarkerFlags)
  if 0 < #compassMarkers then
    self.currShownMarkerID = compassMarkers[1]
    if 1 < #compassMarkers then
      for i = 2, #compassMarkers do
        game.Compass.HideMarker(compassMarkers[i])
      end
    end
  else
    self.currShownMarkerID = nil
  end
  for _, realmName in ipairs(mapConsts.REALM_NAMES) do
    self:EnableAllFog(realmName)
  end
  self.menu:ExecuteInstructions()
end
function MapOn:Exit()
  CompletionistMapV100_DestroyNornirChestPins(self)
  CompletionistMapV100_DestroyNornirPins(self)
  CompletionistMapV100_DestroyMapPin(self)
  self.menu:Deactivate(true)
  Audio.StopSound("SND_UX_Pause_Menu_Map_Cursor_LP")
  util.Hide("AllMaps", "Map", "MapCursor", "mapDepthBlur")
  self:HideSummary()
  self.mapSummaryCard_Region:HideCard()
  self.mapSummaryCard_Realm:HideCard()
  self.goFilter:Hide()
  self.goFilterList:Hide()
  self.goFilterLabelContainer:Hide()
  self.goFilterLabel:Hide()
  self.goFilterIndicatorPrev:Hide()
  self.goFilterIndicatorNext:Hide()
  util.Hide("overviewOutline_Selected", "overviewOutline_Unselected")
  self:ClearMarkers(true)
  self:ClearReticleInfo()
  self.markerIdHashToSelectOnOpen = nil
  self.openedAtMarker = nil
  self.currRealmName = nil
  self:ClearIcons()
  self.realmMarkerInfo = {}
  self.filterButtonMapping = {1}
  self.currQuestID = nil
  self.currMarkerID = nil
  self.currMarkerPlayerIcon = false
  self.fastTravelPointSelected = false
  self.fastTravelCancelled = false
  self.isOpenForFastTravel = false
  for _, realmName in ipairs(mapConsts.REALM_NAMES) do
    self:EnableAllFog(realmName)
  end
  if self.playingMoveToActiveMarker then
    Audio.StopSound("SND_UX_Pause_Menu_Map_MoveTo_Active_Marker_LP")
    self.playingMoveToActiveMarker = false
  end
end
function MapOn:EVT_TouchPad_Release()
  if tutorialUtil.CurrentlyShowingStep() then
    return
  end
  if game.IsMapAvailable then
    if not game.IsMapAvailable() then
      return
    end
  elseif game.build.GOLD_VERSION == 0 then
    return
  end
  if not self.fastTravelPointSelected then
    self.fastTravelCancelled = true
    util.CallScriptOnCurrentInteractObject("TriggerFastTravelCancel")
  end
  self:SendEventToUIFsm("globalMenu", "EVT_TURN_OFF_GLOBAL_MENU")
end
function MapOn:GetSubStateNames()
  return mapUtil.GetDiscoveredRealmNames()
end
function MapOn:SubmenuList_Button_Update(button)
  local alphaValue = 1
  local fadeTime = 0
  button:AlphaFade(alphaValue, fadeTime)
  button:SetIcon(button:get_item())
  button:UpdateNewIcon(function(button)
    return buttonUtil.ShowNotification(button, "Map")
  end)
end
function MapOn:SubmenuList_Button_OnLoseFocus(button)
  local realmName = button:get_item()
  if button._MapMenu_ManuallySelected and realmName ~= nil then
    UI.ClearNotification("Map", realmName)
    button:UpdateNewIcon(function(button)
      return buttonUtil.ShowNotification(button, "Map")
    end)
    button._MapMenu_ManuallySelected = nil
  end
  self:SendEventToUIFsm("inWorldMenu", "EVT_REFRESH_NOTIFICATIONS")
end
function MapOn:SubmenuList_Button_OnGainFocus(button)
  local currentItem = button:get_item()
  self.menu:SetSubmenuListLabelText(consts.inworldMenu_SubmenuList, util.GetLAMSMsg(lamsConsts[currentItem]))
  local subState = self:GetState(currentItem)
  subState.menu:set_instructionEntries(self.menu:get_instructionEntries())
  button._MapMenu_ManuallySelected = true
  self:Goto(currentItem)
end
function MapOn:GetShowOnCompassPrompt(currMenu)
  if self.completionistMapV100NornirChestSelected ~= nil then
    local pin = self.completionistMapV100NornirChestSelected
    if not CompletionistMapV100_IsNornirChestRemaining(pin) then
      return false, nil
    end
    if self.isOpenedForFastTravel or
        not game.Compass.HaveCompass() or
        self.currRealmName ~= mapUtil.GetPlayerRealm() or
        tutorialUtil.CurrentlyShowingStep() then
      return false, nil
    end
    local target = _G.CompletionistMapV100Target
    local sameTarget = target ~= nil and
      target.type == "NornirChest" and
      target.registryKey == pin.registryKey
    local lamsId = sameTarget and target.active and
      lamsConsts.RemoveFromCompass or lamsConsts.AddToCompass
    return true, "[AdvanceButton] " .. util.GetLAMSMsg(lamsId)
  end

  if self.completionistMapV100NornirSelected ~= nil then
    local pin = self.completionistMapV100NornirSelected

    if not CompletionistMapV100_IsNornirKeyRemaining(pin) then
      return false, nil
    end

    if self.isOpenedForFastTravel or
        not game.Compass.HaveCompass() or
        self.currRealmName ~= mapUtil.GetPlayerRealm() or
        tutorialUtil.CurrentlyShowingStep() then
      return false, nil
    end

    local target = _G.CompletionistMapV100Target
    local sameTarget =
      target ~= nil and
      target.type == "NornirPuzzle" and
      target.registryKey == pin.registryKey and
      target.keyIndex == pin.keyIndex

    local lamsId =
      sameTarget and target.active and
      lamsConsts.RemoveFromCompass or
      lamsConsts.AddToCompass

    if self.completionistMapV100NornirPromptLogged ~= pin.keyIndex then
      self.completionistMapV100NornirPromptLogged = pin.keyIndex
      print("[CompletionistMap v0.10.1] NORNIR_PROMPT" ..
        " visible=true" ..
        " index=" .. tostring(pin.keyIndex) ..
        " active=" .. tostring(sameTarget and target.active == true))
    end

    return true, "[AdvanceButton] " .. util.GetLAMSMsg(lamsId)
  end

  if self.completionistMapV100Selected then
    if CompletionistMapV100_IsRavenCollected() then
      return false, nil
    end

    if self.isOpenedForFastTravel or
        not game.Compass.HaveCompass() or
        self.currRealmName ~= mapUtil.GetPlayerRealm() or
        tutorialUtil.CurrentlyShowingStep() then
      return false, nil
    end

    local target = _G.CompletionistMapV100Target
    local sameTarget = target ~= nil and target.type == "Raven"
    local lamsId =
      sameTarget and target.active and
      lamsConsts.RemoveFromCompass or
      lamsConsts.AddToCompass

    return true, "[AdvanceButton] " .. util.GetLAMSMsg(lamsId)
  end  if not (not self.isOpenedForFastTravel and game.Compass.HaveCompass()) or self.currRealmName ~= mapUtil.GetPlayerRealm() or self.currMarkerID == nil or tutorialUtil.CurrentlyShowingStep() or not Map.MarkerHasAnyFlag(self.currMarkerID, enabledShowOnCompassMarkerFlags) then
    return false, nil
  end
  local showOnCompassText = lamsConsts.AddToCompass
  if self.currMarkerID == nil and self.currShownMarkerID ~= nil or self.currMarkerID == self.currShownMarkerID then
    showOnCompassText = lamsConsts.RemoveFromCompass
  elseif self.currShownMarkerID ~= nil and self.currMarkerID ~= self.currShownMarkerID then
    showOnCompassText = lamsConsts.ReplaceInCompass
  end
  return true, "[AdvanceButton] " .. util.GetLAMSMsg(showOnCompassText)
end
function MapOn:UpdateFooterButtonPrompt(currMenu, showConfirmFastTravel, showGoToJournal)
  local showShowOnCompass, showOnCompassText = self:GetShowOnCompassPrompt(currMenu)
  currMenu:UpdateFooterButton("ShowOnCompass", showShowOnCompass, showOnCompassText)
  currMenu:UpdateFooterButton("ConfirmFastTravel", showConfirmFastTravel and self.isOpenedForFastTravel)
  local showPlayerToggle =
    not showGoToJournal and
    not self.isOpenedForFastTravel and
    mapUtil.GetPlayerRealm() == self.currRealmName

  if showPlayerToggle then
    local playerToggleText =
      _G.CompletionistMapV100PlayerMarkerVisible == false and
      "[SquareButton] Show Kratos" or
      "[SquareButton] Hide Kratos"

    currMenu:UpdateFooterButton(
      "GoToJournal",
      true,
      playerToggleText
    )
  else
    currMenu:UpdateFooterButton(
      "GoToJournal",
      showGoToJournal and not self.isOpenedForFastTravel
    )
  end
  currMenu:UpdateFooterButton("ActiveMarkers", not self.isOpenedForFastTravel)
  currMenu:UpdateFooterButton("Move", true)
  currMenu:UpdateFooterButton("Zoom", true)
  currMenu:UpdateFooterButton("Settings", not self.isOpenedForFastTravel)
  currMenu:UpdateFooterButton("Exit", true)
  currMenu:UpdateFooterButton("Weapon", true)
  currMenu:UpdateFooterButton("Skill", true)
  currMenu:UpdateFooterButton("Quest", true)
  currMenu:UpdateFooterButton("Close", true)
  currMenu:UpdateFooterButtonText()
end
function MapOn:HideAllMaps()
  for _, realmName in ipairs(mapConsts.REALM_NAMES) do
    util.Hide(mapUtil.GetRealmCollisionGOName(realmName))
    util.Hide(realmName)
  end
end
function MapOn:ShowMap(realmName)
  self:HideAllMaps()
  util.Show(mapUtil.GetRealmCollisionGOName(realmName))
  util.Show(realmName)
end
function MapOn:UpdateMapState()
  local GetGlobalVar = game.Level.GetVariable
  local completedCineNumber = GetGlobalVar("CompletedCineNumber")
  local hammerFallCineNumber = 355
  local stonemasonFallCineNumber = 570
  local peaksPassSummitRevealedCineNumber = 310
  local afterLightChangeCineNumber = 242
  local jotunheimRevealed = GetGlobalVar("_GBL_JotTowerRevealed")
  local goMap = util.GetUiObjByName("mapScene")
  local goAlfheim = goMap:FindSingleGOByName("Alfheim")
  local jid_red = goAlfheim:GetJointIndex("emit_map_alfheim_beam_red")
  local jid_white = goAlfheim:GetJointIndex("emit_map_alfheim_beam")
  if completedCineNumber >= afterLightChangeCineNumber then
    goAlfheim:ShowJoint(jid_white)
    goAlfheim:HideJoint(jid_red)
  else
    goAlfheim:ShowJoint(jid_red)
    goAlfheim:HideJoint(jid_white)
  end
  local goJotunheimTower = util.GetUiObjByName("RealmTower4")
  local goJotunheimTowerCollision = util.GetUiObjByName("towercollision_jotunheim")
  local goJotunheimTowerInAlfheim = goAlfheim:FindSingleGOByName("RealmTower9")
  local goNiflheim = goMap:FindSingleGOByName("Niflheim")
  local goJotunheimTowerInNiflheim = goNiflheim:FindSingleGOByName("RealmTower9")
  if jotunheimRevealed then
    goJotunheimTower:Show()
    goJotunheimTowerCollision:Show()
    goJotunheimTowerInAlfheim:Show()
    goJotunheimTowerInNiflheim:Show()
  else
    goJotunheimTower:Hide()
    goJotunheimTowerCollision:Hide()
    goJotunheimTowerInAlfheim:Hide()
    goJotunheimTowerInNiflheim:Hide()
  end
  local goAlfWaterGroup = util.GetUiObjByName("Alfheim_Water")
  local jid_AlfWater1 = goAlfWaterGroup:GetJointIndex("AlfWater1")
  if GetGlobalVar("ALF_TrenchOpen") then
    goAlfWaterGroup:HideJoint(jid_AlfWater1)
  else
    goAlfWaterGroup:ShowJoint(jid_AlfWater1)
  end
  local goHammerStatesGroup = util.GetUiObjByName("Hammer_map_states")
  local goHammer = goHammerStatesGroup:FindSingleGOByName("hammer_stonemason_map")
  goHammerStatesGroup:Show()
  goHammer:Show()
  if completedCineNumber >= hammerFallCineNumber then
    animationUtil.SetTransform(goHammer, goHammerStatesGroup, "hammer_down")
  else
    animationUtil.SetTransform(goHammer, goHammerStatesGroup, "hammer_up")
  end
  local goStonemason = util.GetUiObjByName("map_stonemason_giant")
  goStonemason:Show()
  if completedCineNumber <= stonemasonFallCineNumber then
    local targetTimelinePos = 0.1
    local animRate = 0
    UI.Anim(goStonemason, consts.AS_Forward, "", animRate, targetTimelinePos)
  else
    local targetTimelinePos = 0.2
    local animRate = 0
    UI.Anim(goStonemason, consts.AS_Forward, "", animRate, targetTimelinePos)
  end
  local goSummit_gateTree = util.GetUiObjByName("Summit_gateTree")
  if completedCineNumber >= peaksPassSummitRevealedCineNumber then
    goSummit_gateTree:Show()
  else
    goSummit_gateTree:Hide()
  end
  local goThorStatue1 = util.GetUiObjByName("thorStatue1")
  if 340 <= completedCineNumber then
    goThorStatue1:Hide()
  else
    goThorStatue1:Show()
  end
  local goMidgard = goMap:FindSingleGOByName("Midgard")
  local jid_smallThorStatue = goMidgard:GetJointIndex("smallThorStatue")
  if GetGlobalVar("ThorStatueBroken") or game.QuestManager.GetQuestState("Quest_UnfinishedBusiness03_Objective_01") == questConsts.QUEST_STATE_COMPLETE then
    goMidgard:HideJoint(jid_smallThorStatue)
  else
    goMidgard:ShowJoint(jid_smallThorStatue)
  end
  self:UpdateSnakeState(completedCineNumber)
  self:UpdateHelheimBoat()
  self:UpdateWaterLevel()
  self:AnimateFog()
end
function MapOn:CheckForTutorial()
  local resourceValue = game.Wallets.GetResourceValue("HERO", "MapTutorial")
  local hasResource = -1 < resourceValue
  if not hasResource and game.Level.GetVariable("CompletedCineNumber") >= 180 then
    self:SendEventToUIFsm("inWorldMenu", "EVT_ATTEMPT_TUTORIAL", "Map", "MapTutorial", "MapFilterTutorial")
  end
end
function MapOn:UpdateSnakeState(completedCineNumber)
  local currentSnakeState = mapConsts.snakeState_1
  for _, table in ipairs(mapConsts.snakeIdleTable) do
    if completedCineNumber >= table.MinCine and completedCineNumber < table.MaxCine then
      currentSnakeState = table.State
      break
    end
  end
  local goSnake = util.GetUiObjByName("worldSnake")
  local targetTimelinePos = currentSnakeState * 0.1
  local animRate = 0
  UI.Anim(goSnake, consts.AS_Forward, "", animRate, targetTimelinePos)
end
function MapOn:SetupCameraForMap(realmName)
  if tweaks.tMapCamera and realmName ~= nil then
    map_camera.CollisionRoot = mapUtil.GetRealmCollisionGOName(realmName)
    Camera.SetMapCamera(nil)
    Camera.SetMapCamera(map_camera)
  end
end
function MapOn:UpdateHelheimBoat()
  local GetGlobalVar = game.Level.GetVariable
  local boatState = GetGlobalVar("Hel_MapState")
  local goMapBoat = util.GetUiObjByName("map_helheim_boat")
  goMapBoat:Show()
  local targetTimelinePos = 0
  if boatState == 1 then
    targetTimelinePos = 0.1
  elseif boatState == 2 then
    targetTimelinePos = 0.2
  elseif boatState == 3 then
    targetTimelinePos = 0.3
  elseif boatState == 4 then
    targetTimelinePos = 0.4
  end
  local animRate = 0
  UI.Anim(goMapBoat, consts.AS_Forward, "", animRate, targetTimelinePos)
end
function MapOn:UpdateWaterLevel()
  local targetTimelinePos = 0.3
  local animRate = 0
  local goWaterGroup = util.GetUiObjByName("Midgard_Water")
  local jid_waterLevel0 = goWaterGroup:GetJointIndex("WaterLevel0")
  local jid_waterLevel1 = goWaterGroup:GetJointIndex("WaterLevel1")
  if game.Level.GetVariable("_GBL_WaterDrop01Triggered") == false then
    goWaterGroup:ShowJoint(jid_waterLevel0)
    goWaterGroup:HideJoint(jid_waterLevel1)
    targetTimelinePos = 0.3
  elseif game.Level.GetVariable("_GBL_WaterDrop02Triggered") == false then
    goWaterGroup:ShowJoint(jid_waterLevel1)
    goWaterGroup:HideJoint(jid_waterLevel0)
    targetTimelinePos = 0.2
  else
    goWaterGroup:HideJoint(jid_waterLevel1)
    goWaterGroup:HideJoint(jid_waterLevel0)
    targetTimelinePos = 0.1
  end
  local goLakeText = util.GetUiObjByName("CalderaLake")
  local calderaShoresARegionInfo = mapUtil.GetRegionInfo(mapConsts.REGION_CALDERASHORESA)
  local calderaShoresDiscovered = mapUtil.RegionInfo_IsDiscovered(calderaShoresARegionInfo)
  if calderaShoresDiscovered then
    goLakeText:Show()
    UI.Anim(goLakeText, consts.AS_Forward, "", animRate, targetTimelinePos)
  else
    goLakeText:Hide()
  end
end
function MapOn:UpdateTempleRotation(realmName)
  mapUtil.UpdateTempleRotation(realmName)
end
function MapOn:AnimateFog()
  local goFogAnimated = util.GetUiObjByName("fogNoise_Animated")
  local targetTimelinePos = 1
  local animRate = 0.01
  UI.Anim(goFogAnimated, consts.AS_ForwardCycle, "", animRate, targetTimelinePos)
  local goRenderLayer = util.GetUiObjByName("mapRenderLayer")
  goRenderLayer:Show()
  animRate = 0.01
  UI.Anim(goRenderLayer, consts.AS_ForwardCycle, "", animRate, targetTimelinePos)
  local goMidgardWaterGroup = util.GetUiObjByName("Midgard_Water")
  animRate = 0.01
  UI.Anim(goMidgardWaterGroup, consts.AS_ForwardCycle, "", animRate, targetTimelinePos)
  local goAlfWaterGroup = util.GetUiObjByName("Alfheim_Water")
  animRate = 0.01
  UI.Anim(goAlfWaterGroup, consts.AS_ForwardCycle, "", animRate, targetTimelinePos)
end
function MapOn:EnableAllFog(realmName)
  local fogTable = mapConsts.MAP_FOG_GAMEOBJECTS
  local allRegionInfo = mapUtil.GetAllRegionInfoInRealm(realmName)
  local goMapVis = util.GetUiObjByName("Maps")
  for _, regionInfo in ipairs(allRegionInfo) do
    local regionName = mapUtil.RegionInfo_GetName(regionInfo)
    local regionID = mapUtil.RegionInfo_GetID(regionInfo)
    local isInvertFogRegion = mapUtil.Region_HasFlags(regionID, {
      mapConsts.REGION_FLAG_INVERT_FOG
    })
    local fogObjectName = fogTable[regionName]
    if isInvertFogRegion then
      util.Show(fogObjectName)
    else
      util.Hide(fogObjectName)
    end
    local goRealm = goMapVis:FindSingleGOByName(realmName)
    if goRealm ~= nil then
      local goRealmTextHolder = goRealm:FindSingleGOByName("text")
      if goRealmTextHolder ~= nil then
        local jointName = mapConsts.MAP_TEXT_GAMEOBJECTS[regionName]
        if jointName ~= nil then
          local iJoint = goRealmTextHolder:GetJointIndex(jointName)
          goRealmTextHolder:HideJoint(iJoint)
        end
      end
    end
  end
end
function MapOn:SetupVisibilityOfRegions(realmName)
  local fogTable = mapConsts.MAP_FOG_GAMEOBJECTS
  local allRegionInfo = mapUtil.GetAllRegionInfoInRealm(realmName)
  for _, regionInfo in ipairs(allRegionInfo) do
    local regionName = mapUtil.RegionInfo_GetName(regionInfo)
    local regionID = mapUtil.RegionInfo_GetID(regionInfo)
    local isRegionDiscovered = mapUtil.RegionInfo_IsDiscovered(regionInfo)
    local isInvertFogRegion = mapUtil.Region_HasFlags(regionID, {
      mapConsts.REGION_FLAG_INVERT_FOG
    })
    local fogObjectName = fogTable[regionName]
    local shouldShowFog = isRegionDiscovered
    if isInvertFogRegion then
      shouldShowFog = not shouldShowFog
    end
    if shouldShowFog then
      util.Show(fogObjectName)
    else
      util.Hide(fogObjectName)
    end
    local goMapVis = util.GetUiObjByName("Maps")
    local goRealm = goMapVis:FindSingleGOByName(realmName)
    local goRealmTextHolder = goRealm:FindSingleGOByName("text")
    if goRealmTextHolder ~= nil then
      local jointName = mapConsts.MAP_TEXT_GAMEOBJECTS[regionName]
      if jointName ~= nil then
        local iJoint = goRealmTextHolder:GetJointIndex(jointName)
        if isRegionDiscovered then
          goRealmTextHolder:ShowJoint(iJoint)
        else
          goRealmTextHolder:HideJoint(iJoint)
        end
      end
    end
  end
end
function MapOn:MapCollisionChangeHandler(currState, collisionGameObjectTable, realmName)
  -- Child puzzle actors take priority over their parent chest when their
  -- clickable roots overlap at high zoom.
  local completionistMapV100NornirPin =
    CompletionistMapV100_FindNornirCollision(
      self,
      collisionGameObjectTable
    )

  if completionistMapV100NornirPin ~= nil then
    self.completionistMapV100NornirSelected =
      completionistMapV100NornirPin
    self.completionistMapV100NornirLastHitFrame =
      self.completionistMapV100Frame or 0
    self.completionistMapV100NornirChestSelected = nil
    self.completionistMapV100Selected = false

    CompletionistMapV100_SetCustomCursorSelected(true)

    CompletionistMapV100_NornirReticle(
      self,
      currState,
      completionistMapV100NornirPin
    )

    print("[CompletionistMap v0.10.1] NORNIR_SELECTION" ..
      " active=true" ..
      " registryKey=" ..
        tostring(completionistMapV100NornirPin.registryKey) ..
      " index=" ..
        tostring(completionistMapV100NornirPin.keyIndex) ..
      " priority=child" ..
      " snapMode=native_cursor" ..
      " preservesZoom=true")
    return
  end

  if self.completionistMapV100NornirSelected ~= nil then
    local frame = self.completionistMapV100Frame or 0
    local lastHit =
      self.completionistMapV100NornirLastHitFrame or frame

    if frame - lastHit <= 12 then
      return
    end

    self.completionistMapV100NornirSelected = nil
    print("[CompletionistMap v0.10.1] NORNIR_SELECTION cleared=true" ..
      " latchFrames=12")
  end

  local completionistMapV100ChestPin =
    CompletionistMapV100_FindNornirChestCollision(
      self, collisionGameObjectTable
    )

  if completionistMapV100ChestPin ~= nil then
    self.completionistMapV100NornirChestSelected = completionistMapV100ChestPin
    self.completionistMapV100NornirSelected = nil
    self.completionistMapV100Selected = false
    CompletionistMapV100_SetCustomCursorSelected(true)
    CompletionistMapV100_NornirChestReticle(
      self, currState, completionistMapV100ChestPin
    )
    print("[CompletionistMap v0.10.1] NORNIR_CHEST_SELECTION" ..
      " active=true registryKey=" ..
        tostring(completionistMapV100ChestPin.registryKey) ..
      " priority=parent" ..
      " snapMode=native_cursor" ..
      " preservesZoom=true")
    return
  end

  self.completionistMapV100NornirChestSelected = nil

  local completionistMapV100IsCustom =
    CompletionistMapV100_CollisionContainsPin(
      self,
      collisionGameObjectTable
    )

  if completionistMapV100IsCustom then
    local frame = self.completionistMapV100Frame or 0
    self.completionistMapV100LastHitFrame = frame

    if not self.completionistMapV100CollisionState then
      print("[CompletionistMap v0.10.1] MAP_COLLISION hit=true")
    end
    self.completionistMapV100CollisionState = true

    if not self.completionistMapV100Selected then
      self.completionistMapV100Selected = true
      print("[CompletionistMap v0.10.1] MAP_SELECTION active=true")
    end

    CompletionistMapV100_SetCustomCursorSelected(true)
    CompletionistMapV100_ShowReticle(self, currState)

    if not self.completionistMapV100NativeSnapLogged then
      self.completionistMapV100NativeSnapLogged = true
      print("[CompletionistMap v0.10.1] MAP_SNAP" ..
        " mode=native_cursor" ..
        " preservesZoom=true" ..
        " frame=" .. tostring(frame))
    end
    return
  end

  if self.completionistMapV100CollisionState then
    print("[CompletionistMap v0.10.1] MAP_COLLISION hit=false_debounced")
  end
  self.completionistMapV100CollisionState = false

  if self.completionistMapV100Selected then
    local frame = self.completionistMapV100Frame or 0
    local lastHit = self.completionistMapV100LastHitFrame or 0
    local age = frame - lastHit

    if age <= 6 then
      return
    end

    self.completionistMapV100Selected = false
    print("[CompletionistMap v0.10.1] MAP_SELECTION cleared=true" ..
      " ageFrames=" .. tostring(age))
  end  local iconCollInfo, terrainCollInfo = mapUtil.GetPrioritizedIconAndTerrain(collisionGameObjectTable)
  local showConfirmFastTravel = false
  local showGoToJournal = false
  local setReticleSelected = false
  self.currQuestID = nil
  self.currMarkerID = nil
  self.currMarkerPlayerIcon = false
  if self.isOpenedForFastTravel and Camera.HasTarget ~= nil and Camera.HasTarget() then
    local fastTravelList = currState.menu:GetList("FastTravelList")
    local currFastTravelMarkerInfo
    if self.clickedMarkerInfo ~= nil then
      currFastTravelMarkerInfo = self.clickedMarkerInfo
    else
      currFastTravelMarkerInfo = fastTravelList:GetSelectedItem()
    end
    if self.clickedPlayer then
      self.currMarkerPlayerIcon = true
    end
    if currFastTravelMarkerInfo == nil then
      Camera.PointAt(CALDERA_MAP_POSITION, true)
    else
      self.currMarkerID = currFastTravelMarkerInfo.Id
      if iconCollInfo ~= nil then
        local collisionType = mapUtil.GetMapCollisionInfoType(iconCollInfo)
        local markerInfo = mapUtil.GetMapCollisionInfoInfo(iconCollInfo)
        if self.clickedPlayer or markerInfo ~= nil and markerInfo.Id == self.currMarkerID then
          setReticleSelected = true
        end
      end
      local isDiscoveredButLocked = currFastTravelMarkerInfo.State == tweaks.eTokenState.kDiscoveredButLocked
      showConfirmFastTravel = self.clickedMarkerInfo == nil and not self.clickedPlayer and not isDiscoveredButLocked and not self:IsPlayerAtMarker(currFastTravelMarkerInfo)
    end
    if self.clickedPlayer then
      currFastTravelMarkerInfo = nil
    end
    self:UpdateReticleInfo(currState, currFastTravelMarkerInfo)
  else
    self.clickedMarkerInfo = nil
    self.clickedPlayer = false
    if iconCollInfo == nil then
      self:ClearReticleInfo()
      local cineNumberAfterWhichTowerInfoIsDisplayed = 200
      if cineNumberAfterWhichTowerInfoIsDisplayed <= game.Level.GetVariable("CompletedCineNumber") then
        for i = 1, #collisionGameObjectTable do
          local collGO = collisionGameObjectTable[i]
          if collGO ~= nil and collGO.GetName ~= nil then
            local name = collGO:GetName()
            if string.sub(name, 1, 15) == "towercollision_" then
              local towerName = string.sub(name, 16)
              local title = util.GetLAMSMsg(lamsConsts.towerDesc[towerName], towerName)
              self:SetReticleInfo(currState, title, "")
            end
          end
        end
      end
    else
      local collisionType = mapUtil.GetMapCollisionInfoType(iconCollInfo)
      local markerInfo = mapUtil.GetMapCollisionInfoInfo(iconCollInfo)
      if markerInfo ~= nil then
        if collisionType == mapConsts.MAP_COLL_ICON then
          local markerID = markerInfo.Id
          self.currMarkerID = markerID
          local hasQuest, questName = questUtil.FindQuestForMarker(markerID)
          self.currQuestID = hasQuest and questName or nil
          showGoToJournal = hasQuest
        end
        if Map.MarkerHasAnyFlag(markerInfo.Id, fastTravelMarkerFlags) then
          local isDiscoveredButLocked = markerInfo.State == tweaks.eTokenState.kDiscoveredButLocked
          showConfirmFastTravel = not isDiscoveredButLocked and not self:IsPlayerAtMarker(markerInfo)
        end
      elseif collisionType == mapConsts.MAP_COLL_PLAYER_ICON then
        self.currMarkerPlayerIcon = true
      end
      self:UpdateReticleInfo(currState, markerInfo)
      setReticleSelected = true
    end
  end
  if terrainCollInfo == nil then
    self:HideSummary()
  else
    self:UpdateSummary(realmName, terrainCollInfo)
  end
  local goCursorRefnode = util.GetUiObjByName("MapCursor")
  animationUtil.SetCursorSelected(goCursorRefnode, setReticleSelected)
  if setReticleSelected then
    Audio.PlaySound("SND_UX_Pause_Menu_Screen_Map_Region_Hover_Tick")
  end
  self:UpdateFooterButtonPrompt(currState.menu, showConfirmFastTravel, showGoToJournal)
end
function MapOn:GetMapMarkerTrackingState(markerID)
  local trackingState = questConsts.TRACKING_STATE_NONE
  local hasQuest, questID = questUtil.FindQuestForMarker(markerID)
  if hasQuest then
    local trackingInfo = questUtil.GetTrackingInfo(questID)
    trackingState = questUtil.TrackingInfo_GetTrackingState(trackingInfo, questID)
  end
  if self.currShownMarkerID ~= nil and markerID == self.currShownMarkerID then
    trackingState = questConsts.TRACKING_STATE_TRACKED
  end
  return trackingState
end
function MapOn:GetMapMarkerTrackingStateFromIconGO(goIcon)
  local trackingState = questConsts.TRACKING_STATE_NONE
  local markerInfo = Map.FindInfoFromIcon(goIcon)
  if markerInfo ~= nil then
    trackingState = self:GetMapMarkerTrackingState(markerInfo.Id)
  end
  return trackingState
end
function MapOn:UpdateMapMarkerHighlights()
  for i = 1, #self.markers do
    local markerInfo = self.markers[i]
    local goIcon = markerInfo.iconGO
    local goIconTracked = goIcon:FindSingleGOByName("MapIconAreaMainQuest_area")
    local goIconTrackedSide = goIcon:FindSingleGOByName("MapIconAreaSideQuest_area")
    local goIconUntracked = goIcon:FindSingleGOByName("untracked")
    local goIconLock = goIcon:FindSingleGOByName("lock")
    local trackingState = self:GetMapMarkerTrackingStateFromIconGO(goIcon)
    local isRadiusMarker = Map.MarkerHasAnyFlag(markerInfo.Id, {"RadiusType"})
    local isDiscoveredButLocked = markerInfo.State == tweaks.eTokenState.kDiscoveredButLocked
    local goMarkerLockIcon = goIcon:FindSingleGOByName("lock")
    if goIconLock ~= nil then
      if isDiscoveredButLocked == true then
        goIconLock:Show()
      else
        goIconLock:Hide()
      end
    end
    if isRadiusMarker and goIconUntracked then
      local offset = engine.Vector.New(markerInfo.OffsetX, 0, markerInfo.OffsetY)
      goIconUntracked:SetLocalPosition(offset)
      goIconUntracked:Show()
      if trackingState == questConsts.TRACKING_STATE_TRACKED then
        UI.Anim(goIconUntracked, consts.AS_ForwardCycle_NoReset, "", 1)
      else
        UI.Anim(goIconUntracked, consts.AS_Forward, "", 0, 0)
      end
    end
    if trackingState == questConsts.TRACKING_STATE_TRACKED then
      if isRadiusMarker and goIconTracked then
        goIconTracked:Show()
      elseif isRadiusMarker and goIconTrackedSide then
        goIconTrackedSide:Show()
      end
      UI.Anim(goIcon, consts.AS_ForwardCycle_NoReset, "", 1)
    else
      if isRadiusMarker and goIconTracked then
        goIconTracked:Hide()
      elseif isRadiusMarker and goIconTrackedSide then
        goIconTrackedSide:Hide()
      end
      UI.Anim(goIcon, consts.AS_Forward, "", 0, 0)
    end
  end
end
function MapOn:IsPlayerAtMarker(markerInfo)
  return self.openedAtMarker ~= nil and markerInfo ~= nil and markerInfo.Id == self.openedAtMarker
end
function MapOn:FastTravel_Button_Update(button)
  local markerInfo = button:get_item()
  local isPlayerAtMarker = self:IsPlayerAtMarker(markerInfo)
  local isLocked = markerInfo ~= nil and markerInfo.State == tweaks.eTokenState.kDiscoveredButLocked
  local textColor = (isPlayerAtMarker or isLocked) and colors.GRAY or colors.WHITE
  button:SetTextColor(textColor)
end
function MapOn:FastTravel_Button_OnGainFocus(currState, button)
  local markerInfo = button:get_item()
  if markerInfo ~= nil then
    Camera.PointAtGO(markerInfo.iconGO)
    Audio.PlaySound("SND_UX_Pause_Menu_Map_MoveTo_Active_Marker_LP")
    self.playingMoveToActiveMarker = true
  end
  local isDiscoveredButLocked = markerInfo.State == tweaks.eTokenState.kDiscoveredButLocked
  local showConfirmFastTravel = not isDiscoveredButLocked and not self:IsPlayerAtMarker(markerInfo)
  local showGoToJournal = false
  self:UpdateFooterButtonPrompt(currState.menu, showConfirmFastTravel, showGoToJournal)
end
function MapOn:FastTravel_Button_ItemCompare(item, otherItem)
  return item ~= nil and otherItem ~= nil and item.Id == otherItem.Id
end
function MapOn:UpdateFastTravelList(currState)
  local fastTravelList = currState.menu:GetList("FastTravelList")
  if self.isOpenedForFastTravel then
    local unlockedFastTravelMarkers = {}
    for i = 1, #self.markers do
      local markerInfo = self.markers[i]
      if (markerInfo.State == tweaks.eTokenState.kDiscovered or markerInfo.State == tweaks.eTokenState.kDiscoveredButLocked) and Map.MarkerHasAnyFlag(markerInfo.Id, fastTravelMarkerFlags) then
        unlockedFastTravelMarkers[#unlockedFastTravelMarkers + 1] = markerInfo
      end
    end
    fastTravelList:Refresh(unlockedFastTravelMarkers, true, true, nil, function(item)
      return util.GetLAMSMsg(item.LamsDescriptionId, item.Id)
    end)
    fastTravelList:HideLabel()
  else
    local hideList = true
    local clearButtons = false
    fastTravelList:Deactivate(hideList, clearButtons)
    self:UpdateFooterButtonPrompt(currState.menu, false, false)
  end
end
function MapOn:SelectFastTravelButtonByMarkerInfo(currState, markerInfoToSelect)
  local fastTravelList = currState.menu:GetList("FastTravelList")
  if not self:FastTravel_Button_ItemCompare(fastTravelList:GetSelectedItem(), markerInfoToSelect) then
    fastTravelList:SelectItem(markerInfoToSelect, true)
  end
end
function MapOn:ClearReticleInfo()
  local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
  goMapCursorText:Hide()
  self._goCursorTextGroup_Top:Hide()
  self._goCursorTextGroup_Bottom:Hide()
end
function MapOn:Update()
  self.completionistMapV100Frame =
    (self.completionistMapV100Frame or 0) + 1

  CompletionistMapV100_RefreshNornirPins(self)
  CompletionistMapV100_RefreshNornirChestPins(self)
  CompletionistMapV100_IsTargetCollected()
  CompletionistMapV100_RefreshCustomPins(self)

  if CompletionistMapV100_IsRavenCollected() then
    if self.completionistMapV100MapIconGO ~= nil then
      CompletionistMapV100_DestroyMapPin(self)
      print("[CompletionistMap v0.10.1] MAP_PIN_REMOVE reason=raven_collected")
    end
  end  if Camera.GetCursorScaleValue then
    local cursorScaleValue = Camera.GetCursorScaleValue() * 0.5
    local goTop = self._goCursorTextGroup_Top
    local vTargetPos = engine.Vector.New(0, cursorScaleValue, 0)
    local translationTime = 0
    local useWorldSpace = false
    UI.SetGOTransformInterpolated(goTop, vTargetPos, translationTime, useWorldSpace)
    local goBottom = self._goCursorTextGroup_Bottom
    vTargetPos = engine.Vector.New(0, -cursorScaleValue, 0)
    UI.SetGOTransformInterpolated(goBottom, vTargetPos, translationTime, useWorldSpace)
  end
end
function MapOn:UpdateReticleInfo(currState, markerInfo)
  local title = ""
  local desc = ""
  if markerInfo ~= nil then
    local isFastTravelMarker = Map.MarkerHasAnyFlag(markerInfo.Id, fastTravelMarkerFlags)
    local isDiscoveredButLocked = markerInfo.State == tweaks.eTokenState.kDiscoveredButLocked
    title = util.GetLAMSMsg(markerInfo.LamsNameId, markerInfo.Id)
    desc = util.GetLAMSMsg(markerInfo.LamsDescriptionId, markerInfo.Id)
    if isDiscoveredButLocked then
      desc = isFastTravelMarker and util.GetLAMSMsg(lamsConsts.LockedFastTravelMarker) or util.GetLAMSMsg(lamsConsts.LockedMarker)
    end
    if self.isOpenedForFastTravel and Map.MarkerHasAnyFlag(markerInfo.Id, fastTravelMarkerFlags) then
      self:SelectFastTravelButtonByMarkerInfo(currState, markerInfo)
    end
  elseif self.currMarkerPlayerIcon then
    title = "[MSG:" .. lamsConsts.Kratos .. "]"
  end
  self:SetReticleInfo(currState, title, desc)
end
function MapOn:SetReticleInfo(currState, title, desc)
  local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
  goMapCursorText:Show()
  local goTitle = goMapCursorText:FindSingleGOByName("CursorInfo_Bottom")
  local thTitle = util.GetTextHandle(goTitle, "CursorTitle_Text")
  if not util.IsStringNilOrEmpty(title) then
    UI.SetText(thTitle, title)
    goTitle:Show()
  else
    UI.SetText(thTitle, "")
    goTitle:Hide()
  end
  local thDescription = util.GetTextHandle(goTitle, "CursorDescription_Text")
  if not util.IsStringNilOrEmpty(desc) then
    UI.SetText(thDescription, desc)
  else
    UI.SetText(thDescription, "")
  end
  local goCursorInfo_Top = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
  local thPrompt = util.GetTextHandle(goCursorInfo_Top, "CursorAction_Text")
  UI.SetTextIsClickable(thPrompt)
  if self.isOpenedForFastTravel then
    UI.SetText(thPrompt, "")
    goCursorInfo_Top:Hide()
  elseif self.currQuestID ~= nil then
    UI.SetText(thPrompt, "[SquareButton] " .. util.GetLAMSMsg(lamsConsts.GoToJournal))
    goCursorInfo_Top:Show()
  else
    local showShowOnCompass, promptText = self:GetShowOnCompassPrompt(currState.menu)
    if showShowOnCompass then
      UI.SetText(thPrompt, promptText)
      goCursorInfo_Top:Show()
    else
      UI.SetText(thPrompt, "")
      goCursorInfo_Top:Hide()
    end
  end
end
function MapOn:ShowRegionSummary()
  local onScreen = true
  self.mapSummaryCard_Region:SetOnScreen(onScreen)
end
function MapOn:HideSummary()
  local onScreen = false
  self.currentRegionId = nil
  self.mapSummaryCard_Region:SetOnScreen(onScreen)
end
function MapOn:UpdateRealmSummary(realmName)
  local realmInfo = game.Map.GetRealmInfo(realmName)
  self.mapSummaryCard_Realm:SetProperty("RealmInfo", realmInfo)
  local doTransitionAnim = true
  self.mapSummaryCard_Realm:Update(doTransitionAnim)
  if self.isOpenedForFastTravel or self.mapSummaryCard_Realm:GetProperty("numActiveRows") <= 0 then
    self.mapSummaryCard_Realm:HideCard()
  else
    self.mapSummaryCard_Realm:ShowCard()
  end
end
function MapOn:UpdateSummary(realmName, terrainCollInfo)
  local regionIsDifferentFromLastTime = false
  if terrainCollInfo ~= nil then
    local goTerrainCollision = mapUtil.GetMapCollisionInfoGameObject(terrainCollInfo)
    local wadName = goTerrainCollision:GetName()
    local wadRegionInfo = mapUtil.RegionInfo_GetRegionInfoFromWadName(wadName)
    local regionInfo
    if wadRegionInfo ~= nil then
      local allRegionInfo = mapUtil.GetAllRegionInfoInRealm(realmName)
      for i = 1, #allRegionInfo do
        if allRegionInfo[i].Id == wadRegionInfo.Id then
          regionInfo = wadRegionInfo
          break
        end
      end
    end
    if regionInfo ~= nil then
      local isRegionDiscovered = mapUtil.RegionInfo_IsDiscovered(regionInfo)
      local neverShowSummary = mapUtil.Region_HasFlags(regionInfo.Id, {
        "NeverShowSummary"
      })
      if isRegionDiscovered and not neverShowSummary then
        local regionSummaryInfo = Map.GetRegionSummaryInfo(regionInfo.Id)
        self.mapSummaryCard_Region:SetProperty("RegionInfo", regionInfo)
        self.mapSummaryCard_Region:SetProperty("RegionSummaryInfo", regionSummaryInfo)
        if self._previousRegionID ~= regionInfo.Id then
          self._previousRegionID = regionInfo.Id
          regionIsDifferentFromLastTime = true
        end
        if self.currentRegionId == nil or regionInfo.Id ~= self.currentRegionId then
          self:ShowRegionSummary()
        end
        self.currentRegionId = regionInfo.Id
      else
        self:HideSummary()
      end
    else
      self:HideSummary()
    end
  end
  local doTransitionAnim = regionIsDifferentFromLastTime
  self.mapSummaryCard_Region:Update(false)
end
function MapOn:SubmenuSetup(currState)
  currState.menu = menu.Menu.New(currState, {
    FooterButtonInfo = {
      {
        Item = "ConfirmFastTravel",
        Text = "[AdvanceButton] " .. util.GetLAMSMsg(lamsConsts.Confirm)
      },
      {
        Item = "ShowOnCompass",
        Text = "",
        EventHandlers = {
          {
            Events = {
              "EVT_Advance_Release"
            },
            Handler = function()
              self:ShowOnCompass(currState)
            end
          }
        }
      },
      {
        Item = "GoToJournal",
        Text = "[SquareButton] " .. util.GetLAMSMsg(lamsConsts.GoToJournal),
        EventHandlers = {
          {
            Events = {
              "EVT_Square_Release"
            },
            Handler = function()
              self:Menu_Square_ReleaseHandler()
            end
          }
        }
      },
      {
        Item = "ActiveMarkers",
        Text = "[R3] " .. util.GetLAMSMsg(lamsConsts.ActiveMarkers)
      },
      {
        Item = "Move",
        Text = "[JoystickL] " .. util.GetLAMSMsg(lamsConsts.Move)
      },
      {
        Item = "Zoom",
        Text = "[JoystickRY] " .. util.GetLAMSMsg(lamsConsts.Zoom)
      },
      {
        Item = "Settings",
        Text = "[TriangleButton] " .. util.GetLAMSMsg(lamsConsts.Options),
        EventHandlers = {
          {
            Events = {
              "EVT_Triangle_Release"
            },
            Handler = function()
              self:Menu_Triangle_ReleaseHandler()
            end
          }
        }
      },
      {
        Item = "Weapon",
        Text = "",
        EventHandlers = {
          {
            Events = {
              "EVT_GO_TO_WEAPON_MENU"
            },
            Handler = function()
              if not self.isOpenedForFastTravel then
                self:SendEventToUIFsm("globalMenu", "EVT_GO_TO_WEAPON")
              end
            end
          }
        }
      },
      {
        Item = "Skill",
        Text = "",
        EventHandlers = {
          {
            Events = {
              "EVT_GO_TO_SKILL_TREE_MENU"
            },
            Handler = function()
              self:SendEventToUIFsm("globalMenu", "EVT_GO_TO_SKILL_TREE")
            end
          }
        }
      },
      {
        Item = "Quest",
        Text = "",
        EventHandlers = {
          {
            Events = {
              "EVT_GO_TO_QUEST_MENU"
            },
            Handler = function()
              self:SendEventToUIFsm("globalMenu", "EVT_GO_TO_QUEST")
            end
          }
        }
      },
      {
        Item = "Exit",
        Text = "[BackButton] " .. util.GetLAMSMsg(lamsConsts.Exit),
        EventHandlers = {
          {
            Events = {
              "EVT_Back_Release"
            },
            Handler = function()
              self:Menu_Back_ReleaseHandler()
            end
          }
        }
      },
      {
        Item = "Close",
        Text = "",
        EventHandlers = {
          {
            Events = {
              "EVT_Options_Release"
            },
            Handler = function()
              self:Menu_Options_ReleaseHandler()
            end
          }
        }
      }
    }
  })
  local fastTravelList = list.List.New(currState, {
    MaxFocusableObjectCount = 10,
    ListObjectName = "FastTravelList",
    EmptyTextLamsID = lamsConsts.NoFastTravelPointsAvailable,
    NextEvents = {
      "EVT_Down_Release"
    },
    PreviousEvents = {
      "EVT_Up_Release"
    },
    EventHandlers = {
      {
        Events = {
          "EVT_Advance_Release"
        },
        Handler = function()
          self:ConfirmFastTravel(currState)
        end
      }
    },
    Button_Update = function(button)
      self:FastTravel_Button_Update(button)
    end,
    Button_OnGainFocus = function(button)
      self:FastTravel_Button_OnGainFocus(currState, button)
    end,
    Button_ItemCompare = function(item, otherItem)
      return self:FastTravel_Button_ItemCompare(item, otherItem)
    end
  })
  fastTravelList:SetSelectedButton(1, false)
  currState.menu:SetList("FastTravelList", fastTravelList)
  fastTravelList:SetHeaderText(util.GetLAMSMsg(lamsConsts.FastTravelPoints))
end
function MapOn:ClearMarkers(clear_all)
  local first = clear_all == true and 1 or #self.alwaysOnMarkers + 1
  for index = #self.markers, first, -1 do
    self.markers[index].shown = false
    self.markers[index] = nil
  end
  if clear_all then
    self.alwaysOnMarkers = {}
  end
end
function MapOn:ClearIcons()
  for i = 1, #self.realmMarkerInfo do
    local markerInfo = self.realmMarkerInfo[i]
    if markerInfo.iconGO ~= nil then
      Map.RecycleIcon(markerInfo.iconGO)
      markerInfo.iconGO = nil
    end
  end
end
function MapOn:UpdateIcons()
  for i = 1, #self.realmMarkerInfo do
    local markerInfo = self.realmMarkerInfo[i]
    if markerInfo.shown and markerInfo.iconGO == nil then
      markerInfo.iconGO = Map.CreateMarkerIcon(markerInfo.Id, markerInfo.regionId, "")
    elseif markerInfo.iconGO ~= nil then
      if markerInfo.shown then
        markerInfo.iconGO:Show()
      else
        markerInfo.iconGO:Hide()
      end
    end
    if markerInfo.iconGO ~= nil then
      UI.SetIsClickable(markerInfo.iconGO)
    end
  end
end
function MapOn:GetRealmMarkerInfo()
  self:ClearIcons()
  self.realmMarkerInfo = {}
  if self.currRealmName == nil then
    return
  end
  local regionInfoTable = mapUtil.GetAllRegionInfoInRealm(self.currRealmName)
  for _, regionInfo in ipairs(regionInfoTable) do
    local regionMarkerInfoTable = Map.GetMarkersInfoTable(regionInfo.Id)
    for i = 1, #regionMarkerInfoTable do
      local markerInfo = regionMarkerInfoTable[i]
      local hasQuest, questName = questUtil.FindQuestForMarker(markerInfo.Id)
      if not hasQuest or game.QuestManager.GetQuestState(questName) ~= questConsts.QUEST_STATE_COMPLETE then
        markerInfo.regionId = regionInfo.Id
        self.realmMarkerInfo[#self.realmMarkerInfo + 1] = regionMarkerInfoTable[i]
      end
    end
  end
  self:UpdateFilterButtonMapping()
end
function MapOn:GetAlwaysOnMarkers()
  self:ClearMarkers(true)
  for i = 1, #self.realmMarkerInfo do
    local markerInfo = self.realmMarkerInfo[i]
    if Map.MarkerHasAnyFlag(markerInfo.Id, alwaysOnMarkerFlags) and mapUtil.MapMarkerInfoHasStates(markerInfo, markerStates) then
      markerInfo.shown = true
      tablex.FastInsert(self.alwaysOnMarkers, markerInfo, #self.alwaysOnMarkers + 1)
      tablex.FastInsert(self.markers, markerInfo, #self.markers + 1)
    end
  end
end
function MapOn:GetMarkers()
  self:ClearMarkers()
  for i = 1, #self.realmMarkerInfo do
    local markerInfo = self.realmMarkerInfo[i]
    if Map.MarkerHasAnyFlag(markerInfo.Id, self.markerIncludeFlags) and mapUtil.MapMarkerInfoHasStates(markerInfo, markerStates) then
      markerInfo.shown = true
      tablex.FastInsert(self.markers, markerInfo, #self.markers + 1)
    end
  end
end
function MapOn:ShouldShowPlayerMarker()
  local playerRealm = mapUtil.GetPlayerRealm()
  local showPlayerMarker =
    playerRealm == self.currRealmName and
    self.playerIconGO ~= nil and
    _G.CompletionistMapV100PlayerMarkerVisible ~= false
  local Hel_MapState = game.Level.GetVariable("Hel_MapState")
  local inTheLight = game.Level.GetVariable("CompletedCineNumber") == 240
  local onBoat = 2 <= Hel_MapState and Hel_MapState < 5 and playerRealm == mapConsts.REALM_HELHEIM
  local fastTraveling = Player.FindPlayer().CurrentLevelWadName == "Gbl000_FastTravel"
  if onBoat or fastTraveling or inTheLight then
    showPlayerMarker = false
  end
  return showPlayerMarker
end
function MapOn:SubmenuEnter(currState, realmName)
  currState.menu:Activate()
  self.completionistMapV100Menu = currState.menu
  util.GetUiObjByName("MapCursorInfo"):Hide()
  local prevRealmName = self.currRealmName
  self.currRealmName = realmName
  self:UpdateTempleRotation(realmName)
  self:UpdateRealmSummary(realmName)
  self:HideSummary()
  self:ShowMap(realmName)
  self:SetupCameraForMap(realmName)
  self:StartTimer("FogShowDelayTimer", 0.25, function()
    self:SetupVisibilityOfRegions(realmName)
  end)
  self:UpdateMapState()
  if self.isOpenedForFastTravel then
    self:GetRealmMarkerInfo()
    self:GetAlwaysOnMarkers()
    self.markerIncludeFlags = fastTravelMarkerFlags
  elseif prevRealmName ~= self.currRealmName then
    self:GetRealmMarkerInfo()
    self:GetAlwaysOnMarkers()
  end
  self:GetMarkers()
  self:UpdateIcons()
  self:UpdateMapMarkerHighlights()
  self:UpdateFilterUI()
  if self.playerIconGO ~= nil then
    Map.SetPlayerMapMarkerToPlayerMapTransform(self.playerIconGO, "facingJoint", "arrowJoint")
    CompletionistMapV100_LogMapCalibration(self)
  end
  local showPlayerMarker = self:ShouldShowPlayerMarker()
  if showPlayerMarker then
    self.playerIconGO:Show()
  else
    self.playerIconGO:Hide()
  end
  local selectMarker
  if self.markerIdHashToSelectOnOpen ~= nil then
    self.openedAtMarker = self.markerIdHashToSelectOnOpen
    self.markerIdHashToSelectOnOpen = nil
    for i = 1, #self.markers do
      local marker = self.markers[i]
      if marker.Id == self.openedAtMarker then
        selectMarker = marker
        local instant = true
        Camera.PointAtGO(marker.iconGO, instant)
        break
      end
    end
  elseif showPlayerMarker then
    local instant = true
    Camera.PointAtGO(self.playerIconGO, instant)
  elseif _G.CompletionistMapV100PlayerMarkerVisible == false and
      mapUtil.GetPlayerRealm() == self.currRealmName and
      self.playerIconGO ~= nil then
    local instant = true
    Camera.PointAtGO(self.playerIconGO, instant)
    print("[CompletionistMap v0.10.1] PLAYER_HIDDEN_CENTER" ..
      " centered=true realm=" .. tostring(self.currRealmName))
  elseif Camera.PointAt ~= nil then
    local instant = true
    Camera.PointAt(CALDERA_MAP_POSITION, instant)
  end
  self:UpdateFastTravelList(currState)
  if self.isOpenedForFastTravel and selectMarker ~= nil then
    self:SelectFastTravelButtonByMarkerInfo(currState, selectMarker)
  end
  CompletionistMapV100_CreateMapPin(self, currState)
  CompletionistMapV100_CreateNornirChestPins(self, currState)
  CompletionistMapV100_CreateNornirPins(self, currState)
  CompletionistMapV100_RefreshCustomPins(self)
  UI.WorldUIRender(map_camera.Name)
  currState.menu:ExecuteInstructions()
end
function MapOn:SubmenuExit(currState)
  CompletionistMapV100_DestroyNornirChestPins(self)
  CompletionistMapV100_DestroyNornirPins(self)
  CompletionistMapV100_DestroyMapPin(self)
  currState.menu:Deactivate(true)
  self:ClearMarkers(true)
  if self.playerIconGO ~= nil then
    self.playerIconGO:Hide()
  end
  if tweaks.tMapCamera then
    Camera.SetMapCamera()
  end
  self:HideAllMaps()
end
function MapOn:ConfirmFastTravel(currState)
  local fastTravelList = currState.menu:GetList("FastTravelList")
  local currFastTravelMarkerInfo = fastTravelList:GetSelectedItem()
  local isDiscoveredButLocked = currFastTravelMarkerInfo.State == tweaks.eTokenState.kDiscoveredButLocked
  if self.currMarkerID ~= nil and Map.MarkerHasAnyFlag(self.currMarkerID, fastTravelMarkerFlags) and self:IsPlayerAtMarker(currFastTravelMarkerInfo) == false and self.fastTravelCancelled == false and not isDiscoveredButLocked then
    self.fastTravelPointSelected = true
    util.CallScriptOnCurrentInteractObject("TriggerFastTravelPointSelected", currFastTravelMarkerInfo.Id)
    self:Menu_Options_ReleaseHandler(false)
  end
end
function MapOn:Menu_Back_ReleaseHandler()
  if self.isOpenedForFastTravel == true and self.fastTravelPointSelected == false then
    self.fastTravelCancelled = true
    util.CallScriptOnCurrentInteractObject("TriggerFastTravelCancel")
  end
  self:SendEventToUIFsm("globalMenu", "EVT_TURN_OFF_GLOBAL_MENU")
end
function MapOn:Menu_Square_ReleaseHandler()
  local currRootQuestID = questUtil.GetRootQuestID(self.currQuestID)

  if not questUtil.IsValidID(currRootQuestID) then
    _G.CompletionistMapV100PlayerMarkerVisible =
      not (_G.CompletionistMapV100PlayerMarkerVisible ~= false)

    local visible =
      _G.CompletionistMapV100PlayerMarkerVisible ~= false

    if self.playerIconGO ~= nil then
      if visible and self:ShouldShowPlayerMarker() then
        self.playerIconGO:Show()
      else
        self.playerIconGO:Hide()
      end
    end

    if self.completionistMapV100Menu ~= nil then
      local text =
        visible and
        "[SquareButton] Hide Kratos" or
        "[SquareButton] Show Kratos"

      self.completionistMapV100Menu:UpdateFooterButton(
        "GoToJournal",
        true,
        text
      )
      self.completionistMapV100Menu:UpdateFooterButtonText()
    end

    print("[CompletionistMap v0.10.1] PLAYER_MARKER_TOGGLE" ..
      " visible=" .. tostring(visible))
    Audio.PlaySound("SND_UX_Pause_Menu_Map_Region_Hover_Tick")
    return
  end  local currRootQuestID = questUtil.GetRootQuestID(self.currQuestID)
  if questUtil.IsValidID(currRootQuestID) then
    local goFlourish = util.GetUiObjByName("CursorInfo_Top")
    goFlourish:Show()
    local animRate = 1
    local animStartTime = 0
    local animEndTime = 1
    UI.Anim(goFlourish, consts.AS_Forward, "", animRate, animStartTime, animEndTime)
    self:SendEventToUIFsm("globalMenu", "EVT_GO_TO_QUEST", currRootQuestID)
    Audio.PlaySound("SND_UX_Pause_Menu_Map_Jump_To_Journal")
  end
end
function MapOn:Menu_Triangle_ReleaseHandler()
  self:SendEventToUIFsm("globalMenu", "EVT_OPEN_SETTINGS_MENU")
end
function MapOn:Menu_Options_ReleaseHandler()
  self:Menu_Back_ReleaseHandler()
end
function MapOn:FindNextMarker(direction)
  local startIndex = self.jumpToMarkerIndex
  local trackedMarker = false
  local cursorAtMarker = false
  repeat
    self.jumpToMarkerIndex = self.jumpToMarkerIndex + direction
    if self.jumpToMarkerIndex < 0 then
      self.jumpToMarkerIndex = #self.markers
    end
    if self.jumpToMarkerIndex > #self.markers then
      self.jumpToMarkerIndex = 0
    end
    trackedMarker = self.jumpToMarkerIndex == 0 or self:GetMapMarkerTrackingState(self.markers[self.jumpToMarkerIndex].Id) == questConsts.TRACKING_STATE_TRACKED
    cursorAtMarker = self.jumpToMarkerIndex == 0 and self.currMarkerPlayerIcon or self.jumpToMarkerIndex ~= 0 and self.currMarkerID ~= nil and self.markers[self.jumpToMarkerIndex].Id == self.currMarkerID
  until not (not trackedMarker or cursorAtMarker) or startIndex == self.jumpToMarkerIndex
  if self.jumpToMarkerIndex == 0 and not self:ShouldShowPlayerMarker() and mapUtil.GetPlayerRealm() == self.currRealmName and self.markers[1] ~= nil and self:GetMapMarkerTrackingState(self.markers[1].Id) == questConsts.TRACKING_STATE_TRACKED then
    self.jumpToMarkerIndex = 1
  end
end
function MapOn:JumpToMarker()
  if self.jumpToMarkerIndex == 0 and self:ShouldShowPlayerMarker() then
    Camera.PointAtGO(self.playerIconGO)
  elseif self.markers[self.jumpToMarkerIndex] ~= nil then
    Camera.PointAtGO(self.markers[self.jumpToMarkerIndex].iconGO)
  end
end
function MapOn:EVT_R2_Release()
  if self.isOpenedForFastTravel or not tutorialUtil.AreEventsAllowed({
    "EVT_R2_Release"
  }) then
    return true
  end
  self:Menu_Next_Filter(1)
end
function MapOn:EVT_L2_Release()
  if self.isOpenedForFastTravel or not tutorialUtil.AreEventsAllowed({
    "EVT_L2_Release"
  }) then
    return true
  end
  self:Menu_Next_Filter(-1)
end
function MapOn:EVT_R3_Release()
  if self.isOpenedForFastTravel or not tutorialUtil.AreEventsAllowed({
    "EVT_R3_Release"
  }) then
    return true
  end
  if #self.markers == 0 and self.currMarkerPlayerIcon then
    return
  end
  self:FindNextMarker(1)
  self:JumpToMarker()
  Audio.PlaySound("SND_UX_Pause_Menu_Map_MoveTo_Active_Marker_LP")
  self.playingMoveToActiveMarker = true
end
function MapOn:EVT_MAPCURSOR_ARRIVED_AT_TARGET()
  if self.playingMoveToActiveMarker then
    Audio.StopSound("SND_UX_Pause_Menu_Map_MoveTo_Active_Marker_LP")
    self.playingMoveToActiveMarker = false
  end
end
function MapOn:MouseClickHandler(currState)
  for key, button in ipairs(self.goFilterButtons) do
    if UI.GetEventSenderGameObject() == button then
      local first = self.completionistMapV100FilterWindowFirst or 1
      local desired = first + key - 1
      if desired <= #self.filterButtonMapping then
        self:Menu_Next_Filter(desired - self.filterIndex)
      end
      return
    end
  end
  for i = 1, #self.realmMarkerInfo do
    local markerInfo = self.realmMarkerInfo[i]
    if markerInfo.iconGO ~= nil and UI.GetEventSenderGameObject() == markerInfo.iconGO then
      if self.isOpenedForFastTravel and Map.MarkerHasAnyFlag(markerInfo.Id, fastTravelMarkerFlags) then
        local fastTravelList = currState.menu:GetList("FastTravelList")
        if markerInfo == fastTravelList:GetSelectedItem() then
          Camera.PointAtGO(markerInfo.iconGO)
        else
          self:SelectFastTravelButtonByMarkerInfo(currState, markerInfo)
        end
        self.clickedMarkerInfo = nil
        self.clickedPlayer = false
      else
        Camera.PointAtGO(markerInfo.iconGO)
        self.clickedMarkerInfo = markerInfo
        self.clickedPlayer = false
      end
    end
  end
  if UI.GetEventSenderGameObject() == self.playerIconGO then
    Camera.PointAtGO(self.playerIconGO)
    if self.isOpenedForFastTravel then
      self.clickedMarkerInfo = nil
      self.clickedPlayer = true
    end
  end
end
function MapOn:Menu_Next_Filter(direction)
  if self.isOpenedForFastTravel then return end
  self.filterIndex =
    (self.filterIndex + direction - 1) % #self.filterButtonMapping + 1

  local logical = self.filterButtonMapping[self.filterIndex]
  if logical ~= nil and logical > 0 then
    self.markerIncludeFlags = markerFilters[logical].markerIncludeFlags
    self:GetAlwaysOnMarkers()
    self:GetMarkers()
  else
    self:ClearMarkers(true)
  end

  self:UpdateIcons()
  CompletionistMapV100_RefreshCustomPins(self)
  self:UpdateFilterUI()
  self.jumpToMarkerIndex = 0
  self:UpdateMapMarkerHighlights()
  Audio.PlaySound("SND_UX_Pause_Menu_Map_Filters_Tick")
  print("[CompletionistMap v0.10.1] FILTER_CHANGE" ..
    " logical=" .. tostring(logical) ..
    " index=" .. tostring(self.filterIndex))
end

function MapOn:UpdateFilterButtonMapping()
  self.filterButtonMapping = {1}
  self.filterIndex = 1
  self.markerIncludeFlags = markerFilters[1].markerIncludeFlags

  for filterIndex = 2, #markerFilters do
    local markerIncludeFlags = markerFilters[filterIndex].markerIncludeFlags
    for i = 1, #self.realmMarkerInfo do
      local markerInfo = self.realmMarkerInfo[i]
      if Map.MarkerHasAnyFlag(markerInfo.Id, markerIncludeFlags) and
          mapUtil.MapMarkerInfoHasStates(markerInfo, markerStates) then
        self.filterButtonMapping[#self.filterButtonMapping + 1] = filterIndex
        break
      end
    end
  end

  if self.currRealmName == "Midgard" then
    self.filterButtonMapping[#self.filterButtonMapping + 1] = COMPLETIONIST_FILTER
    self.filterButtonMapping[#self.filterButtonMapping + 1] = RAVEN_FILTER
    self.filterButtonMapping[#self.filterButtonMapping + 1] = NORNIR_CHEST_FILTER
    self.filterButtonMapping[#self.filterButtonMapping + 1] = NORNIR_PUZZLE_FILTER

    print("[CompletionistMap v0.10.1] FILTER_MAPPING" ..
      " total=" .. tostring(#self.filterButtonMapping) ..
      " completionist=true")
  end

  self:UpdateFilterUI()
end

function MapOn:UpdateFilterUI()
  local logical = self.filterButtonMapping[self.filterIndex] or 1
  local label = completionistFilterLabels[logical]
  if label ~= nil then
    UI.SetText(self.thFilterLabel, label)
  else
    UI.SetText(self.thFilterLabel, util.GetLAMSMsg(markerFilters[logical].name))
  end

  local total = #self.filterButtonMapping
  local visible = math.min(#self.goFilterButtons, total)
  local first = 1
  if total > visible then
    first = self.filterIndex - math.floor(visible / 2)
    if first < 1 then first = 1 end
    local maxFirst = total - visible + 1
    if first > maxFirst then first = maxFirst end
  end
  self.completionistMapV100FilterWindowFirst = first

  local posOffset = (#self.goFilterButtons - visible) * 0.2
  for slot = 1, #self.goFilterButtons do
    local button = self.goFilterButtons[slot]
    if slot <= visible then
      local logicalIndex = first + slot - 1
      local pos = engine.Vector.New(
        self.goFilterButtonPositions[slot].x + posOffset,
        self.goFilterButtonPositions[slot].y,
        self.goFilterButtonPositions[slot].z
      )
      button:SetWorldPosition(pos)
      button:Show()
      local selected = logicalIndex == self.filterIndex
      UI.Anim(
        button,
        consts.AS_Forward,
        "",
        consts.DEFAULT_BUTTON_ANIM_RATE,
        selected and 0 or 0.5,
        selected and 0.5 or 1
      )
    else
      UI.Anim(button, consts.AS_Reset, "", 0, 0)
      button:Hide()
    end
  end
end
function MapOn:ShowOnCompass(currState)
  if self.completionistMapV100NornirChestSelected ~= nil then
    CompletionistMapV100_ClearStockCompass(self, "custom_nornir_chest")
    local pin = self.completionistMapV100NornirChestSelected
    if not CompletionistMapV100_IsNornirChestRemaining(pin) then
      self.completionistMapV100NornirChestSelected = nil
      return
    end
    local target = _G.CompletionistMapV100Target
    local sameTarget = target ~= nil and
      target.type == "NornirChest" and
      target.registryKey == pin.registryKey
    if sameTarget and target.active then
      target.active = false
      Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass")
    else
      target.type = "NornirChest"
      target.realm = "Midgard"
      target.registryKey = pin.registryKey
      target.keyIndex = nil
      target.regionQuest = nil
      target.x = pin.worldX
      target.y = pin.worldY
      target.z = pin.worldZ
      target.mapX = pin.mapX
      target.mapZ = pin.mapZ
      target.collected = false
      target.active = true
      _G.CompletionistMapV100TargetCollectedNornirLogged = false
      _G.CompletionistMapV100NornirTargetGeneration =
        (_G.CompletionistMapV100NornirTargetGeneration or 0) + 1
      Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass")
    end
    CompletionistMapV100_NornirChestReticle(self, currState, pin)
    print("[CompletionistMap v0.10.1] NORNIR_CHEST_COMPASS" ..
      " active=" .. tostring(target.active) ..
      " registryKey=" .. tostring(pin.registryKey) ..
      " x=" .. tostring(pin.worldX) ..
      " y=" .. tostring(pin.worldY) ..
      " z=" .. tostring(pin.worldZ))
    return
  end

  if self.completionistMapV100NornirSelected ~= nil then
    CompletionistMapV100_ClearStockCompass(self, "custom_nornir_puzzle")
    local pin = self.completionistMapV100NornirSelected

    if not CompletionistMapV100_IsNornirKeyRemaining(pin) then
      self.completionistMapV100NornirSelected = nil
      return
    end

    local target = _G.CompletionistMapV100Target
    local sameTarget =
      target ~= nil and
      target.type == "NornirPuzzle" and
      target.registryKey == pin.registryKey and
      target.keyIndex == pin.keyIndex

    if sameTarget and target.active then
      target.active = false
      Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass")
    else
      target.type = "NornirPuzzle"
      target.realm = "Midgard"
      target.registryKey = pin.registryKey
      target.keyIndex = pin.keyIndex
      target.keyType = pin.keyType
      target.regionQuest = nil
      target.x = pin.worldX
      target.y = pin.worldY
      target.z = pin.worldZ
      target.mapX = pin.mapX
      target.mapZ = pin.mapZ
      target.collected = false
      target.active = true
      _G.CompletionistMapV100NornirTargetGeneration =
        (_G.CompletionistMapV100NornirTargetGeneration or 0) + 1
      Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass")
    end

    CompletionistMapV100_NornirReticle(self, currState, pin)

    print("[CompletionistMap v0.10.1] NORNIR_COMPASS" ..
      " active=" .. tostring(target.active) ..
      " registryKey=" .. tostring(pin.registryKey) ..
      " index=" .. tostring(pin.keyIndex) ..
      " x=" .. tostring(pin.worldX) ..
      " y=" .. tostring(pin.worldY) ..
      " z=" .. tostring(pin.worldZ))
    return
  end

  if self.completionistMapV100Selected then
    CompletionistMapV100_ClearStockCompass(self, "custom_raven")
    local target = _G.CompletionistMapV100Target

    if CompletionistMapV100_IsRavenCollected() then
      if target ~= nil and target.type == "Raven" then
        target.active = false
        target.collected = true
      end
      self.completionistMapV100Selected = false
      print("[CompletionistMap v0.10.1] CUSTOM_COMPASS refused=raven_collected")
      return
    end

    local sameTarget = target ~= nil and target.type == "Raven"

    if sameTarget and target.active then
      target.active = false
      Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass")
    else
      target.type = "Raven"
      target.realm = "Midgard"
      target.regionQuest = "RegionSummary_VF_Raven_Parent"
      target.registryKey = nil
      target.keyIndex = nil
      target.x = COMPLETIONIST_RAVEN_WORLD_X
      target.y = COMPLETIONIST_RAVEN_WORLD_Y
      target.z = COMPLETIONIST_RAVEN_WORLD_Z
      target.mapX = COMPLETIONIST_RAVEN_MAP_X
      target.mapZ = COMPLETIONIST_RAVEN_MAP_Z
      target.collected = false
      target.active = true
      _G.CompletionistMapV100TargetCollectedNornirLogged = false
      Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass")
    end

    CompletionistMapV100_ShowReticle(self, currState)

    print("[CompletionistMap v0.10.1] CUSTOM_COMPASS" ..
      " active=" .. tostring(target.active) ..
      " mode=hud_native_visual_proof" ..
      " x=" .. tostring(target.x) ..
      " y=" .. tostring(target.y) ..
      " z=" .. tostring(target.z))
    return
  end
  local completionistTarget = _G.CompletionistMapV100Target
  if completionistTarget ~= nil and
      completionistTarget.active == true and
      self.currMarkerID ~= nil then
    completionistTarget.active = false
    print("[CompletionistMap v0.10.1] CUSTOM_COMPASS_CLEAR" ..
      " reason=stock_marker_selected" ..
      " type=" .. tostring(completionistTarget.type))
  end
  local updatePrompt = false
  if self.currMarkerID ~= nil then
    if not Map.MarkerHasAnyFlag(self.currMarkerID, enabledShowOnCompassMarkerFlags) then
      return
    end
    updatePrompt = true
    if self.currMarkerID == self.currShownMarkerID then
      game.Compass.HideMarker(self.currShownMarkerID)
      Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass")
      self.currShownMarkerID = nil
    else
      if self.currShownMarkerID ~= nil then
        game.Compass.HideMarker(self.currShownMarkerID)
      end
      local markerType
      for i = 1, #enabledShowOnCompassMarkerFlags do
        local enabledMarkerFlag = enabledShowOnCompassMarkerFlags[i]
        if Map.MarkerHasFlag(self.currMarkerID, {enabledMarkerFlag}) then
          markerType = enabledMarkerFlag
          break
        end
      end
      assert(markerType ~= nil, "unable to find ShowOnCompass marker type")
      game.Compass.ShowMarker(self.currMarkerID, markerType)
      Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass")
      self.currShownMarkerID = self.currMarkerID
    end
  elseif self.currShownMarkerID ~= nil then
    updatePrompt = true
    game.Compass.HideMarker(self.currShownMarkerID)
    self.currShownMarkerID = nil
  end
  if updatePrompt then
    local currMenu = currState.menu
    local showShowOnCompass, text = self:GetShowOnCompassPrompt(currMenu)
    local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
    goMapCursorText:Show()
    local goCursorInfo_Top = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
    local thPrompt = util.GetTextHandle(goCursorInfo_Top, "CursorAction_Text")
    UI.SetTextIsClickable(thPrompt)
    UI.SetText(thPrompt, showShowOnCompass and text or "")
    self:UpdateMapMarkerHighlights()
    currMenu:UpdateFooterButton("ShowOnCompass", showShowOnCompass, text)
    currMenu:UpdateFooterButtonText()
  end
end
function MapOn:EVT_TURN_OFF_MAP_MENU()
  self:Goto("MapOff")
end
function Midgard:Setup()
  self.mapOn = self:GetState("MapOn")
  self.mapOn:SubmenuSetup(self)
end
function Midgard:Enter()
  self.mapOn:SubmenuEnter(self, "Midgard")
end
function Midgard:Exit()
  self.mapOn:SubmenuExit(self)
end
function Midgard:EVT_HandleMapCollisionChangeHook(collisionGameObjectTable)
  self.mapOn:MapCollisionChangeHandler(self, collisionGameObjectTable, "Midgard")
end
function Midgard:EVT_MOUSE_CLICKED()
  self.mapOn:MouseClickHandler(self)
end
function Alfheim:Setup()
  self.mapOn = self:GetState("MapOn")
  self.mapOn:SubmenuSetup(self)
end
function Alfheim:Enter()
  self.mapOn:SubmenuEnter(self, "Alfheim")
end
function Alfheim:Exit()
  self.mapOn:SubmenuExit(self)
end
function Alfheim:EVT_HandleMapCollisionChangeHook(collisionGameObjectTable)
  self.mapOn:MapCollisionChangeHandler(self, collisionGameObjectTable, "Alfheim")
end
function Alfheim:EVT_MOUSE_CLICKED()
  self.mapOn:MouseClickHandler(self)
end
function Helheim:Setup()
  self.mapOn = self:GetState("MapOn")
  self.mapOn:SubmenuSetup(self)
end
function Helheim:Enter()
  self.mapOn:SubmenuEnter(self, "Helheim")
end
function Helheim:Exit()
  self.mapOn:SubmenuExit(self)
end
function Helheim:EVT_HandleMapCollisionChangeHook(collisionGameObjectTable)
  self.mapOn:MapCollisionChangeHandler(self, collisionGameObjectTable, "Helheim")
end
function Helheim:EVT_MOUSE_CLICKED()
  self.mapOn:MouseClickHandler(self)
end
function Jotunheim:Setup()
  self.mapOn = self:GetState("MapOn")
  self.mapOn:SubmenuSetup(self)
end
function Jotunheim:Enter()
  self.mapOn:SubmenuEnter(self, "Jotunheim")
end
function Jotunheim:Exit()
  self.mapOn:SubmenuExit(self)
end
function Jotunheim:EVT_HandleMapCollisionChangeHook(collisionGameObjectTable)
  self.mapOn:MapCollisionChangeHandler(self, collisionGameObjectTable, "Jotunheim")
end
function Jotunheim:EVT_MOUSE_CLICKED()
  self.mapOn:MouseClickHandler(self)
end
function Niflheim:Setup()
  self.mapOn = self:GetState("MapOn")
  self.mapOn:SubmenuSetup(self)
end
function Niflheim:Enter()
  self.mapOn:SubmenuEnter(self, "Niflheim")
end
function Niflheim:Exit()
  self.mapOn:SubmenuExit(self)
end
function Niflheim:EVT_HandleMapCollisionChangeHook(collisionGameObjectTable)
  self.mapOn:MapCollisionChangeHandler(self, collisionGameObjectTable, "Niflheim")
end
function Niflheim:EVT_MOUSE_CLICKED()
  self.mapOn:MouseClickHandler(self)
end
function Muspelheim:Setup()
  self.mapOn = self:GetState("MapOn")
  self.mapOn:SubmenuSetup(self)
end
function Muspelheim:Enter()
  self.mapOn:SubmenuEnter(self, "Muspelheim")
end
function Muspelheim:Exit()
  self.mapOn:SubmenuExit(self)
end
function Muspelheim:EVT_HandleMapCollisionChangeHook(collisionGameObjectTable)
  self.mapOn:MapCollisionChangeHandler(self, collisionGameObjectTable, "Muspelheim")
end
function Muspelheim:EVT_MOUSE_CLICKED()
  self.mapOn:MouseClickHandler(self)
end
function Svartalheim:Setup()
  self.mapOn = self:GetState("MapOn")
  self.mapOn:SubmenuSetup(self)
end
function Svartalheim:Enter()
  self.mapOn:SubmenuEnter(self, "Svartalheim")
end
function Svartalheim:Exit()
  self.mapOn:SubmenuExit(self)
end
function Svartalheim:EVT_HandleMapCollisionChangeHook(collisionGameObjectTable)
  self.mapOn:MapCollisionChangeHandler(self, collisionGameObjectTable, "Svartalheim")
end
function Svartalheim:EVT_MOUSE_CLICKED()
  self.mapOn:MouseClickHandler(self)
end
function Vanaheim:Setup()
  self.mapOn = self:GetState("MapOn")
  self.mapOn:SubmenuSetup(self)
end
function Vanaheim:Enter()
  self.mapOn:SubmenuEnter(self, "Vanaheim")
end
function Vanaheim:Exit()
  self.mapOn:SubmenuExit(self)
end
function Vanaheim:EVT_HandleMapCollisionChangeHook(collisionGameObjectTable)
  self.mapOn:MapCollisionChangeHandler(self, collisionGameObjectTable, "Vanaheim")
end
function Vanaheim:EVT_MOUSE_CLICKED()
  self.mapOn:MouseClickHandler(self)
end
function Asgard:Setup()
  self.mapOn = self:GetState("MapOn")
  self.mapOn:SubmenuSetup(self)
end
function Asgard:Enter()
  self.mapOn:SubmenuEnter(self, "Asgard")
end
function Asgard:Exit()
  self.mapOn:SubmenuExit(self)
end
function Asgard:EVT_HandleMapCollisionChangeHook(collisionGameObjectTable)
  self.mapOn:MapCollisionChangeHandler(self, collisionGameObjectTable, "Asgard")
end
function Asgard:EVT_MOUSE_CLICKED()
  self.mapOn:MouseClickHandler(self)
end
function MapMenu:OnSaveCheckpoint(tab)
end
function MapMenu:OnRestoreCheckpoint(tab)
end



-- BEGIN COMPLETIONIST V0.10.4 RAVEN REGISTERED CLASS RUNTIME PROOF
--
-- Field proof for the corrected, grown r_ui.wad candidate. The authored Raven
-- marker points directly at goMapIconCompletionistRaven. No Dock map proxy is
-- created. The visual payload still carries cloned stock Dock pixels at this
-- gate on purpose; custom Raven texpack artwork is a separate later variable.
do
  local prefix = "[CompletionistMap v0.10.4-raven-registered-runtime] "
  local candidate = "Completionist_V103_Veithurgard_Raven_01"
  local expectedMapResource = "goMapIconCompletionistRaven"

  local function log(category, fields)
    print(prefix .. category .. " " .. fields)
  end

  local function safeField(tab, name)
    if tab == nil then return nil end
    local ok, value = pcall(function() return tab[name] end)
    if ok then return value end
    return nil
  end

  local function safeName(go)
    if go == nil then return "<nil>" end
    local ok, value = pcall(function() return go:GetName() end)
    if ok and value ~= nil then return tostring(value) end
    return "<name-unavailable>"
  end

  local function getRegionId(info, markerId)
    for _, name in ipairs({"regionId", "RegionId", "RegionID", "regionID"}) do
      local value = safeField(info, name)
      if value ~= nil then return value, "marker_info." .. name end
    end

    local callOK, found, region = pcall(function()
      return game.Map.FindRegionFromMarker(markerId)
    end)
    if not callOK then
      return nil, "FindRegionFromMarker.error=" .. tostring(found)
    end
    if found ~= true or region == nil then
      return nil, "FindRegionFromMarker.not_found"
    end
    return region, "FindRegionFromMarker.region"
  end

  CompletionistMapV100_CreateMapPin = function(self, currState)
    if self == nil or self.currRealmName ~= "Midgard" then return end

    CompletionistMapV100_DestroyMapPin(self)
    if CompletionistMapV100_IsRavenCollected() then
      log("REGISTERED_RESULT", "active=false reason=raven_collected dockProxyUsed=false")
      return
    end

    local infoOK, info = pcall(function()
      return game.Map.GetMarkerInfo(candidate)
    end)
    if not infoOK or info == nil then
      log("REGISTERED_RESULT",
        "active=false reason=marker_info_failed dockProxyUsed=false error=" .. tostring(info))
      return
    end

    local markerId = safeField(info, "Id") or safeField(info, "id")
    local markerIcon = safeField(info, "Icon") or safeField(info, "icon") or
      safeField(info, "IconName") or safeField(info, "iconName")
    local markerState = safeField(info, "State") or safeField(info, "state")
    local regionId, regionSource = getRegionId(info, markerId)

    log("REGISTERED_PREFLIGHT",
      "candidate=" .. candidate ..
      " id=" .. tostring(markerId) ..
      " authoredIcon=" .. tostring(markerIcon) ..
      " state=" .. tostring(markerState) ..
      " region=" .. tostring(regionId) ..
      " regionType=" .. tostring(type(regionId)) ..
      " regionSource=" .. tostring(regionSource) ..
      " expectedMapResource=" .. expectedMapResource ..
      " compassType=DockPoint" ..
      " texpackLoaded=false" ..
      " dockProxyUsed=false")

    if markerId == nil or regionId == nil then
      log("REGISTERED_RESULT", "active=false reason=id_or_region_unresolved dockProxyUsed=false")
      return
    end

    local createOK, newGO = pcall(function()
      return Map.CreateMarkerIcon(markerId, regionId, "")
    end)
    if not createOK or newGO == nil then
      log("REGISTERED_RESULT",
        "active=false reason=CreateMarkerIcon_failed regionSource=" .. tostring(regionSource) ..
        " dockProxyUsed=false error=" .. tostring(newGO))
      return
    end

    local clickableOK, clickableErr = pcall(function() UI.SetIsClickable(newGO) end)
    local showOK, showErr = pcall(function() newGO:Show() end)
    if not showOK then
      pcall(function() Map.RecycleIcon(newGO) end)
      log("REGISTERED_RESULT",
        "active=false reason=show_failed dockProxyUsed=false error=" .. tostring(showErr))
      return
    end

    self.completionistMapV100MapIconGO = newGO
    self.completionistMapV100MapIconFrames = 0
    CompletionistMapV100_LogIconCapabilities(newGO, "raven_registered_class_runtime")

    local goName = safeName(newGO)
    local posOK, pos = pcall(function() return newGO:GetWorldPosition() end)
    local looksLikeDedicatedName = string.find(string.lower(goName), "completionistraven", 1, true) ~= nil
    local isDockGO = string.lower(goName) == "mapicondock"

    log("REGISTERED_RESULT",
      "active=true" ..
      " candidate=" .. candidate ..
      " resourceExpected=" .. expectedMapResource ..
      " goName=" .. goName ..
      " dedicatedNameObserved=" .. tostring(looksLikeDedicatedName) ..
      " dockGOObserved=" .. tostring(isDockGO) ..
      " clickableOK=" .. tostring(clickableOK) ..
      " clickableError=" .. tostring(clickableErr) ..
      " nativePlacement=" .. tostring(posOK and pos ~= nil) ..
      " position=" .. (posOK and pos ~= nil and
        ("x=" .. tostring(pos.x) .. ",y=" .. tostring(pos.y) .. ",z=" .. tostring(pos.z)) or "<unavailable>") ..
      " texpackLoaded=false" ..
      " dockProxyUsed=false")
  end

  log("REGISTERED_API",
    "installed=true candidate=" .. candidate ..
    " mapResource=" .. expectedMapResource ..
    " compassType=DockPoint" ..
    " texpackLoaded=false" ..
    " dockProxyUsed=false" ..
    " callsOnLoad=false")
end
-- END COMPLETIONIST V0.10.4 RAVEN REGISTERED CLASS RUNTIME PROOF
-- BEGIN COMPLETIONIST V0.10.4 RAVEN ARTWORK LAYER PROOF
--
-- Visual-only diagnostic layered on the proven corrected registered class.
-- The custom Raven texpack is active and this bridge renders the dedicated
-- goMapIconCompletionistRaven map object directly. For this diagnostic only,
-- the map icon is allowed to render even when the tested Raven has already been
-- collected so artwork can still be inspected. No marker state, save state,
-- progression value, or native compass state is changed here.
do
  local prefix = "[CompletionistMap v0.10.4-raven-artwork] "
  local candidate = "Completionist_V103_Veithurgard_Raven_01"
  local expectedMapResource = "goMapIconCompletionistRaven"

  local function log(category, fields)
    print(prefix .. category .. " " .. fields)
  end

  local function safeField(tab, name)
    if tab == nil then return nil end
    local ok, value = pcall(function() return tab[name] end)
    if ok then return value end
    return nil
  end

  local function safeName(go)
    if go == nil then return "<nil>" end
    local ok, value = pcall(function() return go:GetName() end)
    if ok and value ~= nil then return tostring(value) end
    return "<name-unavailable>"
  end

  local function getRegionId(info, markerId)
    for _, name in ipairs({"regionId", "RegionId", "RegionID", "regionID"}) do
      local value = safeField(info, name)
      if value ~= nil then return value, "marker_info." .. name end
    end

    local callOK, found, region = pcall(function()
      return game.Map.FindRegionFromMarker(markerId)
    end)
    if not callOK then
      return nil, "FindRegionFromMarker.error=" .. tostring(found)
    end
    if found ~= true or region == nil then
      return nil, "FindRegionFromMarker.not_found"
    end
    return region, "FindRegionFromMarker.region"
  end

  CompletionistMapV100_CreateMapPin = function(self, currState)
    if self == nil or self.currRealmName ~= "Midgard" then return end

    CompletionistMapV100_DestroyMapPin(self)

    local collected = false
    local collectedOK, collectedValue = pcall(function()
      return CompletionistMapV100_IsRavenCollected()
    end)
    if collectedOK then collected = collectedValue == true end

    local infoOK, info = pcall(function()
      return game.Map.GetMarkerInfo(candidate)
    end)
    if not infoOK or info == nil then
      log("ART_RESULT",
        "active=false reason=marker_info_failed error=" .. tostring(info) ..
        " diagnosticShowEvenIfCollected=true progressionWritten=false")
      return
    end

    local markerId = safeField(info, "Id") or safeField(info, "id")
    local markerState = safeField(info, "State") or safeField(info, "state")
    local regionId, regionSource = getRegionId(info, markerId)

    log("ART_PREFLIGHT",
      "candidate=" .. candidate ..
      " id=" .. tostring(markerId) ..
      " state=" .. tostring(markerState) ..
      " collected=" .. tostring(collected) ..
      " region=" .. tostring(regionId) ..
      " regionType=" .. tostring(type(regionId)) ..
      " regionSource=" .. tostring(regionSource) ..
      " expectedMapResource=" .. expectedMapResource ..
      " texpackLoaded=true" ..
      " diagnosticShowEvenIfCollected=true" ..
      " dockProxyUsed=false" ..
      " progressionWritten=false")

    if markerId == nil or regionId == nil then
      log("ART_RESULT", "active=false reason=id_or_region_unresolved progressionWritten=false")
      return
    end

    local createOK, newGO = pcall(function()
      return Map.CreateMarkerIcon(markerId, regionId, "")
    end)
    if not createOK or newGO == nil then
      log("ART_RESULT",
        "active=false reason=CreateMarkerIcon_failed error=" .. tostring(newGO) ..
        " progressionWritten=false")
      return
    end

    local clickableOK, clickableErr = pcall(function() UI.SetIsClickable(newGO) end)
    local showOK, showErr = pcall(function() newGO:Show() end)
    if not showOK then
      pcall(function() Map.RecycleIcon(newGO) end)
      log("ART_RESULT",
        "active=false reason=show_failed error=" .. tostring(showErr) ..
        " progressionWritten=false")
      return
    end

    self.completionistMapV100MapIconGO = newGO
    self.completionistMapV100MapIconFrames = 0
    CompletionistMapV100_LogIconCapabilities(newGO, "raven_artwork_layer")

    local goName = safeName(newGO)
    local posOK, pos = pcall(function() return newGO:GetWorldPosition() end)
    local dedicated = string.find(string.lower(goName), "completionistraven", 1, true) ~= nil

    log("ART_RESULT",
      "active=true" ..
      " candidate=" .. candidate ..
      " resourceExpected=" .. expectedMapResource ..
      " goName=" .. goName ..
      " dedicatedNameObserved=" .. tostring(dedicated) ..
      " collectedAtRender=" .. tostring(collected) ..
      " clickableOK=" .. tostring(clickableOK) ..
      " clickableError=" .. tostring(clickableErr) ..
      " nativePlacement=" .. tostring(posOK and pos ~= nil) ..
      " position=" .. (posOK and pos ~= nil and
        ("x=" .. tostring(pos.x) .. ",y=" .. tostring(pos.y) .. ",z=" .. tostring(pos.z)) or "<unavailable>") ..
      " texpackLoaded=true" ..
      " diagnosticShowEvenIfCollected=true" ..
      " dockProxyUsed=false" ..
      " progressionWritten=false")
  end

  _G.CompletionistMapV104RavenArtworkDiagnostic = true
  log("ART_API",
    "installed=true candidate=" .. candidate ..
    " mapResource=" .. expectedMapResource ..
    " texpackLoaded=true diagnosticShowEvenIfCollected=true" ..
    " compassType=DockPoint dockProxyUsed=false progressionWritten=false")
end
-- END COMPLETIONIST V0.10.4 RAVEN ARTWORK LAYER PROOF
-- BEGIN COMPLETIONIST V0.10.3 NATIVE RAVEN PRODUCTION BRIDGE
-- Raven-only production candidate for the native compass path proven in the
-- v0.10.3 live field test. This maps the existing Completionist Raven map
-- selection to an independently-authored native map token and lets God of War
-- own compass position, distance and route behaviour.
--
-- No marker progression state is changed here. The native marker remains
-- InitState=0 in the authored DCB data and is addressed only by its dedicated ID.
do
  local prefix = "[CompletionistMap v0.10.3-native] "
  local candidate = "Completionist_V103_Veithurgard_Raven_01"
  local markerType = "CompletionistRaven"
  local originalPrompt = MapOn.GetShowOnCompassPrompt
  local originalShow = MapOn.ShowOnCompass
  local originalUpdate = MapOn.Update

  local verifyFrames = 0
  local verifyBucket = -1
  local promptIntent = nil
  local lastManagerShown = nil

  local function log(category, fields)
    print(prefix .. category .. " " .. fields)
  end

  local function ravenSelected(self)
    return self ~= nil and self.completionistMapV100Selected == true
  end

  local function candidateInfo()
    local ok, info = pcall(function()
      return game.Map.GetMarkerInfo(candidate)
    end)
    if not ok then
      return nil, "lookup_error=" .. tostring(info)
    end
    if info == nil then
      return nil, "registered=false"
    end
    return info, nil
  end

  local function shownState()
    local info = candidateInfo()
    local candidateId = info ~= nil and tostring(info.Id) or nil
    local ok, ids = pcall(function()
      return game.Compass.FindMarkersByIconClass(enabledShowOnCompassMarkerFlags)
    end)
    if not ok then
      return false, {}, false, tostring(ids)
    end

    local found = false
    local others = {}
    for _, id in ipairs(ids or {}) do
      if candidateId ~= nil and tostring(id) == candidateId then
        found = true
      else
        others[#others + 1] = id
      end
    end
    return found, others, true, nil
  end

  local function suppressLegacyRavenHud()
    local target = _G.CompletionistMapV100Target
    if target ~= nil and target.type == "Raven" and target.active == true then
      target.active = false
      log("LEGACY_R3L3_DISABLED", "reason=native_raven_tracking")
    end
  end

  local function updatePrompt(self, currState)
    if currState == nil or currState.menu == nil then return end

    local show, text = self:GetShowOnCompassPrompt(currState.menu)

    -- Keep the cursor-card copy and footer copy in sync. The native compass
    -- manager commits ShowMarker/HideMarker asynchronously, so GetShowOnCompassPrompt
    -- also honours promptIntent until the manager reports the requested state.
    local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
    if goMapCursorText ~= nil then
      goMapCursorText:Show()
      local goCursorInfoTop = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
      if goCursorInfoTop ~= nil then
        local thPrompt = util.GetTextHandle(goCursorInfoTop, "CursorAction_Text")
        if thPrompt ~= nil then
          UI.SetTextIsClickable(thPrompt)
          UI.SetText(thPrompt, show and text or "")
        end
        if show then
          goCursorInfoTop:Show()
        else
          goCursorInfoTop:Hide()
        end
      end
    end

    currState.menu:UpdateFooterButton("ShowOnCompass", show, text)
    currState.menu:UpdateFooterButtonText()

    log("NATIVE_RAVEN_PROMPT_REFRESH",
      "cursor=true footer=true visible=" .. tostring(show) ..
      " intent=" .. tostring(promptIntent) ..
      " text=" .. tostring(text))
  end

  local function refreshPromptFromLiveMap(self)
    if self ~= nil and self.menu ~= nil and ravenSelected(self) then
      updatePrompt(self, {menu = self.menu})
    end
  end

  local function hideCandidate(reason)
    local info = candidateInfo()
    local id = info ~= nil and tostring(info.Id) or "<missing>"
    log("NATIVE_RAVEN_HIDE", "stage=before reason=" .. tostring(reason) .. " id=" .. id)
    local ok, err = pcall(function()
      game.Compass.HideMarker(candidate)
    end)
    log("NATIVE_RAVEN_HIDE",
      "stage=lua_return ok=" .. tostring(ok) ..
      " error=" .. tostring(err))
    if ok then
      _G.CompletionistMapV103NativeRavenTracked = false
    end
    return ok
  end

  function MapOn:GetShowOnCompassPrompt(currMenu)
    if ravenSelected(self) then
      if CompletionistMapV100_IsRavenCollected() then
        return false, nil
      end
      if self.isOpenedForFastTravel or
          not game.Compass.HaveCompass() or
          self.currRealmName ~= mapUtil.GetPlayerRealm() or
          tutorialUtil.CurrentlyShowingStep() then
        return false, nil
      end

      local shown, others, queryOK = shownState()
      local lamsId = lamsConsts.AddToCompass

      -- Show/Hide is asynchronous in the native compass manager. Keep the UI
      -- on the user's requested state until shownState catches up, otherwise
      -- stock reticle refreshes can overwrite the prompt with the old text.
      if promptIntent == "tracked" then
        lamsId = lamsConsts.RemoveFromCompass
      elseif promptIntent == "untracked" then
        if queryOK and #others > 0 then
          lamsId = lamsConsts.ReplaceInCompass
        else
          lamsId = lamsConsts.AddToCompass
        end
      elseif queryOK and shown then
        lamsId = lamsConsts.RemoveFromCompass
      elseif queryOK and #others > 0 then
        lamsId = lamsConsts.ReplaceInCompass
      end
      return true, "[AdvanceButton] " .. util.GetLAMSMsg(lamsId)
    end

    return originalPrompt(self, currMenu)
  end

  function MapOn:ShowOnCompass(currState)
    if not ravenSelected(self) then
      return originalShow(self, currState)
    end

    if CompletionistMapV100_IsRavenCollected() then
      promptIntent = nil
      hideCandidate("raven_already_collected")
      self.completionistMapV100Selected = false
      updatePrompt(self, currState)
      return
    end

    local info, lookupError = candidateInfo()
    if info == nil then
      log("NATIVE_RAVEN_RESULT", "refused=candidate_missing " .. tostring(lookupError))
      return
    end

    local p = info.Coordinates
    local flagOK, hasDockFlag = pcall(function()
      return Map.MarkerHasFlag(candidate, {markerType})
    end)
    if not flagOK or hasDockFlag ~= true or p == nil then
      log("NATIVE_RAVEN_RESULT",
        "refused=preflight_failed flagOK=" .. tostring(flagOK) ..
        " dockFlag=" .. tostring(flagOK and hasDockFlag == true) ..
        " coordinates=" .. tostring(p ~= nil))
      return
    end

    local shown, others, queryOK, queryErr = shownState()
    if not queryOK then
      log("NATIVE_RAVEN_RESULT",
        "refused=active_marker_query_failed error=" .. tostring(queryErr))
      return
    end

    if shown then
      if hideCandidate("user_remove") then
        promptIntent = "untracked"
        self.currShownMarkerID = nil
        Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass")
      end
      updatePrompt(self, currState)
      return
    end

    -- Match stock Replace in Compass semantics without touching marker state.
    -- Hide only currently tracked compass targets returned by the native manager.
    for _, id in ipairs(others) do
      local hideOK, hideErr = pcall(function()
        game.Compass.HideMarker(id)
      end)
      log("NATIVE_RAVEN_REPLACE",
        "oldId=" .. tostring(id) ..
        " hideOK=" .. tostring(hideOK) ..
        " error=" .. tostring(hideErr))
    end

    suppressLegacyRavenHud()

    log("NATIVE_RAVEN_PREFLIGHT",
      "id=" .. tostring(info.Id) ..
      " state=" .. tostring(info.State) ..
      " wad=" .. tostring(info.WadName) ..
      " x=" .. tostring(p.x) ..
      " y=" .. tostring(p.y) ..
      " z=" .. tostring(p.z))
    log("NATIVE_RAVEN_SHOW",
      "stage=before id=" .. tostring(info.Id) ..
      " markerType=" .. tostring(markerType))

    local showOK, showErr = pcall(function()
      game.Compass.ShowMarker(candidate, markerType)
    end)
    log("NATIVE_RAVEN_SHOW",
      "stage=lua_return ok=" .. tostring(showOK) ..
      " error=" .. tostring(showErr))

    if not showOK then
      promptIntent = nil
      log("NATIVE_RAVEN_RESULT", "active=false reason=lua_wrapper_failed")
      return
    end

    promptIntent = "tracked"
    self.currShownMarkerID = info.Id
    _G.CompletionistMapV103NativeRavenTracked = true
    verifyFrames = 0
    verifyBucket = -1
    Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass")
    updatePrompt(self, currState)
    log("NATIVE_RAVEN_RESULT", "request_queued=true active=true")
  end

  function MapOn:Update(...)
    local result = originalUpdate(self, ...)

    local shown, _, queryOK = shownState()
    if queryOK then
      local settledIntent = false
      if promptIntent == "tracked" and shown then
        promptIntent = nil
        settledIntent = true
        log("NATIVE_RAVEN_PROMPT_SETTLED", "state=tracked")
      elseif promptIntent == "untracked" and not shown then
        promptIntent = nil
        settledIntent = true
        log("NATIVE_RAVEN_PROMPT_SETTLED", "state=untracked")
      end

      if ravenSelected(self) and
          (settledIntent or lastManagerShown == nil or shown ~= lastManagerShown) then
        refreshPromptFromLiveMap(self)
      end
      lastManagerShown = shown
    end

    if queryOK and shown then
      _G.CompletionistMapV103NativeRavenTracked = true
      suppressLegacyRavenHud()

      if CompletionistMapV100_IsRavenCollected() then
        promptIntent = nil
        hideCandidate("raven_collected_map_update")
      else
        verifyFrames = verifyFrames + 1
        local bucket = math.floor(verifyFrames / 300)
        if bucket ~= verifyBucket then
          verifyBucket = bucket
          log("NATIVE_RAVEN_VERIFY",
            "active=true frame=" .. tostring(verifyFrames) ..
            " native_manager=true")
        end
      end
    elseif queryOK then
      _G.CompletionistMapV103NativeRavenTracked = false
    end

    return result
  end

  _G.CompletionistMapV103NativeRavenEnabled = true
  log("NATIVE_RAVEN_API",
    "installed=true candidate=" .. candidate ..
    " markerType=" .. tostring(markerType) ..
    " calls_on_load=false legacy_r3l3_for_raven=false prompt_async_guard=true")
end
-- END COMPLETIONIST V0.10.3 NATIVE RAVEN PRODUCTION BRIDGE
-- BEGIN COMPLETIONIST V0.10.4 SINGLE ACTIVE COMPASS CONTROL
-- Final Raven-only manager bridge for v0.10.4 testing.
--
-- Why this wrapper owns Raven-origin actions:
-- the older Raven bridge's shownState() queries enabledShowOnCompassMarkerFlags,
-- which contains stock classes but not CompletionistRaven. Once the Raven uses its
-- custom class, delegating Remove from Compass to that older bridge can re-show the
-- Raven instead of hiding it. This layer uses FindMarkersByIconClass({CompletionistRaven})
-- for the Raven and the stock class list for ordinary targets.
do
  local prefix = "[CompletionistMap v0.10.4-single-active-v3] "
  local ravenCandidate = "Completionist_V103_Veithurgard_Raven_01"
  local ravenClass = "CompletionistRaven"
  local previousShow = MapOn.ShowOnCompass
  local previousUpdate = MapOn.Update
  local previousPrompt = MapOn.GetShowOnCompassPrompt

  local stockReplacePending = false
  local ravenIntent = nil -- "tracked" / "untracked" while native manager settles
  local retryFrames = 0
  local retryBucket = -1

  local function log(category, fields)
    print(prefix .. category .. " " .. fields)
  end

  local function ravenSelected(self)
    return self ~= nil and self.completionistMapV100Selected == true
  end

  local function candidateInfo()
    local ok, info = pcall(function()
      return game.Map.GetMarkerInfo(ravenCandidate)
    end)
    if not ok then
      return nil, tostring(info)
    end
    if info == nil then
      return nil, "candidate_missing"
    end
    return info, nil
  end

  local function candidateIdString()
    local info = candidateInfo()
    return info ~= nil and tostring(info.Id) or nil
  end

  local function ravenShown()
    local candidateId = candidateIdString()
    if candidateId == nil then
      return false, false, "candidate_lookup_failed"
    end

    local ok, ids = pcall(function()
      return game.Compass.FindMarkersByIconClass({ravenClass})
    end)
    if not ok then
      return false, false, tostring(ids)
    end

    for _, id in ipairs(ids or {}) do
      if tostring(id) == candidateId then
        return true, true, nil
      end
    end
    return false, true, nil
  end

  local function stockTargets()
    local ravenId = candidateIdString()
    local ok, ids = pcall(function()
      return game.Compass.FindMarkersByIconClass(enabledShowOnCompassMarkerFlags)
    end)
    if not ok then
      return {}, false, tostring(ids)
    end

    local out = {}
    for _, id in ipairs(ids or {}) do
      if ravenId == nil or tostring(id) ~= ravenId then
        out[#out + 1] = id
      end
    end
    return out, true, nil
  end

  local function actionText(lamsId)
    return "[AdvanceButton] " .. util.GetLAMSMsg(lamsId)
  end

  local function hideRaven(reason)
    local ok, err = pcall(function()
      game.Compass.HideMarker(ravenCandidate)
    end)
    log("HIDE_RAVEN",
      "reason=" .. tostring(reason) ..
      " ok=" .. tostring(ok) ..
      " error=" .. tostring(err))
    return ok
  end

  local function hideStockTargets(reason)
    local ids, ok, err = stockTargets()
    if not ok then
      log("HIDE_STOCK", "reason=" .. tostring(reason) .. " queryOK=false error=" .. tostring(err))
      return false, 0
    end

    for _, id in ipairs(ids) do
      local hideOK, hideErr = pcall(function()
        game.Compass.HideMarker(id)
      end)
      log("HIDE_STOCK",
        "reason=" .. tostring(reason) ..
        " id=" .. tostring(id) ..
        " ok=" .. tostring(hideOK) ..
        " error=" .. tostring(hideErr))
    end
    return true, #ids
  end

  local function suppressLegacyRavenHud()
    local target = _G.CompletionistMapV100Target
    if target ~= nil and target.type == "Raven" and target.active == true then
      target.active = false
      log("LEGACY_R3L3_DISABLED", "reason=native_custom_raven_tracking")
    end
  end

  local function refreshRavenPrompt(self)
    if self == nil or self.menu == nil or not ravenSelected(self) then return end
    local show, text = self:GetShowOnCompassPrompt(self.menu)

    local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
    if goMapCursorText ~= nil then
      goMapCursorText:Show()
      local goCursorInfoTop = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
      if goCursorInfoTop ~= nil then
        local thPrompt = util.GetTextHandle(goCursorInfoTop, "CursorAction_Text")
        if thPrompt ~= nil then
          UI.SetTextIsClickable(thPrompt)
          UI.SetText(thPrompt, show and text or "")
        end
        if show then goCursorInfoTop:Show() else goCursorInfoTop:Hide() end
      end
    end

    self.menu:UpdateFooterButton("ShowOnCompass", show, text)
    self.menu:UpdateFooterButtonText()
    log("PROMPT_REFRESH",
      "visible=" .. tostring(show) ..
      " intent=" .. tostring(ravenIntent) ..
      " text=" .. tostring(text))
  end

  function MapOn:GetShowOnCompassPrompt(currMenu)
    local show, previousText = previousPrompt(self, currMenu)
    if not ravenSelected(self) or not show then
      return show, previousText
    end

    -- During an asynchronous user action, reflect the requested state immediately.
    if ravenIntent == "tracked" then
      return true, actionText(lamsConsts.RemoveFromCompass)
    elseif ravenIntent == "untracked" then
      local others, stockOK = stockTargets()
      if stockOK and #others > 0 then
        return true, actionText(lamsConsts.ReplaceInCompass)
      end
      return true, actionText(lamsConsts.AddToCompass)
    end

    local shown, ravenOK, ravenErr = ravenShown()
    if not ravenOK then
      log("PROMPT_LIVE_QUERY", "ravenQueryOK=false error=" .. tostring(ravenErr) .. " fallback=previous")
      return show, previousText
    end
    if shown then
      return true, actionText(lamsConsts.RemoveFromCompass)
    end

    local others, stockOK, stockErr = stockTargets()
    if not stockOK then
      log("PROMPT_LIVE_QUERY", "stockQueryOK=false error=" .. tostring(stockErr) .. " fallback=previous")
      return show, previousText
    end
    if #others > 0 then
      return true, actionText(lamsConsts.ReplaceInCompass)
    end
    return true, actionText(lamsConsts.AddToCompass)
  end

  function MapOn:ShowOnCompass(currState)
    if not ravenSelected(self) then
      local shown, queryOK, queryErr = ravenShown()
      local trackedHint = _G.CompletionistMapV103NativeRavenTracked == true

      if shown or trackedHint then
        stockReplacePending = true
        ravenIntent = "untracked"
        retryFrames = 0
        retryBucket = -1
        log("STOCK_REPLACE_BEGIN",
          "ravenShown=" .. tostring(shown) ..
          " trackedHint=" .. tostring(trackedHint) ..
          " queryOK=" .. tostring(queryOK) ..
          " queryError=" .. tostring(queryErr))
        hideRaven("stock_marker_selected")
      else
        stockReplacePending = false
      end

      -- Stock-origin actions stay game-owned.
      return previousShow(self, currState)
    end

    stockReplacePending = false
    retryFrames = 0
    retryBucket = -1

    local info, infoErr = candidateInfo()
    if info == nil then
      ravenIntent = nil
      log("RAVEN_ACTION", "refused=candidate_missing error=" .. tostring(infoErr))
      return
    end

    local shown, queryOK, queryErr = ravenShown()
    if not queryOK then
      ravenIntent = nil
      log("RAVEN_ACTION", "refused=custom_class_query_failed error=" .. tostring(queryErr))
      return
    end

    if shown then
      if hideRaven("user_remove") then
        ravenIntent = "untracked"
        self.currShownMarkerID = nil
        Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass")
        refreshRavenPrompt(self)
        log("RAVEN_REMOVE", "request_queued=true")
      end
      return
    end

    local stockOK, stockCount = hideStockTargets("raven_replace")
    if not stockOK then
      ravenIntent = nil
      log("RAVEN_ACTION", "refused=stock_target_query_failed")
      return
    end

    suppressLegacyRavenHud()
    local showOK, showErr = pcall(function()
      game.Compass.ShowMarker(ravenCandidate, ravenClass)
    end)
    log("RAVEN_SHOW",
      "ok=" .. tostring(showOK) ..
      " error=" .. tostring(showErr) ..
      " replacedStockCount=" .. tostring(stockCount))

    if not showOK then
      ravenIntent = nil
      return
    end

    ravenIntent = "tracked"
    self.currShownMarkerID = info.Id
    _G.CompletionistMapV103NativeRavenTracked = true
    Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass")
    refreshRavenPrompt(self)
  end

  function MapOn:Update(...)
    local result = previousUpdate(self, ...)

    local shown, ravenOK, ravenErr = ravenShown()
    if ravenOK then
      _G.CompletionistMapV103NativeRavenTracked = shown
      if shown then suppressLegacyRavenHud() end

      if stockReplacePending then
        if not shown then
          stockReplacePending = false
          ravenIntent = nil
          retryFrames = 0
          retryBucket = -1
          log("STOCK_REPLACE_SETTLED", "ravenActive=false")
          refreshRavenPrompt(self)
        else
          retryFrames = retryFrames + 1
          local bucket = math.floor(retryFrames / 30)
          if retryFrames == 1 or bucket ~= retryBucket then
            retryBucket = bucket
            hideRaven("stock_replace_async_retry")
          end
        end
      elseif ravenIntent == "untracked" then
        if not shown then
          ravenIntent = nil
          retryFrames = 0
          retryBucket = -1
          log("RAVEN_REMOVE_SETTLED", "ravenActive=false")
          refreshRavenPrompt(self)
        else
          retryFrames = retryFrames + 1
          local bucket = math.floor(retryFrames / 30)
          if retryFrames == 1 or bucket ~= retryBucket then
            retryBucket = bucket
            hideRaven("raven_remove_async_retry")
          end
        end
      elseif ravenIntent == "tracked" then
        local others, stockOK = stockTargets()
        if shown and stockOK and #others == 0 then
          ravenIntent = nil
          retryFrames = 0
          retryBucket = -1
          log("RAVEN_SHOW_SETTLED", "ravenActive=true stockTargets=0")
          refreshRavenPrompt(self)
        else
          retryFrames = retryFrames + 1
          local bucket = math.floor(retryFrames / 30)
          if stockOK and #others > 0 and (retryFrames == 1 or bucket ~= retryBucket) then
            retryBucket = bucket
            hideStockTargets("raven_replace_async_retry")
          end
        end
      end
    elseif stockReplacePending or ravenIntent ~= nil then
      retryFrames = retryFrames + 1
      if retryFrames == 1 or retryFrames % 60 == 0 then
        log("VERIFY", "ravenQueryOK=false error=" .. tostring(ravenErr) .. " frame=" .. tostring(retryFrames))
      end
    end

    return result
  end

  _G.CompletionistMapV104SingleActiveCompass = true
  _G.CompletionistMapV104SingleActivePromptLiveSync = true
  _G.CompletionistMapV104RavenActionsUseCustomClassManager = true
  log("API",
    "installed=true ravenClass=" .. ravenClass ..
    " invariant=single_active_compass_target raven_actions=custom_class_manager prompt=live_manager")
end
-- END COMPLETIONIST V0.10.4 SINGLE ACTIVE COMPASS CONTROL

-- BEGIN COMPLETIONIST SHARED LOADER TWIN PROBE
-- Same resource, new marker UID. No token state or compass writes.
do
  local twinName = "Completionist_V104_Veithurgard_Raven_Twin_01"
  local createRaven = CompletionistMapV100_CreateMapPin
  local prefix = "[CompletionistMap shared-loader-twin] "

  local function log(text)
    print(prefix .. text)
  end

  local function clearTwin(self)
    local go = self.completionistSharedLoaderTwinGO
    if go ~= nil then
      local ok, err = pcall(function() Map.RecycleIcon(go) end)
      if not ok then
        log("CLEANUP_FAILED error=" .. tostring(err))
        return false
      end
      if self.mapIconCollision == go then self.mapIconCollision = nil end
      self.completionistSharedLoaderTwinGO = nil
      local selected = self.completionistMapV104SelectedRavenIdentity
      if selected ~= nil and selected.Name == twinName then
        self.completionistMapV104SelectedRavenIdentity = nil
      end
      log("RECYCLED twin=true")
    end
    return true
  end

  -- Map view owns Twin. Raven completion owns only real pin.
  for _, method in ipairs({"SubmenuExit", "Exit", "ClearIcons"}) do
    local previous = MapOn[method]
    assert(type(previous) == "function", "Missing map lifecycle method: " .. method)
    MapOn[method] = function(self, ...)
      clearTwin(self)
      return previous(self, ...)
    end
  end

  CompletionistMapV100_CreateMapPin = function(self, currState)
    local result = createRaven(self, currState)
    if self.currRealmName ~= "Midgard" then return result end
    if self.completionistSharedLoaderTwinGO ~= nil then
      log("SKIP reason=prior_twin_not_recycled")
      return result
    end

    -- The Twin is a separate map marker instance that only shares the Raven visual
    -- resource. Its lifetime must not depend on a live production Raven UI object.
    local original = self.completionistMapV100MapIconGO
    local originalPresent = original ~= nil

    local ok, err = pcall(function()
      local info = Map.GetMarkerInfo(twinName)
      if info == nil or info.Id == nil then
        log("LOOKUP found=false")
        return
      end
      local found, region = Map.FindRegionFromMarker(info.Id)
      log("LOOKUP found=true uid=" .. tostring(info.Id) ..
          " state=" .. tostring(info.State) .. " regionFound=" .. tostring(found) ..
          " region=" .. tostring(region) .. " originalPresent=" .. tostring(originalPresent))
      if found ~= true or region == nil then return end
      local go = Map.CreateMarkerIcon(info.Id, region, "")
      if go == nil then
        log("CREATE success=false reason=nil_object originalPresent=" .. tostring(originalPresent))
        return
      end
      if originalPresent and go == original then
        log("CREATE success=false reason=original_object_reused originalPresent=true")
        return
      end
      self.completionistSharedLoaderTwinGO = go
      go:Show()

      if originalPresent then
        local a, z = original:GetWorldPosition(), go:GetWorldPosition()
        local dx, dy, dz = z.x-a.x, z.y-a.y, z.z-a.z
        log("CREATE success=true distinctObjects=true sharedLoader=goMapIconCompletionistRaven" ..
            " uid=" .. tostring(info.Id) .. " goName=" .. tostring(go:GetName()) ..
            " originalPresent=true originalGO=" .. tostring(original) .. " twinGO=" .. tostring(go) ..
            " originalPos=" .. tostring(a.x) .. "," .. tostring(a.y) .. "," .. tostring(a.z) ..
            " twinPos=" .. tostring(z.x) .. "," .. tostring(z.y) .. "," .. tostring(z.z) ..
            " mapSpaceDistance=" .. tostring(math.sqrt(dx*dx+dy*dy+dz*dz)) ..
            " stateWritten=false compassWritten=false")
      else
        local z = go:GetWorldPosition()
        log("CREATE success=true distinctObjects=not_applicable sharedLoader=goMapIconCompletionistRaven" ..
            " uid=" .. tostring(info.Id) .. " goName=" .. tostring(go:GetName()) ..
            " originalPresent=false twinGO=" .. tostring(go) ..
            " twinPos=" .. tostring(z.x) .. "," .. tostring(z.y) .. "," .. tostring(z.z) ..
            " stateWritten=false compassWritten=false")
      end
    end)
    if not ok then
      log("CREATE success=false error=" .. tostring(err) .. " originalPresent=" .. tostring(originalPresent))
      clearTwin(self)
    end
    return result
  end
  log("API installed=true resource=goMapIconCompletionistRaven expectedPoolCapacity=2 independentTwinLifetime=true")
end
-- END COMPLETIONIST SHARED LOADER TWIN PROBE

-- BEGIN COMPLETIONIST V0.10.4 UID-AWARE RAVEN COMPASS ROUTING V3.3
-- Capture exact custom map identity at collision dispatch, then bind it to the
-- compass action only when the matching real/Twin prompt is offered.
-- Keep armed identity through human delay and incidental collision callbacks.
-- Keep stock actions owned by the proven single-active-v3 controller.
do
  local prefix = "[CompletionistMap v0.10.4-uid-lifecycle-v3.3] "
  local ravenName = "Completionist_V103_Veithurgard_Raven_01"
  local twinName = "Completionist_V104_Veithurgard_Raven_Twin_01"
  local ravenClass = "CompletionistRaven"
  local previousPrompt = MapOn.GetShowOnCompassPrompt
  local previousShow = MapOn.ShowOnCompass
  local previousUpdate = MapOn.Update
  local previousCollision = MapOn.MapCollisionChangeHandler
  local compassPending = nil
  local promptOverride = nil
  local lastMapOnSelf = nil
  local knownRavenIdentity = nil
  local completionObserved = nil
  local selectionGeneration = 0

  local function log(category, fields)
    print(prefix .. category .. " " .. fields)
  end

  local function markerInfo(name)
    local ok, info = pcall(function() return game.Map.GetMarkerInfo(name) end)
    if not ok or info == nil or info.Id == nil then
      log("MARKER_INFO", "name=" .. tostring(name) .. " ok=" .. tostring(ok) ..
          " error=" .. tostring(info))
      return nil
    end
    return info
  end

  local function identity(name, kind)
    local info = markerInfo(name)
    if info == nil then return nil end
    local result = {
      Kind = kind,
      Name = name,
      Id = info.Id,
      IdString = tostring(info.Id),
      X = info.X,
      Y = info.Y,
      Z = info.Z,
    }
    if name == ravenName then knownRavenIdentity = result end
    return result
  end

  -- Production bridge publishes native Raven state. False from an older restored
  -- checkpoint must win over stale quest state. This is read-only for progression.
  CompletionistMapV100_IsRavenCollected = function()
    local state = _G.CompletionistMapV100TargetRavenKilled
    if type(state) == "boolean" then return state end
    local ok, quest = pcall(function()
      return game.QuestManager.GetQuestState("RegionSummary_VF_Raven_Parent")
    end)
    if not ok or quest == nil then return nil end
    return tostring(quest) == "Complete"
  end

  local function originalCollected()
    local ok, value = pcall(CompletionistMapV100_IsRavenCollected)
    if not ok or type(value) ~= "boolean" then return nil end
    return value
  end

  local function collisionIdentity(self, collision)
    if self == nil or collision == nil then return nil, nil end
    if self.completionistSharedLoaderTwinGO ~= nil and
        collision == self.completionistSharedLoaderTwinGO then
      return identity(twinName, "twin"), "twin_object_reference"
    end
    if self.completionistMapV100MapIconGO ~= nil and
        collision == self.completionistMapV100MapIconGO then
      if originalCollected() ~= false then return nil, "raven_collected" end
      return identity(ravenName, "real"), "raven_object_reference"
    end
    return nil, nil
  end

  local function clearSelection(self, reason)
    if self == nil then return end
    local old = self.completionistMapV104RavenSelection
    self.completionistMapV104RavenSelection = nil
    if old ~= nil then
      log("SELECT_DISARM", "reason=" .. tostring(reason) ..
          " state=" .. tostring(old.State) ..
          " kind=" .. tostring(old.Kind) .. " name=" .. tostring(old.Name) ..
          " uid=" .. tostring(old.IdString) ..
          " generation=" .. tostring(old.Generation))
    end
  end

  local function captureSelection(self, selected, source)
    if self == nil or selected == nil then return nil end
    local old = self.completionistMapV104RavenSelection
    if old ~= nil and old.IdString == selected.IdString then
      old.Source = source
      return old
    end
    if old ~= nil then clearSelection(self, "exact_custom_replaced") end
    selectionGeneration = selectionGeneration + 1
    selected.Generation = selectionGeneration
    selected.State = "candidate-custom"
    selected.Source = source
    self.completionistMapV104RavenSelection = selected
    log("SELECT_CANDIDATE", "source=" .. tostring(source) ..
        " kind=" .. tostring(selected.Kind) .. " name=" .. selected.Name ..
        " uid=" .. selected.IdString ..
        " generation=" .. tostring(selected.Generation))
    return selected
  end

  local function currentSelection(self)
    if self == nil then return nil end
    local selected = self.completionistMapV104RavenSelection
    if selected == nil then return nil end
    if selected.Name == ravenName and originalCollected() ~= false then
      clearSelection(self, "raven_collected")
      return nil
    end
    return selected
  end

  local function collisionTableSelection(self, collisions)
    if type(collisions) ~= "table" then return nil, false end
    local hasCollision = false
    local twin = nil
    for _, collision in ipairs(collisions) do
      hasCollision = true
      local selected, source = collisionIdentity(self, collision)
      if selected ~= nil and selected.Kind == "real" then return selected, source end
      if selected ~= nil and selected.Kind == "twin" then twin = selected end
    end
    if twin ~= nil then return twin, "twin_object_reference" end
    return nil, hasCollision
  end

  local function armSelection(self, selected)
    if self == nil or selected == nil then return nil end
    if selected.State == "armed-custom" then return selected end
    if selected.State ~= "candidate-custom" then
      clearSelection(self, "invalid_state_before_arm")
      return nil
    end
    selected.State = "armed-custom"
    log("SELECT_ARM", "source=GetShowOnCompassPrompt_custom_raven_owner" ..
        " kind=" .. tostring(selected.Kind) .. " name=" .. selected.Name ..
        " uid=" .. selected.IdString ..
        " generation=" .. tostring(selected.Generation))
    return selected
  end

  local function consumeSelection(self)
    local selected = currentSelection(self)
    if selected == nil or selected.State ~= "armed-custom" then return nil end
    self.completionistMapV104RavenSelection = nil
    log("SELECT_CONSUME", "kind=" .. tostring(selected.Kind) ..
        " name=" .. selected.Name .. " uid=" .. selected.IdString ..
        " generation=" .. tostring(selected.Generation))
    return selected
  end

  local function exactTwinCollisionSelection(selected)
    return selected ~= nil and
      selected.Kind == "twin" and
      selected.Name == twinName and
      selected.Source == "collision_table:twin_object_reference"
  end

  local function customRavenOwnsPrompt(self, show, selected)
    if show ~= true or self == nil or selected == nil then return false end
    if exactTwinCollisionSelection(selected) then
      return self.currMarkerID ~= nil and
        tostring(self.currMarkerID) == selected.IdString
    end
    -- Keep the human-proven real Raven prompt bridge unchanged.
    return selected.Kind == "real" and selected.Name == ravenName and
      self.completionistMapV100Selected == true and
      self.completionistMapV100NornirSelected == nil and
      self.completionistMapV100NornirChestSelected == nil and
      self.currMarkerID == nil
  end

  local function customRavenOwnsAction(self, selected)
    if self == nil or selected == nil then return false end
    if exactTwinCollisionSelection(selected) then
      return self.currMarkerID ~= nil and
        tostring(self.currMarkerID) == selected.IdString
    end
    return selected.Kind == "real" and selected.Name == ravenName and
      self.completionistMapV100Selected == true and self.currMarkerID == nil
  end

  local function currentMarkerDiffersFromSelection(self, selected)
    return self ~= nil and selected ~= nil and self.currMarkerID ~= nil and
      tostring(self.currMarkerID) ~= selected.IdString
  end

  local function confirmedDifferentPromptReason(self, selected)
    if currentMarkerDiffersFromSelection(self, selected) then
      return "confirmed_native_prompt:marker=" .. tostring(self.currMarkerID)
    end
    return "confirmed_other_custom_prompt"
  end

  local function customTargetIds()
    local ok, ids = pcall(function()
      return game.Compass.FindMarkersByIconClass({ravenClass})
    end)
    if not ok then return {}, false, tostring(ids) end
    return ids or {}, true, nil
  end

  local function containsId(ids, idString)
    for _, id in ipairs(ids or {}) do
      if tostring(id) == idString then return true end
    end
    return false
  end

  local function customShown(selected)
    if selected == nil then return false, false, "selection_missing" end
    local ids, ok, err = customTargetIds()
    if not ok then return false, false, err end
    return containsId(ids, selected.IdString), true, nil
  end

  local function stockTargets()
    local ok, ids = pcall(function()
      return game.Compass.FindMarkersByIconClass(enabledShowOnCompassMarkerFlags)
    end)
    if not ok then return {}, false, tostring(ids) end
    return ids or {}, true, nil
  end

  local function knownNameForId(id)
    local idString = tostring(id)
    local real = markerInfo(ravenName)
    if real ~= nil and tostring(real.Id) == idString then return ravenName end
    local twin = markerInfo(twinName)
    if twin ~= nil and tostring(twin.Id) == idString then return twinName end
    return nil
  end

  local function hideCustomTargets(reason, exceptIdString)
    local ids, ok, err = customTargetIds()
    if not ok then
      log("HIDE_CUSTOM", "reason=" .. tostring(reason) ..
          " queryOK=false error=" .. tostring(err))
      return false, 0
    end
    local hidden = 0
    local allHidden = true
    for _, id in ipairs(ids) do
      if exceptIdString == nil or tostring(id) ~= exceptIdString then
        local name = knownNameForId(id)
        local target = name or id
        local hideOK, hideErr = pcall(function() game.Compass.HideMarker(target) end)
        log("HIDE_CUSTOM", "reason=" .. tostring(reason) .. " id=" .. tostring(id) ..
            " name=" .. tostring(name) .. " ok=" .. tostring(hideOK) ..
            " error=" .. tostring(hideErr))
        if hideOK then hidden = hidden + 1 end
        if not hideOK then allHidden = false end
      end
    end
    return allHidden, hidden
  end

  local function hideStockTargets(reason)
    local ids, ok, err = stockTargets()
    if not ok then
      log("HIDE_STOCK", "reason=" .. tostring(reason) ..
          " queryOK=false error=" .. tostring(err))
      return false, 0
    end
    local hidden = 0
    local allHidden = true
    for _, id in ipairs(ids) do
      local hideOK, hideErr = pcall(function() game.Compass.HideMarker(id) end)
      log("HIDE_STOCK", "reason=" .. tostring(reason) .. " id=" .. tostring(id) ..
          " ok=" .. tostring(hideOK) .. " error=" .. tostring(hideErr))
      if hideOK then hidden = hidden + 1 end
      if not hideOK then allHidden = false end
    end
    return allHidden, hidden
  end

  local function actionText(lamsId)
    return "[AdvanceButton] " .. util.GetLAMSMsg(lamsId)
  end

  local function suppressLegacyRavenHud()
    local target = _G.CompletionistMapV100Target
    if target ~= nil and target.type == "Raven" and target.active == true then
      target.active = false
      log("LEGACY_R3L3_DISABLED", "reason=uid_routed_native_custom_tracking")
    end
  end

  local function promptForSelection(selected, show, previousText)
    if selected == nil or not show then return show, previousText end
    if compassPending ~= nil and compassPending.IdString == selected.IdString then
      if compassPending.State == "tracked" then
        return true, actionText(lamsConsts.RemoveFromCompass)
      end
      local custom = customTargetIds()
      local stock = stockTargets()
      if #custom > 0 or #stock > 0 then
        return true, actionText(lamsConsts.ReplaceInCompass)
      end
      return true, actionText(lamsConsts.AddToCompass)
    end
    local shown, queryOK, queryErr = customShown(selected)
    if not queryOK then
      log("PROMPT", "uid=" .. selected.IdString ..
          " queryOK=false error=" .. tostring(queryErr))
      return show, previousText
    end
    if shown then return true, actionText(lamsConsts.RemoveFromCompass) end
    local custom, customOK, customErr = customTargetIds()
    local stock, stockOK, stockErr = stockTargets()
    if not customOK or not stockOK then
      log("PROMPT", "uid=" .. selected.IdString ..
          " customOK=" .. tostring(customOK) .. " customError=" .. tostring(customErr) ..
          " stockOK=" .. tostring(stockOK) .. " stockError=" .. tostring(stockErr))
      return show, previousText
    end
    if #custom > 0 or #stock > 0 then
      return true, actionText(lamsConsts.ReplaceInCompass)
    end
    return true, actionText(lamsConsts.AddToCompass)
  end

  local function refreshPrompt(self, selected)
    if self == nil or self.menu == nil then return end
    promptOverride = selected
    local show, text = self:GetShowOnCompassPrompt(self.menu)
    promptOverride = nil
    local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
    if goMapCursorText ~= nil then
      goMapCursorText:Show()
      local top = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
      if top ~= nil then
        local handle = util.GetTextHandle(top, "CursorAction_Text")
        if handle ~= nil then
          UI.SetTextIsClickable(handle)
          UI.SetText(handle, show and text or "")
        end
        if show then top:Show() else top:Hide() end
      end
    end
    self.menu:UpdateFooterButton("ShowOnCompass", show, text)
    self.menu:UpdateFooterButtonText()
    log("PROMPT_REFRESH", "visible=" .. tostring(show) .. " text=" .. tostring(text))
  end

  function MapOn:MapCollisionChangeHandler(currState, collisionGameObjectTable, realmName)
    lastMapOnSelf = self
    local selected, source = collisionTableSelection(self, collisionGameObjectTable)
    if selected ~= nil then
      captureSelection(self, selected, "collision_table:" .. tostring(source))
    end
    -- Noncustom callbacks alone prove nothing. The base handler debounces them
    -- and can emit several while the custom prompt remains the current action.
    return previousCollision(self, currState, collisionGameObjectTable, realmName)
  end

  function MapOn:GetShowOnCompassPrompt(currMenu)
    lastMapOnSelf = self
    local show, previousText = previousPrompt(self, currMenu)
    if promptOverride ~= nil then
      return promptForSelection(promptOverride, show, previousText)
    end
    local selected = currentSelection(self)
    if selected ~= nil and not show then
      clearSelection(self, "prompt_unavailable")
      return show, previousText
    end
    if selected ~= nil and not customRavenOwnsPrompt(self, show, selected) then
      clearSelection(self, confirmedDifferentPromptReason(self, selected))
      return show, previousText
    end
    selected = armSelection(self, selected)
    return promptForSelection(selected, show, previousText)
  end

  function MapOn:ShowOnCompass(currState)
    lastMapOnSelf = self
    local current = currentSelection(self)
    if currentMarkerDiffersFromSelection(self, current) then
      clearSelection(self, "confirmed_native_action:marker=" .. tostring(self.currMarkerID))
    elseif current ~= nil and not customRavenOwnsAction(self, current) then
      clearSelection(self, "custom_prompt_owner_lost_before_action")
    elseif current ~= nil and current.State ~= "armed-custom" then
      clearSelection(self, "action_without_prompt_arm")
    end
    local selected = consumeSelection(self)
    if selected == nil then
      -- Stock actions stay native. Hide only active Twin first because the older
      -- controller knows real Raven but predates Twin UID.
      local twin = identity(twinName, "twin")
      if twin ~= nil then
        local twinShown, queryOK = customShown(twin)
        if queryOK and twinShown then
          local ok, err = pcall(function() game.Compass.HideMarker(twinName) end)
          if not ok then
            log("STOCK_REPLACE_TWIN_REFUSED", "uid=" .. twin.IdString ..
                " reason=twin_hide_failed error=" .. tostring(err) ..
                " nativeDelegated=false")
            return
          end
          log("STOCK_REPLACE_TWIN", "uid=" .. twin.IdString ..
              " hideOK=true nativeDelegated=true")
        end
      end
      return previousShow(self, currState)
    end

    if selected.Name == ravenName and originalCollected() ~= false then
      log("ACTION_REFUSED", "name=" .. selected.Name .. " uid=" .. selected.IdString ..
          " reason=raven_collected")
      return
    end
    local shown, queryOK, queryErr = customShown(selected)
    if not queryOK then
      log("ACTION_REFUSED", "name=" .. selected.Name .. " uid=" .. selected.IdString ..
          " reason=custom_class_query_failed error=" .. tostring(queryErr))
      return
    end
    if shown then
      local hideOK, hideErr = pcall(function() game.Compass.HideMarker(selected.Name) end)
      log("REMOVE", "name=" .. selected.Name .. " uid=" .. selected.IdString ..
          " ok=" .. tostring(hideOK) .. " error=" .. tostring(hideErr))
      if hideOK then
        compassPending = {IdString=selected.IdString, State="untracked", Frames=0}
        self.currShownMarkerID = nil
        if _G.CompletionistMapV104UidRavenTrackedName == selected.Name then
          _G.CompletionistMapV104UidRavenTrackedName = nil
        end
        Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass")
        refreshPrompt(self, selected)
      end
      return
    end

    local customOK, customCount = hideCustomTargets("raven_uid_replace", selected.IdString)
    local stockOK, stockCount = hideStockTargets("raven_uid_replace")
    if not customOK or not stockOK then
      compassPending = nil
      log("ACTION_REFUSED", "name=" .. selected.Name .. " uid=" .. selected.IdString ..
          " reason=replace_query_failed")
      return
    end
    suppressLegacyRavenHud()
    local showOK, showErr = pcall(function()
      game.Compass.ShowMarker(selected.Name, ravenClass)
    end)
    log("SHOW", "name=" .. selected.Name .. " uid=" .. selected.IdString ..
        " class=" .. ravenClass ..
        " ok=" .. tostring(showOK) .. " error=" .. tostring(showErr) ..
        " replacedCustomCount=" .. tostring(customCount) ..
        " replacedStockCount=" .. tostring(stockCount))
    if not showOK then compassPending = nil return end
    compassPending = {IdString=selected.IdString, State="tracked", Frames=0}
    self.currShownMarkerID = selected.Id
    _G.CompletionistMapV104UidRavenTrackedName = selected.Name
    Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass")
    refreshPrompt(self, selected)
  end

  local function observeMapCompletion(self)
    local collected = originalCollected()
    if collected == nil then return end
    if collected == false then
      if completionObserved == true then log("LIFECYCLE_REARM", "reason=MapOn.Update") end
      completionObserved = false
      return
    end
    if completionObserved == true then return end
    local real = identity(ravenName, "real") or knownRavenIdentity
    local shown, queryOK, queryErr = customShown(real)
    local hideAttempted, hideOK, hideErr = false, true, nil
    if shown then
      hideAttempted = true
      hideOK, hideErr = pcall(function() game.Compass.HideMarker(ravenName) end)
    end
    if self ~= nil then
      local selected = currentSelection(self)
      if selected ~= nil and selected.Name == ravenName then clearSelection(self, "raven_collected") end
      if real ~= nil and self.currShownMarkerID ~= nil and
          tostring(self.currShownMarkerID) == real.IdString then
        self.currShownMarkerID = nil
      end
    end
    if real ~= nil and compassPending ~= nil and compassPending.IdString == real.IdString then
      compassPending = nil
    end
    if _G.CompletionistMapV104UidRavenTrackedName == ravenName then
      _G.CompletionistMapV104UidRavenTrackedName = nil
    end
    local settled = queryOK and not shown and not hideAttempted
    if hideAttempted or completionObserved ~= settled then
      log("LIFECYCLE_CLEAR", "reason=MapOn.Update originalCollected=true" ..
          " hideAttempted=" .. tostring(hideAttempted) ..
          " hideOK=" .. tostring(hideOK) ..
          " hideError=" .. tostring(hideErr or queryErr) ..
          " settled=" .. tostring(settled) ..
          " twinTouched=false progressionWrites=false")
    end
    completionObserved = settled
  end

  function MapOn:Update(...)
    lastMapOnSelf = self
    observeMapCompletion(self)
    local result = previousUpdate(self, ...)
    if compassPending ~= nil then
      compassPending.Frames = compassPending.Frames + 1
      local ids, ok, err = customTargetIds()
      if ok then
        local shown = containsId(ids, compassPending.IdString)
        local settled = (compassPending.State == "tracked" and shown) or
                        (compassPending.State == "untracked" and not shown)
        if settled then
          log("SETTLED", "uid=" .. compassPending.IdString ..
              " state=" .. compassPending.State ..
              " frames=" .. tostring(compassPending.Frames))
          compassPending = nil
        elseif compassPending.Frames == 180 then
          log("VERIFY_TIMEOUT", "uid=" .. compassPending.IdString ..
              " state=" .. compassPending.State)
          compassPending = nil
        end
      elseif compassPending.Frames == 1 or compassPending.Frames % 60 == 0 then
        log("VERIFY", "uid=" .. compassPending.IdString ..
            " queryOK=false error=" .. tostring(err) ..
            " frame=" .. tostring(compassPending.Frames))
      end
    end
    return result
  end

  for _, method in ipairs({"SubmenuExit", "Exit", "ClearIcons"}) do
    local previous = MapOn[method]
    assert(type(previous) == "function", "Missing map lifecycle method: " .. method)
    MapOn[method] = function(self, ...)
      clearSelection(self, "map_teardown:" .. method)
      compassPending = nil
      if lastMapOnSelf == self then lastMapOnSelf = nil end
      return previous(self, ...)
    end
  end

  _G.CompletionistMapV104UidAwareRavenCompassRouting = true
  _G.CompletionistMapV104UidAwareRavenCompassRoutingV33 = true
  log("API", "installed=true identitySource=MapOn.MapCollisionChangeHandler_collision_table" ..
      " selectionStateMachine=none,candidate-custom,armed-custom" ..
      " armedSelectionExpiry=ui_lifecycle_only" ..
      " armSignal=GetShowOnCompassPrompt_exact_real_or_same_uid_exact_twin" ..
      " stockSignal=currMarkerID_differs_from_exact_custom_candidate" ..
      " markerIdentity=Map.GetMarkerInfo compassClass=" .. ravenClass ..
      " singleActive=true gameplayCleanup=persistent_precisionchallenge" ..
      " progressionWrites=false twinLifecycleIndependent=true")
end
-- END COMPLETIONIST V0.10.4 UID-AWARE RAVEN COMPASS ROUTING V3.3

-- BEGIN COMPLETIONIST V0.10.5 ALL RAVENS
-- Data drives all Raven work. Raven markers stay hidden until atomic authority is established.
do
  local prefix = "[CompletionistMap v0.10.5-all-ravens] "
  local ravenClass = "CompletionistRaven"
  local mapResource = "goMapIconCompletionistRaven"
  local provenName = "Completionist_V103_Veithurgard_Raven_01"
  local rows = {
    {CatalogueId="raven_95b9c6444d479ac68207b1829d02909b",Name="Completionist_V105_Raven_95b9c6444d479ac6",UidHex="0664D1B9E406D64D",Realm="Alfheim",RegionId="25B5C98A27101CB7",ParentQuest="RegionSummary_ALF_Raven_Parent"},
    {CatalogueId="raven_63f2a1a74274de6df3962490fb6552e9",Name="Completionist_V105_Raven_63f2a1a74274de6d",UidHex="15E7B235887EA0C2",Realm="Alfheim",RegionId="25B5C98A27101CB7",ParentQuest="RegionSummary_ALF_Raven_Parent"},
    {CatalogueId="raven_a824e12946c803e8511da79bc52a193f",Name="Completionist_V105_Raven_a824e12946c803e8",UidHex="1FC01FAB6070DDFB",Realm="Helheim",RegionId="FE4E39694E7F6B29",ParentQuest="RegionSummary_HEL_Raven_Parent"},
    {CatalogueId="raven_2811daa04ce30f079ff758b3bf04369d",Name="Completionist_V105_Raven_2811daa04ce30f07",UidHex="01CDC544ACC956C9",Realm="Helheim",RegionId="FE4E39694E7F6B29",ParentQuest="RegionSummary_HEL_Raven_Parent"},
    {CatalogueId="raven_595d8539488753c54fa471a46631e8c7",Name="Completionist_V105_Raven_595d8539488753c5",UidHex="C00ADDF537A535BD",Realm="Helheim",RegionId="FE4E39694E7F6B29",ParentQuest="RegionSummary_HEL_Raven_Parent"},
    {CatalogueId="raven_69a8e9f3434cd84b48c7c688094ed2e4",Name="Completionist_V105_Raven_69a8e9f3434cd84b",UidHex="97EF09F410C2506A",Realm="Helheim",RegionId="FE4E39694E7F6B29",ParentQuest="RegionSummary_HEL_Raven_Parent"},
    {CatalogueId="raven_7ffab2af4d6e2c7e7a9d42a58943bdf1",Name="Completionist_V105_Raven_7ffab2af4d6e2c7e",UidHex="F6A541CF3949609C",Realm="Helheim",RegionId="FE4E39694E7F6B29",ParentQuest="RegionSummary_HEL_Raven_Parent"},
    {CatalogueId="raven_b13e52024ecc5909d1fe478ee2c54e8c",Name="Completionist_V105_Raven_b13e52024ecc5909",UidHex="59ED7C538496830E",Realm="Helheim",RegionId="FE4E39694E7F6B29",ParentQuest="RegionSummary_HEL_Raven_Parent"},
    {CatalogueId="raven_7ffe9f6e4e18734cebadc892d24801e4",Name="Completionist_V105_Raven_7ffe9f6e4e18734c",UidHex="11944D04B7464701",Realm="Midgard",RegionId="018E0CE2EAEAA53D",ParentQuest="RegionSummary_BC_Raven_Parent"},
    {CatalogueId="raven_bc9c2cea4b7e1feaf09bb58f1b691035",Name="Completionist_V105_Raven_bc9c2cea4b7e1fea",UidHex="911828CAFC2703E5",Realm="Midgard",RegionId="018E0CE2EAEAA53D",ParentQuest="RegionSummary_BC_Raven_Parent"},
    {CatalogueId="raven_2b86b2ad4f6c006d5f6db0af57a190a4",Name="Completionist_V105_Raven_2b86b2ad4f6c006d",UidHex="2D469D999E0FB832",Realm="Midgard",RegionId="018E325B7D1CFC3B",ParentQuest="RegionSummary_BM_Raven_Parent"},
    {CatalogueId="raven_73ac895445d967756cbf34ac591ac205",Name="Completionist_V105_Raven_73ac895445d96775",UidHex="55970A556AFFD664",Realm="Midgard",RegionId="9391E1AF5C0C0C70",ParentQuest="RegionSummary_BSW_Raven_Parent"},
    {CatalogueId="raven_11d083554dd320d5e23ccca24f339acd",Name="Completionist_V105_Raven_11d083554dd320d5",UidHex="AF13DC156ACA6E78",Realm="Midgard",RegionId="3A9BFC89F5AB6FE3",ParentQuest="RegionSummary_BT_Raven_Parent"},
    {CatalogueId="raven_ef8568004bd6283b79b4819bb3e5cb0f",Name="Completionist_V105_Raven_ef8568004bd6283b",UidHex="16B1C4AD5F7DA2D2",Realm="Midgard",RegionId="6732D984CAA9285A",ParentQuest="RegionSummary_BW_Raven_Parent"},
    {CatalogueId="raven_4b8990ee4053cd00d13299928da1a9fc",Name="Completionist_V105_Raven_4b8990ee4053cd00",UidHex="A67E934E2EECBD5C",Realm="Midgard",RegionId="7B7F0B522FFA9124",ParentQuest="RegionSummary_CALS_Raven_Parent"},
    {CatalogueId="raven_df5a6f7543fa157f4cd630a19c038deb",Name="Completionist_V105_Raven_df5a6f7543fa157f",UidHex="BB9DBFCB8C866AEB",Realm="Midgard",RegionId="7B7F0B522FFA9124",ParentQuest="RegionSummary_CALS_Raven_Parent"},
    {CatalogueId="raven_e4d9b53e4e0330fc07421d8fea348f1d",Name="Completionist_V105_Raven_e4d9b53e4e0330fc",UidHex="190618C0A60E79EE",Realm="Midgard",RegionId="62F2A92841484ABF",ParentQuest="RegionSummary_FOOT_Raven_Parent"},
    {CatalogueId="raven_2862a927444bf9df95a605b6a1cfec2b",Name="Completionist_V105_Raven_2862a927444bf9df",UidHex="76F941DA1362135A",Realm="Midgard",RegionId="62F2A92841484ABF",ParentQuest="RegionSummary_FOOT_Raven_Parent"},
    {CatalogueId="raven_528d332048f734d84b2f8ca26b3abafc",Name="Completionist_V105_Raven_528d332048f734d8",UidHex="CF93AD9D203E63CC",Realm="Midgard",RegionId="7AF9D3D169EFE9B7",ParentQuest="RegionSummary_FOR_Raven_Parent"},
    {CatalogueId="raven_3f0baac6405889c7478896801b6a637c",Name="Completionist_V105_Raven_3f0baac6405889c7",UidHex="08451787929A6E02",Realm="Midgard",RegionId="7880D593C85F2451",ParentQuest="RegionSummary_FD_Raven_Parent"},
    {CatalogueId="raven_ad56521740c745076417e99ddf1dd7a4",Name="Completionist_V105_Raven_ad56521740c74507",UidHex="3E555E8FCCD523B7",Realm="Midgard",RegionId="7880D593C85F2451",ParentQuest="RegionSummary_FD_Raven_Parent"},
    {CatalogueId="raven_b5ec8398449f573b8a70b7a4fb1154af",Name="Completionist_V105_Raven_b5ec8398449f573b",UidHex="5CDB7378D8D67D98",Realm="Midgard",RegionId="7880D593C85F2451",ParentQuest="RegionSummary_FD_Raven_Parent"},
    {CatalogueId="raven_14a87a63401390815b4e4ab2b4e619d0",Name="Completionist_V105_Raven_14a87a6340139081",UidHex="E24448E356FE718F",Realm="Midgard",RegionId="7880D593C85F2451",ParentQuest="RegionSummary_FD_Raven_Parent"},
    {CatalogueId="raven_97b753a94e069b45a5e031b81a5b9f91",Name="Completionist_V105_Raven_97b753a94e069b45",UidHex="E7EFC86FCBAF98BB",Realm="Midgard",RegionId="7880D593C85F2451",ParentQuest="RegionSummary_FD_Raven_Parent"},
    {CatalogueId="raven_09c20f1b44476543307d8d8a444401f7",Name="Completionist_V105_Raven_09c20f1b44476543",UidHex="C80BFF3879136CFA",Realm="Midgard",RegionId="0000489975E7755D",ParentQuest="RegionSummary_HTTK_Raven_Parent"},
    {CatalogueId="raven_93bb416243c6d7afd0dadf824507fcb6",Name="Completionist_V105_Raven_93bb416243c6d7af",UidHex="4C9D0C42D69BEC28",Realm="Midgard",RegionId="0000489975E7755D",ParentQuest="RegionSummary_HTTK_Raven_Parent"},
    {CatalogueId="raven_b65148ce40189997a7ee6abb05551d95",Name="Completionist_V105_Raven_b65148ce40189997",UidHex="175DE4FF10D771FD",Realm="Midgard",RegionId="0000489975E7755D",ParentQuest="RegionSummary_HTTK_Raven_Parent"},
    {CatalogueId="raven_4f3ed8604f52329654cb89a77cb7b227",Name="Completionist_V105_Raven_4f3ed8604f523296",UidHex="5BDFDCC40708B704",Realm="Midgard",RegionId="0000489975E7755D",ParentQuest="RegionSummary_HTTK_Raven_Parent"},
    {CatalogueId="raven_ce4340a84992a449844e0394671c59eb",Name="Completionist_V105_Raven_ce4340a84992a449",UidHex="A9BA3AD986C6062D",Realm="Midgard",RegionId="0000489975E7755D",ParentQuest="RegionSummary_HTTK_Raven_Parent"},
    {CatalogueId="raven_0b07c75f438ce0cfe8b6feb7731ffc9c",Name="Completionist_V105_Raven_0b07c75f438ce0cf",UidHex="5B764018874C3076",Realm="Midgard",RegionId="3E2B34150449C3E7",ParentQuest="RegionSummary_HM01_Raven_Parent"},
    {CatalogueId="raven_d869e60744104a9e8865428d5fc2f63a",Name="Completionist_V105_Raven_d869e60744104a9e",UidHex="6C3689A3012B1F35",Realm="Midgard",RegionId="3E2B34150449C7F6",ParentQuest="RegionSummary_HM02_Raven_Parent"},
    {CatalogueId="raven_349cc1eb4752a6149cf89f9f94644092",Name="Completionist_V105_Raven_349cc1eb4752a614",UidHex="C14EFF68E72A3957",Realm="Midgard",RegionId="3E2B34150449C7F6",ParentQuest="RegionSummary_HM02_Raven_Parent"},
    {CatalogueId="raven_7ea7fe24483df9d884fd4790840bf692",Name="Completionist_V105_Raven_7ea7fe24483df9d8",UidHex="E61370AF12127058",Realm="Midgard",RegionId="7071EB6E695042F0",ParentQuest="RegionSummary_HSH_Raven_Parent"},
    {CatalogueId="raven_e01f95a84dd1e99dde0952856855399d",Name="Completionist_V105_Raven_e01f95a84dd1e99d",UidHex="68320FC1AD1F583D",Realm="Midgard",RegionId="7071EB6E695042F0",ParentQuest="RegionSummary_HSH_Raven_Parent"},
    {CatalogueId="raven_9deba5114d8045898dafc5be9add793b",Name="Completionist_V105_Raven_9deba5114d804589",UidHex="E3D252337EAF420F",Realm="Midgard",RegionId="0B6DF6C03C11EAB1",ParentQuest="RegionSummary_ISA_Raven_Parent"},
    {CatalogueId="raven_62fbf37c443c70aeca40ac840f6084b1",Name="Completionist_V105_Raven_62fbf37c443c70ae",UidHex="899396E22A253632",Realm="Midgard",RegionId="2FDD4E80C774CB0E",ParentQuest="RegionSummary_ISW_Raven_Parent"},
    {CatalogueId="raven_fa8d596f445ba456bc5b11905aa4af07",Name="Completionist_V105_Raven_fa8d596f445ba456",UidHex="8013FD7D4DD7B426",Realm="Midgard",RegionId="254A1280A3285151",ParentQuest="RegionSummary_MT_Raven_Parent"},
    {CatalogueId="raven_4532135740478ac108377e8b1c51a501",Name="Completionist_V105_Raven_4532135740478ac1",UidHex="7F019D16F7C2A561",Realm="Midgard",RegionId="ED623FA0A76B2934",ParentQuest="RegionSummary_PP_Raven_Parent"},
    {CatalogueId="raven_fb1ebb004216311e237c36b23a10707b",Name="Completionist_V105_Raven_fb1ebb004216311e",UidHex="5871B7E2287D2A6C",Realm="Midgard",RegionId="ED623FA0A76B2934",ParentQuest="RegionSummary_PP_Raven_Parent"},
    {CatalogueId="raven_b88e14b5413082e98c4d9cadcbf6ad10",Name="Completionist_V105_Raven_b88e14b5413082e9",UidHex="8034B66C18AF4433",Realm="Midgard",RegionId="ED623FA0A76B2934",ParentQuest="RegionSummary_PP_Raven_Parent"},
    {CatalogueId="raven_5a498384495d58916e944883eb2c90bb",Name="Completionist_V105_Raven_5a498384495d5891",UidHex="FFA0150372875D11",Realm="Midgard",RegionId="ED623FA0A76B2934",ParentQuest="RegionSummary_PP_Raven_Parent"},
    {CatalogueId="raven_100bb5c44d6b69eba68eb895d005f956",Name="Completionist_V105_Raven_100bb5c44d6b69eb",UidHex="B3CCC54892477D07",Realm="Midgard",RegionId="4EFD98E8E80E1239",ParentQuest="RegionSummary_RP_Raven_Parent"},
    {CatalogueId="raven_d9db91914694cfe73fa5b9abb208d25d",Name="Completionist_V105_Raven_d9db91914694cfe7",UidHex="F3859EDE52A924C6",Realm="Midgard",RegionId="4EFD98E8E80E1239",ParentQuest="RegionSummary_RP_Raven_Parent"},
    {CatalogueId="raven_97e41c48491b177e804019a649735e58",Name="Completionist_V105_Raven_97e41c48491b177e",UidHex="22E45B129D98FF0C",Realm="Midgard",RegionId="4EFD98E8E80E1239",ParentQuest="RegionSummary_RP_Raven_Parent"},
    {CatalogueId="raven_ccbc62d64eb0f79bbf76e9a08401a137",Name="Completionist_V105_Raven_ccbc62d64eb0f79b",UidHex="3B3AA9A54985EEAD",Realm="Midgard",RegionId="4EFD98E8E80E1239",ParentQuest="RegionSummary_RP_Raven_Parent"},
    {CatalogueId="raven_f8fdd3a4438c9697f8aa308323b2465e",Name="Completionist_V105_Raven_f8fdd3a4438c9697",UidHex="4F3249151CC9571C",Realm="Midgard",RegionId="4EFD98E8E80E1239",ParentQuest="RegionSummary_RP_Raven_Parent"},
    {CatalogueId="raven_ac45261c43ee745cd2e20a9cf61a817d",Name="Completionist_V105_Raven_ac45261c43ee745c",UidHex="BDBD4A14BF88FC2A",Realm="Midgard",RegionId="4EFD98E8E80E1239",ParentQuest="RegionSummary_RP_Raven_Parent"},
    {CatalogueId="raven_5a652cfb4af86af517b33c8676dbbfc5",Name="Completionist_V105_Raven_5a652cfb4af86af5",UidHex="4585940C8A61F596",Realm="Midgard",RegionId="4EFD98E8E80E1239",ParentQuest="RegionSummary_RP_Raven_Parent"},
    {CatalogueId="raven_8ca357c445d32c015159d6b93e173686",Name="Completionist_V105_Raven_8ca357c445d32c01",UidHex="D54F2CA5440A5C1D",Realm="Midgard",RegionId="848BB2D584D32E1B",ParentQuest="RegionSummary_SM_Raven_Parent"},
    {CatalogueId="raven_a70cd386408985c8bedbc98a7aaed456",Name="Completionist_V105_Raven_a70cd386408985c8",UidHex="D01919CCDEE91096",Realm="Midgard",RegionId="848BB2D584D32E1B",ParentQuest="RegionSummary_SM_Raven_Parent"},
    {CatalogueId="raven_642d0d164af0a5d4076e77933c549a5d",Name="Completionist_V103_Veithurgard_Raven_01",UidHex="E15E6BC82AE2773E",Realm="Midgard",RegionId="A1845BEF17F0E7BB",ParentQuest="RegionSummary_VF_Raven_Parent"},
    {CatalogueId="raven_c945cb53465b58decfcbd4a221cb5326",Name="Completionist_V105_Raven_c945cb53465b58de",UidHex="C9C31EE99E7E4339",Realm="Midgard",RegionId="A1845BEF17F0E7BB",ParentQuest="RegionSummary_VF_Raven_Parent"},
    {CatalogueId="raven_e32f7bab42fd7298890f6aa56a734562",Name="Completionist_V105_Raven_e32f7bab42fd7298",UidHex="ED1B8C2B562EE253",Realm="Midgard",RegionId="A1845BEF17F0E7BB",ParentQuest="RegionSummary_VF_Raven_Parent"},
  }
  local byName = {}
  local byCatalogueId = {}
  for _, row in ipairs(rows) do
    byName[row.Name] = row
    byCatalogueId[row.CatalogueId] = row
  end

  local byMarkerId = {}

  local states = _G.CompletionistMapV105RavenState or {}
  _G.CompletionistMapV105RavenState = states
  local eventKilled = _G.CompletionistMapV105EventKilled or {}
  _G.CompletionistMapV105EventKilled = eventKilled
  local hasAuthoritativeRavenState =
      _G.CompletionistMapV105HasAuthoritativeRavenState == true
  local previousPrompt = MapOn.GetShowOnCompassPrompt
  local previousShow = MapOn.ShowOnCompass
  local previousUpdate = MapOn.Update
  local previousCollision = MapOn.MapCollisionChangeHandler
  local lastMapOnSelf = nil
  local selectionGeneration = 0
  local promptIntent = nil
  local promptOverride = nil
  local promptSettleFrames = 0
  local promptSettleBucket = -1
  local customCompassOwnsTarget = false
  local nativeBoundaryPending = false
  local beginAuthorityBoundary = nil
  local hideStockExcept = nil
  local suppressLegacyRavenHud = nil
  local updateHighlights = nil
  local nativeBoundaryEpoch =
      tonumber(_G.CompletionistMapV105NativeBoundaryEpoch) or 0
  local nativeBoundaryCaptureReady = false
  local nativeBoundarySource = nil
  local nativeResetRecheckFrames = 0
  local nativeResetRecheckBucket = -1
  local nativeResetRecheckLimit = 360
  local nativePort = 43753
  local nativeRequest = "GET RAVEN_SNAPSHOT_V1\n"
  local nativeMaxResponseBytes = 4096
  local lastNativeGeneration = tonumber(_G.CompletionistMapV105LastNativeRavenGeneration)
  local lastNativeRestoreEpoch =
      tonumber(_G.CompletionistMapV105LastNativeRestoreEpoch)
  local lastNativeNotice = nil
  local lastRegionSummaryDiagnosticKey = nil
  local regionSummaryTargetCounts = {
    RegionSummary_CALS_Raven_Parent = 1,
    RegionSummary_RP_Raven_Parent = 6,
  }
  local regionSummaryBonusParents = {
    RegionSummary_CALS_Raven_Parent = true,
    RegionSummary_RP_Raven_Parent = true,
  }

  local function regionSummaryTargetCount(parent, physicalCount)
    return regionSummaryTargetCounts[parent] or physicalCount
  end

  local function log(category, fields)
    print(prefix .. category .. " " .. fields)
  end

  local function isCollected(catalogueId)
    return states[catalogueId] == true
  end

  local function shouldShow(catalogueId)
    return hasAuthoritativeRavenState and
        byCatalogueId[catalogueId] ~= nil and not isCollected(catalogueId)
  end

  local function nativeNotice(category, fields, key)
    if key == lastNativeNotice then return end
    lastNativeNotice = key
    log(category, fields)
  end

  local function buildRegionSummaryGroups()
    local groups = {}
    for _, row in ipairs(rows) do
      if type(row.ParentQuest) == "string" and row.ParentQuest ~= "" then
        local group = groups[row.ParentQuest]
        if group == nil then
          group = {count=0, realms={}, rows={}}
          groups[row.ParentQuest] = group
        end
        group.count = group.count + 1
        group.realms[row.Realm] = true
        group.rows[#group.rows + 1] = row
      end
    end
    return groups
  end

  local function readRegionSummaryCompleted(parent, physicalCount)
    if type(game) ~= "table" or type(game.QuestManager) ~= "table" or
        type(game.QuestManager.GetQuestProgressAndGoal) ~= "function" then
      return nil, "unavailable", nil, nil
    end
    local ok, progress, goal = pcall(
        game.QuestManager.GetQuestProgressAndGoal, parent)
    if not ok then return nil, "query_failed", nil, nil end

    local progressNumber = tonumber(progress)
    local goalNumber = tonumber(goal)
    local completed = nil
    local shape = "ambiguous"

    -- The PC runtime observed in field captures returns (nil, completed).
    -- Keep support for the conventional (progress, goal) shape when the goal
    -- exactly matches this one-to-one physical group.
    if progressNumber == nil and goalNumber ~= nil then
      completed = goalNumber
      shape = "second_only_completed"
    elseif progressNumber ~= nil and goalNumber == nil then
      completed = progressNumber
      shape = "first_only_completed"
    elseif progressNumber ~= nil and goalNumber ~= nil then
      if goalNumber == physicalCount and progressNumber >= 0 and
          progressNumber <= goalNumber then
        completed = progressNumber
        shape = "progress_goal"
      elseif progressNumber == physicalCount and goalNumber >= 0 and
          goalNumber <= progressNumber then
        completed = goalNumber
        shape = "goal_progress_reversed"
      end
    end

    if completed == nil or completed < 0 or completed > physicalCount or
        completed ~= math.floor(completed) then
      return nil, shape, progressNumber, goalNumber
    end
    return completed, shape, progressNumber, goalNumber
  end

  local function logRegionSummaryDiagnostics(source)
    if hasAuthoritativeRavenState then return end

    local groups = buildRegionSummaryGroups()
    local parents = {}
    for parent, _ in pairs(groups) do parents[#parents + 1] = parent end
    table.sort(parents)

    local records = {}
    local keyParts = {}
    for _, parent in ipairs(parents) do
      local group = groups[parent]
      local completed, shape, progressNumber, goalNumber =
          readRegionSummaryCompleted(
              parent, regionSummaryTargetCount(parent, group.count))
      local realmNames = {}
      for realm, _ in pairs(group.realms) do realmNames[#realmNames + 1] = realm end
      table.sort(realmNames)
      local realmText = table.concat(realmNames, ",")
      local constraintSafe =
          regionSummaryBonusParents[parent] ~= true and completed ~= nil
      local record =
          "parent=" .. parent ..
          " progress=" .. tostring(progressNumber) ..
          " goal=" .. tostring(goalNumber) ..
          " completed=" .. tostring(completed) ..
          " accessorShape=" .. tostring(shape) ..
          " catalogueCount=" .. tostring(group.count) ..
          " constraintSafe=" .. tostring(constraintSafe) ..
          " bonusParent=" .. tostring(regionSummaryBonusParents[parent] == true) ..
          " realms=" .. realmText
      records[#records + 1] = record
      keyParts[#keyParts + 1] = record
    end

    local key = table.concat(keyParts, "|")
    if key == lastRegionSummaryDiagnosticKey then return end
    lastRegionSummaryDiagnosticKey = key
    for _, record in ipairs(records) do
      log("REGION_SUMMARY_DIAGNOSTIC",
          "source=" .. tostring(source) .. " " .. record ..
          " readOnly=true progressionWrites=false")
    end
  end

  local function closeSocket(client)
    if client ~= nil then pcall(function() client:close() end) end
  end

  local function receiveNativeLine(client)
    local bytes = {}
    for index = 1, nativeMaxResponseBytes do
      local ok, value, err = pcall(function() return client:receive(1) end)
      if not ok or type(value) ~= "string" or string.len(value) ~= 1 then
        return nil, "receive:" .. tostring(ok and err or value)
      end
      if value == "\n" then return table.concat(bytes), nil end
      if value == "\r" then return nil, "response_cr" end
      bytes[index] = value
    end
    return nil, "response_too_large"
  end

  local function parseNativeSnapshot(line, expectedSchema, expectedBoundaryEpoch)
    local header = expectedSchema == 2 and "RAVEN_SNAPSHOT_V2 " or "RAVEN_SNAPSHOT_V1 "
    if expectedSchema == 1 and line == "RAVEN_SNAPSHOT_V1 UNAVAILABLE" then
      return nil, "snapshot_not_ready"
    end
    if expectedSchema == 2 and type(line) == "string" and
        string.sub(line, 1, string.len("RAVEN_SNAPSHOT_V2 UNAVAILABLE")) ==
            "RAVEN_SNAPSHOT_V2 UNAVAILABLE" then
      return nil, "boundary_snapshot_not_ready"
    end
    if type(line) ~= "string" or
        string.sub(line, 1, string.len(header)) ~= header then
      return nil, "response_header"
    end

    local partialHeader =
        expectedSchema == 2 and "RAVEN_SNAPSHOT_V2 PARTIAL " or
            "RAVEN_SNAPSHOT_V1 PARTIAL "
    local isPartial =
        string.sub(line, 1, string.len(partialHeader)) == partialHeader

    local fields = {}
    for key, value in string.gmatch(line, "([%a][%w]*)=([^%s]+)") do
      if fields[key] ~= nil then return nil, "duplicate_field:" .. key end
      fields[key] = value
    end

    local function integer(name)
      local value = tonumber(fields[name])
      if value == nil or value < 0 or value ~= math.floor(value) then
        return nil
      end
      return value
    end

    local schema = integer("schema")
    local generation = integer("generation")
    local capturedTickMs = integer("capturedTickMs")
    local count = integer("count")
    local unknown = integer("unknown")
    local alive = integer("alive")
    local killed = integer("killed")
    local explicit = integer("explicit")
    local absentWadFalse = integer("absentWadFalse")
    local restoreEpoch = expectedSchema == 1 and integer("restoreEpoch") or nil
    local boundaryEpoch = expectedSchema == 2 and integer("boundaryEpoch") or nil

    if schema ~= expectedSchema or capturedTickMs == nil or count ~= #rows or
        unknown == nil or alive == nil or killed == nil or
        explicit == nil or absentWadFalse == nil or
        fields.killedIds == nil or
        (expectedSchema == 1 and restoreEpoch == nil) then
      return nil, "response_counts"
    end
    if expectedSchema == 2 and
        (boundaryEpoch == nil or boundaryEpoch < 1 or
         boundaryEpoch ~= expectedBoundaryEpoch) then
      return nil, "boundary_epoch_mismatch"
    end

    if isPartial then
      if generation ~= nil or
          (unknown < 1 and absentWadFalse < 1) or
          alive + killed + unknown ~= #rows or
          explicit + absentWadFalse > alive + killed or
          fields.unknownIds == nil or fields.absenceIds == nil then
        return nil, "partial_counts"
      end

      local states = {}
      for catalogueId, _ in pairs(byCatalogueId) do states[catalogueId] = false end

      local unknownCatalogueIds = {}
      local unknownSeen = {}
      if fields.unknownIds ~= "-" then
        for catalogueId in string.gmatch(fields.unknownIds, "([^,]+)") do
          if byCatalogueId[catalogueId] == nil then
            return nil, "unknown_catalogue_id"
          end
          if unknownSeen[catalogueId] then
            return nil, "duplicate_unknown_catalogue_id"
          end
          unknownSeen[catalogueId] = true
          states[catalogueId] = nil
          unknownCatalogueIds[#unknownCatalogueIds + 1] = catalogueId
        end
      end
      if #unknownCatalogueIds ~= unknown then
        return nil, "partial_unknown_count"
      end

      local absenceCatalogueIds = {}
      local absenceSeen = {}
      if fields.absenceIds ~= "-" then
        for catalogueId in string.gmatch(fields.absenceIds, "([^,]+)") do
          if byCatalogueId[catalogueId] == nil then
            return nil, "unknown_catalogue_id"
          end
          if unknownSeen[catalogueId] or absenceSeen[catalogueId] then
            return nil, "partial_absence_overlap"
          end
          absenceSeen[catalogueId] = true
          absenceCatalogueIds[#absenceCatalogueIds + 1] = catalogueId
        end
      end
      if #absenceCatalogueIds ~= absentWadFalse then
        return nil, "partial_absence_count"
      end

      local killedCatalogueIds = {}
      local killedSeen = {}
      if fields.killedIds ~= "-" then
        for catalogueId in string.gmatch(fields.killedIds, "([^,]+)") do
          if byCatalogueId[catalogueId] == nil then
            return nil, "unknown_catalogue_id"
          end
          if unknownSeen[catalogueId] or absenceSeen[catalogueId] then
            return nil, "partial_overlap"
          end
          if killedSeen[catalogueId] then
            return nil, "duplicate_catalogue_id"
          end
          killedSeen[catalogueId] = true
          states[catalogueId] = true
          killedCatalogueIds[#killedCatalogueIds + 1] = catalogueId
        end
      end
      if #killedCatalogueIds ~= killed then return nil, "killed_count" end

      local inferredAlive = 0
      for catalogueId, _ in pairs(byCatalogueId) do
        if states[catalogueId] == false then inferredAlive = inferredAlive + 1 end
      end
      if inferredAlive ~= alive then return nil, "partial_alive_count" end

      return {
        partial = true,
        schema = schema, capturedTickMs = capturedTickMs,
        restoreEpoch = restoreEpoch, boundaryEpoch = boundaryEpoch,
        count = count, unknownCount = unknown,
        aliveCount = alive, killedCount = killed,
        explicitCount = explicit,
        absenceDefaultFalseCount = absentWadFalse,
        states = states,
        killedCatalogueIds = killedCatalogueIds,
        unknownCatalogueIds = unknownCatalogueIds,
        absenceCatalogueIds = absenceCatalogueIds,
      }, nil
    end

    -- A stable raw fresh-save image is all absence-default false rows.
    -- Process-local positive kill notes from the previous save can still be
    -- merged into that image before Lua sees it when no gameplay Raven exists
    -- to advance the bridge epoch. In that exact case the apparent killed rows
    -- are overlay-only: explicit remains zero and each overlay kill replaces
    -- one absence-default row. Preserve the shape for RegionSummary-guarded
    -- fresh-zero normalization instead of rejecting it as malformed.
    local freshZeroOverlayShape =
        explicit == 0 and alive + killed == #rows and
        absentWadFalse + killed == #rows
    if generation == nil or generation < 1 or unknown ~= 0 or
        alive + killed ~= #rows or
        (explicit + absentWadFalse ~= #rows and not freshZeroOverlayShape) then
      return nil, "response_counts"
    end

    local states = {}
    for catalogueId, _ in pairs(byCatalogueId) do states[catalogueId] = false end
    local killedCatalogueIds = {}
    if fields.killedIds ~= "-" then
      for catalogueId in string.gmatch(fields.killedIds, "([^,]+)") do
        if byCatalogueId[catalogueId] == nil then
          return nil, "unknown_catalogue_id"
        end
        if states[catalogueId] == true then
          return nil, "duplicate_catalogue_id"
        end
        states[catalogueId] = true
        killedCatalogueIds[#killedCatalogueIds + 1] = catalogueId
      end
    end
    if #killedCatalogueIds ~= killed then return nil, "killed_count" end

    return {
      partial = false,
      schema = schema, generation = generation, capturedTickMs = capturedTickMs,
      restoreEpoch = restoreEpoch, boundaryEpoch = boundaryEpoch,
      count = count, unknownCount = 0,
      aliveCount = alive, killedCount = killed,
      explicitCount = explicit,
      absenceDefaultFalseCount = absentWadFalse,
      states = states, killedCatalogueIds = killedCatalogueIds,
    }, nil
  end

  local function requestNativeSnapshot(request, schema, boundaryEpoch)
    local socketOK, socket = pcall(require, "socket.core")
    if not socketOK or type(socket) ~= "table" or type(socket.tcp) ~= "function" then
      return nil, "socket_core_unavailable"
    end
    local createOK, client = pcall(socket.tcp)
    if not createOK or client == nil then return nil, "socket_create" end
    pcall(function() client:settimeout(0.25) end)
    pcall(function() client:settimeout(0.25, "t") end)
    local connectOK, connected, connectError = pcall(function()
      return client:connect("127.0.0.1", nativePort)
    end)
    if not connectOK or connected == nil then
      closeSocket(client)
      return nil, "connect:" .. tostring(connectOK and connectError or connected)
    end
    local sendOK, sent, sendError = pcall(function()
      return client:send(request)
    end)
    if not sendOK or sent ~= string.len(request) then
      closeSocket(client)
      return nil, "send:" .. tostring(sendOK and sendError or sent)
    end
    local line, receiveError = receiveNativeLine(client)
    closeSocket(client)
    if line == nil then return nil, receiveError end
    return parseNativeSnapshot(line, schema, boundaryEpoch)
  end

  local function getRavenSnapshot()
    return requestNativeSnapshot(nativeRequest, 1, nil)
  end

  local function captureRavenBoundarySnapshot(boundaryEpoch)
    if type(boundaryEpoch) ~= "number" or boundaryEpoch < 1 or
        boundaryEpoch ~= math.floor(boundaryEpoch) then
      return nil, "invalid_boundary_epoch"
    end
    local request = "CAPTURE RAVEN_SNAPSHOT_V2 boundaryEpoch=" ..
        tostring(boundaryEpoch) .. "\n"
    return requestNativeSnapshot(request, 2, boundaryEpoch)
  end

  local nativeNamespace = rawget(_G, "CompletionistMapNative")
  if nativeNamespace == nil then
    nativeNamespace = {}
    rawset(_G, "CompletionistMapNative", nativeNamespace)
  end
  if type(nativeNamespace) == "table" then
    if rawget(nativeNamespace, "GetRavenSnapshot") == nil then
      nativeNamespace.GetRavenSnapshot = getRavenSnapshot
    elseif type(nativeNamespace.GetRavenSnapshot) ~= "function" then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=api_collision:get", "api_collision:get")
    end

    if rawget(nativeNamespace, "CaptureRavenBoundarySnapshot") == nil then
      nativeNamespace.CaptureRavenBoundarySnapshot = captureRavenBoundarySnapshot
    elseif type(nativeNamespace.CaptureRavenBoundarySnapshot) ~= "function" then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=api_collision:capture", "api_collision:capture")
    end
  else
    nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
        "reason=namespace_collision", "namespace_collision")
  end

  local function validateFullNativeAuthority(snapshot, source)
    if type(snapshot) ~= "table" or type(snapshot.states) ~= "table" then
      return false, "full_invalid"
    end

    local groups = buildRegionSummaryGroups()

    -- The native publication gate already requires the raw all-false image to
    -- remain stable for 750 ms. A fresh save can inherit process-local positive
    -- kill notes from the previous save if no Raven gameplay instance existed
    -- to advance the bridge epoch. Those overlay-only kills are recognizable:
    -- no state is explicit, and every apparent kill replaces one WAD-absence
    -- default row. RegionSummary is the independent veto before normalizing
    -- that exact shape back to the raw 0/53 fresh authority.
    local freshZeroBase =
        snapshot.explicitCount == 0 and
        snapshot.aliveCount + snapshot.killedCount == #rows and
        snapshot.absenceDefaultFalseCount + snapshot.killedCount == #rows
    if freshZeroBase then
      for parent, group in pairs(groups) do
        local targetCount = regionSummaryTargetCount(parent, group.count)
        local completed = readRegionSummaryCompleted(parent, targetCount)
        if completed ~= nil and completed > 0 then
          nativeNotice("NATIVE_AUTHORITY_REGION_REFUSED",
              "reason=fresh_zero_conflict parent=" .. tostring(parent) ..
              " completed=" .. tostring(completed) ..
              " overlayKilled=" .. tostring(snapshot.killedCount) ..
              " source=" .. tostring(source),
              "fresh_zero_conflict:" .. tostring(parent) .. ":" ..
              tostring(completed) .. ":" .. tostring(snapshot.killedCount))
          return false, "fresh_zero_region_summary_conflict", false
        end
      end
      if snapshot.killedCount > 0 then
        nativeNotice("NATIVE_AUTHORITY_FRESH_ZERO_NORMALIZED",
            "overlayKilled=" .. tostring(snapshot.killedCount) ..
            " source=" .. tostring(source) ..
            " readOnly=true progressionWrites=false",
            "fresh_zero_normalized:" .. tostring(snapshot.killedCount))
      end
      return true, nil, true
    end
    for parent, group in pairs(groups) do
      local targetCount = regionSummaryTargetCount(parent, group.count)
      local completed, shape =
          readRegionSummaryCompleted(parent, targetCount)
      if completed == nil then
        nativeNotice("NATIVE_AUTHORITY_REGION_REFUSED",
            "reason=region_summary_ambiguous parent=" .. tostring(parent) ..
            " accessorShape=" .. tostring(shape) ..
            " source=" .. tostring(source),
            "full_region_summary:" .. tostring(parent))
        return false, "region_summary_ambiguous"
      end

      local nativeKilled = 0
      for _, row in ipairs(group.rows) do
        if snapshot.states[row.CatalogueId] == true then
          nativeKilled = nativeKilled + 1
        end
      end

      local valid = nativeKilled == completed
      if regionSummaryBonusParents[parent] == true then
        valid = valid or nativeKilled == completed + 1
      end
      if not valid then
        nativeNotice("NATIVE_AUTHORITY_REGION_REFUSED",
            "reason=count_conflict parent=" .. tostring(parent) ..
            " completed=" .. tostring(completed) ..
            " nativeKilled=" .. tostring(nativeKilled) ..
            " physical=" .. tostring(group.count) ..
            " target=" .. tostring(targetCount) ..
            " bonusParent=" ..
            tostring(regionSummaryBonusParents[parent] == true) ..
            " source=" .. tostring(source),
            "full_count_conflict:" .. tostring(parent) .. ":" ..
            tostring(completed) .. ":" .. tostring(nativeKilled))
        return false, "region_summary_count_conflict"
      end
    end
    return true, nil
  end

  local function resolvePartialNativeAuthority(
      snapshot, source, boundaryApply, requestedBoundaryEpoch)
    if snapshot.partial ~= true or type(snapshot.states) ~= "table" or
        type(snapshot.unknownCount) ~= "number" or
        type(snapshot.absenceCatalogueIds) ~= "table" then
      return false, "partial_invalid"
    end
    if snapshot.unknownCount < 0 or snapshot.absenceDefaultFalseCount < 0 or
        snapshot.unknownCount + snapshot.absenceDefaultFalseCount < 1 then
      return false, "partial_invalid"
    end
    if boundaryApply and snapshot.boundaryEpoch ~= requestedBoundaryEpoch then
      return false, "partial_boundary_epoch_mismatch"
    end

    local groups = buildRegionSummaryGroups()
    local resolved = {}
    for catalogueId, _ in pairs(byCatalogueId) do
      resolved[catalogueId] = snapshot.states[catalogueId]
    end

    local absenceSeen = {}
    for _, catalogueId in ipairs(snapshot.absenceCatalogueIds) do
      if byCatalogueId[catalogueId] == nil or absenceSeen[catalogueId] then
        return false, "partial_absence_invalid"
      end
      absenceSeen[catalogueId] = true
      if resolved[catalogueId] ~= false then
        return false, "partial_absence_state"
      end
      resolved[catalogueId] = nil
    end

    local solvedUnresolved = 0
    local expectedUnresolved =
        snapshot.unknownCount + snapshot.absenceDefaultFalseCount

    for parent, group in pairs(groups) do
      local unresolvedRows = {}
      local knownKilled = 0
      for _, row in ipairs(group.rows) do
        local state = resolved[row.CatalogueId]
        if state == nil then
          unresolvedRows[#unresolvedRows + 1] = row
        elseif state == true then
          knownKilled = knownKilled + 1
        elseif state ~= false then
          return false, "partial_state_type"
        end
      end

      local targetCount = regionSummaryTargetCount(parent, group.count)
      local completed, shape =
          readRegionSummaryCompleted(parent, targetCount)
      if completed == nil then
        nativeNotice("NATIVE_AUTHORITY_PARTIAL_REFUSED",
            "reason=region_summary_ambiguous parent=" .. tostring(parent) ..
            " accessorShape=" .. tostring(shape),
            "partial_region_summary:" .. tostring(parent))
        return false, "partial_region_summary"
      end

      if regionSummaryBonusParents[parent] == true then
        if #unresolvedRows > 0 then
          nativeNotice("NATIVE_AUTHORITY_PARTIAL_REFUSED",
              "reason=bonus_parent_unresolved parent=" .. tostring(parent) ..
              " unknown=" .. tostring(#unresolvedRows),
              "partial_bonus_parent:" .. tostring(parent))
          return false, "partial_bonus_parent"
        end
        if knownKilled ~= completed and knownKilled ~= completed + 1 then
          nativeNotice("NATIVE_AUTHORITY_PARTIAL_REFUSED",
              "reason=bonus_count_conflict parent=" .. tostring(parent) ..
              " completed=" .. tostring(completed) ..
              " knownKilled=" .. tostring(knownKilled),
              "partial_bonus_conflict:" .. tostring(parent))
          return false, "partial_bonus_conflict"
        end
      else
        local remainingKilled = completed - knownKilled
        if remainingKilled < 0 or remainingKilled > #unresolvedRows then
          nativeNotice("NATIVE_AUTHORITY_PARTIAL_REFUSED",
              "reason=constraint_conflict parent=" .. tostring(parent) ..
              " completed=" .. tostring(completed) ..
              " knownKilled=" .. tostring(knownKilled) ..
              " unresolved=" .. tostring(#unresolvedRows),
              "partial_constraint_conflict:" .. tostring(parent))
          return false, "partial_constraint_conflict"
        end

        if #unresolvedRows == 0 then
          if remainingKilled ~= 0 then
            return false, "partial_constraint_conflict"
          end
        else
          local resolvedKilled = nil
          if remainingKilled == 0 then
            resolvedKilled = false
          elseif remainingKilled == #unresolvedRows then
            resolvedKilled = true
          else
            nativeNotice("NATIVE_AUTHORITY_PARTIAL_REFUSED",
                "reason=constraint_not_unique parent=" .. tostring(parent) ..
                " remainingKilled=" .. tostring(remainingKilled) ..
                " unresolved=" .. tostring(#unresolvedRows),
                "partial_constraint_not_unique:" .. tostring(parent))
            return false, "partial_constraint_not_unique"
          end

          for _, row in ipairs(unresolvedRows) do
            resolved[row.CatalogueId] = resolvedKilled
            solvedUnresolved = solvedUnresolved + 1
          end
        end
      end
    end

    if solvedUnresolved ~= expectedUnresolved then
      nativeNotice("NATIVE_AUTHORITY_PARTIAL_REFUSED",
          "reason=unmapped_unresolved solved=" .. tostring(solvedUnresolved) ..
          " expected=" .. tostring(expectedUnresolved),
          "partial_unmapped_unresolved")
      return false, "partial_unmapped_unresolved"
    end

    local killedIds = {}
    local aliveCount = 0
    for catalogueId, _ in pairs(byCatalogueId) do
      local value = resolved[catalogueId]
      if type(value) ~= "boolean" then
        nativeNotice("NATIVE_AUTHORITY_PARTIAL_REFUSED",
            "reason=incomplete_states catalogueId=" .. tostring(catalogueId),
            "partial_incomplete_states")
        return false, "partial_incomplete_states"
      end
      if value then
        killedIds[#killedIds + 1] = catalogueId
      else
        aliveCount = aliveCount + 1
      end
    end
    if #killedIds + aliveCount ~= #rows then
      return false, "partial_resolved_counts"
    end

    local apply = _G.CompletionistMapV105ApplyPersistedRavenKills
    if type(apply) ~= "function" then
      return false, "apply_api_unavailable"
    end
    local applied, accepted = apply(
        killedIds,
        "native_partial_region_summary:" .. tostring(source) ..
        (boundaryApply and ":boundaryEpoch:" ..
            tostring(requestedBoundaryEpoch) or ""),
        boundaryApply)
    if applied ~= true or accepted ~= #killedIds then
      return false, "partial_apply_refused"
    end

    if boundaryApply then
      lastNativeRestoreEpoch = requestedBoundaryEpoch
      _G.CompletionistMapV105LastNativeRestoreEpoch = requestedBoundaryEpoch
      if type(_G.CompletionistMapV105LocationAuthorityReady) == "function" then _G.CompletionistMapV105LocationAuthorityReady(requestedBoundaryEpoch) end
      nativeBoundaryPending = false
      nativeBoundaryCaptureReady = false
      nativeBoundarySource = nil
      nativeResetRecheckFrames = 0
      nativeResetRecheckBucket = -1
    elseif snapshot.restoreEpoch ~= nil then
      lastNativeRestoreEpoch = snapshot.restoreEpoch
      _G.CompletionistMapV105LastNativeRestoreEpoch = snapshot.restoreEpoch
      if type(_G.CompletionistMapV105LocationAuthorityReady) == "function" then _G.CompletionistMapV105LocationAuthorityReady(snapshot.restoreEpoch) end
    end

    lastNativeNotice = nil
    log("NATIVE_AUTHORITY_DERIVED",
        "knownKilled=" .. tostring(snapshot.killedCount) ..
        " knownAlive=" .. tostring(snapshot.aliveCount) ..
        " nativeUnknown=" .. tostring(snapshot.unknownCount) ..
        " absenceUnresolved=" ..
        tostring(snapshot.absenceDefaultFalseCount) ..
        " resolvedUnresolved=" .. tostring(expectedUnresolved) ..
        " finalKilled=" .. tostring(#killedIds) ..
        " finalAlive=" .. tostring(aliveCount) ..
        " postBoundary=" .. tostring(boundaryApply) ..
        " boundaryEpoch=" ..
        tostring(boundaryApply and requestedBoundaryEpoch or 0) ..
        " restoreEpoch=" ..
        tostring(boundaryApply and requestedBoundaryEpoch or
            snapshot.restoreEpoch or 0) ..
        " authority=native_partial_plus_region_summary" ..
        " readOnly=true progressionWrites=false")
    return true, nil
  end

  local function refreshNativeAuthority(source)
    local namespace = rawget(_G, "CompletionistMapNative")
    if type(namespace) ~= "table" then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=namespace_unavailable", "namespace_unavailable")
      return false, "namespace_unavailable"
    end

    local boundaryApply = nativeBoundaryPending
    local requestedBoundaryEpoch = nil
    local accessor = nil
    if boundaryApply then
      if not nativeBoundaryCaptureReady then
        nativeNotice("NATIVE_AUTHORITY_BOUNDARY_WAIT",
            "epoch=" .. tostring(nativeBoundaryEpoch) ..
            " source=" .. tostring(nativeBoundarySource) ..
            " reason=load_not_complete",
            "boundary_not_ready:" .. tostring(nativeBoundaryEpoch))
        return false, "boundary_not_ready"
      end
      accessor = namespace.CaptureRavenBoundarySnapshot
      requestedBoundaryEpoch = nativeBoundaryEpoch
    else
      accessor = namespace.GetRavenSnapshot
    end

    if type(accessor) ~= "function" then
      local apiName = boundaryApply and "capture_api_unavailable" or "api_unavailable"
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=" .. apiName, apiName)
      return false, apiName
    end

    local ok, snapshot, reason
    if boundaryApply then
      ok, snapshot, reason = pcall(accessor, requestedBoundaryEpoch)
    else
      ok, snapshot, reason = pcall(accessor)
    end
    if not ok or type(snapshot) ~= "table" then
      local unavailable = ok and tostring(reason) or "call_failed:" .. tostring(snapshot)
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=" .. unavailable,
          "unavailable:" .. tostring(boundaryApply) .. ":" .. unavailable)
      return false, unavailable
    end

    if not boundaryApply then
      local restoreEpoch = tonumber(snapshot.restoreEpoch)
      if restoreEpoch == nil or restoreEpoch < 0 or
          restoreEpoch ~= math.floor(restoreEpoch) then
        nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
            "reason=invalid_restore_epoch", "invalid_restore_epoch")
        return false, "invalid_restore_epoch"
      end
      if lastNativeRestoreEpoch ~= nil and restoreEpoch < lastNativeRestoreEpoch then
        nativeNotice("NATIVE_AUTHORITY_STALE",
            "restoreEpoch=" .. tostring(restoreEpoch) ..
            " lastRestoreEpoch=" .. tostring(lastNativeRestoreEpoch),
            "stale_restore_epoch:" .. tostring(restoreEpoch))
        return false, "stale_restore_epoch"
      end
      if restoreEpoch > 0 and
          (lastNativeRestoreEpoch == nil or restoreEpoch > lastNativeRestoreEpoch) then
        if type(beginAuthorityBoundary) ~= "function" then
          return false, "boundary_api_unavailable"
        end
        beginAuthorityBoundary("native_restore_epoch", true, restoreEpoch)
        return refreshNativeAuthority(tostring(source) .. ":restore_epoch")
      end
    end

    if snapshot.partial == true then
      local resolved, partialReason = resolvePartialNativeAuthority(
          snapshot, source, boundaryApply, requestedBoundaryEpoch)
      if not resolved then
        nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
            "reason=" .. tostring(partialReason),
            "partial_unavailable:" .. tostring(partialReason))
      end
      return resolved, partialReason
    end

    local regionValid, regionReason, normalizeFreshZero =
        validateFullNativeAuthority(snapshot, source)
    if not regionValid then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=" .. tostring(regionReason),
          "full_region_unavailable:" .. tostring(regionReason))
      return false, regionReason
    end

    local generation = tonumber(snapshot.generation)
    if generation == nil or generation < 1 or generation ~= math.floor(generation) then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=invalid_generation", "invalid_generation")
      return false, "invalid_generation"
    end
    if lastNativeGeneration ~= nil and generation <= lastNativeGeneration then
      nativeNotice("NATIVE_AUTHORITY_STALE",
          "generation=" .. tostring(generation) ..
          " last=" .. tostring(lastNativeGeneration) ..
          " postBoundary=" .. tostring(boundaryApply),
          "stale:" .. tostring(generation) .. ":" .. tostring(lastNativeGeneration))
      return false, "stale"
    end

    local expectedSchema = boundaryApply and 2 or 1
    local freshZeroBase =
        normalizeFreshZero == true and
        snapshot.explicitCount == 0 and
        snapshot.aliveCount + snapshot.killedCount == #rows and
        snapshot.absenceDefaultFalseCount + snapshot.killedCount == #rows
    if type(snapshot.states) ~= "table" or snapshot.schema ~= expectedSchema or
        type(snapshot.count) ~= "number" or snapshot.count ~= #rows or
        type(snapshot.aliveCount) ~= "number" or
        type(snapshot.killedCount) ~= "number" or
        snapshot.aliveCount + snapshot.killedCount ~= #rows or
        type(snapshot.explicitCount) ~= "number" or
        type(snapshot.absenceDefaultFalseCount) ~= "number" or
        (snapshot.explicitCount + snapshot.absenceDefaultFalseCount ~= #rows and
         not freshZeroBase) then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=invalid_snapshot", "invalid_snapshot")
      return false, "invalid_snapshot"
    end

    if boundaryApply and snapshot.boundaryEpoch ~= requestedBoundaryEpoch then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=boundary_epoch_mismatch expected=" ..
          tostring(requestedBoundaryEpoch) .. " actual=" ..
          tostring(snapshot.boundaryEpoch),
          "boundary_epoch_mismatch:" .. tostring(requestedBoundaryEpoch) ..
          ":" .. tostring(snapshot.boundaryEpoch))
      return false, "boundary_epoch_mismatch"
    end

    local killedIds = {}
    for catalogueId, _ in pairs(byCatalogueId) do
      local value = snapshot.states[catalogueId]
      if type(value) ~= "boolean" then
        nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
            "reason=incomplete_states", "incomplete_states")
        return false, "incomplete_states"
      end
      if not freshZeroBase and value then
        killedIds[#killedIds + 1] = catalogueId
      end
    end
    if (not freshZeroBase and #killedIds ~= snapshot.killedCount) or
        (freshZeroBase and #killedIds ~= 0) then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=state_count_mismatch", "state_count_mismatch")
      return false, "state_count_mismatch"
    end

    local apply = _G.CompletionistMapV105ApplyPersistedRavenKills
    if type(apply) ~= "function" then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=apply_api_unavailable", "apply_api_unavailable")
      return false, "apply_api_unavailable"
    end

    local applied, accepted = apply(
        killedIds,
        "native:" .. tostring(source) ..
        ":generation:" .. tostring(generation) ..
        (boundaryApply and ":boundaryEpoch:" ..
            tostring(requestedBoundaryEpoch) or ""),
        boundaryApply)
    if applied ~= true or accepted ~= #killedIds then
      nativeNotice("NATIVE_AUTHORITY_UNAVAILABLE",
          "reason=apply_refused", "apply_refused")
      return false, "apply_refused"
    end

    lastNativeGeneration = generation
    _G.CompletionistMapV105LastNativeRavenGeneration = generation
    if boundaryApply then
      lastNativeRestoreEpoch = requestedBoundaryEpoch
      _G.CompletionistMapV105LastNativeRestoreEpoch = requestedBoundaryEpoch
      if type(_G.CompletionistMapV105LocationAuthorityReady) == "function" then _G.CompletionistMapV105LocationAuthorityReady(requestedBoundaryEpoch) end
      nativeBoundaryPending = false
      nativeBoundaryCaptureReady = false
      nativeBoundarySource = nil
      nativeResetRecheckFrames = 0
      nativeResetRecheckBucket = -1
    elseif snapshot.restoreEpoch ~= nil then
      lastNativeRestoreEpoch = snapshot.restoreEpoch
      _G.CompletionistMapV105LastNativeRestoreEpoch = snapshot.restoreEpoch
      if type(_G.CompletionistMapV105LocationAuthorityReady) == "function" then _G.CompletionistMapV105LocationAuthorityReady(snapshot.restoreEpoch) end
    end

    lastNativeNotice = nil
    log("NATIVE_AUTHORITY_APPLIED",
        "generation=" .. tostring(generation) ..
        " killed=" .. tostring(snapshot.killedCount) ..
        " alive=" .. tostring(snapshot.aliveCount) ..
        " explicit=" .. tostring(snapshot.explicitCount) ..
        " absentWadFalse=" .. tostring(snapshot.absenceDefaultFalseCount) ..
        " postBoundary=" .. tostring(boundaryApply) ..
        " boundaryEpoch=" ..
        tostring(boundaryApply and requestedBoundaryEpoch or 0) ..
        " restoreEpoch=" ..
        tostring(boundaryApply and requestedBoundaryEpoch or snapshot.restoreEpoch or 0) ..
        " authority=" .. (boundaryApply and "capture_v2" or "latest_v1"))
    return true, nil
  end

  local function rememberMarkerId(name, info)
    if type(name) ~= "string" or type(info) ~= "table" or info.Id == nil then return end
    byMarkerId[tostring(info.Id)] = name
  end

  local function markerInfo(name)
    local ok, info = pcall(function() return game.Map.GetMarkerInfo(name) end)
    if not ok or type(info) ~= "table" or info.Id == nil then return nil end
    rememberMarkerId(name, info)
    return info
  end

  local function knownNameForId(id)
    if id == nil then return nil end
    local key = tostring(id)
    local cached = byMarkerId[key]
    if cached ~= nil then return cached end
    for name, _ in pairs(byName) do
      local info = markerInfo(name)
      if info ~= nil and tostring(info.Id) == key then return name end
    end
    return nil
  end

  local function recycle(go)
    if go == nil then return true end
    local ok = pcall(function() Map.RecycleIcon(go) end)
    return ok
  end

  local function clearLegacy(self)
    if self.completionistSharedLoaderTwinGO ~= nil then
      recycle(self.completionistSharedLoaderTwinGO)
      self.completionistSharedLoaderTwinGO = nil
    end
    if self.completionistMapV100MapIconGO ~= nil then
      recycle(self.completionistMapV100MapIconGO)
      self.completionistMapV100MapIconGO = nil
    end
    self.completionistMapV100Selected = false
  end

  local function clearSelection(self, reason)
    local selected = self and self.completionistMapV105SelectedRaven or nil
    if selected ~= nil then
      log("SELECT_DISARM", "reason=" .. tostring(reason) ..
          " name=" .. selected.Name .. " uid=" .. selected.IdString)
    end
    selectionGeneration = selectionGeneration + 1
    if self ~= nil then self.completionistMapV105SelectedRaven = nil end
  end

  local function clearIcons(self, reason)
    local icons = self.completionistMapV105RavenIcons or {}
    for name, go in pairs(icons) do
      recycle(go)
      if self.mapIconCollision == go then self.mapIconCollision = nil end
      icons[name] = nil
    end
    self.completionistMapV105RavenIcons = icons
    self.completionistMapV105RavenVisibilityKey = nil
    promptIntent = nil
    promptSettleFrames = 0
    promptSettleBucket = -1
    clearSelection(self, reason)
  end

  -- v0.10.1's pinned map source defines the custom filter contract as:
  --   1    = Show All
  --   -101 = Completionist
  --   -102 = Ravens
  -- The all-Ravens layer must follow that same contract and must never render
  -- collectible pins while the map is opened for Mystic Gateway fast travel.
  local function ravenFilterKind(self)
    if self == nil or type(self.filterButtonMapping) ~= "table" then return 1 end
    local index = tonumber(self.filterIndex) or 1
    return self.filterButtonMapping[index] or 1
  end

  local function ravenMapVisible(self)
    if self == nil or self.isOpenedForFastTravel == true then return false end
    local filter = ravenFilterKind(self)
    if filter == 1 then
      if _G.CompletionistMapV105ShowAll and not _G.CompletionistMapV105ShowAll() then
        return false
      end
      return true
    elseif filter == -101 or filter == -102 then
      if _G.CompletionistMapV105ShowCategories and not _G.CompletionistMapV105ShowCategories() then
        return false
      end
      return true
    end
    return false
  end

  local function ravenVisibilityKey(self)
    return tostring(self and self.currRealmName or "-") .. ":" ..
      tostring(self and self.isOpenedForFastTravel == true) .. ":" ..
      tostring(ravenFilterKind(self)) .. ":" ..
      tostring(_G.CompletionistMapV105ShowAll and _G.CompletionistMapV105ShowAll() or false) .. ":" ..
      tostring(_G.CompletionistMapV105ShowCategories and _G.CompletionistMapV105ShowCategories() or true)
  end

  local function syncIcons(self, reason)
    if self == nil then return end
    lastMapOnSelf = self
    clearLegacy(self)
    local icons = self.completionistMapV105RavenIcons or {}
    self.completionistMapV105RavenIcons = icons
    local realm = self.currRealmName
    local mapVisible = ravenMapVisible(self)
    local filter = ravenFilterKind(self)
    local visibilityKey = ravenVisibilityKey(self)
    if self.completionistMapV105RavenVisibilityKey ~= visibilityKey then
      self.completionistMapV105RavenVisibilityKey = visibilityKey
      log("MAP_VISIBILITY",
          "reason=" .. tostring(reason) ..
          " realm=" .. tostring(realm) ..
          " fastTravel=" .. tostring(self.isOpenedForFastTravel == true) ..
          " filter=" .. tostring(filter) ..
          " ravensVisible=" .. tostring(mapVisible))
    end

    if not mapVisible then
      clearSelection(self, "raven_map_hidden_by_mode_or_filter")
    end

    for name, go in pairs(icons) do
      local row = byName[name]
      if row == nil or row.Realm ~= realm or isCollected(row.CatalogueId) then
        recycle(go)
        if self.mapIconCollision == go then self.mapIconCollision = nil end
        icons[name] = nil
      else
        pcall(function()
          if mapVisible then go:Show() else go:Hide() end
        end)
      end
    end
    if not mapVisible then return end

    for _, row in ipairs(rows) do
      if row.Realm == realm and shouldShow(row.CatalogueId) and icons[row.Name] == nil then
        local ok, value = pcall(function()
          local info = markerInfo(row.Name)
          if info == nil then return nil, "marker_info" end
          local found, region = Map.FindRegionFromMarker(info.Id)
          if found ~= true or region == nil then return nil, "region" end
          return Map.CreateMarkerIcon(info.Id, region, ""), nil
        end)
        local go = ok and value or nil
        if go ~= nil then
          icons[row.Name] = go
          go:Show()
        else
          log("ICON_CREATE_FAILED", "name=" .. row.Name .. " reason=" .. tostring(reason))
        end
      end
    end
  end

  _G.CompletionistMapV105ResyncRavens = function(target)
    local map = target or lastMapOnSelf
    if map ~= nil then
      syncIcons(map, "toggle_markers")
    end
  end

    local previousNextFilter = MapOn.Menu_Next_Filter
  if type(previousNextFilter) == "function" then
    MapOn.Menu_Next_Filter = function(self, ...)
      local result = previousNextFilter(self, ...)
      syncIcons(self, "filter_change")
      return result
    end
  end

  local previousUpdateFilterButtonMapping = MapOn.UpdateFilterButtonMapping
  if type(previousUpdateFilterButtonMapping) == "function" then
    MapOn.UpdateFilterButtonMapping = function(self, ...)
      local result = previousUpdateFilterButtonMapping(self, ...)
      local realmHasRavens = false
      for _, row in ipairs(rows) do
        if row.Realm == self.currRealmName then
          realmHasRavens = true
          break
        end
      end
      if realmHasRavens and type(self.filterButtonMapping) == "table" then
        local hasRavenFilter = false
        for _, logical in ipairs(self.filterButtonMapping) do
          if logical == -102 then
            hasRavenFilter = true
            break
          end
        end
        if not hasRavenFilter then
          self.filterButtonMapping[#self.filterButtonMapping + 1] = -102
          if type(self.UpdateFilterUI) == "function" then self:UpdateFilterUI() end
          log("RAVEN_FILTER_MAPPING",
              "realm=" .. tostring(self.currRealmName) ..
              " added=true logical=-102")
        end
      end
      return result
    end
  end

  local createPins = CompletionistMapV100_CreateMapPin
  CompletionistMapV100_CreateMapPin = function(self, currState)
    lastMapOnSelf = nil
    local refreshed, refreshReason = refreshNativeAuthority("map_create")
    log("NATIVE_AUTHORITY_REFRESH", "source=map_create result=" ..
        (refreshed and "applied" or tostring(refreshReason)) ..
        " lastGeneration=" .. tostring(lastNativeGeneration))
    if not refreshed and not hasAuthoritativeRavenState then
      logRegionSummaryDiagnostics("map_create")
    end
    local result = createPins(self, currState)
    syncIcons(self, "map_create")
    return result
  end

  for _, method in ipairs({"SubmenuExit", "Exit", "ClearIcons"}) do
    local previous = MapOn[method]
    assert(type(previous) == "function", "Missing map lifecycle method: " .. method)
    MapOn[method] = function(self, ...)
      local trackedCatalogueId =
          customCompassOwnsTarget and _G.CompletionistMapV105TrackedCatalogueId or nil
      clearIcons(self, "map_teardown:" .. method)
      local result = previous(self, ...)

      -- The stock map lifecycle may reclaim compass ownership after MapOn.Update
      -- has stopped running. If a custom Raven is still tracked, make the
      -- custom class the final writer and remove only foreign stock targets.
      local row = trackedCatalogueId and byCatalogueId[trackedCatalogueId] or nil
      if row ~= nil and shouldShow(row.CatalogueId) then
        local info = markerInfo(row.Name)
        if info ~= nil then
          suppressLegacyRavenHud()
          pcall(function() game.Compass.ShowMarker(row.Name, ravenClass) end)
          hideStockExcept(tostring(info.Id), "map_teardown_owner_guard")
          suppressLegacyRavenHud()
          self.currShownMarkerID = nil
          log("COMPASS_EXIT_REASSERT",
              "method=" .. method .. " name=" .. row.Name ..
              " uid=" .. tostring(info.Id) ..
              " customClass=" .. ravenClass)
        end
      end

      if lastMapOnSelf == self then lastMapOnSelf = nil end
      return result
    end
  end

  _G.CompletionistMapV105GetRavenTargetName = function()
    local id = _G.CompletionistMapV105TrackedCatalogueId
    local row = id and byCatalogueId[id]
    return row and row.Name or nil
  end
  _G.CompletionistMapV105HasRavenCompassTarget = function()
    return _G.CompletionistMapV105TrackedCatalogueId ~= nil
  end
  _G.CompletionistMapV105ReleaseRavenCompass = function()
    if _G.CompletionistMapV105TrackedCatalogueId ~= nil then
      local row = byCatalogueId[_G.CompletionistMapV105TrackedCatalogueId]
      if row ~= nil then
        pcall(function() game.Compass.HideMarker(row.Name) end)
      end
      _G.CompletionistMapV105TrackedCatalogueId = nil
      promptIntent = nil
      customCompassOwnsTarget = false
      if lastMapOnSelf and type(lastMapOnSelf.UpdateMapMarkerHighlights) == "function" then
        pcall(lastMapOnSelf.UpdateMapMarkerHighlights, lastMapOnSelf)
      end
    end
    return true
  end

  local function collisionSelection(self, collisionTable)
    local icons = self.completionistMapV105RavenIcons or {}
    for _, collision in ipairs(collisionTable or {}) do
      for name, go in pairs(icons) do
        if collision == go then
          local row = byName[name]
          if row ~= nil and shouldShow(row.CatalogueId) then
            local info = markerInfo(name)
            if info ~= nil then
              return {
                Family = "raven", Name = name, CatalogueId = row.CatalogueId,
                Id = info.Id, IdString = tostring(info.Id), ObjectRef = go,
                State = "candidate-custom", Source = "exact_collision_object",
              }
            end
          end
        end
      end
    end
    return nil
  end

  local function captureSelection(self, selected)
    selectionGeneration = selectionGeneration + 1
    selected.Generation = selectionGeneration
    self.completionistMapV105SelectedRaven = selected
    log("SELECT_CANDIDATE", "name=" .. selected.Name .. " uid=" .. selected.IdString ..
        " source=" .. selected.Source)
  end

  local function currentSelection(self)
    local selected = self and self.completionistMapV105SelectedRaven or nil
    if selected == nil then return nil end
    if not ravenMapVisible(self) then
      clearSelection(self, "raven_map_hidden_by_mode_or_filter")
      return nil
    end
    local icons = self.completionistMapV105RavenIcons or {}
    if selected.Generation ~= selectionGeneration or
        icons[selected.Name] ~= selected.ObjectRef or
        not shouldShow(selected.CatalogueId) then
      clearSelection(self, "candidate_no_longer_exact")
      return nil
    end
    return selected
  end

  local function promptOwned(self, show, selected)
    if show ~= true or selected == nil then return false end
    if self.currMarkerID ~= nil then
      return tostring(self.currMarkerID) == selected.IdString
    end
    return selected.Name == provenName and self.completionistMapV100Selected == true and
      self.completionistMapV100NornirSelected == nil and
      self.completionistMapV100NornirChestSelected == nil
  end

  local function customIds()
    local ok, ids = pcall(function()
      return game.Compass.FindMarkersByIconClass({ravenClass})
    end)
    if not ok then return {}, false, tostring(ids) end
    return ids or {}, true, nil
  end

  local function stockIds()
    local ok, ids = pcall(function()
      return game.Compass.FindMarkersByIconClass(enabledShowOnCompassMarkerFlags)
    end)
    if not ok then return {}, false, tostring(ids) end
    return ids or {}, true, nil
  end

  local function contains(ids, idString)
    for _, id in ipairs(ids or {}) do
      if tostring(id) == idString then return true end
    end
    return false
  end

  local function hideCustom(exceptIdString, reason)
    local ids, ok, err = customIds()
    if not ok then return false, 0, err end
    local hidden = 0
    for _, id in ipairs(ids) do
      if exceptIdString == nil or tostring(id) ~= exceptIdString then
        local target = knownNameForId(id) or id
        local hideOK = pcall(function() game.Compass.HideMarker(target) end)
        if not hideOK then return false, hidden, "hide_failed:" .. tostring(id) end
        hidden = hidden + 1
      end
    end
    return true, hidden, nil
  end

  hideStockExcept = function(exceptIdString, reason)
    local ids, ok, err = stockIds()
    if not ok then return false, 0, err end
    local hidden = 0
    for _, id in ipairs(ids) do
      if exceptIdString == nil or tostring(id) ~= exceptIdString then
        local target = knownNameForId(id) or id
        local hideOK = pcall(function() game.Compass.HideMarker(target) end)
        if not hideOK then return false, hidden, "hide_failed:" .. tostring(id) end
        hidden = hidden + 1
      end
    end
    return true, hidden, nil
  end

  local function hideStock(reason)
    return hideStockExcept(nil, reason)
  end

  local function hasOther(ids, exceptIdString)
    for _, id in ipairs(ids or {}) do
      if exceptIdString == nil or tostring(id) ~= exceptIdString then return true end
    end
    return false
  end

  local function actionText(lamsId)
    return "[AdvanceButton] " .. util.GetLAMSMsg(lamsId)
  end

  suppressLegacyRavenHud = function()
    local target = _G.CompletionistMapV100Target
    if target ~= nil and target.type == "Raven" and target.active == true then
      target.active = false
      log("LEGACY_RAVEN_HUD_DISABLED", "reason=custom_raven_compass_owner")
    end
  end

  updateHighlights = function(targetMap)
    local target = targetMap or lastMapOnSelf
    if target == nil or type(UI) ~= "table" or type(UI.Anim) ~= "function" then return end
    local trackedId = _G.CompletionistMapV105TrackedCatalogueId
    local trackedRow = trackedId and byCatalogueId[trackedId]
    local trackedName = trackedRow and trackedRow.Name or nil
    for name, icon in pairs(target.completionistMapV105RavenIcons or {}) do
      if trackedName ~= nil and name == trackedName then
        pcall(UI.Anim, icon, 10, "", 1)
      else
        pcall(UI.Anim, icon, 0, "", 0, 0)
      end
    end
  end

  local function promptText(selected)
    if selected == nil then return actionText(lamsConsts.AddToCompass) end
    if promptIntent ~= nil and promptIntent.IdString == selected.IdString then
      if promptIntent.State == "tracked" then
        return actionText(lamsConsts.RemoveFromCompass)
      elseif promptIntent.State == "untracked" then
        local ids, customOK = customIds()
        local hasOtherCustom = false
        if customOK then
          for _, id in ipairs(ids) do
            if tostring(id) ~= selected.IdString then
              hasOtherCustom = true
              break
            end
          end
        end
        local stock, stockOK = stockIds()
        if hasOtherCustom or (stockOK and hasOther(stock, selected.IdString)) or
            (_G.CompletionistMapV105HasLocationCompassTarget and _G.CompletionistMapV105HasLocationCompassTarget()) or
            (_G.CompletionistMapV105HasNornirCompassTarget and _G.CompletionistMapV105HasNornirCompassTarget()) then
          return actionText(lamsConsts.ReplaceInCompass)
        end
        return actionText(lamsConsts.AddToCompass)
      end
    end
    if _G.CompletionistMapV105TrackedCatalogueId == selected.CatalogueId then
      return actionText(lamsConsts.RemoveFromCompass)
    end
    local ids, ok = customIds()
    if ok and contains(ids, selected.IdString) then
      return actionText(lamsConsts.RemoveFromCompass)
    end
    local hasOther = false
    if _G.CompletionistMapV105TrackedCatalogueId ~= nil then
      hasOther = true
    elseif type(_G.CompletionistMapV105HasLocationCompassTarget) == "function" and _G.CompletionistMapV105HasLocationCompassTarget() then
      hasOther = true
    elseif type(_G.CompletionistMapV105HasNornirCompassTarget) == "function" and _G.CompletionistMapV105HasNornirCompassTarget() then
      hasOther = true
    elseif lastMapOnSelf and lastMapOnSelf.currShownMarkerID ~= nil then
      hasOther = true
    else
      local stock = stockIds()
      if (ok and #ids > 0) or #stock > 0 then hasOther = true end
    end
    if hasOther then
      return actionText(lamsConsts.ReplaceInCompass)
    end
    return actionText(lamsConsts.AddToCompass)
  end

  local function refreshPrompt(self, selected)
    if self == nil or selected == nil then return end
    selected = currentSelection(self) or selected
    local menu = self.menu or (activeMap and activeMap.menu)
    local text = promptText(selected)

    local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
    if goMapCursorText ~= nil then
      goMapCursorText:Show()
      local top = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
      if top ~= nil then
        local handle = util.GetTextHandle(top, "CursorAction_Text")
        if handle ~= nil then
          UI.SetTextIsClickable(handle)
          UI.SetText(handle, text)
        end
        top:Show()
      end
    end
    if menu ~= nil and type(menu.UpdateFooterButton) == "function" then
      menu:UpdateFooterButton("ShowOnCompass", true, text)
      if type(menu.UpdateFooterButtonText) == "function" then
        menu:UpdateFooterButtonText()
      end
    end
    if menu ~= nil and type(self.UpdateFooterButtonPrompt) == "function" then
      pcall(self.UpdateFooterButtonPrompt, self, menu, false, false)
    end
    log("PROMPT_REFRESH", "name=" .. selected.Name ..
        " state=" .. tostring(promptIntent and promptIntent.State or "observed") ..
        " text=" .. tostring(text))
  end

  local function showRavenReticle(self, currState, selected)
    if self == nil or currState == nil or selected == nil then return end
    local ok, err = pcall(function()
      self:SetReticleInfo(currState, "Odin's Raven", "Completionist Map")
    end)
    if ok then
      log("RETICLE", "name=" .. selected.Name ..
          " title=Odin's Raven subtitle=Completionist Map")
    else
      log("RETICLE_FAILED", "name=" .. selected.Name .. " error=" .. tostring(err))
    end
    refreshPrompt(self, selected)
  end

  function MapOn:MapCollisionChangeHandler(currState, collisionTable, realmName)
    lastMapOnSelf = self
    local selected = collisionSelection(self, collisionTable)
    if selected ~= nil then captureSelection(self, selected) end
    local result = previousCollision(self, currState, collisionTable, realmName)
    if selected ~= nil and currentSelection(self) ~= nil then
      showRavenReticle(self, currState, selected)
    end
    return result
  end

  function MapOn:GetShowOnCompassPrompt(currMenu)
    lastMapOnSelf = self
    local show, text = previousPrompt(self, currMenu)
    if promptOverride ~= nil then
      return true, promptText(promptOverride)
    end
    local selected = currentSelection(self)
    if selected == nil then return show, text end
    selected.State = "armed-custom"
    log("SELECT_ARM", "name=" .. selected.Name .. " uid=" .. selected.IdString)
    return true, promptText(selected)
  end

  function MapOn:ShowOnCompass(currState)
    lastMapOnSelf = self
    local selected = currentSelection(self)
    if selected == nil then
      customCompassOwnsTarget = false
      promptIntent = nil
      local customOK = hideCustom(nil, "other_target_replace")
      if not customOK then return end
      _G.CompletionistMapV105TrackedCatalogueId = nil
      pcall(function() self:UpdateMapMarkerHighlights() end)
      return previousShow(self, currState)
    end
    selected.State = "armed-custom"
    if not shouldShow(selected.CatalogueId) then return end
    local ids, queryOK = customIds()
    local wantsRemove = contains(ids, selected.IdString) or (_G.CompletionistMapV105TrackedCatalogueId == selected.CatalogueId)
    if promptIntent ~= nil and promptIntent.IdString == selected.IdString then
      wantsRemove = promptIntent.State == "tracked"
    end
    if wantsRemove then
      customCompassOwnsTarget = true
      local ok = pcall(function() game.Compass.HideMarker(selected.Name) end)
      if ok then
        if _G.CompletionistMapV105TrackedCatalogueId == selected.CatalogueId then
          _G.CompletionistMapV105TrackedCatalogueId = nil
        end
        self.currShownMarkerID = nil
        promptIntent = {
          IdString=selected.IdString, State="untracked",
          Name=selected.Name, CatalogueId=selected.CatalogueId,
        }
        promptSettleFrames = 0
        promptSettleBucket = -1
        suppressLegacyRavenHud()
        hideStock("raven_remove_guard")
        Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass")
        pcall(function() self:UpdateMapMarkerHighlights() end)
        updateHighlights(self)
        refreshPrompt(self, selected)
        log("REMOVE", "name=" .. selected.Name .. " uid=" .. selected.IdString)
      end
      return true
    end
    local customOK, customCount = hideCustom(selected.IdString, "raven_replace")
    local stockOK, stockCount = hideStockExcept(selected.IdString, "raven_replace")
    if not customOK or not stockOK then return end
    suppressLegacyRavenHud()
    if type(_G.CompletionistMapV105ReleaseLocationCompass) == "function" then
      pcall(_G.CompletionistMapV105ReleaseLocationCompass)
    end
    if type(_G.CompletionistMapV105ReleaseNornirCompass) == "function" then
      pcall(_G.CompletionistMapV105ReleaseNornirCompass)
    end
    local showOK, showErr = pcall(function()
      game.Compass.ShowMarker(selected.Name, ravenClass)
    end)
    if not showOK then
      log("SHOW_FAILED", "name=" .. selected.Name .. " error=" .. tostring(showErr))
      return
    end
    customCompassOwnsTarget = true
    suppressLegacyRavenHud()
    hideStockExcept(selected.IdString, "raven_post_show_guard")
    _G.CompletionistMapV105TrackedCatalogueId = selected.CatalogueId
    self.currShownMarkerID = selected.Id
    promptIntent = {
      IdString=selected.IdString, State="tracked",
      Name=selected.Name, CatalogueId=selected.CatalogueId,
    }
    promptSettleFrames = 0
    promptSettleBucket = -1
    Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass")
    pcall(function() self:UpdateMapMarkerHighlights() end)
    updateHighlights(self)
    refreshPrompt(self, selected)
    log("SHOW", "name=" .. selected.Name .. " uid=" .. selected.IdString ..
        " replacedCustomCount=" .. tostring(customCount) ..
        " replacedStockCount=" .. tostring(stockCount))
    return true
  end

  local previousHighlights = MapOn.UpdateMapMarkerHighlights
  function MapOn:UpdateMapMarkerHighlights(...)
    if previousHighlights then previousHighlights(self, ...) end
    updateHighlights(self)
  end

  function MapOn:Update(...)
    local result = previousUpdate(self, ...)

    if self ~= nil and
        self.completionistMapV105RavenVisibilityKey ~= ravenVisibilityKey(self) then
      syncIcons(self, "map_mode_or_filter_change")
    end

    if customCompassOwnsTarget then
      suppressLegacyRavenHud()
      local exceptIdString = promptIntent and promptIntent.IdString or nil
      local trackedRow = byCatalogueId[_G.CompletionistMapV105TrackedCatalogueId]
      if trackedRow ~= nil then
        local trackedInfo = markerInfo(trackedRow.Name)
        if trackedInfo ~= nil then exceptIdString = tostring(trackedInfo.Id) end
      end
      local stock, stockOK = stockIds()
      if stockOK and hasOther(stock, exceptIdString) then
        hideStockExcept(exceptIdString, "custom_raven_owner_guard")
      end
    end

    if nativeResetRecheckFrames > 0 then
      nativeResetRecheckFrames = nativeResetRecheckFrames - 1
      local elapsed = nativeResetRecheckLimit - nativeResetRecheckFrames
      local bucket = math.floor(elapsed / 30)
      if elapsed == 1 or bucket ~= nativeResetRecheckBucket then
        nativeResetRecheckBucket = bucket
        local refreshed, reason = refreshNativeAuthority("post_reset_recheck")
        log("NATIVE_AUTHORITY_RECHECK", "frame=" .. tostring(elapsed) ..
            " result=" .. (refreshed and "applied" or tostring(reason)) ..
            " lastGeneration=" .. tostring(lastNativeGeneration))
      end
      if nativeResetRecheckFrames == 0 then
        nativeResetRecheckBucket = -1
        log("NATIVE_AUTHORITY_RECHECK_DONE",
            "lastGeneration=" .. tostring(lastNativeGeneration))
      end
    end

    if promptIntent == nil then return result end

    local intent = promptIntent
    local row = intent.Name and byName[intent.Name] or nil
    if row == nil or tostring(row.CatalogueId) ~= tostring(intent.CatalogueId) then
      promptIntent = nil
      promptSettleFrames = 0
      promptSettleBucket = -1
      log("PROMPT_SETTLE_ABORT", "reason=identity_missing id=" .. tostring(intent.IdString))
      return result
    end

    local info = markerInfo(row.Name)
    if info == nil or tostring(info.Id) ~= intent.IdString then
      promptIntent = nil
      promptSettleFrames = 0
      promptSettleBucket = -1
      log("PROMPT_SETTLE_ABORT", "reason=uid_changed name=" .. tostring(row.Name))
      return result
    end

    local selected = {
      Name=row.Name, CatalogueId=row.CatalogueId,
      Id=info.Id, IdString=tostring(info.Id),
    }
    local custom, customOK = customIds()
    local stock, stockOK = stockIds()
    suppressLegacyRavenHud()

    if intent.State == "tracked" then
      if customOK and not contains(custom, intent.IdString) and shouldShow(row.CatalogueId) then
        pcall(function() game.Compass.ShowMarker(row.Name, ravenClass) end)
        suppressLegacyRavenHud()
        custom, customOK = customIds()
        stock, stockOK = stockIds()
      end
      if stockOK and hasOther(stock, intent.IdString) then
        hideStockExcept(intent.IdString, "raven_replace_async_retry")
        stock = stockIds()
      end
      if customOK and contains(custom, intent.IdString) and
          not hasOther(stock, intent.IdString) then
        promptSettleFrames = 0
        promptSettleBucket = -1
        refreshPrompt(self, selected)
        if not intent.Settled then log("PROMPT_SETTLED", "state=tracked name=" .. row.Name) end
        intent.Settled = true
      else
        promptSettleFrames = promptSettleFrames + 1
        refreshPrompt(self, selected)
      end
    elseif intent.State == "untracked" then
      if intent.Settled then
        refreshPrompt(self, selected)
        return result
      end
      promptSettleFrames = promptSettleFrames + 1
      local bucket = math.floor(promptSettleFrames / 30)
      if customOK and contains(custom, intent.IdString) and
          (promptSettleFrames == 1 or bucket ~= promptSettleBucket) then
        promptSettleBucket = bucket
        pcall(function() game.Compass.HideMarker(row.Name) end)
      end
      if stockOK and hasOther(stock, intent.IdString) then
        hideStockExcept(intent.IdString, "raven_remove_async_retry")
      end
      local customAfter, customAfterOK = customIds()
      local stockAfter, stockAfterOK = stockIds()
      if promptSettleFrames >= 3 and customAfterOK and stockAfterOK and
          not contains(customAfter, intent.IdString) and
          not hasOther(stockAfter, intent.IdString) then
        intent.Settled = true
        promptSettleFrames = 0
        promptSettleBucket = -1
        customCompassOwnsTarget = false
        refreshPrompt(self, selected)
        log("PROMPT_SETTLED", "state=untracked name=" .. row.Name)
      else
        refreshPrompt(self, selected)
      end
    else
      promptIntent = nil
      promptSettleFrames = 0
      promptSettleBucket = -1
      log("PROMPT_SETTLE_ABORT", "reason=invalid_state state=" .. tostring(intent.State))
    end
    return result
  end

  local function hideExactTracked(row)
    if _G.CompletionistMapV105TrackedCatalogueId ~= row.CatalogueId then return end
    local info = markerInfo(row.Name)
    if info == nil then return end
    local ids, ok = customIds()
    if ok and contains(ids, tostring(info.Id)) then
      pcall(function() game.Compass.HideMarker(row.Name) end)
    end
    if customCompassOwnsTarget then
      suppressLegacyRavenHud()
      hideStock("tracked_raven_collected")
    end
    _G.CompletionistMapV105TrackedCatalogueId = nil
    customCompassOwnsTarget = false
    promptIntent = nil
    promptSettleFrames = 0
    promptSettleBucket = -1
    if lastMapOnSelf ~= nil then lastMapOnSelf.currShownMarkerID = nil end
  end

  -- Nornir candidate: release Raven UI ownership without changing authority.
  _G.CompletionistMapV105ReleaseRavenCompass = function()
    local ok = hideCustom(nil, "nornir_target_replace")
    if not ok then return false end
    local hadRaven = (_G.CompletionistMapV105TrackedCatalogueId ~= nil)
    customCompassOwnsTarget = false
    promptIntent = nil
    promptSettleFrames = 0
    promptSettleBucket = -1
    _G.CompletionistMapV105TrackedCatalogueId = nil
    if lastMapOnSelf then
      clearSelection(lastMapOnSelf, "nornir_target_replace")
      if hadRaven then
        lastMapOnSelf.currShownMarkerID = nil
      end
      if type(lastMapOnSelf.UpdateMapMarkerHighlights) == "function" then
        pcall(lastMapOnSelf.UpdateMapMarkerHighlights, lastMapOnSelf)
      end
    end
    suppressLegacyRavenHud()
    return true
  end

  _G.CompletionistMapV105PublishRavenState = function(catalogueId, collected, source)
    local row = byCatalogueId[catalogueId]
    if row == nil or type(collected) ~= "boolean" then return false end
    if collected ~= true then
      log("STATE_DEFERRED", "catalogueId=" .. catalogueId ..
          " source=" .. tostring(source) ..
          " reason=alive_requires_atomic_authority progressionWrites=false")
      return true
    end
    eventKilled[catalogueId] = true
    states[catalogueId] = true
    hideExactTracked(row)
    if lastMapOnSelf ~= nil then syncIcons(lastMapOnSelf, "state:" .. tostring(source)) end
    log("STATE", "catalogueId=" .. catalogueId .. " collected=true" ..
        " source=" .. tostring(source) .. " progressionWrites=false")
    return true
  end

  _G.CompletionistMapV105ApplyPersistedRavenKills = function(
      catalogueIds, source, clearEventEvidence)
    if type(catalogueIds) ~= "table" then return false, 0 end

    if clearEventEvidence == true then
      for catalogueId, _ in pairs(eventKilled) do eventKilled[catalogueId] = nil end
    end

    for catalogueId, _ in pairs(states) do states[catalogueId] = nil end
    local accepted = 0
    for key, value in pairs(catalogueIds) do
      local catalogueId = nil
      if type(key) == "number" then
        catalogueId = value
      elseif value == true then
        catalogueId = key
      end
      local row = byCatalogueId[catalogueId]
      if row ~= nil and states[catalogueId] ~= true then
        states[catalogueId] = true
        accepted = accepted + 1
        hideExactTracked(row)
      end
    end

    local eventOverlayCount = 0
    for catalogueId, value in pairs(eventKilled) do
      local row = byCatalogueId[catalogueId]
      if value == true and row ~= nil then
        eventOverlayCount = eventOverlayCount + 1
        states[catalogueId] = true
        hideExactTracked(row)
      end
    end

    hasAuthoritativeRavenState = true
    _G.CompletionistMapV105HasAuthoritativeRavenState = true
    if lastMapOnSelf ~= nil then syncIcons(lastMapOnSelf, "persisted:" .. tostring(source)) end
    log("PERSISTED_KILLS", "source=" .. tostring(source) ..
        " accepted=" .. tostring(accepted) ..
        " eventOverlay=" .. tostring(eventOverlayCount) ..
        " clearEventEvidence=" .. tostring(clearEventEvidence == true) ..
        " authorityEstablished=true catalogueDefaultVisible=false progressionWrites=false")
    return true, accepted
  end

  beginAuthorityBoundary = function(source, captureReady, forcedEpoch)
    if forcedEpoch ~= nil then
      nativeBoundaryEpoch = forcedEpoch
    else
      nativeBoundaryEpoch = nativeBoundaryEpoch + 1
    end
    _G.CompletionistMapV105NativeBoundaryEpoch = nativeBoundaryEpoch
    nativeBoundaryPending = true
    nativeBoundaryCaptureReady = captureReady ~= false
    nativeBoundarySource = tostring(source)
    nativeResetRecheckFrames = nativeResetRecheckLimit
    nativeResetRecheckBucket = -1
    local customWasTracked = (_G.CompletionistMapV105TrackedCatalogueId ~= nil) or customCompassOwnsTarget
    customCompassOwnsTarget = false
    promptIntent = nil
    promptSettleFrames = 0
    promptSettleBucket = -1
    _G.CompletionistMapV105TrackedCatalogueId = nil
    hideCustom(nil, "authority_boundary")
    if lastMapOnSelf ~= nil then
      clearSelection(lastMapOnSelf, "authority_boundary")
      if customWasTracked then
        lastMapOnSelf.currShownMarkerID = nil
      end
    end
    log("AUTHORITY_BOUNDARY",
        "source=" .. tostring(source) ..
        " boundaryEpoch=" .. tostring(nativeBoundaryEpoch) ..
        " captureReady=" .. tostring(nativeBoundaryCaptureReady) ..
        " staleStateRetained=true atomicAuthorityRequired=true" ..
        " postBoundaryRecheckFrames=" .. tostring(nativeResetRecheckLimit) ..
        " progressionWrites=false")
    return true
  end

  -- Notify Nornir through the existing boundary; keep one load-hook chain.
  local ravenBoundary = beginAuthorityBoundary
  beginAuthorityBoundary = function(...)
    local source, captureReady = ...
    local controller = rawget(_G, "CompletionistMapV105Nornir")
    if controller then
      controller:BeginEpoch((controller.service.epoch or 0) + 1)
      if controller.liveReader then controller.liveReader:SetReady(captureReady ~= false) end
    end
    return ravenBoundary(...)
  end

  _G.CompletionistMapV105RefreshLocationAuthority = function() return refreshNativeAuthority("collectible_background") end
  _G.CompletionistMapV105NotifyAuthorityBoundary = beginAuthorityBoundary
  _G.CompletionistMapV105ResetRavenStates = beginAuthorityBoundary

  local pendingBoundary = rawget(_G, "CompletionistMapV105PendingAuthorityBoundary")
  if pendingBoundary ~= nil then
    _G.CompletionistMapV105PendingAuthorityBoundary = nil
    if type(pendingBoundary) == "table" then
      beginAuthorityBoundary(
          pendingBoundary.source or "pending",
          pendingBoundary.captureReady ~= false)
    else
      beginAuthorityBoundary(pendingBoundary, true)
    end
  end

  if not _G.CompletionistMapV105LoadBoundaryHooksInstalled then
    _G.CompletionistMapV105LoadBoundaryHooksInstalled = true
    local thunkOK, thunk = pcall(require, "core.thunk")
    if thunkOK and type(thunk) == "table" and type(thunk.Install) == "function" then
      local dataOK, dataErr = pcall(thunk.Install, "EVT_LoadSaveData", function(...)
        beginAuthorityBoundary("EVT_LoadSaveData", false)
      end)
      log("LOAD_BOUNDARY_HOOK", "event=EVT_LoadSaveData" ..
          " installed=" .. tostring(dataOK) ..
          (dataOK and "" or " error=" .. tostring(dataErr)))

      local doneOK, doneErr = pcall(thunk.Install, "EVT_LoadSaveFile_Done", function(...)
        beginAuthorityBoundary("EVT_LoadSaveFile_Done", true)
      end)
      log("LOAD_BOUNDARY_HOOK", "event=EVT_LoadSaveFile_Done" ..
          " installed=" .. tostring(doneOK) ..
          (doneOK and "" or " error=" .. tostring(doneErr)))
    else
      log("LOAD_BOUNDARY_HOOK", "installed=false reason=core_thunk_unavailable")
    end
  end

  for catalogueId, value in pairs(_G.CompletionistMapV105PendingRavenState or {}) do
    _G.CompletionistMapV105PublishRavenState(catalogueId, value, "pending")
  end
  _G.CompletionistMapV105PendingRavenState = {}
  log("API", "installed=true catalogueCount=" .. tostring(#rows) ..
      " mapResource=" .. mapResource .. " compassClass=" .. ravenClass ..
      " exactCollisionRequired=true markerIdAloneInfersRaven=false" ..
      " permanentPolling=false postLoadBoundedRefresh=true progressionWrites=false catalogueDefaultVisible=false" ..
      " positiveEventEvidenceOnly=true atomicAuthorityClearsState=true" ..
      " sessionKillOverlay=true loadBoundaryClearsOverlay=true" ..
      " boundaryEpochCapture=true loadDataCaptureReady=false loadDoneCaptureReady=true" ..
      " persistedKillBootstrap=true nativeAuthority=loopback_v2_boundary_capture" ..
      " nativePort=" .. tostring(nativePort) .. " staticDescriptorWrites=false")
end
-- END COMPLETIONIST V0.10.5 ALL RAVENS

-- BEGIN COMPLETIONIST RAVEN ONLY CLEANUP
-- Frozen map base still has old chest fallback. Block old pins here.
do
  CompletionistMapV100_GetNornirRegistry = function()
    return {}, "raven_only"
  end
  CompletionistMapV100_CreateNornirChestPins = function(self)
    CompletionistMapV100_DestroyNornirChestPins(self)
  end
  CompletionistMapV100_CreateNornirPins = function(self)
    CompletionistMapV100_DestroyNornirPins(self)
  end

  local updateMapping = MapOn.UpdateFilterButtonMapping
  MapOn.UpdateFilterButtonMapping = function(self, ...)
    local result = updateMapping(self, ...)
    local selected = self.filterButtonMapping[self.filterIndex]
    local kept = {}
    local selectedIndex = 1
    for _, logical in ipairs(self.filterButtonMapping) do
      if logical ~= -103 and logical ~= -104 then
        kept[#kept + 1] = logical
        if logical == selected then selectedIndex = #kept end
      end
    end
    self.filterButtonMapping = kept
    self.filterIndex = selectedIndex
    self:UpdateFilterUI()
    return result
  end
end
-- END COMPLETIONIST RAVEN ONLY CLEANUP

-- BEGIN COMPLETIONIST V0.10.5 NORNIR SAVED STATE TEST
-- Nornir families use stock map art, matching compass classes, and exact chest keys.
do
  local rows = {
    {Name="Completionist_V105_NornirSeal_13292091fefa7d2d",UidHex="02C42143F8031960",IdString="199320859318622560",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_13292091fefa7d2dde3b2ff7bfbb81c0",ParentId="nornir_chest_f8548c574dc67cba277c5cb31099648b",Reference="GnomeTarget_LargeA",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirBell_20c0d951a8d68ad7",UidHex="02DD395917AD1923",IdString="206384212741003555",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_20c0d951a8d68ad7ad5480c3c5e7471e",ParentId="nornir_chest_d8e4c77444fe09d0a960198ab802058e",Reference="bellTarget_05",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirBell_bbae700182fabe29",UidHex="030D135328802B4E",IdString="219853204693723982",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_bbae700182fabe29b44ca9ebb5259df3",ParentId="nornir_chest_3f3a8e7844ff44f57da024b2efce93dc",Reference="bellTarget_C",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirBell_b17c6a9711703d8e",UidHex="0452FAC1D83F805B",IdString="311587034705657947",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_b17c6a9711703d8e4e77314c4644b5d7",ParentId="nornir_chest_d2cacb84426fd68d504a11ae125c2b62",Reference="Riv420Bell_01",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirChest_a2cdfc7a4f0ab68e",UidHex="075C20AF4D6984E1",IdString="530334793413002465",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_a2cdfc7a4f0ab68eac212bb108cd35b7",ParentId=nil,Reference=nil,EventKey="wad_xpl940_beachcave|spinnerbell_01|spinnerbell_02|spinnerbell_03",Class="SIDE"},
    {Name="Completionist_V105_NornirSeal_079c5535f3ec75c1",UidHex="11CD7A2328E53125",IdString="1282815760299012389",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_079c5535f3ec75c14991244ffdcc950e",ParentId="nornir_chest_a336e1844ac7c90b6cd6288e2cdab274",Reference="runic_breakable_01",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_db19533bf8500d21",UidHex="1279660121FF107E",IdString="1331207319916056702",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_db19533bf8500d2138c7d45f384cea6b",ParentId="nornir_chest_c0cf411940bad7d00042afa7a46f5514",Reference="runic_breakable_03",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_005aabcf8ad0669d",UidHex="155A4A27502342D5",IdString="1538623755409113813",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_005aabcf8ad0669ddb3e20b78ab39600",ParentId="nornir_chest_c0cf411940bad7d00042afa7a46f5514",Reference="runic_breakable_01",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirBell_48d1f323ee55c124",UidHex="1ABCBBE4F1A3466E",IdString="1926621332588676718",Family="nornir_bell",Realm="Alfheim",CatalogueId="nornir_bell_48d1f323ee55c124f14b49d43c5aaf57",ParentId="nornir_chest_e00c75d24c76b498de4c1f85c997c65e",Reference="BlankBell_Real_01",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirBell_1d6b73234f73e89d",UidHex="1D793F92AE51514E",IdString="2123798598504239438",Family="nornir_bell",Realm="Alfheim",CatalogueId="nornir_bell_1d6b73234f73e89d63abcbcd0fc8efd3",ParentId="nornir_chest_522448bf4d91b0f19de6adbd1c77d709",Reference="BellTarget_1",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirSeal_271ba83ac46670ba",UidHex="1F20F2FECFE07D50",IdString="2243059790653717840",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_271ba83ac46670ba8bf5f2b3f120b3bb",ParentId="nornir_chest_45bbcd15458cd30c3338a7b3dab9b3d9",Reference="runic_breakable_02",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirMechanism_fcaa67b85c4ba0b3",UidHex="20D83027122AD1BE",IdString="2366694548549849534",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_fcaa67b85c4ba0b3183cd68cc34fe072",ParentId="nornir_chest_a6ac8eeb4ea2545ab05df19e8ea6ee8f",Reference="MemoryChest_SpinBase2",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirBell_ce4bff4f7f5e96d4",UidHex="21438036A08DFA1F",IdString="2396900398801484319",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_ce4bff4f7f5e96d4233997069516d341",ParentId="nornir_chest_6b7011074e78df82ecd508b6b1a8444f",Reference="BellTarget_Small_02",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirSeal_8ed2a59c055136e0",UidHex="24F3801B4974F589",IdString="2662612659390969225",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_8ed2a59c055136e0241439cd29ac62cc",ParentId="nornir_chest_6d18634c4e86282d1cfa0e84f6d5654f",Reference="runic_breakable_01",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirMechanism_05c6e0544d3ddf1b",UidHex="2D67857ED720111F",IdString="3271730434129531167",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_05c6e0544d3ddf1bb25db9f6e9ca98fb",ParentId="nornir_chest_69780ade492b089119484199e5423527",Reference="Base_001",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirChest_7d8b404340e8ef8e",UidHex="2D7CE28A3ADB3187",IdString="3277743712139686279",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_7d8b404340e8ef8edb4096b3a1a1e3fc",ParentId=nil,Reference=nil,EventKey="wad_riv325_dangersexit|runic_gnome_01|runic_gnome_02|runic_gnome_03",Class="SIDE"},
    {Name="Completionist_V105_NornirChest_e00c75d24c76b498",UidHex="2EA561626E7B5AE2",IdString="3361199772290210530",Family="nornir_chest",Realm="Alfheim",CatalogueId="nornir_chest_e00c75d24c76b498de4c1f85c997c65e",ParentId=nil,Reference=nil,EventKey="wad_alf210_lakedarklh|blankbell_real_01|blankbell_real_02|blankbell_real_03",Class="SIDE"},
    {Name="Completionist_V105_NornirMechanism_bfec931786e54468",UidHex="321072C71AF769E2",IdString="3607509501000247778",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_bfec931786e544681e2a43207415c6d6",ParentId="nornir_chest_c02f019049d50ea0146c478fd46f4a49",Reference="SpinnerChest_Spinner_Base_xx03",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirSeal_656a5fdf63955533",UidHex="355BBBB3EFC13DCF",IdString="3844873088386809295",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_656a5fdf63955533b4fb2cc272089bd4",ParentId="nornir_chest_6d18634c4e86282d1cfa0e84f6d5654f",Reference="runic_breakable_02",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_2b1559b687f28789",UidHex="361DD1C75EC134FA",IdString="3899503506591134970",Family="nornir_seal",Realm="Helheim",CatalogueId="nornir_seal_2b1559b687f2878980e106d4158ebed7",ParentId="nornir_chest_6fc8ac794c63bf63a13736b7cd3c7f25",Reference="runic_breakable_03",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirChest_3ec0daa848922cad",UidHex="366EA5AB3C7FBD38",IdString="3922254480359275832",Family="nornir_chest",Realm="Alfheim",CatalogueId="nornir_chest_3ec0daa848922cad4fb30c8bb93c171f",ParentId=nil,Reference=nil,EventKey="wad_alf320_trenchadark|bellchest_belltarget_01|bellchest_belltarget_02|bellchest_belltarget_03",Class="SIDE"},
    {Name="Completionist_V105_NornirSeal_f2f91e45016fc614",UidHex="36D51EC9374B13A0",IdString="3951098097652405152",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_f2f91e45016fc6149dc7198c47af560f",ParentId="nornir_chest_45bbcd15458cd30c3338a7b3dab9b3d9",Reference="runic_breakable_01",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirChest_f8ac74b9414e59e7",UidHex="3EB4DC4CE5A8A44E",IdString="4518478548988109902",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_f8ac74b9414e59e764d8738182c00663",ParentId=nil,Reference=nil,EventKey="wad_peak140_caverndark|spinchest_spinbase1|spinchest_spinbase2|spinchest_spinbase3",Class="SIDE"},
    {Name="Completionist_V105_NornirChest_69780ade492b0891",UidHex="411B1292A6F0CC31",IdString="4691363857911827505",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_69780ade492b089119484199e5423527",ParentId=nil,Reference=nil,EventKey="wad_riv475_freyahouseext|base_001|base_002|base_003",Class="SIDE"},
    {Name="Completionist_V105_NornirSeal_970a5a2a13850831",UidHex="48E5DA7CDCEA7CAD",IdString="5252844770214706349",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_970a5a2a138508313ec687bbe1a4d40f",ParentId="nornir_chest_a336e1844ac7c90b6cd6288e2cdab274",Reference="runic_breakable_02",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirChest_c190d59340706bb7",UidHex="4B51EBDECCBB3330",IdString="5427378368108245808",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_c190d59340706bb79925cb9f2d5867cf",ParentId=nil,Reference=nil,EventKey="wad_xpl200_funeral|runiclock01|runiclock02|runiclock03",Class="SIDE"},
    {Name="Completionist_V105_NornirSeal_0dae8b5eefe17cd0",UidHex="4BBA435AE6F03F17",IdString="5456747956213399319",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_0dae8b5eefe17cd00fa6f569d6be247d",ParentId="nornir_chest_0f0cc7ca48423bb296f6ddbed87a8f3b",Reference="runic_breakable_02",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirBell_fcd4e40c67ffc41a",UidHex="4D239AB19E4D3D56",IdString="5558456452761075030",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_fcd4e40c67ffc41a08124ba02d472017",ParentId="nornir_chest_a2cdfc7a4f0ab68eac212bb108cd35b7",Reference="SpinnerBell_01",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirMechanism_79b41e91b2267af3",UidHex="4E9C22AE4B7155B3",IdString="5664440563310613939",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_79b41e91b2267af30fc0fb18c76b2256",ParentId="nornir_chest_c02f019049d50ea0146c478fd46f4a49",Reference="SpinnerChest_Spinner_Base_xx01",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirChest_6fc8ac794c63bf63",UidHex="53E33A1A60EB52DF",IdString="6044739009830933215",Family="nornir_chest",Realm="Helheim",CatalogueId="nornir_chest_6fc8ac794c63bf63a13736b7cd3c7f25",ParentId=nil,Reference=nil,EventKey="wad_helr100_docks|runic_breakable_01|runic_breakable_02|runic_breakable_03",Class="SIDE"},
    {Name="Completionist_V105_NornirMechanism_87973454a6ca9486",UidHex="5955A2BC867B8063",IdString="6437230172989784163",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_87973454a6ca948640415ba8df0cdaef",ParentId="nornir_chest_a6ac8eeb4ea2545ab05df19e8ea6ee8f",Reference="MemoryChest_SpinBase1",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirChest_d8e4c77444fe09d0",UidHex="5B1C81E3F3AEBE85",IdString="6565265172845215365",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_d8e4c77444fe09d0a960198ab802058e",ParentId=nil,Reference=nil,EventKey="wad_xpl100_httk|belltarget_04|belltarget_05|belltarget_06",Class="SIDE"},
    {Name="Completionist_V105_NornirBell_572d69650a8644e5",UidHex="5C00C607020D59C9",IdString="6629516384890870217",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_572d69650a8644e5f7450ca82026d0ce",ParentId="nornir_chest_d8e4c77444fe09d0a960198ab802058e",Reference="bellTarget_06",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirSeal_54223c28eba6f744",UidHex="5DB474A95F8D2035",IdString="6752150012136595509",Family="nornir_seal",Realm="Alfheim",CatalogueId="nornir_seal_54223c28eba6f74455c19c8d51e3ba60",ParentId="nornir_chest_9a92c24340832c2107ff7d997c9fcbda",Reference="runic_breakable_03",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirBell_a26fa8766d4f4ad2",UidHex="60FBF45D57796A20",IdString="6988447928532167200",Family="nornir_bell",Realm="Alfheim",CatalogueId="nornir_bell_a26fa8766d4f4ad27c0b8f961446188c",ParentId="nornir_chest_522448bf4d91b0f19de6adbd1c77d709",Reference="BellTarget_2",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirBell_4ff4e0e8246abed8",UidHex="6318CCB09CC5EC82",IdString="7140682268112448642",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_4ff4e0e8246abed8af54e9e8df80ee3b",ParentId="nornir_chest_d8e4c77444fe09d0a960198ab802058e",Reference="bellTarget_04",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirBell_1038da33b1f82eed",UidHex="6676B77F01DF2716",IdString="7383290395240638230",Family="nornir_bell",Realm="Alfheim",CatalogueId="nornir_bell_1038da33b1f82eed90ad9b81d596a959",ParentId="nornir_chest_3ec0daa848922cad4fb30c8bb93c171f",Reference="BellChest_BellTarget_03",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirBell_51461684261a2db5",UidHex="6C78833BF8859BA3",IdString="7816141446897310627",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_51461684261a2db5058696409d078465",ParentId="nornir_chest_3f3a8e7844ff44f57da024b2efce93dc",Reference="bellTarget_B",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirSeal_625b3d6bc0435ed2",UidHex="6E5A11F8A444BD2F",IdString="7951687851681561903",Family="nornir_seal",Realm="Helheim",CatalogueId="nornir_seal_625b3d6bc0435ed2a018263bccd06e6c",ParentId="nornir_chest_6fc8ac794c63bf63a13736b7cd3c7f25",Reference="runic_breakable_01",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_4b0424d798c7393f",UidHex="6F15ED125CAE4FE2",IdString="8004564575841046498",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_4b0424d798c7393f24e381ca117eb65a",ParentId="nornir_chest_7d8b404340e8ef8edb4096b3a1a1e3fc",Reference="runic_gnome_03",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirBell_bc2d881962aa413f",UidHex="7178A8D7ACD298AD",IdString="8176470767762053293",Family="nornir_bell",Realm="Alfheim",CatalogueId="nornir_bell_bc2d881962aa413fdfcb338266d50c3e",ParentId="nornir_chest_e00c75d24c76b498de4c1f85c997c65e",Reference="BlankBell_Real_02",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirSeal_b645b89aaa91dadd",UidHex="745435BC5B1EA281",IdString="8382383889542193793",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_b645b89aaa91dadd201bd05cec2a7a9b",ParentId="nornir_chest_c190d59340706bb79925cb9f2d5867cf",Reference="RunicLock01",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirBell_55249a6d5cb16088",UidHex="75229846C36E8F95",IdString="8440476081339666325",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_55249a6d5cb16088f6ca2be05960d62b",ParentId="nornir_chest_a2cdfc7a4f0ab68eac212bb108cd35b7",Reference="SpinnerBell_02",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirSeal_cbc9f8235eb56d42",UidHex="753424D22979DDF1",IdString="8445415686284107249",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_cbc9f8235eb56d42ab024b9c8e6dcd15",ParentId="nornir_chest_f8548c574dc67cba277c5cb31099648b",Reference="GnomeTarget_LargeB",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_310eca117f6be8f1",UidHex="75D3D8803C64A87A",IdString="8490367767804160122",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_310eca117f6be8f196a125176d6d6d92",ParentId="nornir_chest_7d8b404340e8ef8edb4096b3a1a1e3fc",Reference="runic_gnome_02",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_8b4b90238c7e0724",UidHex="76DB95A4FAE033D6",IdString="8564603652191302614",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_8b4b90238c7e0724d4c6dec2dd6b541c",ParentId="nornir_chest_0f0cc7ca48423bb296f6ddbed87a8f3b",Reference="runic_breakable_01",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirBell_09f553d4ab6850d4",UidHex="7BE1F34FC92F5167",IdString="8926683460428321127",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_09f553d4ab6850d40c3077b5b160eb17",ParentId="nornir_chest_a2cdfc7a4f0ab68eac212bb108cd35b7",Reference="SpinnerBell_03",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirSeal_cc33e12510466275",UidHex="7D7555AACB02B429",IdString="9040226019054892073",Family="nornir_seal",Realm="Helheim",CatalogueId="nornir_seal_cc33e125104662754d3e29692c1f62ce",ParentId="nornir_chest_6fc8ac794c63bf63a13736b7cd3c7f25",Reference="runic_breakable_02",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirChest_6b7011074e78df82",UidHex="8567A5DC53F5124D",IdString="-8833909778343980467",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_6b7011074e78df82ecd508b6b1a8444f",ParentId=nil,Reference=nil,EventKey="wad_xpl970_beachtower|belltarget_small_01|belltarget_small_02|belltarget_small_03",Class="SIDE"},
    {Name="Completionist_V105_NornirMechanism_02f54dd393f50610",UidHex="86916C6DD52FEE00",IdString="-8750093382020239872",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_02f54dd393f50610a8c68ea9f984643f",ParentId="nornir_chest_69780ade492b089119484199e5423527",Reference="Base_003",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirSeal_3f382379fb8382d2",UidHex="900D5E062F620432",IdString="-8066687976892922830",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_3f382379fb8382d20a1d19add1700693",ParentId="nornir_chest_c0cf411940bad7d00042afa7a46f5514",Reference="runic_breakable_02",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_c69651b360469e83",UidHex="909DDA15E708788B",IdString="-8026019173299095413",Family="nornir_seal",Realm="Alfheim",CatalogueId="nornir_seal_c69651b360469e83ea72bce3b6f9d5d1",ParentId="nornir_chest_9a92c24340832c2107ff7d997c9fcbda",Reference="runic_breakable_02",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_c96a86a4659fbe80",UidHex="93A5EB760B926AC5",IdString="-7807575486744073531",Family="nornir_seal",Realm="Alfheim",CatalogueId="nornir_seal_c96a86a4659fbe80d74d5cf2f42173a0",ParentId="nornir_chest_9a92c24340832c2107ff7d997c9fcbda",Reference="runic_breakable_01",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirMechanism_de76137609824e37",UidHex="97C11205ED994E91",IdString="-7511702886806892911",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_de76137609824e37c6f2ee896724e14c",ParentId="nornir_chest_a6ac8eeb4ea2545ab05df19e8ea6ee8f",Reference="MemoryChest_SpinBase3",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirSeal_72621b388e9021c0",UidHex="9B70921C19AA02EE",IdString="-7246131151051816210",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_72621b388e9021c020984698fa67149a",ParentId="nornir_chest_7d8b404340e8ef8edb4096b3a1a1e3fc",Reference="runic_gnome_01",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirChest_c0cf411940bad7d0",UidHex="9BCD93D7AAA947BE",IdString="-7219952073114564674",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_c0cf411940bad7d00042afa7a46f5514",ParentId=nil,Reference=nil,EventKey="wad_peak720_summitascenthub|runic_breakable_01|runic_breakable_02|runic_breakable_03",Class="SIDE"},
    {Name="Completionist_V105_NornirBell_455ab099c29ba90c",UidHex="9F905B5D1EE61761",IdString="-6948953769524193439",Family="nornir_bell",Realm="Alfheim",CatalogueId="nornir_bell_455ab099c29ba90c933fdf0515091f11",ParentId="nornir_chest_3ec0daa848922cad4fb30c8bb93c171f",Reference="BellChest_BellTarget_01",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirSeal_55989fca9463ea8e",UidHex="A08646818DB05C32",IdString="-6879733858519983054",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_55989fca9463ea8ee7b7cdf9d265ab15",ParentId="nornir_chest_a336e1844ac7c90b6cd6288e2cdab274",Reference="runic_breakable_03",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirBell_f7cc30210784667d",UidHex="A0D44C4F2F218C70",IdString="-6857772429601567632",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_f7cc30210784667d9a956c0c330e7819",ParentId="nornir_chest_d2cacb84426fd68d504a11ae125c2b62",Reference="Riv420Bell_02",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirBell_939c16e8297260b4",UidHex="A1102EA8983B9A86",IdString="-6840916532332356986",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_939c16e8297260b45cab0b7a6b084891",ParentId="nornir_chest_6b7011074e78df82ecd508b6b1a8444f",Reference="BellTarget_Small_01",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirChest_522448bf4d91b0f1",UidHex="A36B4B80ECE88A4E",IdString="-6671155405916698034",Family="nornir_chest",Realm="Alfheim",CatalogueId="nornir_chest_522448bf4d91b0f19de6adbd1c77d709",ParentId=nil,Reference=nil,EventKey="wad_alf690_lakelightlh|belltarget_1|belltarget_2|belltarget_3",Class="SIDE"},
    {Name="Completionist_V105_NornirSeal_48821d4b8f6f5779",UidHex="A48FEC5B32B8042F",IdString="-6588787853382646737",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_48821d4b8f6f5779ac3684af7869fffd",ParentId="nornir_chest_c190d59340706bb79925cb9f2d5867cf",Reference="RunicLock02",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirBell_58710bb4fbea91ee",UidHex="A6A2E2A31C2571B1",IdString="-6439335327006625359",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_58710bb4fbea91ee1cfddce17b0b5c62",ParentId="nornir_chest_3f3a8e7844ff44f57da024b2efce93dc",Reference="bellTarget_A",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirChest_f8548c574dc67cba",UidHex="A881DD0044F19921",IdString="-6304515010115561183",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_f8548c574dc67cba277c5cb31099648b",ParentId=nil,Reference=nil,EventKey="wad_cal500_runevault|gnometarget_largea|gnometarget_largeb|gnometarget_largec",Class="SIDE"},
    {Name="Completionist_V105_NornirMechanism_e9c07816acae07d0",UidHex="A894ED793D350894",IdString="-6299148873810769772",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_e9c07816acae07d0d29d50cf4b1a449a",ParentId="nornir_chest_f8ac74b9414e59e764d8738182c00663",Reference="SpinChest_SpinBase3",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirSeal_e13ac1a440ed69f3",UidHex="AC0D2EC271AA7763",IdString="-6049127311823177885",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_e13ac1a440ed69f387db6bfbbd4be2c6",ParentId="nornir_chest_c190d59340706bb79925cb9f2d5867cf",Reference="RunicLock03",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirMechanism_37552eb66009b6fe",UidHex="B6C64AE69E768018",IdString="-5276447559056457704",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_37552eb66009b6fecf799dfb42a753ca",ParentId="nornir_chest_f8ac74b9414e59e764d8738182c00663",Reference="SpinChest_SpinBase2",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirChest_a336e1844ac7c90b",UidHex="B90FD1A62277FB7A",IdString="-5111636540569158790",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_a336e1844ac7c90b6cd6288e2cdab274",ParentId=nil,Reference=nil,EventKey="wad_xpl920_islandclimb|runic_breakable_01|runic_breakable_02|runic_breakable_03",Class="SIDE"},
    {Name="Completionist_V105_NornirBell_7bb7fa75dfb9a12c",UidHex="BD108ECD1D6A3CB8",IdString="-4823198189300859720",Family="nornir_bell",Realm="Alfheim",CatalogueId="nornir_bell_7bb7fa75dfb9a12c235326f72de3846a",ParentId="nornir_chest_e00c75d24c76b498de4c1f85c997c65e",Reference="BlankBell_Real_03",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirChest_a6ac8eeb4ea2545a",UidHex="C725154F60C58836",IdString="-4096844855353440202",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_a6ac8eeb4ea2545ab05df19e8ea6ee8f",ParentId=nil,Reference=nil,EventKey="wad_foot100_base|memorychest_spinbase1|memorychest_spinbase2|memorychest_spinbase3",Class="SIDE"},
    {Name="Completionist_V105_NornirChest_c02f019049d50ea0",UidHex="C9B3DDFC6EC0F539",IdString="-3912539574995192519",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_c02f019049d50ea0146c478fd46f4a49",ParentId=nil,Reference=nil,EventKey="wad_xpl950_beachmaze|spinnerchest_spinner_base_xx01|spinnerchest_spinner_base_xx02|spinnerchest_spinner_base_xx03",Class="SIDE"},
    {Name="Completionist_V105_NornirChest_0f0cc7ca48423bb2",UidHex="CB856DC6115DD787",IdString="-3781495614645348473",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_0f0cc7ca48423bb296f6ddbed87a8f3b",ParentId=nil,Reference=nil,EventKey="wad_riv925_freyacave|runic_breakable_01|runic_breakable_02|runic_breakable_03",Class="SIDE"},
    {Name="Completionist_V105_NornirMechanism_852fd59bca1426db",UidHex="CC283588A2968B65",IdString="-3735677029944226971",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_852fd59bca1426dbb06fe5a2ad712ad1",ParentId="nornir_chest_c02f019049d50ea0146c478fd46f4a49",Reference="SpinnerChest_Spinner_Base_xx02",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirChest_9a92c24340832c21",UidHex="D212A548B7CF36B7",IdString="-3309401044423854409",Family="nornir_chest",Realm="Alfheim",CatalogueId="nornir_chest_9a92c24340832c2107ff7d997c9fcbda",ParentId=nil,Reference=nil,EventKey="wad_alf340_trenchbdark|runic_breakable_01|runic_breakable_02|runic_breakable_03",Class="SIDE"},
    {Name="Completionist_V105_NornirMechanism_f747f31b84e60195",UidHex="D2AC14538B25227C",IdString="-3266213280701144452",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_f747f31b84e60195ec5da9adeaac82ed",ParentId="nornir_chest_69780ade492b089119484199e5423527",Reference="Base_002",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirSeal_4088b5d5749c3a03",UidHex="D4667E60D4A3EAB8",IdString="-3141684735694869832",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_4088b5d5749c3a03145bb68a33a7f2b3",ParentId="nornir_chest_45bbcd15458cd30c3338a7b3dab9b3d9",Reference="runic_breakable_03",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_edb597eb3fcc50d8",UidHex="D4F0C38B2EF4EE53",IdString="-3102765140702597549",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_edb597eb3fcc50d897b382f360fa5619",ParentId="nornir_chest_6d18634c4e86282d1cfa0e84f6d5654f",Reference="runic_breakable_03",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirChest_3f3a8e7844ff44f5",UidHex="DA7448063CED933A",IdString="-2705458284513619142",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_3f3a8e7844ff44f57da024b2efce93dc",ParentId=nil,Reference=nil,EventKey="wad_xpl850_dungeonforest|belltarget_a|belltarget_b|belltarget_c",Class="SIDE"},
    {Name="Completionist_V105_NornirMechanism_739746f815d13616",UidHex="DCFC7D96D080F61F",IdString="-2523003604537641441",Family="nornir_mechanism",Realm="Midgard",CatalogueId="nornir_mechanism_739746f815d13616f8a6d6ef039730f1",ParentId="nornir_chest_f8ac74b9414e59e764d8738182c00663",Reference="SpinChest_SpinBase1",EventKey=nil,Class="AreaEntrance"},
    {Name="Completionist_V105_NornirBell_262a7d6d0d999d0e",UidHex="DE8CAADE115DBA29",IdString="-2410363829799241175",Family="nornir_bell",Realm="Alfheim",CatalogueId="nornir_bell_262a7d6d0d999d0e281fc3437c7c4887",ParentId="nornir_chest_3ec0daa848922cad4fb30c8bb93c171f",Reference="BellChest_BellTarget_02",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirBell_0a218968e317838d",UidHex="E39B2AC2BE257B1B",IdString="-2045994589807609061",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_0a218968e317838d36fba55bea1f3bf3",ParentId="nornir_chest_6b7011074e78df82ecd508b6b1a8444f",Reference="BellTarget_Small_03",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirSeal_79c9f99c41034f2b",UidHex="E657EB07C8DD1361",IdString="-1848750703345069215",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_79c9f99c41034f2ba90fdd476357f622",ParentId="nornir_chest_f8548c574dc67cba277c5cb31099648b",Reference="GnomeTarget_LargeC",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirSeal_ee9062f9def604e3",UidHex="E7B90ABC6B176D52",IdString="-1749355175889900206",Family="nornir_seal",Realm="Midgard",CatalogueId="nornir_seal_ee9062f9def604e3dcc2aa2adf4203fe",ParentId="nornir_chest_0f0cc7ca48423bb296f6ddbed87a8f3b",Reference="runic_breakable_03",EventKey=nil,Class="Valkyrie"},
    {Name="Completionist_V105_NornirChest_d2cacb84426fd68d",UidHex="EA2DC8F689222222",IdString="-1572379733694209502",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_d2cacb84426fd68d504a11ae125c2b62",ParentId=nil,Reference=nil,EventKey="wad_riv420_forestboarstart|riv420bell_01|riv420bell_02|riv420bell_03",Class="SIDE"},
    {Name="Completionist_V105_NornirBell_6a49e5f6bc88d53b",UidHex="EF65E2AB9537714D",IdString="-1196300899426274995",Family="nornir_bell",Realm="Alfheim",CatalogueId="nornir_bell_6a49e5f6bc88d53b1b42ecd4a4868977",ParentId="nornir_chest_522448bf4d91b0f19de6adbd1c77d709",Reference="BellTarget_3",EventKey=nil,Class="FightLocation"},
    {Name="Completionist_V105_NornirChest_45bbcd15458cd30c",UidHex="F4CA38685DA49EA5",IdString="-807771162260758875",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_45bbcd15458cd30c3338a7b3dab9b3d9",ParentId=nil,Reference=nil,EventKey="wad_riv225_dangerscave|runic_breakable_01|runic_breakable_02|runic_breakable_03",Class="SIDE"},
    {Name="Completionist_V105_NornirChest_6d18634c4e86282d",UidHex="F4DEAB818C65C826",IdString="-802015110730758106",Family="nornir_chest",Realm="Midgard",CatalogueId="nornir_chest_6d18634c4e86282d1cfa0e84f6d5654f",ParentId=nil,Reference=nil,EventKey="wad_for600_spire|runic_breakable_01|runic_breakable_02|runic_breakable_03",Class="SIDE"},
    {Name="Completionist_V105_NornirBell_c626289e29408cee",UidHex="F5D8CB5FA742DC8A",IdString="-731611327759197046",Family="nornir_bell",Realm="Midgard",CatalogueId="nornir_bell_c626289e29408ceec48e309cc46a22b2",ParentId="nornir_chest_d2cacb84426fd68d504a11ae125c2b62",Reference="Riv420Bell_03",EventKey=nil,Class="FightLocation"},
  }
  local loadedPaths = {
    ["nornir_chest_a2cdfc7a4f0ab68eac212bb108cd35b7"]={Level="xpl940_beachcave",Path={"gochest_runic_tier1_xpl940_1","gogameplay_objects","goxpl940_ents_nooffset","goxpl940_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier1_xpl940_1","gogameplay_objects","goxpl940_ents_nooffset","goxpl940_ents"}},
    ["nornir_chest_7d8b404340e8ef8edb4096b3a1a1e3fc"]={Level="riv325_dangersexit",Path={"golockedchest_traproom","goriv325_cbt"},ScriptPath={"gochest_locked_parent","golockedchest_traproom","goriv325_cbt"}},
    ["nornir_chest_e00c75d24c76b498de4c1f85c997c65e"]={Level="alf210_lakedarklh",Path={"gochest_runic_tier1_alf210_1","go_bellsetup_hunt_______","goalf210_ents_nooffset","goalf210_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier1_alf210_1","go_bellsetup_hunt_______","goalf210_ents_nooffset","goalf210_ents"}},
    ["nornir_chest_3ec0daa848922cad4fb30c8bb93c171f"]={Level="alf320_trenchadark",Path={"gochest_runic_tier1_alf320_1","go___basic_bellchest_setup___","goalf320_ents_nooffset","goalf320_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier1_alf320_1","go___basic_bellchest_setup___","goalf320_ents_nooffset","goalf320_ents"}},
    ["nornir_chest_f8ac74b9414e59e764d8738182c00663"]={Level="peak140_caverndark",Path={"gochest_locked_tier3_peak140_1","gospinchest_setup","gopeak140_ents"},ScriptPath={"gochest_locked_parent","gochest_locked_tier3_peak140_1","gospinchest_setup","gopeak140_ents"}},
    ["nornir_chest_69780ade492b089119484199e5423527"]={Level="riv475_freyahouseext",Path={"gochest_locked_tier3_riv475_1","go____spinchest_setup____","goriv475_cbt"},ScriptPath={"gochest_locked_parent","gochest_locked_tier3_riv475_1","go____spinchest_setup____","goriv475_cbt"}},
    ["nornir_chest_c190d59340706bb79925cb9f2d5867cf"]={Level="xpl200_funeral",Path={"gochest_runic_tier2_xpl200_1","gocontainers","goxpl200_ents_nooffset","goxpl200_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier2_xpl200_1","gocontainers","goxpl200_ents_nooffset","goxpl200_ents"}},
    ["nornir_chest_6fc8ac794c63bf63a13736b7cd3c7f25"]={Level="helr100_docks",Path={"gochest_runic_tier4_helr100_1","gohelr100_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier4_helr100_1","gohelr100_ents"}},
    ["nornir_chest_d8e4c77444fe09d0a960198ab802058e"]={Level="xpl100_httk",Path={"gochest_locked_tier5_xpl100_1","gocontainers","goxpl100_ents_nooffset","goxpl100_ents"},ScriptPath={"gochest_locked_parent","gochest_locked_tier5_xpl100_1","gocontainers","goxpl100_ents_nooffset","goxpl100_ents"}},
    ["nornir_chest_6b7011074e78df82ecd508b6b1a8444f"]={Level="xpl970_beachtower",Path={"gochest_locked_tier1_xpl970_1","gopickups","goxpl970_ents_nooffset","goxpl970_ents"},ScriptPath={"gochest_locked_parent","gochest_locked_tier1_xpl970_1","gopickups","goxpl970_ents_nooffset","goxpl970_ents"}},
    ["nornir_chest_c0cf411940bad7d00042afa7a46f5514"]={Level="peak720_summitascenthub",Path={"gochest_locked_tier3_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"},ScriptPath={"gochest_locked_parent","gochest_locked_tier3_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"}},
    ["nornir_chest_522448bf4d91b0f19de6adbd1c77d709"]={Level="alf690_lakelightlh",Path={"gochest_runic_tier1_alf690","goalf690_ents_nooffset","goalf690_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier1_alf690","goalf690_ents_nooffset","goalf690_ents"}},
    ["nornir_chest_f8548c574dc67cba277c5cb31099648b"]={Level="cal500_runevault",Path={"gochest_locked_tier4_cal500_1","gowad","gocal500_ents"},ScriptPath={"gochest_locked_parent","gochest_locked_tier4_cal500_1","gowad","gocal500_ents"}},
    ["nornir_chest_a336e1844ac7c90b6cd6288e2cdab274"]={Level="xpl920_islandclimb",Path={"gochest_runic_tier1_xpl920_1","gochestpickups_loot","goxpl920_ents_nooffset","goxpl920_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier1_xpl920_1","gochestpickups_loot","goxpl920_ents_nooffset","goxpl920_ents"}},
    ["nornir_chest_a6ac8eeb4ea2545ab05df19e8ea6ee8f"]={Level="foot100_base",Path={"gochest_locked_tier1_foot100_1","go______memorychest_poisonsetup","gofoot100_ents"},ScriptPath={"gochest_locked_parent","gochest_locked_tier1_foot100_1","go______memorychest_poisonsetup","gofoot100_ents"}},
    ["nornir_chest_c02f019049d50ea0146c478fd46f4a49"]={Level="xpl950_beachmaze",Path={"golootlockedchest_spintype_xx01","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},ScriptPath={"gochest_locked_parent","gochest_locked_parent","gorunic_chest_axe_tier02_04","golootlockedchest_spintype_xx01","gopickups","goxpl950_ents_nooffset","goxpl950_ents"}},
    ["nornir_chest_0f0cc7ca48423bb296f6ddbed87a8f3b"]={Level="riv925_freyacave",Path={"gochest_locked_tier1_riv925_1","goriv925_cbt"},ScriptPath={"gochest_locked_parent","gochest_locked_tier1_riv925_1","goriv925_cbt"}},
    ["nornir_chest_9a92c24340832c2107ff7d997c9fcbda"]={Level="alf340_trenchbdark",Path={"gochest_runic_tier1_alf340_1","goloot","goalf340_ents_nooffset","goalf340_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier1_alf340_1","goloot","goalf340_ents_nooffset","goalf340_ents"}},
    ["nornir_chest_3f3a8e7844ff44f57da024b2efce93dc"]={Level="xpl850_dungeonforest",Path={"gochest_runic_tier1_xpl850_1","gobell_triplechest_01","goxpl850_ents_nooffset","goxpl850_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier1_xpl850_1","gobell_triplechest_01","goxpl850_ents_nooffset","goxpl850_ents"}},
    ["nornir_chest_d2cacb84426fd68d504a11ae125c2b62"]={Level="riv420_forestboarstart",Path={"gochest_runic_tier1_riv420_1","goriv420_cbt"},ScriptPath={"gochest_locked_parent","gochest_runic_tier1_riv420_1","goriv420_cbt"}},
    ["nornir_chest_45bbcd15458cd30c3338a7b3dab9b3d9"]={Level="riv225_dangerscave",Path={"golootlockedchest","goriv225_cbt"},ScriptPath={"gochest_locked_parent","golootlockedchest","goriv225_cbt"}},
    ["nornir_chest_6d18634c4e86282d1cfa0e84f6d5654f"]={Level="for600_spire",Path={"gochest_runic_tier1_for600_1","golocked_triple_chest","gofor600_ents"},ScriptPath={"gochest_locked_parent","gochest_runic_tier1_for600_1","golocked_triple_chest","gofor600_ents"}},
  }
  local Saved = (function()
-- Fresh native checkpoint reads. Socket polling never waits for capture work.
local Saved={}
Saved.__index=Saved
function Saved.New(rows,contract,transport,expectedRestoreEpoch)
 local self=setmetatable({parents={},contract=contract,nonce=0,nextRead=0,
  expectedRestoreEpoch=expectedRestoreEpoch},Saved)
 for _,row in ipairs(rows) do if row.family=='nornir_chest' then self.parents[#self.parents+1]=row end end
 table.sort(self.parents,function(a,b) return a.id<b.id end)
 if not transport then
  local ok,socket=pcall(require,'socket.core')
  if ok and type(socket)=='table' and type(socket.gettime)=='function' and type(socket.tcp)=='function' then
   transport={now=socket.gettime,create=socket.tcp}
  end
 end
 self.transport=transport
 return self
end
function Saved:Reset(epoch)
 if self.client then pcall(function() self.client:close() end) end
 self.epoch=epoch; self.client=nil; self.snapshot=nil; self.buffer=''; self.nextRead=0
end
function Saved:Current(epoch)
 if not self.snapshot or self.snapshot.epoch~=epoch or not self.snapshotTime or not self.transport then return nil end
 local age=self.transport.now()-self.snapshotTime
 if age<0 or age>2.5 then return nil end
 if self.expectedRestoreEpoch and tonumber(self.snapshot.restoreEpoch)~=self.expectedRestoreEpoch() then return nil end
 return self.snapshot
end
function Saved:Parse(line)
 local nonce,restore,contract,states=string.match(line,
  '^NORNIR_SNAPSHOT_V1 nonce=(%d+) restoreEpoch=(%d+) contract=(%x+) states=([0-4]+)$')
 if nonce~=tostring(self.nonce) or contract~=self.contract or #states~=#self.parents then return nil end
 if self.expectedRestoreEpoch then
  local expected=self.expectedRestoreEpoch()
  if type(expected)~='number' or expected<0 or expected~=math.floor(expected) or
   tonumber(restore)~=expected then return nil end
 end
 local result={epoch=self.epoch,states={},restoreEpoch=restore}
 for i,row in ipairs(self.parents) do result.states[row.id]=tonumber(string.sub(states,i,i)) end
 return result
end
function Saved:ReadOnce(epoch)
 if epoch~=self.epoch then self:Reset(epoch) end
 if not self.transport then return false,'transport_unavailable' end
 if self.client then pcall(function() self.client:close() end); self.client=nil end
 local ok,client=pcall(self.transport.create)
 if not ok or not client then return false,'socket_create_failed' end
 self.nonce=self.nonce+1
 local request='CAPTURE NORNIR_SNAPSHOT_V1 nonce='..tostring(self.nonce)..'\n'
 local connected,reason=pcall(function()
  assert(client:settimeout(0.5))
  client:settimeout(0.5,'t')
  assert(client:connect('127.0.0.1',43753))
  assert(client:send(request)==#request)
 end)
 if not connected then
  pcall(function() client:close() end)
  return false,'request_failed:'..tostring(reason)
 end
 local received,line,err=pcall(function() return client:receive('*l') end)
 pcall(function() client:close() end)
 self.nextRead=self.transport.now()+2
 if not received or not line then return false,'reply_failed:'..tostring(err) end
 if #line>256 then return false,'reply_too_long' end
 local parsed=self:Parse(line)
 if not parsed then
  if line=='NORNIR_SNAPSHOT_V1 UNAVAILABLE' then return false,'native_unavailable' end
  return false,'reply_rejected:restore='..tostring(self.expectedRestoreEpoch and
   self.expectedRestoreEpoch())..':length='..tostring(#line)
 end
 self.snapshot=parsed
 self.snapshotTime=self.transport.now()
 return true,'accepted:restore='..tostring(parsed.restoreEpoch)
end
function Saved:Poll(epoch)
 if epoch~=self.epoch then self:Reset(epoch) end
 if not self.transport or not epoch then return false end
 local now=self.transport.now()
 local expired=self.snapshot~=nil and self:Current(epoch)==nil
 if expired then self.snapshot=nil end
 if self.client then
  local finished=false
  for _=1,256 do
   local ok,value,err=pcall(function() return self.client:receive(1) end)
   if ok and value=='\n' then
    self.snapshot=self:Parse(self.buffer); self.snapshotTime=now; finished=true; break
   elseif ok and value and #value==1 then
    self.buffer=self.buffer..value
    if #self.buffer>256 then self.snapshot=nil; finished=true; break end
   elseif not ok or err~='timeout' then self.snapshot=nil; finished=true; break
   else break end
  end
  if now>=self.deadline then self.snapshot=nil; finished=true end
  if finished then
   pcall(function() self.client:close() end); self.client=nil; self.nextRead=now+2
   return true
  end
  return expired
 end
 if now<self.nextRead then return expired end
 self.nextRead=now+2
 local ok,client=pcall(self.transport.create)
 if not ok or not client then local had=self.snapshot~=nil; self.snapshot=nil; return had or expired end
 self.nonce=self.nonce+1
 local request='CAPTURE NORNIR_SNAPSHOT_V1 nonce='..tostring(self.nonce)..'\n'
 local connected=pcall(function()
  assert(client:settimeout(0.005)); assert(client:connect('127.0.0.1',43753))
  assert(client:send(request)==#request); assert(client:settimeout(0))
 end)
 if not connected then
  pcall(function() client:close() end)
  local had=self.snapshot~=nil; self.snapshot=nil; return had or expired
 end
 self.client=client; self.buffer=''; self.deadline=now+3
 return expired
end
return Saved

  end)()
  local savedContract = "3725841a2d9286ce801c919c4d49714bac0648c5be6e84c5b95d7a06c126f420"
  local checkpointRows = {}
  for _, row in ipairs(rows) do
    if row.Family == "nornir_chest" then
      checkpointRows[#checkpointRows + 1] = {
        id = row.CatalogueId, family = row.Family,
      }
    end
  end
  local saved = Saved.New(checkpointRows, savedContract, nil, function()
    return tonumber(_G.CompletionistMapV105LastNativeRestoreEpoch)
  end)
  local byName, byKey, children = {}, {}, {}
  for _, row in ipairs(rows) do
    byName[row.Name] = row
    if row.EventKey then byKey[row.EventKey] = row end
    if row.ParentId then
      children[row.ParentId] = children[row.ParentId] or {}
      children[row.ParentId][string.lower(row.Reference)] = row
    end
  end
  local revealed, opened, solved = {}, {}, {}
  local activeMap = nil
  local targetRow = nil
  local captureReady = true
  local loadedReadFrames = 0
  local pendingSnapshots = {}

  local function hideTarget()
    if targetRow ~= nil then
      pcall(function() game.Compass.HideMarker(targetRow.Name) end)
      targetRow = nil
      if activeMap and type(activeMap.UpdateMapMarkerHighlights) == "function" then
        pcall(activeMap.UpdateMapMarkerHighlights, activeMap)
      end
    end
  end

  _G.CompletionistMapV105GetNornirTargetName = function()
    return targetRow and targetRow.Name or nil
  end
  _G.CompletionistMapV105HasNornirCompassTarget = function()
    return targetRow ~= nil
  end
  _G.CompletionistMapV105ReleaseNornirCompass = function()
    hideTarget()
    if activeMap and type(activeMap.UpdateMapMarkerHighlights) == "function" then
      pcall(activeMap.UpdateMapMarkerHighlights, activeMap)
    end
    return true
  end

  local function filter(self)
    return self.filterButtonMapping and self.filterButtonMapping[self.filterIndex] or 1
  end

  local function visible(self, row)
    if self == nil or self.isOpenedForFastTravel then return false end
    local kind = filter(self)
    if kind ~= 1 and kind ~= -101 and
        not (kind == -103 and row.Family == "nornir_chest") and
        not (kind == -104 and row.Family ~= "nornir_chest") then
      return false
    end
    if kind == 1 then
      if _G.CompletionistMapV105ShowAll and not _G.CompletionistMapV105ShowAll() then return false end
    elseif kind < 0 then
      if _G.CompletionistMapV105ShowCategories and not _G.CompletionistMapV105ShowCategories() then return false end
    end
    if row.Family == "nornir_chest" then return not opened[row.CatalogueId] end
    return revealed[row.ParentId] == true and
      not opened[row.ParentId] and not solved[row.CatalogueId]
  end

  local function recycle(self)
    local icons = self.completionistMapV105NornirIdTestIcons or {}
    for name, icon in pairs(icons) do
      pcall(function() Map.RecycleIcon(icon) end)
      if self.mapIconCollision == icon then self.mapIconCollision = nil end
      icons[name] = nil
    end
    self.completionistMapV105NornirIdTestIcons = icons
    self.completionistMapV105NornirSelected = nil
  end

  local function sync(self)
    if self == nil then return end
    activeMap = self
    local icons = self.completionistMapV105NornirIdTestIcons or {}
    self.completionistMapV105NornirIdTestIcons = icons
    for name, icon in pairs(icons) do
      local row = byName[name]
      if row == nil or row.Realm ~= self.currRealmName or not visible(self, row) then
        pcall(function() Map.RecycleIcon(icon) end)
        if self.mapIconCollision == icon then self.mapIconCollision = nil end
        if self.completionistMapV105NornirSelected == row then
          self.completionistMapV105NornirSelected = nil
        end
        icons[name] = nil
      end
    end
    for _, row in ipairs(rows) do
      if row.Realm == self.currRealmName and visible(self, row) and
          icons[row.Name] == nil then
        local ok, icon = pcall(function()
          local info = game.Map.GetMarkerInfo(row.Name)
          if type(info) ~= "table" or info.Id == nil then return nil end
          if tostring(info.Id) ~= row.IdString then return nil end
          local found, region = Map.FindRegionFromMarker(info.Id)
          if found ~= true or region == nil then return nil end
          return Map.CreateMarkerIcon(info.Id, region, "")
        end)
        if ok and icon ~= nil then
          icons[row.Name] = icon
          pcall(function() icon:Show() end)
        else
          print("[CompletionistMapV105NornirIdTest] create_failed name=" .. row.Name)
        end
      end
    end
  end

  _G.CompletionistMapV105ResyncNornir = function(target)
    local map = target or activeMap
    if map ~= nil then
      sync(map)
    end
  end

    local function plainName(value)
    if type(value) ~= "string" then return nil end
    value = string.lower(value)
    if string.sub(value, 1, 2) == "go" then return string.sub(value, 3) end
    return value
  end

  local function exactPath(object, names)
    if object == nil or type(names) ~= "table" then return false end
    for _, expected in ipairs(names) do
      if object == nil or plainName(object:GetName()) ~= plainName(expected) then
        return false
      end
      object = object.Parent
    end
    return true
  end

  local function readLoadedParent(info)
    local level = game.FindLevel(info.Level)
    if level == nil then return nil end
    local placement = level:FindSingleGameObject(plainName(info.Path[1]))
    if not exactPath(placement, info.Path) then return nil end
    local script = placement:FindSingleGOByName(plainName(info.ScriptPath[1]))
    if not exactPath(script, info.ScriptPath) then return nil end
    local ancestor = script
    for _ = 1, #info.ScriptPath - #info.Path do
      ancestor = ancestor.Parent
    end
    if ancestor ~= placement then return nil end
    local owner = script
    if script.IsRefNode then
      owner = script.Child
      if owner == nil or owner.Parent ~= script then return nil end
    end
    return owner.LuaObjectScript.CompletionistNornirObserveSeals()
  end

  local function observeLoadedSeals()
    if type(game.FindLevel) ~= "function" then return false end
    local changed = false
    for _, parent in ipairs(rows) do
      local info = loadedPaths[parent.CatalogueId]
      if info ~= nil and not opened[parent.CatalogueId] then
        local ok, entries = pcall(readLoadedParent, info)
        if ok and type(entries) == "table" and #entries == 3 then
          local nextState, known = {}, true
          for _, entry in ipairs(entries) do
            local ref = type(entry.reference) == "string" and
              string.lower(entry.reference) or nil
            local child = ref and children[parent.CatalogueId] and
              children[parent.CatalogueId][ref]
            if child == nil or child.Family ~= "nornir_seal" or
                type(entry.broken) ~= "boolean" or
                nextState[child.CatalogueId] ~= nil then
              known = false
              break
            end
            nextState[child.CatalogueId] = entry.broken
          end
          if known then
            local count = 0
            local parentChanged = false
            for id, broken in pairs(nextState) do
              if broken then count = count + 1 end
              if (solved[id] == true) ~= broken then
                solved[id] = broken or nil
                changed = true
                parentChanged = true
              end
            end
            if parentChanged then
              print("[CompletionistMapV105Nornir] loaded_seals parent=" ..
                parent.CatalogueId .. " broken=" .. tostring(count))
            end
          end
        end
      end
    end
    if changed and targetRow ~= nil and solved[targetRow.CatalogueId] then
      hideTarget()
    end
    return changed
  end

  local function applySealSnapshot(parent, bits)
    if type(bits) ~= "string" or not string.match(bits, "^[01][01][01]$") then
      return false
    end
    local refs = {}
    for ref, child in pairs(children[parent.CatalogueId] or {}) do
      if child.Family == "nornir_seal" then refs[#refs + 1] = ref end
    end
    if #refs ~= 3 then return false end
    table.sort(refs)
    for index, ref in ipairs(refs) do
      local child = children[parent.CatalogueId][ref]
      solved[child.CatalogueId] =
        string.sub(bits, index, index) == "1" or nil
    end
    return true
  end

  local controller = {service = {epoch = 1}}
  function controller:BeginEpoch(epoch)
    if type(epoch) ~= "number" or epoch <= self.service.epoch then return false end
    self.service.epoch = epoch
    revealed, opened, solved = {}, {}, {}
    local snapshots = pendingSnapshots
    pendingSnapshots = {}
    for _, snapshot in pairs(snapshots) do
      applySealSnapshot(snapshot.parent, snapshot.bits)
    end
    saved:Reset(epoch)
    hideTarget()
    observeLoadedSeals()
    sync(activeMap)
    return true
  end
  controller.liveReader = {}
  function controller.liveReader:SetReady(ready)
    captureReady = ready == true
  end
  _G.CompletionistMapV105Nornir = controller
  saved:Reset(controller.service.epoch)

  local function acceptSaved()
    local snapshot = saved:Current(controller.service.epoch)
    if snapshot == nil then return end
    local changed = false
    for catalogueId, state in pairs(snapshot.states) do
      if state == 4 and not opened[catalogueId] then
        opened[catalogueId] = true
        revealed[catalogueId] = nil
        changed = true
      end
    end
    if not changed then return end
    if targetRow ~= nil and
        (opened[targetRow.CatalogueId] or
         (targetRow.ParentId and opened[targetRow.ParentId])) then
      hideTarget()
    end
    sync(activeMap)
    print("[CompletionistMapV105Nornir] checkpoint_opened epoch=" ..
      tostring(controller.service.epoch) .. " restoreEpoch=" ..
      tostring(snapshot.restoreEpoch))
  end

  local function accept(payload)
    if type(payload) ~= "string" then return end
    local action, key, ref = string.match(payload,
      "^NORNIR_V1\t([a-z]+)\t([^\t]+)\t(.*)$")
    local parent = key and byKey[key] or nil
    if parent == nil then return end
    if action == "attempt" and not opened[parent.CatalogueId] then
      revealed[parent.CatalogueId] = true
    elseif action == "opened" then
      opened[parent.CatalogueId] = true
      revealed[parent.CatalogueId] = nil
    elseif action == "seal" then
      local child = children[parent.CatalogueId] and
        children[parent.CatalogueId][ref]
      if child ~= nil and child.Family == "nornir_seal" then
        solved[child.CatalogueId] = true
      end
    elseif action == "snapshot" then
      if not applySealSnapshot(parent, ref) then return end
      pendingSnapshots[parent.CatalogueId] = {parent = parent, bits = ref}
    else
      return
    end
    print("[CompletionistMapV105Nornir] received=" .. action ..
      " key=" .. key .. " parent=" .. parent.CatalogueId)
    if targetRow ~= nil and
        (opened[targetRow.CatalogueId] or
        (targetRow.ParentId and (opened[targetRow.ParentId] or
        solved[targetRow.CatalogueId]))) then
      hideTarget()
    end
    sync(activeMap)
  end

  local hookOK, thunk = pcall(require, "core.thunk")
  if hookOK and type(thunk) == "table" and type(thunk.Install) == "function" then
    thunk.Install("COMPLETIONIST_NORNIR_EVENT_V1", function(...)
      for index = 1, select("#", ...) do
        local value = select(index, ...)
        if type(value) == "string" and
            string.sub(value, 1, 10) == "NORNIR_V1\t" then
          accept(value)
        end
      end
    end)
  end

  local createPins = CompletionistMapV100_CreateMapPin
  CompletionistMapV100_CreateMapPin = function(self, ...)
    local firstOpen = activeMap ~= self
    local result = createPins(self, ...)
    if firstOpen then
      local ok, status = false, "capture_not_ready"
      if captureReady then
        ok, status = saved:ReadOnce(controller.service.epoch)
        if ok then acceptSaved() end
      end
      print("[CompletionistMapV105Nornir] checkpoint_initial=" ..
        tostring(ok) .. " reason=" .. tostring(status) ..
        " epoch=" .. tostring(controller.service.epoch))
      loadedReadFrames = 0
    end
    observeLoadedSeals()
    sync(self)
    return result
  end

  local update = MapOn.Update
  if type(update) == "function" then
    MapOn.Update = function(self, ...)
      local result = update(self, ...)
      if captureReady and saved:Poll(controller.service.epoch) then
        acceptSaved()
      end
      if loadedReadFrames < 180 then
        loadedReadFrames = loadedReadFrames + 1
        if loadedReadFrames % 30 == 0 and observeLoadedSeals() then
          sync(self)
        end
      end
      return result
    end
  end

  local nextFilter = MapOn.Menu_Next_Filter
  if type(nextFilter) == "function" then
    MapOn.Menu_Next_Filter = function(self, ...)
      local result = nextFilter(self, ...)
      sync(self)
      return result
    end
  end

  local updateMapping = MapOn.UpdateFilterButtonMapping
  MapOn.UpdateFilterButtonMapping = function(self, ...)
    local selected = self.filterButtonMapping and
      self.filterButtonMapping[self.filterIndex]
    local result = updateMapping(self, ...)
    local realmHasNornir = false
    for _, row in ipairs(rows) do
      if row.Realm == self.currRealmName then realmHasNornir = true; break end
    end
    if realmHasNornir and type(self.filterButtonMapping) == "table" then
      local existing = {}
      for _, value in ipairs(self.filterButtonMapping) do existing[value] = true end
      if not existing[-103] then self.filterButtonMapping[#self.filterButtonMapping + 1] = -103 end
      if not existing[-104] then self.filterButtonMapping[#self.filterButtonMapping + 1] = -104 end
      if selected == -103 or selected == -104 then
        for index, value in ipairs(self.filterButtonMapping) do
          if value == selected then self.filterIndex = index; break end
        end
      end
      if type(self.UpdateFilterUI) == "function" then self:UpdateFilterUI() end
    end
    return result
  end

  for _, method in ipairs({"SubmenuExit", "Exit", "ClearIcons"}) do
    local previous = MapOn[method]
    if type(previous) == "function" then
      MapOn[method] = function(self, ...)
        recycle(self)
        if activeMap == self then activeMap = nil end
        return previous(self, ...)
      end
    end
  end

  local collision = MapOn.MapCollisionChangeHandler
  MapOn.MapCollisionChangeHandler = function(self, currState, hits, realmName)
    local result = collision(self, currState, hits, realmName)
    self.completionistMapV105NornirSelected = nil
    for name, icon in pairs(self.completionistMapV105NornirIdTestIcons or {}) do
      for _, hit in ipairs(hits or {}) do
        if hit == icon then
          local row = byName[name]
          local ok, info = pcall(game.Map.GetMarkerInfo, row.Name)
          if ok and info ~= nil and tostring(info.Id) == row.IdString and
              tostring(self.currMarkerID) == row.IdString then
            self.completionistMapV105NornirSelected = row
            local title = row.Family == "nornir_chest" and "Nornir Chest" or
              row.Family == "nornir_seal" and "Nornir Seal" or
              row.Family == "nornir_bell" and "Nornir Bell" or "Nornir Rune Mechanism"
            pcall(function() self:SetReticleInfo(currState, title, "Completionist Map") end)
            local menu = currState and currState.menu or self.menu
            local show, promptStr = self:GetShowOnCompassPrompt(menu)
            if show and promptStr and type(util) == "table" and type(util.GetUiObjByName) == "function" then
              pcall(function()
                local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
                if goMapCursorText ~= nil then
                  goMapCursorText:Show()
                  local top = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
                  if top ~= nil then
                    local handle = util.GetTextHandle(top, "CursorAction_Text")
                    if handle ~= nil then
                      if type(UI) == "table" and type(UI.SetTextIsClickable) == "function" then
                        UI.SetTextIsClickable(handle)
                      end
                      if type(UI) == "table" and type(UI.SetText) == "function" then
                        UI.SetText(handle, promptStr)
                      end
                    end
                    top:Show()
                  end
                end
              end)
            end
            if menu and type(menu.UpdateFooterButton) == "function" and show and promptStr then
              pcall(function()
                menu:UpdateFooterButton("ShowOnCompass", true, promptStr)
                if type(menu.UpdateFooterButtonText) == "function" then
                  menu:UpdateFooterButtonText()
                end
              end)
            end
            if menu and type(self.UpdateFooterButtonPrompt) == "function" then
              pcall(self.UpdateFooterButtonPrompt, self, menu, false, false)
            end
            print("[CompletionistMapV105NornirIdTest] selected name=" .. name ..
              " uid=" .. row.UidHex .. " family=" .. row.Family)
            return result
          end
        end
      end
    end
    return result
  end

  local previousHighlights = MapOn.UpdateMapMarkerHighlights
  MapOn.UpdateMapMarkerHighlights = function(self, ...)
    if previousHighlights then previousHighlights(self, ...) end
    local target = self or activeMap
    if target and type(UI) == "table" and type(UI.Anim) == "function" then
      for name, icon in pairs(target.completionistMapV105NornirIdTestIcons or {}) do
        local row = byName[name]
        if targetRow ~= nil and targetRow == row then
          pcall(UI.Anim, icon, 10, "", 1)
        else
          pcall(UI.Anim, icon, 0, "", 0, 0)
        end
      end
    end
  end

  local previousPrompt = MapOn.GetShowOnCompassPrompt
  MapOn.GetShowOnCompassPrompt = function(self, ...)
    local row = self.completionistMapV105NornirSelected
    if row ~= nil then
      if self.isOpenedForFastTravel or not game.Compass.HaveCompass() or
          self.currRealmName ~= mapUtil.GetPlayerRealm() or
          tutorialUtil.CurrentlyShowingStep() then return false, nil end
      local label = lamsConsts.AddToCompass
      if targetRow == row then
        label = lamsConsts.RemoveFromCompass
      elseif targetRow ~= nil or self.currShownMarkerID ~= nil or
          (_G.CompletionistMapV105HasRavenCompassTarget and _G.CompletionistMapV105HasRavenCompassTarget()) or
          (_G.CompletionistMapV105HasLocationCompassTarget and _G.CompletionistMapV105HasLocationCompassTarget()) then
        label = lamsConsts.ReplaceInCompass
      end
      return true, "[AdvanceButton] " .. util.GetLAMSMsg(label)
    end
    return previousPrompt(self, ...)
  end
  local previousShow = MapOn.ShowOnCompass
  MapOn.ShowOnCompass = function(self, ...)
    local row = self.completionistMapV105NornirSelected
    if row ~= nil then
      if targetRow == row then
        hideTarget()
        pcall(function() Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass") end)
      else
        if type(_G.CompletionistMapV105ReleaseRavenCompass) == "function" and
            _G.CompletionistMapV105ReleaseRavenCompass() == false then return false end
        if type(_G.CompletionistMapV105ReleaseLocationCompass) == "function" and
            _G.CompletionistMapV105ReleaseLocationCompass() == false then return false end
        if self.currShownMarkerID ~= nil then
          pcall(function() game.Compass.HideMarker(self.currShownMarkerID) end)
          self.currShownMarkerID = nil
        end
        hideTarget()
        local nornirClasses = {
          ["nornir_chest"] = "CompletionistNornirChest",
          ["nornir_seal"] = "CompletionistNornirSeal",
          ["nornir_bell"] = "CompletionistNornirBell",
          ["nornir_mechanism"] = "CompletionistNornirMechanism",
        }
        local compassClass = (row.Family and nornirClasses[row.Family]) or row.Class or "CompletionistNornirChest"
        local ok, shown = pcall(game.Compass.ShowMarker, row.Name, compassClass)
        if not ok or shown == false then
          ok, shown = pcall(game.Compass.ShowMarker, row.Name, "SIDE")
        end
        if not ok or shown == false then return false end
        targetRow = row
        local legacy = _G.CompletionistMapV100Target
        if legacy then legacy.active = false end
        pcall(function() Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass") end)
      end
      pcall(function() self:UpdateMapMarkerHighlights() end)
      local currState = select(1, ...)
      local menu = currState and currState.menu or self.menu
      local show, text = self:GetShowOnCompassPrompt(menu)
      if show and text then
        if type(util) == "table" and type(util.GetUiObjByName) == "function" then
          pcall(function()
            local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
            if goMapCursorText ~= nil then
              goMapCursorText:Show()
              local top = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
              if top ~= nil then
                local handle = util.GetTextHandle(top, "CursorAction_Text")
                if handle ~= nil then
                  if type(UI) == "table" and type(UI.SetTextIsClickable) == "function" then
                    UI.SetTextIsClickable(handle)
                  end
                  if type(UI) == "table" and type(UI.SetText) == "function" then
                    UI.SetText(handle, text)
                  end
                end
                top:Show()
              end
            end
          end)
        end
        if menu and type(menu.UpdateFooterButton) == "function" then
          pcall(function()
            menu:UpdateFooterButton("ShowOnCompass", true, text)
            if type(menu.UpdateFooterButtonText) == "function" then
              menu:UpdateFooterButtonText()
            end
          end)
        end
      end
      if menu and type(self.UpdateFooterButtonPrompt) == "function" then
        pcall(self.UpdateFooterButtonPrompt, self, menu, false, false)
      end
      return true
    end
    hideTarget()
    return previousShow(self, ...)
  end

  -- Share the single native compass target with the location layer.
  _G.CompletionistMapV105GetNornirTargetName = function()
    return targetRow and targetRow.Name or nil
  end
  _G.CompletionistMapV105HasNornirCompassTarget = function()
    return targetRow ~= nil
  end
  _G.CompletionistMapV105ReleaseNornirCompass = function()
    hideTarget()
    if activeMap and type(activeMap.UpdateMapMarkerHighlights) == "function" then
      pcall(activeMap.UpdateMapMarkerHighlights, activeMap)
    end
    return true
  end

  print("[CompletionistMapV105NornirNativeTest] installed rows=" .. tostring(#rows) ..
    " renderer=stock_family compass=stock_family checkpoint=exact_or_unknown")
end
-- END COMPLETIONIST V0.10.5 NORNIR SAVED STATE TEST

-- BEGIN COMPLETIONIST V0.10.5 LOCATION STATE
do
local State = (function()
-- Tri-state collection store with save-epoch isolation.
-- States: unknown, remaining, collected.
-- Collection is terminal within one epoch; only a new epoch resets all state.
local State = {}
State.__index = State

function State.New(ids)
  if type(ids) ~= "table" or #ids == 0 then error("State.New requires a non-empty id list") end
  local whitelist, states = {}, {}
  local seen = {}
  for _, id in ipairs(ids) do
    if type(id) ~= "string" or id == "" then error("State.New: each id must be a non-empty string") end
    if seen[id] then error("State.New: duplicate id: " .. id) end
    seen[id] = true
    whitelist[#whitelist + 1] = id
    states[id] = "unknown"
  end
  return setmetatable({
    _whitelist = whitelist,
    _states = states,
    _epoch = 0,
    _revision = 0,
  }, State)
end

function State:BeginEpoch(epoch)
  if type(epoch) ~= "number" or epoch < 0 or epoch > 9007199254740991 or epoch ~= math.floor(epoch) then
    error("BeginEpoch: epoch must be a nonnegative integer")
  end
  if epoch <= self._epoch and self._epoch > 0 then
    error("BeginEpoch: epoch must advance (got " .. tostring(epoch) .. ", current " .. tostring(self._epoch) .. ")")
  end
  if epoch == 0 and self._epoch == 0 then return false end
  self._epoch = epoch
  local changed = false
  for _, id in ipairs(self._whitelist) do
    if self._states[id] ~= "unknown" then
      self._states[id] = "unknown"
      changed = true
    end
  end
  if changed or epoch > 0 then
    self._revision = self._revision + 1
  end
end

function State:Get(id)
  if self._states[id] == nil then return nil end
  return self._states[id]
end

function State:Revision()
  return self._revision
end

function State:Epoch()
  return self._epoch
end

function State:Counts()
  local counts = {unknown=0, remaining=0, collected=0}
  for _, state in pairs(self._states) do counts[state] = counts[state] + 1 end
  return counts
end

function State:Observe(id, state, epoch)
  -- Reject unknown IDs
  if self._states[id] == nil then return false end
  -- Reject invalid states
  if state ~= "remaining" and state ~= "collected" then return false end
  -- Reject stale epoch
  if epoch ~= self._epoch then return false end
  -- Collection is terminal within an epoch: ignore remaining after collected
  if self._states[id] == "collected" then
    return true  -- accepted but no change
  end
  local old = self._states[id]
  self._states[id] = state
  if old ~= state then
    self._revision = self._revision + 1
  end
  return true
end

function State:ApplySnapshot(statesById, epoch)
  -- Validate epoch
  if epoch ~= self._epoch then return false end
  -- Validate full snapshot before any mutation
  if type(statesById) ~= "table" then return false end
  for id, value in pairs(statesById) do
    if self._states[id] == nil then return false end
    if value ~= "unknown" and value ~= "remaining" and value ~= "collected" then return false end
  end
  -- Apply: respect collection terminal rule
  local changed = false
  for id, value in pairs(statesById) do
    if value ~= "unknown" and self._states[id] ~= "collected" and self._states[id] ~= value then
      self._states[id] = value
      changed = true
    end
  end
  if changed then
    self._revision = self._revision + 1
  end
  return true
end

return State

end)()
local Reader = (function()
-- Bounded, nonblocking current-save snapshot transport. No game state writes.
local Reader = {}
Reader.__index = Reader
local codes = {['0']='unknown', ['1']='remaining', ['2']='collected'}
local function integer(value)
  local n = tonumber(value)
  if not n or n < 0 or n > 9007199254740991 or n ~= math.floor(n) then return nil end
  return n
end
function Reader.New(ids, contract, expectedRestoreEpoch, transport)
  assert(type(ids) == 'table' and #ids > 0, 'empty contract')
  local seen, ordered = {}, {}
  for i,id in ipairs(ids) do
    assert(type(id) == 'string' and id ~= '', 'invalid contract id')
    assert(not seen[id], 'duplicate contract id')
    seen[id]=true; ordered[i]=id
  end
  ids=ordered
  local self = setmetatable({ids=ids, contract=contract, expectedRestoreEpoch=expectedRestoreEpoch,
    elapsed=0, nonce=0, generation=0, nextRead=0}, Reader)
  if not transport then
    local ok, socket = pcall(require, 'socket.core')
    if ok and type(socket) == 'table' and type(socket.tcp) == 'function' then
      -- GoW uses 32-bit Lua numbers. Absolute Unix timestamps lose short
      -- intervals, so use the UI timer's elapsed deltas for every deadline.
      transport = {now=function() return self.elapsed end, create=socket.tcp}
    end
  end
  self.transport=transport
  return self
end
function Reader:Advance(dt)
  if type(dt) ~= 'number' or dt < 0 or dt ~= dt or dt == math.huge then return false end
  self.elapsed=self.elapsed+dt
  return true
end
function Reader:Close()
  if self.client then pcall(function() self.client:close() end) end
  self.client=nil; self.buffer=''
end
function Reader:Reset(epoch)
  self:Close()
  self.epoch=epoch; self.generation=0; self.nextRead=0
  self.requestRestore=nil
end
function Reader:Parse(line)
  if type(line) ~= 'string' or #line > 4096 then return nil end
  local nonce, restore, contract, generation, states = line:match(
    '^COLLECTIBLE_SNAPSHOT_V1 nonce=(%d+) restoreEpoch=(%d+) contract=(%x+) generation=(%d+) states=([012]+)$')
  if not nonce or nonce ~= tostring(self.nonce) or contract ~= self.contract or
      #states ~= #self.ids then return nil end
  restore, generation = integer(restore), integer(generation)
  local expected = self.expectedRestoreEpoch()
  if restore == nil or generation == nil or type(expected) ~= 'number' or
      restore ~= expected or restore ~= self.requestRestore or
      generation <= self.generation then return nil end
  local result = {epoch=self.epoch, restoreEpoch=restore, generation=generation, states={}}
  for i, id in ipairs(self.ids) do result.states[id] = codes[states:sub(i,i)] end
  return result
end
function Reader:Poll(epoch)
  if epoch ~= self.epoch then self:Reset(epoch) end
  if not self.transport then return nil end
  local expected = self.expectedRestoreEpoch()
  if type(expected) ~= 'number' or integer(expected) == nil then self:Close(); return nil end
  local now = self.transport.now()
  if self.client then
    if expected ~= self.requestRestore or now >= self.deadline then
      self:Close(); self.nextRead=now+2; return nil
    end
    for _=1,512 do
      local ok, value, err = pcall(function() return self.client:receive(1) end)
      if ok and value == '\n' then
        local parsed = self:Parse(self.buffer)
        self:Close(); self.nextRead=now+2
        if parsed then self.generation=parsed.generation end
        return parsed
      elseif ok and value and #value == 1 then
        self.buffer=self.buffer..value
        if #self.buffer > 4096 then self:Close(); self.nextRead=now+2; break end
      elseif not ok or err ~= 'timeout' then self:Close(); self.nextRead=now+2; break
      else break end
    end
    return nil
  end
  if now < self.nextRead then return nil end
  self.nextRead=now+2
  local ok, client = pcall(self.transport.create)
  if not ok or not client then return nil end
  self.nonce=self.nonce+1
  local request='CAPTURE COLLECTIBLE_SNAPSHOT_V1 nonce='..tostring(self.nonce)..'\n'
  local connected=pcall(function()
    assert(client:settimeout(0.005)); assert(client:connect('127.0.0.1',43753))
    assert(client:send(request)==#request); assert(client:settimeout(0))
  end)
  if not connected then pcall(function() client:close() end); return nil end
  self.client=client; self.buffer=''; self.deadline=now+3; self.requestRestore=expected
  return nil
end
return Reader

end)()
local Runtime = (function()
-- One store survives map opens; the existing Raven/Nornir lifecycle owns epochs.
local Runtime = {}
Runtime.__index = Runtime
function Runtime.New(store, reader)
  return setmetatable({store=store, reader=reader, ready=false}, Runtime)
end
function Runtime:Changed(boundary)
  local counts=self.store:Counts()
  print('[CompletionistLocations] state epoch='..tostring(self.store:Epoch())..
    ' collected='..tostring(counts.collected)..' remaining='..tostring(counts.remaining)..
    ' unknown='..tostring(counts.unknown))
  local notify = _G.CompletionistMapV105LocationStateChanged
  if type(notify) == 'function' then notify(boundary == true) end
end
function Runtime:BeginEpoch(epoch)
  if epoch <= self.store:Epoch() then return false end
  self.ready=false; self.restoreEpoch=nil
  self.store:BeginEpoch(epoch); self.reader:Reset(epoch)
  self.nextLoadedRead=nil
  self.nextAuthorityRead=nil
  self:Changed(true)
  return true
end
function Runtime:AuthorityReady(restore)
  if type(restore) ~= 'number' or restore < 0 or restore > 9007199254740991 or
      restore ~= math.floor(restore) then return false end
  self.restoreEpoch=restore; self.ready=true
  return true
end
function Runtime:Observe(id, state, epoch)
  if not self.ready then return false end
  local before=self.store:Revision()
  local accepted=self.store:Observe(id,state,epoch)
  if self.store:Revision() ~= before then self:Changed() end
  return accepted
end
function Runtime:Tick(dt)
  self.reader:Advance(dt)
  return self:Poll()
end
function Runtime:Poll()
  if self.cleanup then self.cleanup() end
  local epoch=self.store and self.store:Epoch() or 0
  if self.directObserver then
    pcall(self.directObserver, self, epoch)
  end
  if self.loaded then
    local now=self.reader.transport and self.reader.transport.now() or nil
    if now == nil then self.frames=(self.frames or 0)+1; now=self.frames/60 end
    if self.nextLoadedRead == nil or now >= self.nextLoadedRead then
      self.nextLoadedRead=now+2
      self.loaded:Poll()
    end
  end
  if not self.ready then
    local refresh=_G.CompletionistMapV105RefreshLocationAuthority
    local now=self.reader.transport and self.reader.transport.now() or self.reader.elapsed
    if type(refresh) == 'function' and (self.nextAuthorityRead == nil or now >= self.nextAuthorityRead) then
      self.nextAuthorityRead=now+2
      pcall(refresh)
    end
  end
  if not self.ready then return false end
  local snapshot=self.reader:Poll(epoch)
  if not snapshot or snapshot.epoch ~= epoch or snapshot.restoreEpoch ~= self.restoreEpoch then return false end
  local before=self.store:Revision()
  if not self.store:ApplySnapshot(snapshot.states,epoch) then return false end
  if self.store:Revision() ~= before then self:Changed() end
  return true
end
return Runtime

end)()
local Loaded = (function()
-- Exact ancestry + adapter tag; an absent or ambiguous object is unknown.
local Loaded = {}
Loaded.__index = Loaded

local function plain(value)
  if type(value) ~= 'string' then return nil end
  value = value:lower()
  return value:sub(1, 2) == 'go' and value:sub(3) or value
end

local function nameMatches(obj, expected)
  if obj == nil or type(expected) ~= 'string' then return false end
  local ok, objName = pcall(obj.GetName, obj)
  if not ok or type(objName) ~= 'string' then return false end
  return plain(objName) == plain(expected) or objName:lower() == expected:lower()
end

local function pathMatches(object, names)
  if object == nil or type(names) ~= 'table' or #names == 0 then return false end
  local curr = object
  for _, name in ipairs(names) do
    if curr == nil then return false end
    if not nameMatches(curr, name) then return false end
    curr = curr.Parent
  end
  return true
end

local function unique(objects, names, parent)
  if type(objects) ~= 'table' then return nil end
  local found
  for _, object in pairs(objects) do
    if pathMatches(object, names) and (parent == nil or object.Parent == parent) then
      if found ~= nil then return nil end
      found = object
    end
  end
  return found
end

local function observeScript(obj, adapter)
  if obj == nil then return nil end
  local script = obj.LuaObjectScript
  if script == nil then return nil end
  if type(script.CompletionistCollectibleObserve) == 'function' then
    local ok, retAdapter, retState = pcall(script.CompletionistCollectibleObserve)
    if ok and retAdapter == adapter and (retState == 'remaining' or retState == 'collected') then
      return retState
    end
  end
  if adapter == 'chest' then
    if type(script.IsOpen) == 'function' then
      local ok, open = pcall(script.IsOpen)
      if ok and type(open) == 'boolean' then
        return open and 'collected' or 'remaining'
      end
    end
    if type(script.GetState) == 'function' then
      local ok, st = pcall(script.GetState)
      if ok and type(st) == 'number' then
        return st == 4 and 'collected' or 'remaining'
      end
    end
  elseif adapter == 'artefact' then
    if type(script.GetState) == 'function' then
      local ok, st = pcall(script.GetState)
      if ok and type(st) == 'number' then
        return st == 3 and 'collected' or 'remaining'
      end
    end
  elseif adapter == 'dig' then
    if type(script.GetState) == 'function' then
      local ok, st = pcall(script.GetState)
      if ok and type(st) == 'number' then
        if st == 3 then
          local q = script.questName
          if type(q) == 'string' and q ~= '' and type(game.QuestManager) == 'table' and type(game.QuestManager.GetQuestState) == 'function' then
            local ok2, qst = pcall(game.QuestManager.GetQuestState, q)
            if ok2 and qst == 'Complete' then return 'collected' end
            return 'remaining'
          end
          return 'collected'
        end
        return 'remaining'
      end
    end
  elseif adapter == 'shrine' then
    if type(script.IsTriptychCompleted) == 'function' then
      local ok, done = pcall(script.IsTriptychCompleted)
      if ok and type(done) == 'boolean' then
        return done and 'collected' or 'remaining'
      end
    end
  elseif adapter == 'rift' then
    if type(script.hasOpened) == 'boolean' then
      return script.hasOpened and 'collected' or 'remaining'
    end
    if type(script.GetState) == 'function' then
      local ok, st = pcall(script.GetState)
      if ok and type(st) == 'number' then
        return st == 4 and 'collected' or 'remaining'
      end
    end
  end
  return nil
end

local function isAncestorOf(ancestor, node, maxLevels)
  if ancestor == nil or node == nil then return false end
  local curr = node.Parent
  for _ = 1, (maxLevels or 8) do
    if curr == nil then return false end
    if curr == ancestor then return true end
    curr = curr.Parent
  end
  return false
end

local function read(row)
  local level = game.FindLevel(row.level)
  if level == nil then
    level = game.FindLevel('WAD_' .. row.level)
  end
  if level == nil then
    level = game.FindLevel('wad_' .. row.level)
  end
  if level == nil then return nil end

  local pQuery = plain(row.placement[1])
  local placementMatches = level:FindGameObjects(pQuery)
  if (placementMatches == nil or #placementMatches == 0) and type(level.FindGameObjects) == 'function' then
    placementMatches = level:FindGameObjects(row.placement[1])
  end
  if (placementMatches == nil or #placementMatches == 0) and type(level.FindSingleGameObject) == 'function' then
    local single = level:FindSingleGameObject(pQuery) or level:FindSingleGameObject(row.placement[1])
    if single then placementMatches = {single} end
  end

  local placement = unique(placementMatches, row.placement)
  if placement == nil and placementMatches ~= nil and #placementMatches == 1 and nameMatches(placementMatches[1], row.placement[1]) then
    placement = placementMatches[1]
  end
  if placement == nil or not nameMatches(placement, row.placement[1]) then return nil end

  local owner = placement
  if #row.owner > #row.placement then
    local oQuery = plain(row.owner[1])
    local oMatches = nil
    if type(placement.FindGOsByName) == 'function' then
      oMatches = placement:FindGOsByName(oQuery)
      if (oMatches == nil or #oMatches == 0) and oQuery ~= row.owner[1] then
        oMatches = placement:FindGOsByName(row.owner[1])
      end
    end
    local validMatches = {}
    for _, match in ipairs(oMatches or {}) do
      if nameMatches(match, row.owner[1]) then
        validMatches[#validMatches + 1] = match
      end
    end
    oMatches = validMatches
    owner = unique(oMatches, row.owner)
    if owner == nil and #oMatches == 1 then
      owner = oMatches[1]
    end
    if owner == nil then
      if (row.adapter == 'chest' or row.adapter == 'rift' or row.adapter == 'artefact') and #oMatches == 0 then
        owner = placement
      else
        return nil
      end
    end
    if owner ~= placement then
      local ancestor = owner
      -- The exact placement can have collapsed outer scene ancestors at runtime.
      -- Validate every inner owner node and anchor it to that placement object.
      for index = 1, #row.owner - #row.placement do
        if ancestor == nil or not nameMatches(ancestor, row.owner[index]) then return nil end
        ancestor = ancestor.Parent
      end
      if ancestor ~= placement then return nil end
    end
  end

  -- 1. Check owner directly
  local state = observeScript(owner, row.adapter)
  if state ~= nil then return state end
  if placement ~= nil and placement ~= owner then
    state = observeScript(placement, row.adapter)
    if state ~= nil then return state end
  end

  -- 2. If extra is specified, search inside owner
  if row.extra then
    local eQuery = plain(row.extra)
    local child = nil
    if type(owner.FindGOsByName) == 'function' then
      child = unique(owner:FindGOsByName(eQuery), {row.extra})
    end
    if child == nil and type(owner.FindSingleGOByName) == 'function' then
      child = owner:FindSingleGOByName(eQuery)
    end
    if child ~= nil and isAncestorOf(owner, child, 6) then
      local st = observeScript(child, row.adapter)
      if st ~= nil then return st end
      if child.Child ~= nil then
        st = observeScript(child.Child, row.adapter)
        if st ~= nil then return st end
      end
    end
  end

  -- 3. Descendants stepping via Child
  local curr = owner
  for _ = 1, 4 do
    if curr == nil then break end
    local st = observeScript(curr, row.adapter)
    if st ~= nil then return st end
    if curr.Child == nil or curr.Child.Parent ~= curr then break end
    curr = curr.Child
  end

  -- 4. Fast direct lookup for chest scripts under placement or owner
  if row.adapter == 'chest' then
    for _, container in ipairs({owner, placement}) do
      if container ~= nil and type(container.FindSingleGOByName) == 'function' then
        for _, q in ipairs({'gochestscript', 'chestscript', '*chestscript*'}) do
          local ok, node = pcall(container.FindSingleGOByName, container, q)
          if ok and node ~= nil then
            local st = observeScript(node, row.adapter)
            if st ~= nil then return st end
            if node.Child then
              st = observeScript(node.Child, row.adapter)
              if st ~= nil then return st end
            end
          end
        end
      end
    end
  end

  -- 5. Fast direct lookup for rift scripts under placement or owner
  if row.adapter == 'rift' then
    local containers = {owner, placement}
    if owner ~= nil and owner.Parent ~= nil then
      containers[#containers + 1] = owner.Parent
    end
    if placement ~= nil and placement.Parent ~= nil then
      containers[#containers + 1] = placement.Parent
    end
    for _, container in ipairs(containers) do
      if container ~= nil and type(container.FindSingleGOByName) == 'function' then
        for _, q in ipairs({'gopocketrift_interact_loot', 'pocketrift_interact_loot', '*interact_loot*', '*pocketrift*'}) do
          local ok, node = pcall(container.FindSingleGOByName, container, q)
          if ok and node ~= nil then
            local st = observeScript(node, row.adapter)
            if st ~= nil then return st end
            if node.Child then
              st = observeScript(node.Child, row.adapter)
              if st ~= nil then return st end
            end
          end
        end
      end
      if container ~= nil and type(container.FindGOsByName) == 'function' then
        for _, q in ipairs({'gopocketrift_interact_loot', 'pocketrift_interact_loot', '*interact_loot*'}) do
          local ok, nodes = pcall(container.FindGOsByName, container, q)
          if ok and type(nodes) == 'table' then
            for _, node in ipairs(nodes) do
              local st = observeScript(node, row.adapter)
              if st ~= nil then return st end
              if node.Child then
                st = observeScript(node.Child, row.adapter)
                if st ~= nil then return st end
              end
            end
          end
        end
      end
    end
  end

  -- 6. Fast direct lookup for artefact scripts under placement or owner
  if row.adapter == 'artefact' then
    local containers = {owner, placement}
    if owner ~= nil and owner.Parent ~= nil then
      containers[#containers + 1] = owner.Parent
    end
    if placement ~= nil and placement.Parent ~= nil then
      containers[#containers + 1] = placement.Parent
    end
    for _, container in ipairs(containers) do
      if container ~= nil and type(container.FindSingleGOByName) == 'function' then
        for _, q in ipairs({'goartifactscript', 'artifactscript', '*artifact*'}) do
          local ok, node = pcall(container.FindSingleGOByName, container, q)
          if ok and node ~= nil then
            local st = observeScript(node, row.adapter)
            if st ~= nil then return st end
            if node.Child then
              st = observeScript(node.Child, row.adapter)
              if st ~= nil then return st end
            end
          end
        end
      end
      if container ~= nil and type(container.FindGOsByName) == 'function' then
        for _, q in ipairs({'goartifactscript', 'artifactscript', '*artifact*'}) do
          local ok, nodes = pcall(container.FindGOsByName, container, q)
          if ok and type(nodes) == 'table' then
            for _, node in ipairs(nodes) do
              local st = observeScript(node, row.adapter)
              if st ~= nil then return st end
              if node.Child then
                st = observeScript(node.Child, row.adapter)
                if st ~= nil then return st end
              end
            end
          end
        end
      end
    end
  end

  return nil
end

function Loaded.New(rows, runtime)
  return setmetatable({rows = rows, runtime = runtime, nextRead = 0}, Loaded)
end

function Loaded:Poll(levelName)
  if type(game.FindLevel) ~= 'function' then return false end
  local epoch = self.runtime.store:Epoch()
  local accepted = {}
  for _, row in ipairs(self.rows) do
    if levelName == nil or row.level == levelName then
      local ok, state = pcall(read, row)
      if ok and state ~= nil then
        if accepted[row.id] then
          accepted[row.id] = 'unknown'
        else
          accepted[row.id] = state
        end
      end
    end
  end
  local before = self.runtime.store:Revision()
  if self.runtime.store:Epoch() == epoch then
    for id, state in pairs(accepted) do
      self.runtime.store:Observe(id, state, epoch)
    end
  end
  if self.runtime.store:Revision() ~= before then self.runtime:Changed() end
  return true
end

return Loaded

end)()
  local ids = {"artefact_01a8ba24409b5fb49a1c18b43669fe44","artefact_0a43e4954d4fff46abb9ca8e34d875c0","artefact_0d53040849957335c6db68809206f5d1","artefact_0da7cb9744da59cb80fe319d95cada55","artefact_28b7fe1349cdc49da573c6a0657f0a9d","artefact_33f59ee746f63f40199e5f90cad3c236","artefact_379728fc47e4a966be1fc9926011184b","artefact_468c195b480889e354742b876aef3a11","artefact_48edaa8b407e24bed474bebea8ea3821","artefact_4a3d314942f187f69ee5b78302e118fe","artefact_56c4354a4141de7afc7f2e8447ab8767","artefact_5bb11ed5419b42caba813598d29ca473","artefact_5bf15dbc48613f5b548fd2a673d8f7bc","artefact_6cffc9884efa77b424baf987adfdba6a","artefact_6e3739ea4ac8107c495a61af774a9b03","artefact_6f83c0ef48eda412050135a827d51a7a","artefact_6fa420df406be3d033b7eea35a4d10fe","artefact_707ae0e24dc7bc9a56c19eb7ce17b351","artefact_7d8a35dc4d6aabf8065e1ead0c470fcc","artefact_85c29c2b420306564c28b5b09e22532c","artefact_8916f55c4511b74ba8601ba7ef3d86bb","artefact_989065ff4bde64f5ec957da2759037cb","artefact_a0588a9442f0118bdce0cda751b8605d","artefact_ab662cc14c4a21327111dea1a34b96c3","artefact_b18794364cc6b6a5c08596ab8699f35b","artefact_b52df62545c16741e6f2278f9e2ccc32","artefact_bd9a46a34b8fd4660be2129e27fa4004","artefact_c7f91ac1447cff68599696bbbb58e7b7","artefact_c9b7e23040c21e2da5fe8ba4be8ad415","artefact_cf7627ad486711d9eab3339782e5a147","artefact_eb672a1647b1f7e64595e48f821670f5","artefact_f5bd8953457f9662d074d798a111abfc","artefact_f7fbfc3f44991b3da37871879e6de737","artefact_fa511e0a422421b7acc01fa5829c4fe3","artefact_fae85e594ef79ee2e204719767dd5287","artefact_fda837834b361579d4a29194810c3d09","artefact_hel300mainbridgewad00c124ebae0bc24f8b64cc6305246b22","artefact_hel300mainbridgewadb5b33ffb0d723f44a135047d5a839e32","artefact_hel300mainbridgewade4b6326ae64d514490a45593d471478f","artefact_xpl200funeralwad2768cb29f445634bb075f7a858cabcc3","artefact_xpl200funeralwad52e9ebf8ef1b3343b5d025a73ad6fa91","artefact_xpl200funeralwadb6e2b2a41a1b3e4c9ff1f8e5f877039a","artefact_xpl200funeralwadbb9465a7407c9849bf891e0205dac801","artefact_xpl250funeralinteriorwad3f176e49e0a0cd4f8cf59ada5fe9c2d8","artefact_xpl250funeralinteriorwad4813767722fa414b9a3d4972dc8874e7","cipher_chest_285a8836646562d9520d7c890d4ef3b4","cipher_chest_33234eeb6c2a418623f760e0dd11d24d","cipher_chest_368ccc0e6d6636bc0c74043536071ef1","cipher_chest_371db5ac6ac1a1ca6bfe75a33315fe6d","cipher_chest_4935b4ad6d592f85492c85bd0829dcb8","cipher_chest_5b8711edc0ecbc1775d18513dfd02be8","cipher_chest_64d0d4b3bf836bbdca27451d720152f8","cipher_chest_83a70788cdf281a83161cd7e70101b11","cipher_chest_87d50dbd4e3737165c04ae74fe8ffbb7","cipher_chest_a120a8e8b11b778cebccfbe5aab211e9","cipher_chest_a4637747ab0a20fa55d7253b2625da13","cipher_chest_acb38981cfa8d4a13490597c1bcc6dd8","cipher_chest_bed904beed4cc9151ff7944a557ef0bb","cipher_chest_f2220e936a3394ddfe1443657707b770","coffin_00d1d9586170eb2458c9304285d70c2b","coffin_02468d124aa5c0271a90ef15db3a4a9e","coffin_07014abc15905dbf2b905d543b85abfe","coffin_07ad6c3ad556b93e9108d10af5a58d8a","coffin_082e60a8f756390671c4ffa499ce98a2","coffin_0efeb8c8cb24d3981a15a70321c096fe","coffin_0f897d994245a437eea02861452c1e22","coffin_104119f1ce4acbac9a77408da2d7777f","coffin_1ec665d11dec0d4959f2fa6fe571a6cf","coffin_265ee0bf74ea46d94e2271778008959e","coffin_27372e7163253c3104b397c707ea53bb","coffin_2b66a5509901bb0ae8186134879d62fb","coffin_2b80e842d459585947380fe4c7415e0f","coffin_32d35ecd545e598e3e3343964f5db9dd","coffin_3340c954018839640be00a0955892015","coffin_345de6844e1e09c6d4d6a6b4133a793c","coffin_3756070dc04ddc15c61d57cb6c42e5ad","coffin_3dceee4444defddd165bf4929207c58f","coffin_42f17c39434a78c652e5235614526d0a","coffin_44c42ab490af3bedc34e812cb537d913","coffin_45c3d28bfce2949e7091ea076388005c","coffin_4721aafec0abacd3c4adb354cdf6c224","coffin_483ef71604ed462813b9d2190ffc90cf","coffin_49c66a6e387cfdaaa98e4b2afdf7b1d3","coffin_4c894a4cd00f5770ebcf2c0c5de8e2b1","coffin_4cb03c66896412451b9a805908c61395","coffin_514bb8121cc05fa714e491ef162eed3f","coffin_5240a7be264002acbff660741e1607ef","coffin_524f412c218f69b5d6fd2b4ace6be1fb","coffin_530e877c15dc4e8af94d97edcb0d27e9","coffin_5540f9ba7ecad39bfe9f2b5817e16adf","coffin_56534d8b5b802d5d59344beffd1fe9e6","coffin_573b543d74f93b4bd85cffdce6da424d","coffin_575a07cc7dca64c540088be3f4139842","coffin_5abb61ed22d5ef4e63d0fb21411fc797","coffin_5bf1f9791a9a6a851a98e8e377869fbd","coffin_5ee94e6e2d8b3f4f14621809c749f528","coffin_5f33d793b402e41dfae34b6b00b0fcf1","coffin_66d5de24a634f6acd7490fe2f02bc871","coffin_68e0db213e0e075b272fe88aa8d49f54","coffin_6b028789691d219730cefc4630c393f0","coffin_6dd3b15c19d26faac0ddfecf339a50ab","coffin_6fc14ea5854a3ac8af7a57a05be00c91","coffin_711c078a74590cb2158c1d1ea7e73389","coffin_715ae2ff1980d3bfee797f2dd1481ec8","coffin_7261934c1430c94f92e2ba079fed8c3c","coffin_73a23f0e4255942c300031a188e8a525","coffin_742ff8d25ea20efe745ec677e3c21d45","coffin_744b86cb488721d7190188084d7dc635","coffin_78d857a21516770d19e10a59f5a76335","coffin_793530dd17ca89215ba5d26f7357b8aa","coffin_7a8d01b3f8a471a6b7ae8d058f00f12b","coffin_81be3d2815990e8e6e34f3cc239fd25f","coffin_85531ced605effb9af1dad9009031dfd","coffin_89b943bbda8f5c15788d8c5fe3dd5d42","coffin_8c8f0d2bb8dc26dc1867c39ec44b8c11","coffin_8eed9a4a0e0b5390ea90c84406f8f8ce","coffin_8f470545b16b1e425d2fd5f47525bff1","coffin_906db69b1c98e210bfd711cea88cd266","coffin_912c5430d4eba71f2aa2b42a05c68d40","coffin_92217ff2537c4eca00ca2387cb7a1a42","coffin_96381eab3f2918f7ebb47343422a8203","coffin_9b316d325ff8c810a3d018399ab0a1fe","coffin_a1c849de7c794dae09f118bbf46d8dcb","coffin_a2ec2e348926ce92a6dbfa84d1bb3729","coffin_a53778e43c763a0bfa7b902a04cf9eb2","coffin_aaaf95f673179f035c1e67f568f08107","coffin_abc058fb6e88938d0a43c94f13a7bffd","coffin_b24c6a682bdd5571637905ce2e305c2f","coffin_b6a51db40b1e73b0e8c6b24f08b9df77","coffin_b9137381c8685a442887b317281334c3","coffin_bc47cbf3655df68aa52d3948f29070ef","coffin_c289f1218e664d7edf073b93a0cc55f8","coffin_c439b69d88a1f2195464c303b8d65e30","coffin_cacfc0416ffa2a6daaa23c90fca91ff5","coffin_ccc3e6b52c7ac6ccd3a6ac24aced6cfc","coffin_cd8cfd54dfd050d5d4b60bd7ff08eb21","coffin_ce102339a34a1ee210fb708cef487737","coffin_cecd3e1ed37118dbc783f38c40ee4803","coffin_d1bfdaff128036c426e567b41358c072","coffin_d2080e7d0c12a0ccc335b9b6364a3214","coffin_d45ead0e44bc195bc94e7ec18de2edb3","coffin_d468c7d58a26674aa3b5b16dc0e79eaf","coffin_d5a198ed2f341b80b8b04b9a430c5c1c","coffin_d6137b034219becb66bc80d10fd6511f","coffin_dafb5c49c183bb638b57c1be03863ecf","coffin_dbc446d3cdc8af11b26294ada4bf2c9c","coffin_dccf636343f08c57b98bf198059a985f","coffin_def02bc17b1bb0246e28fded510dccf2","coffin_dfca3d7720861fb51244d4e8278d5ab5","coffin_e056e03bfc0b68e1f7569b3a03f72722","coffin_e07e5ac1b623623c121b01c2481f504f","coffin_e0e1c7e7bc737efbfacef065908c43d0","coffin_e2d0ecbabcb5a115e49005576bc680e0","coffin_e7c6bb7592f8d71352a303792bc5a6a6","coffin_e8c9695dda4a836583ad311f9b98d043","coffin_ea9eca6feb88066fe4fc1111549e67df","coffin_ebcc7fde6edd3347424493e2700fae89","coffin_edcb1025a189bc2022b512d6bebaf11a","coffin_f0c400642e139948e733d79ec3119f47","coffin_f1b0d53b18c6d9100c9573cf006d0b63","coffin_f1f9d33e14c532dcec5e55b7e735ca19","coffin_f1fb65044d01667d716a002b1c3391d5","coffin_f2e02def29ac042044af2ff35637b2a9","coffin_f79832e35e68cfc2d8a11e290165fa89","coffin_f7c85deadc9605c7a4dde328c9d916b1","coffin_f9f584304bafcd2f50ab0db9d2694940","coffin_fbad02805a974b9087885a0c497e34ca","coffin_fe52241f85fb3089b8210f793b4a34ee","jotnar_shrine_19c69abd2cdf4145b71903eabdaf87f8","jotnar_shrine_1af4f035065fe9603505c02d9b2e1462","jotnar_shrine_23d6030ef079b748c4574a940bf2047b","jotnar_shrine_4f54c8b2f4d927800573fde8aece376f","jotnar_shrine_5abb17c179c16ed72287fc2740a46f9a","jotnar_shrine_682f1626cae370f11b4df300ae79219d","jotnar_shrine_6e55a7d7704af68ce4b82e5edecf81a7","jotnar_shrine_7dadb7c3e8c5fdc6259b311fe6ac74ba","jotnar_shrine_8a16de1ec11694c5752092bd06e16978","jotnar_shrine_b124fa2d62938dc8fcf85d67432d8550","jotnar_shrine_b35ee9b618a76bfdf24596944d7b11b0","jotnar_shrine_c0d7a4d17e152054e3e3c3e2571d98b8","jotnar_shrine_e49959e54f3f1da0632c3ac2a01d7ec7","legendary_chest_040af4fa440ef7ba52f8e8b317ac3200","legendary_chest_0a04b4de469f3b030064d6827966b213","legendary_chest_0e27df5f4bc5f2545a43178d0115312b","legendary_chest_11e085df4bd47deee3a3448bff9efc62","legendary_chest_23d3213f45e38b632ed8048e876e472d","legendary_chest_36cb588e41cb27a4668052b4529b98a6","legendary_chest_3c05899e46a619015d4cfb995fb61be0","legendary_chest_48f9e1694dc722a549f42893d5b79d9f","legendary_chest_50480b3a40fe25c4770f81a7261cbcb8","legendary_chest_510bd86441ac6a7b71d4f59321c2a08f","legendary_chest_529343984fc313504ac20da874d05c01","legendary_chest_5618d560426940a02e5b39a340c0c209","legendary_chest_5b424870484e691ce32d19be71a03059","legendary_chest_7a71d104452e16e39a25bb8a14e47343","legendary_chest_8002f429448617523d189cbd93b23d4b","legendary_chest_8266c175474b43a4d44938a75e21329d","legendary_chest_890a24d24d2864a1567af691c615870f","legendary_chest_8aabd22a44df8f25a955fe8e04fc0d95","legendary_chest_91a9f92a45d2d3fdb92279b4612ab5d7","legendary_chest_9226bd444f0f0b95dbeb7c927c6b317b","legendary_chest_957a57b3456bd17fd24751a66dbcf01c","legendary_chest_9c0dc602456a00fa44bca1a3b599cf67","legendary_chest_9d7648ab43bf99f90b0cbd86b0a998f1","legendary_chest_9f29650a4a8a5d0eb8bc43af1dbd3d68","legendary_chest_a24ac28d4ea8598d880d7bb099b8b8be","legendary_chest_ace99ef5472abcbac29bd2b396a3fdf3","legendary_chest_ae9454d54e9c9a23f21941b41a4038d3","legendary_chest_b97f559c471fab8850a2ae8741370020","legendary_chest_b9e3be9a46c248cc0ddc159643259c52","legendary_chest_c14a0f2b4559d859347854bccb307f63","legendary_chest_d0b93e274754785e08235285bd6b78f2","legendary_chest_d63295f244f330219b003c913c0dab69","legendary_chest_d6d6acfe444f2ad10b49cea2ba85a1eb","legendary_chest_d6fb0fd64364453cc3e334a2454e0b75","legendary_chest_ede160a54530f55a7667f5a39257843c","legendary_chest_f714d2d845a3dd9e28808db4655e757f","legendary_chest_ff46dfab43efcfc6f0f382a33e2b571d","lore_marker_3d2e2f04d7df6a4b9a4e30601432871f","lore_marker_ab859d0b83766845bb0b0e69023e1c31","lore_marker_alf150bridgedarkwad76250fcb340065498ff1b75bddd20fcf","lore_marker_alf150bridgedarkwad969e45f02f76844192ec5566056fbfd4","lore_marker_alf440hiveextlhwad0f75539e19bc0947ba4d6f46ea0a95d2","lore_marker_alf690lakelightlhwade723fb1f62e1ef4a94d19a5eeeef0673","lore_marker_cal250foothillslhwad8ab6b877e9062c4b9f0d0f375f8326c1","lore_marker_cal250foothillslhwad9614e6b2dfd34f4b86e932b59f2aa621","lore_marker_cal250foothillslhwadb456381ff98fb449896acb659da524fa","lore_marker_cal500runevaultwad14f472bb0d9d2e4993d0774cbc755e02","lore_marker_d988f2795775914592a04b62df2726d9","lore_marker_nid150calderabridgewad2eabc6ebc9dafd40b34cb41a6ffcd2d4","lore_marker_peak100entrancewadeda4d87459eae64ba0a1c556edca5809","lore_marker_peak140caverndarkwad3aae61a66981c34082d9e3dcb14c9a39","lore_marker_peak180enttochimneylhwadcc54f8d5e69b0945a3674ddc65276412","lore_marker_peak200chimneylowwad29a3fec3318213458a458abb0eb539a2","lore_marker_peak500chimneytopwad1d9b928f5f7eab4082f9c52e2f066780","lore_marker_peak720summitascenthubwadda8178f1357e8d45922a657e6f760dd8","lore_marker_riv085dangersentrancelhwad0359c55688ca5b48bd66cf4ae66fbed3","lore_marker_riv200dangersmainwad452dc462aab2814097a8c9a7d317c558","lore_marker_riv420forestboarstartwad0c671129ecb3144cbcf4a641a4160b66","lore_marker_riv475freyahouseextwad5124f330461a8e42b1659c4517e18c29","lore_marker_riv475freyahouseextwad9a50243a697a924481d49d5c44c980ac","lore_marker_riv475freyahouseextwadd328468a73cead438031e76201fbddc9","lore_marker_stn200lakeextwad64309dc36de48d438409f5abb85cfc92","lore_marker_xpl125httklhwad36f99a6c8537174bbaab95fb9d956455","lore_marker_xpl170httkcaverwad776651e16e0bcd4995eaa2ad3e73f56a","lore_marker_xpl200funeralwad0ab993b107a42f41af27749c6749728d","lore_marker_xpl200funeralwadf8ceaf9fdf59ef4c97b6d4398c23bb9d","lore_marker_xpl220funerallhwadeea6c57321539249a4d58ca8baa527cb","lore_marker_xpl225funerallhwadb18d193b7ba34340a8831d0e11ff1b4e","lore_marker_xpl225funerallhwadfb3c8f6c096b464dafa89220022f8c54","lore_marker_xpl250funeralinteriorwadd1ddaedac0dbac478444718ac2f19211","lore_marker_xpl300strongholdwad79d7700bc6e8cf47a77b5403426b5297","lore_marker_xpl300strongholdwade361f1b4a04c074b84896263475139ab","lore_marker_xpl400huldramineswade1701a5ddf529645b442371f82145220","lore_marker_xpl400huldramineswadf014bd94366e7b49ade008aff1769396","lore_marker_xpl425huldramineslhwad7f236d968be3c14db2ecde8780a968a0","lore_marker_xpl650masontrailcavewadb2f0bf0705313e4aa27b33fddd3a0665","lore_marker_xpl910islandshipwreckwad6093995aaaf7ad4b9830d1be0e7e0684","lore_marker_xpl940beachcavewad6093995aaaf7ad4b9830d1be0e7e0684","lore_marker_xpl950beachmazewad6093995aaaf7ad4b9830d1be0e7e0684","lore_marker_xpl960beachshipwad6093995aaaf7ad4b9830d1be0e7e0684","lore_scroll_0a8de84c5e82fd19ccc618bce5ef6f84","lore_scroll_2242aadeda389dae8c5283057c5326ca","lore_scroll_62cc5c222fbe7d849e83705cfe13638c","lore_scroll_dc56801cbe1e7d3cbd54f9150cc78a3c","lore_scroll_e8415d73adfe99aa45c8e142856455da","realm_tear_10374be1dacc7b5afc9b38ff1c50b3f5","realm_tear_12672293750dfc6b1381cf5159ad0615","realm_tear_1c939364d61323b0c9db30a25da5b0f0","realm_tear_2b6da4fe76312741d21ade4905d66ff4","realm_tear_64256db4dca56cbedc9c2ad1bb454bef","realm_tear_64b7ac07cbf1db2d7956e3298e23970f","realm_tear_664c0fd312a6e88d8739f7d5af968fe3","realm_tear_6f5037ce091595b1bc2b0ab31cfaf05b","realm_tear_71588ab9681c6184279e7384fdafbbdd","realm_tear_75c3365cbb3042f761a82660c314147e","realm_tear_80a81219135f07ea1c0eb1948748fc58","realm_tear_885f79d8699b58e655739f1b924bf442","realm_tear_a3857496e778be84cdb14938feb3885d","realm_tear_ad3009f9f80b31ab80419fd380e60c1c","realm_tear_ae12a2c33fd8e441bf159a5fd7ac3c22","realm_tear_af0e22716b928bcf52889387ffc91c4f","realm_tear_b24fe2ba5298d202f41bda97b2a00845","realm_tear_c3d17070f981647e7189e2076fbcc55c","realm_tear_cb9a35e72a6bd571c820349c901762a9","realm_tear_d9d5fe53b4d7bd0c88376c7647f5537e","realm_tear_f4600a74cbfaceabd4ba6d80a59a66bc","treasure_dig_1004498996e12e1bd865e937caf21f2d","treasure_dig_33fd783f7b353537d922042c2a967396","treasure_dig_4a770cc6263ef7c83b7ea0e4130c6c59","treasure_dig_4ec60e59f32086918769282570d5b976","treasure_dig_5f6d01b68cdf70a9815dc6fa7c3a839f","treasure_dig_70214d5859cc48c2bfddd06fb252a8ba","treasure_dig_8c965bccff326f509c02f9321af9a223","treasure_dig_8d79870871fe184c47d369eabbd68f92","treasure_dig_9680b8bc8eff19d4c84b439b0e5a841b","treasure_dig_a46f12e366ccfd55f7a945383f1231d0","treasure_dig_c49a3435a3361bfb0f23ee7a0cecc202","treasure_dig_ebcc555c3dc8b13561d8afa2bd4c0ba0","treasure_map_3cab9691f053fec1dc02301cf9c04021","treasure_map_4011675d69434ff50662d79d43b08305","treasure_map_4a07636dc59583c9bfe877849ab5a97f","treasure_map_5d8b3d55a299888357a6893fcec99c05","treasure_map_67ec3f2c214e4fd07a7eaf0b58cf213c","treasure_map_82e41ccaf3093e62880d64a18227112c","treasure_map_8b1707f94ad818100dd4a5afc67fc6c6","treasure_map_adf20b36ad0f86b68901b8e49aeeb498","treasure_map_aef0891f1c3ee6d1f88f86b1601052f4","treasure_map_b08d1fd606f2ac8a09bf8edc6d5a55b7","treasure_map_ce589a091d984c3581097a8700aad61d","treasure_map_f48eb59997ca3572363316461a106067","wooden_chest_02cb4383595ac1f75f02d048497910be","wooden_chest_05777956466a17869155000961f9c0e4","wooden_chest_0bb016e6a10fa429fd92e7431244acf3","wooden_chest_0e0ac7e313b7a70479ce4799c063e1b6","wooden_chest_0e36e52e4173d490a9b3f8868c7782a0","wooden_chest_1346fea0dd6e8e5cb6868dbd2aa9109c","wooden_chest_1adba8510701fc2e921940af402eb450","wooden_chest_21ce00568c4f2f02e51a4fe20ea80030","wooden_chest_255bd08484850591a8c5077c4efd6b64","wooden_chest_268d53a0272891ccecb31702393e1819","wooden_chest_27794e7010aee1564fa9c0d13927ce5b","wooden_chest_2b8135ab4e8526519563c8c391f156f9","wooden_chest_2d23433148d8f06d05b59b34549fd974","wooden_chest_2d4638fc479567132f4d797b9b327c48","wooden_chest_32d12c1505dcc72956b8b8cb27f928d1","wooden_chest_32d3304f8c18fe1f9d5564e870022cb2","wooden_chest_33d0f7eadfc4eef14aadaa1e9b6c6143","wooden_chest_34c065eb3609a2c1366263e3f493dfa3","wooden_chest_3c854063b4cea27669211d35562b7a9e","wooden_chest_3ca0e634863fd2de8454b4713f9426c5","wooden_chest_3fe0ed11f8da36cf4d6a8534da039235","wooden_chest_4120fd9bd6ee2470fe64e0c46ea7c515","wooden_chest_43a2c9ef875eebd6fff86ba2324a982f","wooden_chest_45cff077ae20b76b69ca0926566ce5c6","wooden_chest_471003f756043c7046d03da4a1c65372","wooden_chest_47d4448bcb8d2e3a3fde0f69672e1f1e","wooden_chest_47feaa163975e37d55a81abb7bffba4e","wooden_chest_5156a959c5b5a08a49303486b7d998cd","wooden_chest_53fd52ac3bb61b72dd6c99bf58b56968","wooden_chest_586cacd7a21c53dd2be423e91e59a256","wooden_chest_5a8b57e2e6ed25b4d95144d451fbfb5d","wooden_chest_5db52378a823a4c80828e0c927521dd3","wooden_chest_6415bc87e3cee7dc64ff87227be631dc","wooden_chest_66a6a9d412a0ec0fadc2deca89c8dbf2","wooden_chest_6930ffe1cf86b6c7c705abebba9774c6","wooden_chest_693971af27e4bc2ec41d2f726a42bcbb","wooden_chest_6b0d3d9e239100c717236687da581bef","wooden_chest_75ca91755fa5f614d3fadf9a08438fb2","wooden_chest_765e2894cba2c865774bff371c57a91d","wooden_chest_779f83a51f7aa40a5c86866d652cb766","wooden_chest_78a1535551a9f6fc3d428be55e683d98","wooden_chest_794573030ab6d881e84137e829ac9ae8","wooden_chest_7bec312d23c04016fae74ca647bb7bc0","wooden_chest_7ca006b2b340188300a7e79f6f83391a","wooden_chest_7cf0e761c72a66b9b4b45b7e640519a7","wooden_chest_7d184e88e7aca574911c6f1addd2a686","wooden_chest_7f6a0836ac388c5b79f08b6048cb998d","wooden_chest_844dbdd31fe6dc2fb08087399b65f67b","wooden_chest_87235278fe5f92c19968896762202b95","wooden_chest_8836735f3c50fd90d214306b51ebeb79","wooden_chest_8d860a080b9f385f3a3105e035d73ab3","wooden_chest_8f8823453060e8adbfbf26f01baa3427","wooden_chest_8fd4ea6fbc9f86102aa363311d694995","wooden_chest_9796b08ff6484677f92dc5c548be592e","wooden_chest_9cf64f1857fba5b156c819bb82eff1f8","wooden_chest_a1d6fa6a5055273efa2aea64e3208312","wooden_chest_a23662374dca6281eb791529945c7210","wooden_chest_a351d959d938ab662188c62ebb286acc","wooden_chest_a64da46f0ee1e4a1c4f1b4144c88b3eb","wooden_chest_a7543637312c028edf79cc16a060097e","wooden_chest_a8c5ea120a8cc56f28fccd66df0e2f37","wooden_chest_ac18175339972ea504597b184294626a","wooden_chest_acf22956026eaf9efd34a12ef5ca22e2","wooden_chest_affb01a0b9017affae4a4d18ca3e61b7","wooden_chest_b14a7e0ad20f015dd563b19abc1a54ca","wooden_chest_b4def36d6cf6253887e2d62acb8e931f","wooden_chest_b6c25a3f683631668b90e34378276b82","wooden_chest_bc78435c8826037845b826e1cca23653","wooden_chest_bcbcd78c5be5d2298f527c26f48c5563","wooden_chest_bd68b87e6f2fa142ead9dbf282303da4","wooden_chest_c0f40c082a0434d8ba5ee63ee743fb69","wooden_chest_c29bba3fbdf1a9d6e75049d29457decf","wooden_chest_c3065d265dcac89c3b807a1121f459ea","wooden_chest_c34cd12e6f6d9025df3fdc4fbe29433c","wooden_chest_c75b16bed331d5ab90b8d6e7a6a742ac","wooden_chest_c7b27bc28ec7f67ef792e16997dbb5b4","wooden_chest_c99b83ff35c4c302a595c64fc926d86e","wooden_chest_c9b78a83ed706e2f87e723017c735303","wooden_chest_cb10ac445973e539532db961c1af4e8a","wooden_chest_cbb47d1bd72b169725ff3d03a4af9282","wooden_chest_cdd6d123984e32a1c6857daaf4212181","wooden_chest_d122572886b8c92453a055b03706a6ce","wooden_chest_d753ce063ba2187aaf6ce654558de5c6","wooden_chest_d7eadb5de53b3584728f114bdd9a26d2","wooden_chest_d9336ed2d59cb4a9961eedd85044b193","wooden_chest_d9b5e3ceb301b036b7cb78f409810ff3","wooden_chest_dac0fe6519eac4b9df6b377f533a73ac","wooden_chest_dbe63347daadc35034b614654d2e35a1","wooden_chest_dfa557277d10a7a70b656a4620c56fda","wooden_chest_e04dfd6c26cc8d4dd0bbce8bccd246ff","wooden_chest_e22d823077569012bc63ecaf45563e77","wooden_chest_ea3cae8ef3136ef470f6d4b3fed9c6b2","wooden_chest_ef35baf6c74c4cd48702005838cd186e","wooden_chest_f366e563226a159bf67b76e565795e3d","wooden_chest_f588ff33e1919a60d2adb07232f79621","wooden_chest_f666f4ec08b715cf7e0862fa5d4d2a37","wooden_chest_f743cadced96375893da7bd242fd68c0","wooden_chest_f8e1e11f0be082351c02df2da90c1f5b","wooden_chest_fa54db89fddd352b2984a348dd33ada1"}
  local store = State.New(ids)
  local epoch = _G.CompletionistMapV105Nornir.service.epoch
  store:BeginEpoch(epoch)
  local runtime
  local reader = Reader.New(ids, "962f42eaf8730a3c56e14b4af6154eb0c091bd3fca6e09ab07642f230a7004c5", function()
    return runtime and runtime.ready and runtime.restoreEpoch or nil
  end)
  runtime = Runtime.New(store, reader)
  runtime.loaded = Loaded.New({{id="artefact_xpl200funeralwad52e9ebf8ef1b3343b5d025a73ad6fa91",adapter="artefact",level="xpl200_funeral",placement={"goartifacthorn02","goxpl200_ents_nooffset","goxpl200_ents"},owner={"goartifactscript","goartifacthorn02","goxpl200_ents_nooffset","goxpl200_ents"},extra=nil},{id="treasure_map_b08d1fd606f2ac8a09bf8edc6d5a55b7",adapter="pickup",level="xpl850_dungeonforest",placement={"gotreasuremapinteract_blackbreath","goxpl850_ents_nooffset","goxpl850_ents"},owner={"gotreasuremapinteract_blackbreath","goxpl850_ents_nooffset","goxpl850_ents"},extra=nil},{id="legendary_chest_c14a0f2b4559d859347854bccb307f63",adapter="chest",level="alf340_trenchbdark",placement={"gochest_legendary_tier1_alf340_1","goloot","goalf340_ents_nooffset","goalf340_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier1_alf340_1","goloot","goalf340_ents_nooffset","goalf340_ents"},extra=nil},{id="lore_scroll_e8415d73adfe99aa45c8e142856455da",adapter="pickup",level="xpl910_islandshipwreck",placement={"gotreasuremapinteract","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gotreasuremapinteract","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},extra=nil},{id="lore_marker_peak180enttochimneylhwadcc54f8d5e69b0945a3674ddc65276412",adapter="lore",level="peak180_enttochimneylh",placement={"gopeak180_ents"},owner={"goinktotem","gopeak180_ents"},extra=nil},{id="legendary_chest_50480b3a40fe25c4770f81a7261cbcb8",adapter="chest",level="xpl980_beachwaterfall",placement={"gochest_legendary_tier1_xpl980_1","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier1_xpl980_1","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},extra=nil},{id="jotnar_shrine_4f54c8b2f4d927800573fde8aece376f",adapter="shrine",level="xpl250_funeralinterior",placement={"gotriptych_skadi","goxpl250_nar_nooffset","goxpl250_nar"},owner={"gotriptych_skadi","goxpl250_nar_nooffset","goxpl250_nar"},extra=nil},{id="legendary_chest_36cb588e41cb27a4668052b4529b98a6",adapter="chest",level="riv925_freyacave",placement={"gochest_legendary_tier1_riv925_3","goriv925_cbt"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier1_riv925_3","goriv925_cbt"},extra=nil},{id="wooden_chest_a64da46f0ee1e4a1c4f1b4144c88b3eb",adapter="chest",level="peak740_summitpeak",placement={"gochest_common_tier3_peak740_2","gopeak740_ents"},owner={"gochest_common_parent","gochest_common_tier3_peak740_2","gopeak740_ents"},extra="gochestscript"},{id="lore_marker_peak100entrancewadeda4d87459eae64ba0a1c556edca5809",adapter="lore",level="peak100_entrance",placement={"gopeak100_ents"},owner={"gosonreadrune","gopeak100_ents"},extra=nil},{id="coffin_514bb8121cc05fa714e491ef162eed3f",adapter="chest",level="xpl100_httk",placement={"gocfn_q1_ambush","goxpl100_cbt_nooffset","goxpl100_cbt"},owner={"gocoffin_parent","gocfn_q1_ambush","goxpl100_cbt_nooffset","goxpl100_cbt"},extra="gochestscript"},{id="legendary_chest_ae9454d54e9c9a23f21941b41a4038d3",adapter="chest",level="riv925_freyacave",placement={"gochest_legendary_tier1_riv925_2","goriv925_cbt"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier1_riv925_2","goriv925_cbt"},extra=nil},{id="legendary_chest_ace99ef5472abcbac29bd2b396a3fdf3",adapter="chest",level="xpl980_beachwaterfall",placement={"gochest_legendary_tier3_xpl980_2","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},owner={"gochestscript","gochest_legendary_parent","gochestobj","gochest_legendary_locked_roots_parent","gochest_legendary_tier3_xpl980_2","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},extra=nil},{id="legendary_chest_8266c175474b43a4d44938a75e21329d",adapter="chest",level="helr100_docks",placement={"gochest_legendary_tier4_helr100_1","gohelr100_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_helr100_1","gohelr100_ents"},extra=nil},{id="coffin_e0e1c7e7bc737efbfacef065908c43d0",adapter="chest",level="stn800_shortcut",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_stn800_1","gostn800_ents_nooffset","gostn800_ents"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_stn800_1","gostn800_ents_nooffset","gostn800_ents"},extra="gochestscript"},{id="wooden_chest_8f8823453060e8adbfbf26f01baa3427",adapter="chest",level="alf600_templeint",placement={"gochest_common_tier1_alf600_1","golootcoffin_tendrilcovered","goalf600_ents_nooffset","goalf600_ents"},owner={"gochest_common_parent","gochest_common_tier1_alf600_1","golootcoffin_tendrilcovered","goalf600_ents_nooffset","goalf600_ents"},extra="gochestscript"},{id="legendary_chest_5b424870484e691ce32d19be71a03059",adapter="chest",level="cal100_hub",placement={"gochest_legendary_tier4_cal100_1","gocal100_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_cal100_1","gocal100_ents"},extra=nil},{id="jotnar_shrine_682f1626cae370f11b4df300ae79219d",adapter="shrine",level="msp100_base",placement={"gotriptych_surtr","gomsp100_ents"},owner={"gotriptych_surtr","gomsp100_ents"},extra=nil},{id="coffin_5240a7be264002acbff660741e1607ef",adapter="chest",level="xpl400_huldramines",placement={"gocoffin_tier3_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},extra="gochestscript"},{id="cipher_chest_64d0d4b3bf836bbdca27451d720152f8",adapter="chest",level="xpl970_beachtower",placement={"gochest_dispell_tier1_cal200_1","goxpl970_ents_nooffset","goxpl970_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier1_cal200_1","goxpl970_ents_nooffset","goxpl970_ents"},extra="gochestscript"},{id="coffin_524f412c218f69b5d6fd2b4ace6be1fb",adapter="chest",level="peak210_rollerroomlh",placement={"gocoffin_tier3_peak210_1","gopeak210_ents_nooffset","gopeak210_ents"},owner={"gocoffin_parent","gocoffin_tier3_peak210_1","gopeak210_ents_nooffset","gopeak210_ents"},extra="gochestscript"},{id="wooden_chest_c3065d265dcac89c3b807a1121f459ea",adapter="chest",level="riv200_dangersmain",placement={"goriv200_cbt"},owner={"gochest_common_parent","goriv200_cbt"},extra="gochestscript"},{id="lore_scroll_dc56801cbe1e7d3cbd54f9150cc78a3c",adapter="pickup",level="for260_chiseldungeon",placement={"gotreasuremapinteract","go____dwarfcorpse_grp_________","gofor260_ents"},owner={"gotreasuremapinteract","go____dwarfcorpse_grp_________","gofor260_ents"},extra=nil},{id="coffin_00d1d9586170eb2458c9304285d70c2b",adapter="chest",level="stn200_lakeext",placement={"gocoffin_tier3_stn100_1","gostn200_ents_nooffset","gostn200_ents"},owner={"gocoffin_parent","gocoffin_tier3_stn100_1","gostn200_ents_nooffset","gostn200_ents"},extra="gochestscript"},{id="wooden_chest_fa54db89fddd352b2984a348dd33ada1",adapter="chest",level="hel600_guardianarena",placement={"gochest_common_tier4_hel600_1","gohel600_ents"},owner={"gochest_common_parent","gochest_common_tier4_hel600_1","gohel600_ents"},extra="gochestscript"},{id="artefact_xpl250funeralinteriorwad4813767722fa414b9a3d4972dc8874e7",adapter="artefact",level="xpl250_funeralinterior",placement={"goartifacthorn04","goxpl250_ents_nooffset","goxpl250_ents"},owner={"goartifactscript","goartifacthorn04","goxpl250_ents_nooffset","goxpl250_ents"},extra=nil},{id="artefact_28b7fe1349cdc49da573c6a0657f0a9d",adapter="artefact",level="riv475_freyahouseext",placement={"goartifactmask12","goriv475_cbt"},owner={"goartifactscript","goartifactmask12","goriv475_cbt"},extra=nil},{id="artefact_a0588a9442f0118bdce0cda751b8605d",adapter="artefact",level="for400_intersection",placement={"goartifacttoy04_new","gofor400_ents"},owner={"goartifactscript","goartifacttoy04","goartifacttoy04_new","gofor400_ents"},extra=nil},{id="lore_scroll_62cc5c222fbe7d849e83705cfe13638c",adapter="pickup",level="peak100_entrance",placement={"gotreasuremapinteract","gopeak100_ents"},owner={"gotreasuremapinteract","gopeak100_ents"},extra=nil},{id="coffin_d1bfdaff128036c426e567b41358c072",adapter="chest",level="helr100_docks",placement={"gocoffin_tier4_helr100_1","gohelr100_ents"},owner={"gocoffin_parent","gocoffin_tier4_helr100_1","gohelr100_ents"},extra="gochestscript"},{id="coffin_78d857a21516770d19e10a59f5a76335",adapter="chest",level="xpl400_huldramines",placement={"gocoffin_tier2_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},owner={"gocoffin_parent","gocoffin_tier2_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},extra="gochestscript"},{id="coffin_575a07cc7dca64c540088be3f4139842",adapter="chest",level="peak720_summitascenthub",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffin_tier4_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffin_tier4_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"},extra="gochestscript"},{id="realm_tear_d9d5fe53b4d7bd0c88376c7647f5537e",adapter="rift",level="alf300_lakedark",placement={"golootpocketrift110","goalf300_cbt_nooffset","goalf300_cbt"},owner={"golootpocketgeo","golootpocketrift110","goalf300_cbt_nooffset","goalf300_cbt"},extra=nil},{id="legendary_chest_d63295f244f330219b003c913c0dab69",adapter="chest",level="peak720_summitascenthub",placement={"gochest_legendary_tier3_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"},owner={"gochestscript","gochest_legendary_parent","gochestobj","gochest_legendary_locked_roots_parent","gochest_legendary_tier3_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"},extra=nil},{id="jotnar_shrine_e49959e54f3f1da0632c3ac2a01d7ec7",adapter="shrine",level="stn105_chiselsite",placement={"gotriptych_thamur","gostn105_ents_nooffset","gostn105_ents"},owner={"gotriptych_thamur","gostn105_ents_nooffset","gostn105_ents"},extra=nil},{id="jotnar_shrine_e49959e54f3f1da0632c3ac2a01d7ec7",adapter="shrine",level="stn905_chiselsite",placement={"gotriptych_thamur","gostn105_ents_nooffset","gostn905_ents"},owner={"gotriptych_thamur","gostn105_ents_nooffset","gostn905_ents"},extra=nil},{id="artefact_48edaa8b407e24bed474bebea8ea3821",adapter="artefact",level="alfdgn110_main",placement={"goartifactalfheim02_rn","goloot","goalfdgn110_ents_nooffset","goalfdgn110_ents"},owner={"goartifactscript","goartifactalfheim02","goartifactalfheim02_rn","goloot","goalfdgn110_ents_nooffset","goalfdgn110_ents"},extra=nil},{id="wooden_chest_d753ce063ba2187aaf6ce654558de5c6",adapter="chest",level="foot250_chiselarena",placement={"gochest_common_tier1_foot250_1","go___loot","gofoot250_ents_nooffset","gofoot250_ents"},owner={"gochest_common_parent","gochest_common_tier1_foot250_1","go___loot","gofoot250_ents_nooffset","gofoot250_ents"},extra="gochestscript"},{id="treasure_dig_9680b8bc8eff19d4c84b439b0e5a841b",adapter="dig",level="xpl910_islandshipwreck",placement={"gotreasuredig_boatcpt_tier3_xpl910","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gotreasuredig_boatcpt_tier3_xpl910","goxpl910_ents_nooffset","goxpl910_ents"},extra=nil},{id="coffin_265ee0bf74ea46d94e2271778008959e",adapter="chest",level="helr100_docks",placement={"gocoffin_tier4_helr100_3","gohelr100_ents"},owner={"gocoffin_parent","gocoffin_tier4_helr100_3","gohelr100_ents"},extra="gochestscript"},{id="coffin_f7c85deadc9605c7a4dde328c9d916b1",adapter="chest",level="peak200_chimneylow",placement={"gocoffin_tier4_peak200_1","gopeak200_ents_nooffset","gopeak200_ents"},owner={"gocoffin_parent","gocoffin_tier4_peak200_1","gopeak200_ents_nooffset","gopeak200_ents"},extra="gochestscript"},{id="coffin_7261934c1430c94f92e2ba079fed8c3c",adapter="chest",level="xpl100_httk",placement={"gocoffin_tier6_xpl100_1","gocontainers","goxpl100_ents_nooffset","goxpl100_ents"},owner={"gocoffin_parent","gocoffin_tier6_xpl100_1","gocontainers","goxpl100_ents_nooffset","goxpl100_ents"},extra="gochestscript"},{id="artefact_8916f55c4511b74ba8601ba7ef3d86bb",adapter="artefact",level="for650_bridge",placement={"goartifacttoy05","gofor650_ents"},owner={"goartifactscript","goartifacttoy05","gofor650_ents"},extra=nil},{id="wooden_chest_765e2894cba2c865774bff371c57a91d",adapter="chest",level="riv975_chiselarena",placement={"gochest_common_tier1_riv975_2","gochests_06","goriv975_ents_nooffset","goriv975_ents"},owner={"gochest_common_parent","gochest_common_tier1_riv975_2","gochests_06","goriv975_ents_nooffset","goriv975_ents"},extra="gochestscript"},{id="realm_tear_1c939364d61323b0c9db30a25da5b0f0",adapter="rift",level="cal250_foothillslh",placement={"golootpocketriftcal250","go______lightcrystal_pocketrift","gocal250_ents"},owner={"golootpocketgeo","golootpocketriftcal250","go______lightcrystal_pocketrift","gocal250_ents"},extra=nil},{id="coffin_68e0db213e0e075b272fe88aa8d49f54",adapter="chest",level="peak180_enttochimneylh",placement={"gocoffin_tier3_peak180_1","gopeak180_ents"},owner={"gocoffin_parent","gocoffin_tier3_peak180_1","gopeak180_ents"},extra="gochestscript"},{id="wooden_chest_844dbdd31fe6dc2fb08087399b65f67b",adapter="chest",level="xpl475_huldramineslh",placement={"gochest_common_tier2_xpl475_1","gorefnodes","goxpl475_ents_nooffset","goxpl475_ents"},owner={"gochest_common_parent","gochest_common_tier2_xpl475_1","gorefnodes","goxpl475_ents_nooffset","goxpl475_ents"},extra="gochestscript"},{id="coffin_793530dd17ca89215ba5d26f7357b8aa",adapter="chest",level="hel300_mainbridge",placement={"gocoffin_tier4_hel300_1","gohel300_ents"},owner={"gocoffin_parent","gocoffin_tier4_hel300_1","gohel300_ents"},extra="gochestscript"},{id="wooden_chest_471003f756043c7046d03da4a1c65372",adapter="chest",level="riv325_dangersexit",placement={"gochest_common_tier1_riv325_1","goriv325_cbt"},owner={"gochest_common_parent","gochest_common_tier1_riv325_1","goriv325_cbt"},extra="gochestscript"},{id="wooden_chest_b6c25a3f683631668b90e34378276b82",adapter="chest",level="hel300_mainbridge",placement={"gobramble_chest_hel300","gohel300_ents"},owner={"gochest_common_parent","gobramble_chest_hel300","gohel300_ents"},extra="gochestscript"},{id="treasure_dig_a46f12e366ccfd55f7a945383f1231d0",adapter="dig",level="xpl900_islandarch",placement={"gotreasure_dig_common_tier3_xpl900_1","goxpl900_ents_nooffset","goxpl900_ents"},owner={"gotreasure_dig_common_tier3_xpl900_1","goxpl900_ents_nooffset","goxpl900_ents"},extra=nil},{id="coffin_2b80e842d459585947380fe4c7415e0f",adapter="chest",level="stn430_hammerclimb",placement={"gocoffin_tier3_stn430_2","gostn430_ents_nooffset","gostn430_ents"},owner={"gocoffin_parent","gocoffin_tier3_stn430_2","gostn430_ents_nooffset","gostn430_ents"},extra="gochestscript"},{id="treasure_map_f48eb59997ca3572363316461a106067",adapter="pickup",level="peak790_chimneytopreturn",placement={"gotreasuremapinteract_valkarena","gopeak790_ents_nooffset","gopeak790_ents"},owner={"gotreasuremapinteract_valkarena","gopeak790_ents_nooffset","gopeak790_ents"},extra=nil},{id="coffin_49c66a6e387cfdaaa98e4b2afdf7b1d3",adapter="chest",level="riv925_freyacave",placement={"gocoffin_tier1_riv925_3","goriv925_cbt"},owner={"gocoffin_parent","gocoffin_tier1_riv925_3","goriv925_cbt"},extra="gochestscript"},{id="wooden_chest_cbb47d1bd72b169725ff3d03a4af9282",adapter="chest",level="xpl920_islandclimb",placement={"gochest_common_tier4_xpl920_1","gochestpickups_loot","goxpl920_ents_nooffset","goxpl920_ents"},owner={"gochest_common_parent","gochest_common_tier4_xpl920_1","gochestpickups_loot","goxpl920_ents_nooffset","goxpl920_ents"},extra="gochestscript"},{id="coffin_c289f1218e664d7edf073b93a0cc55f8",adapter="chest",level="helr100_docks",placement={"gocoffin_tier4_helr100_5","gohelr100_ents"},owner={"gocoffin_parent","gocoffin_tier4_helr100_5","gohelr100_ents"},extra="gochestscript"},{id="coffin_3dceee4444defddd165bf4929207c58f",adapter="chest",level="xpl960_beachship",placement={"gocoffin_tier3_xpl960_1","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl960_1","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},extra="gochestscript"},{id="treasure_dig_5f6d01b68cdf70a9815dc6fa7c3a839f",adapter="dig",level="foot500_top",placement={"gomisc_common_tier2_foot500_1","gofoot500_ents","gofoot500_ents_offset"},owner={"gomisc_common_tier2_foot500_1","gofoot500_ents","gofoot500_ents_offset"},extra=nil},{id="coffin_c439b69d88a1f2195464c303b8d65e30",adapter="chest",level="foot100_base",placement={"gocoffin_tier1_foot100_1","go______posionsetup_ridge","gofoot100_ents"},owner={"gocoffin_parent","gocoffin_tier1_foot100_1","go______posionsetup_ridge","gofoot100_ents"},extra="gochestscript"},{id="coffin_742ff8d25ea20efe745ec677e3c21d45",adapter="chest",level="alf355_chiseldungeon",placement={"gocoffin_tier1_alf355_1","gochests_01","goalf355_ents_nooffset","goalf355_ents"},owner={"gocoffin_parent","gocoffin_tier1_alf355_1","gochests_01","goalf355_ents_nooffset","goalf355_ents"},extra="gochestscript"},{id="wooden_chest_ef35baf6c74c4cd48702005838cd186e",adapter="chest",level="for550_brokenforest",placement={"gochest_common_tier1_for550_1","goloot","gofor550_ents"},owner={"gochest_common_parent","gochest_common_tier1_for550_1","goloot","gofor550_ents"},extra="gochestscript"},{id="coffin_dbc446d3cdc8af11b26294ada4bf2c9c",adapter="chest",level="foot500_top",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_foot500_1","govibratesetups","gofoot500_ents","gofoot500_ents_offset"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_foot500_1","govibratesetups","gofoot500_ents","gofoot500_ents_offset"},extra="gochestscript"},{id="legendary_chest_5618d560426940a02e5b39a340c0c209",adapter="chest",level="hel100_calderaheldressing",placement={"gochest_legendary_tier4_hel100_2","gohel100_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_hel100_2","gohel100_ents"},extra=nil},{id="legendary_chest_890a24d24d2864a1567af691c615870f",adapter="chest",level="xpl100_httk",placement={"gochest_legendary_tier5_xpl100_2","gocontainers","goxpl100_ents_nooffset","goxpl100_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier5_xpl100_2","gocontainers","goxpl100_ents_nooffset","goxpl100_ents"},extra=nil},{id="coffin_def02bc17b1bb0246e28fded510dccf2",adapter="chest",level="for660_templeinterior",placement={"gocoffin_tier1_for660_1","goloot","gofor660_ents"},owner={"gocoffin_parent","gocoffin_tier1_for660_1","goloot","gofor660_ents"},extra="gochestscript"},{id="coffin_f1f9d33e14c532dcec5e55b7e735ca19",adapter="chest",level="riv200_dangersmain",placement={"gocoffin_tier1_riv200_2","goriv200_cbt"},owner={"gocoffin_parent","gocoffin_tier1_riv200_2","goriv200_cbt"},extra="gochestscript"},{id="coffin_744b86cb488721d7190188084d7dc635",adapter="chest",level="foot100_base",placement={"gocoffin_tier1_foot100_2","go______posionsetup_cubby","gofoot100_ents"},owner={"gocoffin_parent","gocoffin_tier1_foot100_2","go______posionsetup_cubby","gofoot100_ents"},extra="gochestscript"},{id="coffin_07014abc15905dbf2b905d543b85abfe",adapter="chest",level="peak120_cavescarelh",placement={"gocoffin_tier3_peak120_1","gopeak120_ents"},owner={"gocoffin_parent","gocoffin_tier3_peak120_1","gopeak120_ents"},extra="gochestscript"},{id="coffin_66d5de24a634f6acd7490fe2f02bc871",adapter="chest",level="xpl960_beachship",placement={"gocoffin_tier3_xpl960_3","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl960_3","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},extra="gochestscript"},{id="wooden_chest_66a6a9d412a0ec0fadc2deca89c8dbf2",adapter="chest",level="cal820_snakebellymid",placement={"gochest_common_tier5_cal820_1","gowad","gocal820_ents_nooffset","gocal820_ents"},owner={"gochest_common_parent","gochest_common_tier5_cal820_1","gowad","gocal820_ents_nooffset","gocal820_ents"},extra="gochestscript"},{id="artefact_fda837834b361579d4a29194810c3d09",adapter="artefact",level="xpl910_islandshipwreck",placement={"goartifactshiphead_inupperarena","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},owner={"goartifactscript","goartifactshiphead01","goartifactshiphead_inupperarena","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},extra=nil},{id="realm_tear_64b7ac07cbf1db2d7956e3298e23970f",adapter="rift",level="cal100_hub",placement={"golootpocketriftalf","gocal100_cbt"},owner={"golootpocketgeo","golootpocketriftalf","gocal100_cbt"},extra=nil},{id="wooden_chest_794573030ab6d881e84137e829ac9ae8",adapter="chest",level="xpl450_huldramines",placement={"gochest_common_tier2_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},owner={"gochest_common_parent","gochest_common_tier2_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},extra="gochestscript"},{id="realm_tear_80a81219135f07ea1c0eb1948748fc58",adapter="rift",level="nid400_center",placement={"gomisc_legendary_tier5_nid400_1","gocombatrift_02","gonid400_ents_nooffset","gonid400_ents"},owner={"golootpocketgeo","gomisc_legendary_tier5_nid400_1","gocombatrift_02","gonid400_ents_nooffset","gonid400_ents"},extra=nil},{id="realm_tear_ad3009f9f80b31ab80419fd380e60c1c",adapter="rift",level="nid400_center",placement={"gomisc_legendary_tier6_nid400_1","gocombatrift_03","gonid400_ents_nooffset","gonid400_ents"},owner={"golootpocketgeo","gomisc_legendary_tier6_nid400_1","gocombatrift_03","gonid400_ents_nooffset","gonid400_ents"},extra=nil},{id="realm_tear_10374be1dacc7b5afc9b38ff1c50b3f5",adapter="rift",level="nid400_center",placement={"gomisc_legendary_tier4_nid400_1","gocombatrift_01","gonid400_ents_nooffset","gonid400_ents"},owner={"golootpocketgeo","gomisc_legendary_tier4_nid400_1","gocombatrift_01","gonid400_ents_nooffset","gonid400_ents"},extra=nil},{id="wooden_chest_75ca91755fa5f614d3fadf9a08438fb2",adapter="chest",level="peak100_entrance",placement={"gochest_common_tier3_peak100_1","gopeak100_ents"},owner={"gochest_common_parent","gochest_common_tier3_peak100_1","gopeak100_ents"},extra="gochestscript"},{id="artefact_4a3d314942f187f69ee5b78302e118fe",adapter="artefact",level="cal100_hub",placement={"goartifactshiphead05","gocal100_ents"},owner={"goartifactscript","goartifactshiphead05","gocal100_ents"},extra=nil},{id="wooden_chest_693971af27e4bc2ec41d2f726a42bcbb",adapter="chest",level="xpl950_beachmaze",placement={"gochest_common_tier4_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},owner={"gochest_common_parent","gochest_common_tier4_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},extra="gochestscript"},{id="wooden_chest_c29bba3fbdf1a9d6e75049d29457decf",adapter="chest",level="peak300_chimneymid",placement={"gochest_common_tier3_peak300_1","gopeak300_ents"},owner={"gochest_common_parent","gochest_common_tier3_peak300_1","gopeak300_ents"},extra="gochestscript"},{id="coffin_aaaf95f673179f035c1e67f568f08107",adapter="chest",level="xpl450_huldramines",placement={"gocoffin_tier5_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},owner={"gocoffin_parent","gocoffin_tier5_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},extra="gochestscript"},{id="artefact_hel300mainbridgewadb5b33ffb0d723f44a135047d5a839e32",adapter="artefact",level="hel300_mainbridge",placement={"goartifactbrooch05_refnode","golootdrop_burnbridge","gohel300_ents"},owner={"goartifactscript","goartifactbrooch05","goartifactbrooch05_refnode","golootdrop_burnbridge","gohel300_ents"},extra=nil},{id="artefact_fa511e0a422421b7acc01fa5829c4fe3",adapter="artefact",level="riv925_freyacave",placement={"goartifactmask01","goriv925_cbt"},owner={"goartifactscript","goartifactmask01","goriv925_cbt"},extra=nil},{id="artefact_hel300mainbridgewade4b6326ae64d514490a45593d471478f",adapter="artefact",level="hel300_mainbridge",placement={"goartifactbrooch04","golootdrop_flat","gohel300_ents"},owner={"goartifactscript","goartifactbrooch04","golootdrop_flat","gohel300_ents"},extra=nil},{id="wooden_chest_d7eadb5de53b3584728f114bdd9a26d2",adapter="chest",level="foot100_base",placement={"gochest_common_tier1_foot100_1","go______loot","gofoot100_ents"},owner={"gochest_common_parent","gochest_common_tier1_foot100_1","go______loot","gofoot100_ents"},extra="gochestscript"},{id="wooden_chest_5a8b57e2e6ed25b4d95144d451fbfb5d",adapter="chest",level="peak190_chimneyenter",placement={"gochest_common_tier3_peak190_1","gopeak190_ents"},owner={"gochest_common_parent","gochest_common_tier3_peak190_1","gopeak190_ents"},extra="gochestscript"},{id="wooden_chest_6930ffe1cf86b6c7c705abebba9774c6",adapter="chest",level="alf345_trenchbdarktwr",placement={"gochest_common_tier1_alf345_1","gopickups","goalf345_ents_nooffset","goalf345_ents"},owner={"gochest_common_parent","gochest_common_tier1_alf345_1","gopickups","goalf345_ents_nooffset","goalf345_ents"},extra="gochestscript"},{id="jotnar_shrine_5abb17c179c16ed72287fc2740a46f9a",adapter="shrine",level="peak720_summitascenthub",placement={"gotryptich","gopeak720_ents_nooffset","gopeak720_ents"},owner={"gotryptich","gopeak720_ents_nooffset","gopeak720_ents"},extra=nil},{id="legendary_chest_d6fb0fd64364453cc3e334a2454e0b75",adapter="chest",level="xpl910_islandshipwreck",placement={"gochest_legendary_tier3_xpl910_1","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier3_xpl910_1","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},extra=nil},{id="treasure_map_adf20b36ad0f86b68901b8e49aeeb498",adapter="pickup",level="xpl930_beachruins",placement={"gotreasuremapinteract_forestdungeon","goxpl930_ents_nooffset","goxpl930_ents"},owner={"gotreasuremapinteract_forestdungeon","goxpl930_ents_nooffset","goxpl930_ents"},extra=nil},{id="wooden_chest_d9336ed2d59cb4a9961eedd85044b193",adapter="chest",level="foot500_top",placement={"gochest_common_tier5_foot500_1","gobramblesetups","gofoot500_ents","gofoot500_ents_offset"},owner={"gochest_common_parent","gochest_common_tier5_foot500_1","gobramblesetups","gofoot500_ents","gofoot500_ents_offset"},extra="gochestscript"},{id="wooden_chest_b4def36d6cf6253887e2d62acb8e931f",adapter="chest",level="hel100_calderaheldressing",placement={"gochest_common_tier4_hel100_3","gohel100_ents"},owner={"gochest_common_parent","gochest_common_tier4_hel100_3","gohel100_ents"},extra="gochestscript"},{id="coffin_8f470545b16b1e425d2fd5f47525bff1",adapter="chest",level="peak210_rollerroomlh",placement={"gocoffin_tier3_peak210_2","gopeak210_ents_nooffset","gopeak210_ents"},owner={"gocoffin_parent","gocoffin_tier3_peak210_2","gopeak210_ents_nooffset","gopeak210_ents"},extra="gochestscript"},{id="wooden_chest_779f83a51f7aa40a5c86866d652cb766",adapter="chest",level="xpl940_beachcave",placement={"gochest_common_tier2_xpl940_1","gogameplay_objects","goxpl940_ents_nooffset","goxpl940_ents"},owner={"gochest_common_parent","gochest_common_tier2_xpl940_1","gogameplay_objects","goxpl940_ents_nooffset","goxpl940_ents"},extra="gochestscript"},{id="coffin_cd8cfd54dfd050d5d4b60bd7ff08eb21",adapter="chest",level="xpl600_masontrail",placement={"gocoffin_tier3_xpl600_1","go____loot","goxpl600_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl600_1","go____loot","goxpl600_ents"},extra="gochestscript"},{id="coffin_85531ced605effb9af1dad9009031dfd",adapter="chest",level="alf390_templeextlh",placement={"gohivecoffin_tier1_alf390_1","goloot","goalf390_ents_nooffset","goalf390_ents"},owner={"gocoffin_parent","gohivecoffin_tier1_alf390_1","goloot","goalf390_ents_nooffset","goalf390_ents"},extra="gochestscript"},{id="realm_tear_75c3365cbb3042f761a82660c314147e",adapter="rift",level="peak740_summitpeak",placement={"golootpocketrift740","gopeak740_cbt"},owner={"golootpocketgeo","golootpocketrift740","gopeak740_cbt"},extra=nil},{id="lore_marker_riv475freyahouseextwad9a50243a697a924481d49d5c44c980ac",adapter="lore",level="riv475_freyahouseext",placement={"goriv475_ents"},owner={"gosonruneread2","goriv475_ents"},extra=nil},{id="artefact_xpl200funeralwad2768cb29f445634bb075f7a858cabcc3",adapter="artefact",level="xpl200_funeral",placement={"goartifacthorn01","goxpl200_ents_nooffset","goxpl200_ents"},owner={"goartifactscript","goartifacthorn01","goxpl200_ents_nooffset","goxpl200_ents"},extra=nil},{id="wooden_chest_c7b27bc28ec7f67ef792e16997dbb5b4",adapter="chest",level="riv420_forestboarstart",placement={"gochest_common_tier1_riv420_1","goriv420_cbt"},owner={"gochest_common_parent","gochest_common_tier1_riv420_1","goriv420_cbt"},extra="gochestscript"},{id="wooden_chest_21ce00568c4f2f02e51a4fe20ea80030",adapter="chest",level="xpl940_beachcave",placement={"gochest_common_tier2_xpl940_3","gogameplay_objects","goxpl940_ents_nooffset","goxpl940_ents"},owner={"gochest_common_parent","gochest_common_tier2_xpl940_3","gogameplay_objects","goxpl940_ents_nooffset","goxpl940_ents"},extra="gochestscript"},{id="coffin_ccc3e6b52c7ac6ccd3a6ac24aced6cfc",adapter="chest",level="xpl850_dungeonforest",placement={"gocoffin_tier2_xpl850_1","goxpl850_ents_nooffset","goxpl850_ents"},owner={"gocoffin_parent","gocoffin_tier2_xpl850_1","goxpl850_ents_nooffset","goxpl850_ents"},extra="gochestscript"},{id="wooden_chest_1adba8510701fc2e921940af402eb450",adapter="chest",level="xpl950_beachmaze",placement={"gochest_common_tier3_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},extra="gochestscript"},{id="wooden_chest_5db52378a823a4c80828e0c927521dd3",adapter="chest",level="xpl400_huldramines",placement={"gochest_common_tier3_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},extra="gochestscript"},{id="wooden_chest_bd68b87e6f2fa142ead9dbf282303da4",adapter="chest",level="peak205_chiselarena",placement={"gochest_common_tier5_peak205_1","gopeak205_ents_nooffset","gopeak205_ents"},owner={"gochest_common_parent","gochest_common_tier5_peak205_1","gopeak205_ents_nooffset","gopeak205_ents"},extra="gochestscript"},{id="wooden_chest_32d12c1505dcc72956b8b8cb27f928d1",adapter="chest",level="riv430_forestboartrack",placement={"gochest_common_tier1_riv430_1","goloot_stuff","goriv430_cbt"},owner={"gochest_common_parent","gochest_common_tier1_riv430_1","goloot_stuff","goriv430_cbt"},extra="gochestscript"},{id="wooden_chest_0e36e52e4173d490a9b3f8868c7782a0",adapter="chest",level="xpl650_masontrailcave",placement={"gochest_common_tier3_xpl650_1","godesign","goxpl650_ents_nooffset","goxpl650_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl650_1","godesign","goxpl650_ents_nooffset","goxpl650_ents"},extra="gochestscript"},{id="coffin_abc058fb6e88938d0a43c94f13a7bffd",adapter="chest",level="riv975_chiselarena",placement={"gocoffin_tier1_riv975_1","goriv975_ents_nooffset","goriv975_ents"},owner={"gocoffin_parent","gocoffin_tier1_riv975_1","goriv975_ents_nooffset","goriv975_ents"},extra="gochestscript"},{id="jotnar_shrine_6e55a7d7704af68ce4b82e5edecf81a7",adapter="shrine",level="alf370_moatscripting",placement={"gotriptych_groa","goalf370_nar_nooffset","goalf370_nar"},owner={"gotriptych_groa","goalf370_nar_nooffset","goalf370_nar"},extra=nil},{id="realm_tear_af0e22716b928bcf52889387ffc91c4f",adapter="rift",level="cal100_hub",placement={"golootpocketriftnid","gocal100_cbt"},owner={"golootpocketgeo","golootpocketriftnid","gocal100_cbt"},extra=nil},{id="legendary_chest_0e27df5f4bc5f2545a43178d0115312b",adapter="chest",level="stn200_lakeext",placement={"gochest_legendary_tier3_stn200_1","gostn200_ents_nooffset","gostn200_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier3_stn200_1","gostn200_ents_nooffset","gostn200_ents"},extra=nil},{id="legendary_chest_9c0dc602456a00fa44bca1a3b599cf67",adapter="chest",level="xpl910_islandshipwreck",placement={"gochest_legendary_tier4_xpl910_1","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_xpl910_1","goxpl910_ents_nooffset","goxpl910_ents"},extra=nil},{id="artefact_5bf15dbc48613f5b548fd2a673d8f7bc",adapter="artefact",level="alf370_moatscripting",placement={"goartifactalfheim04","goalf370_ents_nooffset","goalf370_ents"},owner={"goartifactscript","goartifactalfheim04","goalf370_ents_nooffset","goalf370_ents"},extra=nil},{id="legendary_chest_d6d6acfe444f2ad10b49cea2ba85a1eb",adapter="chest",level="xpl250_funeralinterior",placement={"gochest_legendary_tier2_xpl250_1","goxpl250_ents_nooffset","goxpl250_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier2_xpl250_1","goxpl250_ents_nooffset","goxpl250_ents"},extra=nil},{id="artefact_6fa420df406be3d033b7eea35a4d10fe",adapter="artefact",level="riv400_forestintro",placement={"goartifactmask08","goriv400_cbt"},owner={"goartifactscript","goartifactmask08","goriv400_cbt"},extra=nil},{id="realm_tear_71588ab9681c6184279e7384fdafbbdd",adapter="rift",level="cal100_hub",placement={"golootpocketriftdragon","gocal100_cbt"},owner={"golootpocketgeo","golootpocketriftdragon","gocal100_cbt"},extra=nil},{id="legendary_chest_7a71d104452e16e39a25bb8a14e47343",adapter="chest",level="xpl850_dungeonforest",placement={"gochest_legendary_tier2_xpl850_2","goxpl850_ents_nooffset","goxpl850_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier2_xpl850_2","goxpl850_ents_nooffset","goxpl850_ents"},extra=nil},{id="coffin_ebcc7fde6edd3347424493e2700fae89",adapter="chest",level="xpl250_funeralinterior",placement={"gocoffin_tier2_xpl250_1","goxpl250_ents_nooffset","goxpl250_ents"},owner={"gocoffin_parent","gocoffin_tier2_xpl250_1","goxpl250_ents_nooffset","goxpl250_ents"},extra="gochestscript"},{id="wooden_chest_6b0d3d9e239100c717236687da581bef",adapter="chest",level="stn600_chasmroom",placement={"gochest_common_tier3_stn600_1","goloot","gostn600_ents_nooffset","gostn600_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn600_1","goloot","gostn600_ents_nooffset","gostn600_ents"},extra="gochestscript"},{id="lore_marker_xpl940beachcavewad6093995aaaf7ad4b9830d1be0e7e0684",adapter="lore",level="xpl940_beachcave",placement={"golakeofnine_lightbeacon","go___lakeofnine_quest","goxpl940_ents_nooffset","goxpl940_ents"},owner={"gopsoninteractrune","goquest_lightbeacon_root","golakeofnine_lightbeacon","go___lakeofnine_quest","goxpl940_ents_nooffset","goxpl940_ents"},extra=nil},{id="lore_marker_xpl950beachmazewad6093995aaaf7ad4b9830d1be0e7e0684",adapter="lore",level="xpl950_beachmaze",placement={"golakeofnine_lightbeacon","go___lakeofnine_quest","goxpl950_ents_nooffset","goxpl950_ents"},owner={"gopsoninteractrune","goquest_lightbeacon_root","golakeofnine_lightbeacon","go___lakeofnine_quest","goxpl950_ents_nooffset","goxpl950_ents"},extra=nil},{id="artefact_xpl250funeralinteriorwad3f176e49e0a0cd4f8cf59ada5fe9c2d8",adapter="artefact",level="xpl250_funeralinterior",placement={"goartifacthorn06","goxpl250_ents_nooffset","goxpl250_ents"},owner={"goartifactscript","goartifacthorn06","goxpl250_ents_nooffset","goxpl250_ents"},extra=nil},{id="treasure_dig_8c965bccff326f509c02f9321af9a223",adapter="dig",level="xpl920_islandclimb",placement={"gomisc_common_tier3_xpl920_1","goxpl920_ents_nooffset","goxpl920_ents"},owner={"gomisc_common_tier3_xpl920_1","goxpl920_ents_nooffset","goxpl920_ents"},extra=nil},{id="artefact_ab662cc14c4a21327111dea1a34b96c3",adapter="artefact",level="for560_wolfpit",placement={"goartifacttoy01","gofor560_ents_nooffset","gofor560_ents"},owner={"goartifactscript","goartifacttoy01","gofor560_ents_nooffset","gofor560_ents"},extra=nil},{id="cipher_chest_368ccc0e6d6636bc0c74043536071ef1",adapter="chest",level="riv925_freyacave",placement={"goriv925_drainchest","goriv925_ents"},owner={"gochest_dispell_parent","goriv925_drainchest","goriv925_ents"},extra="gochestscript"},{id="lore_scroll_0a8de84c5e82fd19ccc618bce5ef6f84",adapter="pickup",level="peak780_summitexit",placement={"gotreasuremapinteract_valkarena","gopeak780_ents_nooffset","gopeak780_ents"},owner={"gotreasuremapinteract_valkarena","gopeak780_ents_nooffset","gopeak780_ents"},extra=nil},{id="wooden_chest_acf22956026eaf9efd34a12ef5ca22e2",adapter="chest",level="stn200_lakeext",placement={"gochest_common_tier3_stn200_2","gostn200_ents_nooffset","gostn200_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn200_2","gostn200_ents_nooffset","gostn200_ents"},extra="gochestscript"},{id="wooden_chest_5156a959c5b5a08a49303486b7d998cd",adapter="chest",level="for260_chiseldungeon",placement={"gochest_common_tier5_for260_1","gochests_04","gofor260_ents"},owner={"gochest_common_parent","gochest_common_tier5_for260_1","gochests_04","gofor260_ents"},extra="gochestscript"},{id="wooden_chest_0e0ac7e313b7a70479ce4799c063e1b6",adapter="chest",level="xpl450_huldramines",placement={"gochest_common_tier3_xpl450_2","gochests","goxpl450_ents_nooffset","goxpl450_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl450_2","gochests","goxpl450_ents_nooffset","goxpl450_ents"},extra="gochestscript"},{id="wooden_chest_f666f4ec08b715cf7e0862fa5d4d2a37",adapter="chest",level="xpl980_beachwaterfall",placement={"gochest_common_tier3_xpl980_1","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl980_1","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},extra="gochestscript"},{id="wooden_chest_dbe63347daadc35034b614654d2e35a1",adapter="chest",level="peak260_chimneylowhall",placement={"gochest_common_tier3_peak260_1","gopeak260_ents"},owner={"gochest_common_parent","gochest_common_tier3_peak260_1","gopeak260_ents"},extra="gochestscript"},{id="treasure_map_aef0891f1c3ee6d1f88f86b1601052f4",adapter="pickup",level="xpl970_beachtower",placement={"gopasted__treasuremapinteract","goxpl970_ents_nooffset","goxpl970_ents"},owner={"gopasted__treasuremapinteract","goxpl970_ents_nooffset","goxpl970_ents"},extra=nil},{id="artefact_fae85e594ef79ee2e204719767dd5287",adapter="artefact",level="peak140_caverndark",placement={"goartifactcup01","gopeak140_ents"},owner={"goartifactscript","goartifactcup01","gopeak140_ents"},extra=nil},{id="treasure_dig_70214d5859cc48c2bfddd06fb252a8ba",adapter="dig",level="xpl625_masontraillh",placement={"gotreasuredig_oarsmen_tier4_xpl625","go____loot","goxpl625_ents_nooffset","goxpl625_ents"},owner={"gotreasuredig_oarsmen_tier4_xpl625","go____loot","goxpl625_ents_nooffset","goxpl625_ents"},extra=nil},{id="wooden_chest_0bb016e6a10fa429fd92e7431244acf3",adapter="chest",level="xpl980_beachwaterfall",placement={"gochest_common_tier1_xpl980_1","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},owner={"gochest_common_parent","gochest_common_tier1_xpl980_1","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},extra="gochestscript"},{id="legendary_chest_510bd86441ac6a7b71d4f59321c2a08f",adapter="chest",level="foot200_mid",placement={"gochest_legendary_tier5_foot200_1","go___drainsetup___","gofoot200_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier5_foot200_1","go___drainsetup___","gofoot200_ents"},extra=nil},{id="wooden_chest_9cf64f1857fba5b156c819bb82eff1f8",adapter="chest",level="riv430_forestboartrack",placement={"gochest_common_tier1_riv430_2","goloot_stuff","goriv430_cbt"},owner={"gochest_common_parent","gochest_common_tier1_riv430_2","goloot_stuff","goriv430_cbt"},extra="gochestscript"},{id="wooden_chest_78a1535551a9f6fc3d428be55e683d98",adapter="chest",level="for400_intersection",placement={"gochest_common_tier1_for400_1","gofor400_ents"},owner={"gochest_common_parent","gochest_common_tier1_for400_1","gofor400_ents"},extra="gochestscript"},{id="wooden_chest_6415bc87e3cee7dc64ff87227be631dc",adapter="chest",level="foot250_chiselarena",placement={"gochest_common_tier1_foot250_2","go___loot","gofoot250_ents_nooffset","gofoot250_ents"},owner={"gochest_common_parent","gochest_common_tier1_foot250_2","go___loot","gofoot250_ents_nooffset","gofoot250_ents"},extra="gochestscript"},{id="wooden_chest_dfa557277d10a7a70b656a4620c56fda",adapter="chest",level="xpl960_beachship",placement={"gochest_common_tier3_xpl960_2","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl960_2","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},extra="gochestscript"},{id="coffin_1ec665d11dec0d4959f2fa6fe571a6cf",adapter="chest",level="cal500_runevault",placement={"gocoffin_tier4_cal500_1","gowad","gocal500_ents"},owner={"gocoffin_parent","gocoffin_tier4_cal500_1","gowad","gocal500_ents"},extra="gochestscript"},{id="wooden_chest_3c854063b4cea27669211d35562b7a9e",adapter="chest",level="xpl900_islandarch",placement={"gochest_common_tier3_xpl900_2","go____loot","goxpl900_ents_nooffset","goxpl900_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl900_2","go____loot","goxpl900_ents_nooffset","goxpl900_ents"},extra="gochestscript"},{id="jotnar_shrine_23d6030ef079b748c4574a940bf2047b",adapter="shrine",level="cal590_runevaultelevator",placement={"gotriptych_tyr_base","goruneelevator","gocal590_ents"},owner={"gotriptych_tyr_base","goruneelevator","gocal590_ents"},extra=nil},{id="wooden_chest_47d4448bcb8d2e3a3fde0f69672e1f1e",adapter="chest",level="xpl200_funeral",placement={"gochest_common_tier02","gocoffin_tier1_xpl200_3","gocontainers","goxpl200_ents_nooffset","goxpl200_ents"},owner={"gochest_common_parent","gochest_common_tier02","gocoffin_tier1_xpl200_3","gocontainers","goxpl200_ents_nooffset","goxpl200_ents"},extra="gochestscript"},{id="legendary_chest_8aabd22a44df8f25a955fe8e04fc0d95",adapter="chest",level="riv100_dangersentrance",placement={"gochest_legendary_tier1_riv100_1","goriv100_cbt"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier1_riv100_1","goriv100_cbt"},extra=nil},{id="lore_marker_peak500chimneytopwad1d9b928f5f7eab4082f9c52e2f066780",adapter="lore",level="peak500_chimneytop",placement={"gopeak500_ents"},owner={"gosonreadrune","gopeak500_ents"},extra=nil},{id="treasure_dig_33fd783f7b353537d922042c2a967396",adapter="dig",level="xpl200_funeral",placement={"gotreasuremap_dig_tier2_xpl200_1","goxpl200_qst_nooffset","goxpl200_qst"},owner={"gotreasuremap_dig_tier2_xpl200_1","goxpl200_qst_nooffset","goxpl200_qst"},extra=nil},{id="coffin_5abb61ed22d5ef4e63d0fb21411fc797",adapter="chest",level="xpl225_funerallh",placement={"gocoffin_tier1_xpl225_1","goxpl225_ents_nooffset","goxpl225_ents"},owner={"gocoffin_parent","gocoffin_tier1_xpl225_1","goxpl225_ents_nooffset","goxpl225_ents"},extra="gochestscript"},{id="wooden_chest_c34cd12e6f6d9025df3fdc4fbe29433c",adapter="chest",level="xpl300_stronghold",placement={"gochest_common_tier3_xpl300_2","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl300_2","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},extra="gochestscript"},{id="wooden_chest_05777956466a17869155000961f9c0e4",adapter="chest",level="xpl625_masontraillh",placement={"gochest_common_tier3_xpl625_1","go____loot","goxpl625_ents_nooffset","goxpl625_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl625_1","go____loot","goxpl625_ents_nooffset","goxpl625_ents"},extra="gochestscript"},{id="wooden_chest_45cff077ae20b76b69ca0926566ce5c6",adapter="chest",level="hel200_entrancedoor",placement={"gochest_common_tier3_hel200_1","gohel200_ents"},owner={"gochest_common_parent","gochest_common_tier3_hel200_1","gohel200_ents"},extra="gochestscript"},{id="lore_marker_stn200lakeextwad64309dc36de48d438409f5abb85cfc92",adapter="lore",level="stn200_lakeext",placement={"gostn200_ents_nooffset","gostn200_ents"},owner={"gosonreadrune","gostn200_ents_nooffset","gostn200_ents"},extra=nil},{id="artefact_b52df62545c16741e6f2278f9e2ccc32",adapter="artefact",level="peak720_summitascenthub",placement={"goartifactcup04","gopeak720_ents_nooffset","gopeak720_ents"},owner={"goartifactscript","goartifactcup04","gopeak720_ents_nooffset","gopeak720_ents"},extra=nil},{id="coffin_fe52241f85fb3089b8210f793b4a34ee",adapter="chest",level="xpl650_masontrailcave",placement={"gocoffin_tier3_xpl650_1","godesign","goxpl650_ents_nooffset","goxpl650_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl650_1","godesign","goxpl650_ents_nooffset","goxpl650_ents"},extra="gochestscript"},{id="artefact_7d8a35dc4d6aabf8065e1ead0c470fcc",adapter="artefact",level="xpl940_beachcave",placement={"goartifactshiphead06","goxpl940_ents_nooffset","goxpl940_ents"},owner={"goartifactscript","goartifactshiphead06","goxpl940_ents_nooffset","goxpl940_ents"},extra=nil},{id="coffin_f79832e35e68cfc2d8a11e290165fa89",adapter="chest",level="stn750_returnhallway",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_stn750_1","gostn750_ents_nooffset","gostn750_ents"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_stn750_1","gostn750_ents_nooffset","gostn750_ents"},extra="gochestscript"},{id="wooden_chest_a1d6fa6a5055273efa2aea64e3208312",adapter="chest",level="riv200_dangersmain",placement={"gochest_common_tier1_riv200_1","goriv200_cbt"},owner={"gochest_common_parent","gochest_common_tier1_riv200_1","goriv200_cbt"},extra="gochestscript"},{id="treasure_map_4011675d69434ff50662d79d43b08305",adapter="pickup",level="cal270_stonemasonlh",placement={"gotreasuremapinteract_island_climb","gocal270_ents_nooffset","gocal270_ents"},owner={"gotreasuremapinteract_island_climb","gocal270_ents_nooffset","gocal270_ents"},extra=nil},{id="lore_marker_alf690lakelightlhwade723fb1f62e1ef4a94d19a5eeeef0673",adapter="lore",level="alf690_lakelightlh",placement={"goalf690_ents_nooffset","goalf690_ents"},owner={"goinvisibleinktotem","goalf690_ents_nooffset","goalf690_ents"},extra=nil},{id="artefact_cf7627ad486711d9eab3339782e5a147",adapter="artefact",level="riv475_freyahouseext",placement={"goartifactmask11","goriv475_cbt"},owner={"goartifactscript","goartifactmask11","goriv475_cbt"},extra=nil},{id="coffin_f9f584304bafcd2f50ab0db9d2694940",adapter="chest",level="for700_deerkill",placement={"gocoffin_tier1_for700_1","gofor700_ents"},owner={"gocoffin_parent","gocoffin_tier1_for700_1","gofor700_ents"},extra="gochestscript"},{id="coffin_573b543d74f93b4bd85cffdce6da424d",adapter="chest",level="for650_bridge",placement={"gocoffin_tier1_for650_1","gofor650_ents"},owner={"gocoffin_parent","gocoffin_tier1_for650_1","gofor650_ents"},extra="gochestscript"},{id="realm_tear_885f79d8699b58e655739f1b924bf442",adapter="rift",level="alfdgn210_main",placement={"golootpocketrift210","goalfdgn210_ents_nooffset","goalfdgn210_ents"},owner={"golootpocketgeo","golootpocketrift210","goalfdgn210_ents_nooffset","goalfdgn210_ents"},extra=nil},{id="wooden_chest_268d53a0272891ccecb31702393e1819",adapter="chest",level="cal100_hub",placement={"gochest_common_tier1_cal100_1","gocal100_ents"},owner={"gochest_common_parent","gochest_common_tier1_cal100_1","gocal100_ents"},extra="gochestscript"},{id="wooden_chest_b14a7e0ad20f015dd563b19abc1a54ca",adapter="chest",level="xpl250_funeralinterior",placement={"gochest_common_tier1_xpl250_1","goxpl250_ents_nooffset","goxpl250_ents"},owner={"gochest_common_parent","gochest_common_tier1_xpl250_1","goxpl250_ents_nooffset","goxpl250_ents"},extra="gochestscript"},{id="coffin_4c894a4cd00f5770ebcf2c0c5de8e2b1",adapter="chest",level="stn100_entrance",placement={"gocoffin_parent_0","gostn100_ents_nooffset","gostn100_ents"},owner={"gocoffin_parent","gocoffin_parent_0","gostn100_ents_nooffset","gostn100_ents"},extra="gochestscript"},{id="jotnar_shrine_7dadb7c3e8c5fdc6259b311fe6ac74ba",adapter="shrine",level="for660_templeinterior",placement={"gotriptych_solargarm","gofor660_ents"},owner={"gotriptych_solargarm","gofor660_ents"},extra=nil},{id="realm_tear_b24fe2ba5298d202f41bda97b2a00845",adapter="rift",level="stn800_shortcut",placement={"golootpocketrift_stn800","gostn800_ents_nooffset","gostn800_ents"},owner={"golootpocketgeo","golootpocketrift_stn800","gostn800_ents_nooffset","gostn800_ents"},extra=nil},{id="treasure_map_82e41ccaf3093e62880d64a18227112c",adapter="pickup",level="xpl300_stronghold",placement={"gotreasuremapinteract_oarsmen","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gotreasuremapinteract_oarsmen","goxpl300_ents_nooffset","goxpl300_ents"},extra=nil},{id="coffin_5540f9ba7ecad39bfe9f2b5817e16adf",adapter="chest",level="stn200_lakeext",placement={"gocoffin_tier3_stn200_4","gostn200_ents_nooffset","gostn200_ents"},owner={"gocoffin_parent","gocoffin_tier3_stn200_4","gostn200_ents_nooffset","gostn200_ents"},extra="gochestscript"},{id="wooden_chest_2d23433148d8f06d05b59b34549fd974",adapter="chest",level="stn400_hammerbase",placement={"gochest_common_tier3_stn400_1","gostn400_ents_nooffset","gostn400_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn400_1","gostn400_ents_nooffset","gostn400_ents"},extra="gochestscript"},{id="wooden_chest_87235278fe5f92c19968896762202b95",adapter="chest",level="hel300_mainbridge",placement={"gofalling_chest","gohelchestfall_01","gohelchestfall","godroptpathburnablegeo","gohel300_ents"},owner={"gochest_common_parent","gofalling_chest","gohelchestfall_01","gohelchestfall","godroptpathburnablegeo","gohel300_ents"},extra="gochestscript"},{id="coffin_cacfc0416ffa2a6daaa23c90fca91ff5",adapter="chest",level="xpl910_islandshipwreck",placement={"gocoffin_tier3_xpl910_4","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl910_4","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},extra="gochestscript"},{id="wooden_chest_ac18175339972ea504597b184294626a",adapter="chest",level="stn350_relicroom",placement={"gochest_common_tier3_stn350_1","gostn350_ents_nooffset","gostn350_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn350_1","gostn350_ents_nooffset","gostn350_ents"},extra="gochestscript"},{id="wooden_chest_3fe0ed11f8da36cf4d6a8534da039235",adapter="chest",level="riv225_dangerscave",placement={"gochest_common_tier1_riv420_1","goriv225_cbt"},owner={"gochest_common_parent","gochest_common_tier1_riv420_1","goriv225_cbt"},extra="gochestscript"},{id="lore_marker_d988f2795775914592a04b62df2726d9",adapter="lore",level="cal750_rightwing",placement={"gocal750_ents"},owner={"gorune_18","gorunereading","gorightwing_gameplay","gocal750_ents"},extra=nil},{id="wooden_chest_f588ff33e1919a60d2adb07232f79621",adapter="chest",level="alf150_bridgedark",placement={"gochest_common_tier1_alf150_1","goloot","goalf150_ents_nooffset","goalf150_ents"},owner={"gochest_common_parent","gochest_common_tier1_alf150_1","goloot","goalf150_ents_nooffset","goalf150_ents"},extra="gochestscript"},{id="coffin_42f17c39434a78c652e5235614526d0a",adapter="chest",level="alf340_trenchbdark",placement={"gocoffin_tier1_alf340_3","goloot","goalf340_ents_nooffset","goalf340_ents"},owner={"gocoffin_parent","gocoffin_tier1_alf340_3","goloot","goalf340_ents_nooffset","goalf340_ents"},extra="gochestscript"},{id="legendary_chest_3c05899e46a619015d4cfb995fb61be0",adapter="chest",level="riv925_freyacave",placement={"gofinalchest02","goriv925_ents"},owner={"gochestscript","gochest_legendary_parent","gofinalchest02","goriv925_ents"},extra=nil},{id="coffin_b24c6a682bdd5571637905ce2e305c2f",adapter="chest",level="cal750_rightwing",placement={"gocoffin_tier5_cal750_1","gorightwing_gameplay","gocal750_ents"},owner={"gocoffin_parent","gocoffin_tier5_cal750_1","gorightwing_gameplay","gocal750_ents"},extra="gochestscript"},{id="coffin_104119f1ce4acbac9a77408da2d7777f",adapter="chest",level="xpl200_funeral",placement={"gocoffin_tier1_xpl200_2","gocontainers","goxpl200_ents_nooffset","goxpl200_ents"},owner={"gocoffin_parent","gocoffin_tier1_xpl200_2","gocontainers","goxpl200_ents_nooffset","goxpl200_ents"},extra="gochestscript"},{id="wooden_chest_27794e7010aee1564fa9c0d13927ce5b",adapter="chest",level="stn750_returnhallway",placement={"gochest_common_tier3_stn750_1","gostn750_ents_nooffset","gostn750_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn750_1","gostn750_ents_nooffset","gostn750_ents"},extra="gochestscript"},{id="coffin_912c5430d4eba71f2aa2b42a05c68d40",adapter="chest",level="peak260_chimneylowhall",placement={"gocoffin_tier3_peak260_1","gopeak260_ents"},owner={"gocoffin_parent","gocoffin_tier3_peak260_1","gopeak260_ents"},extra="gochestscript"},{id="legendary_chest_529343984fc313504ac20da874d05c01",adapter="chest",level="xpl920_islandclimb",placement={"gochest_legendary_tier3_xpl920_2","goxpl920_ents_nooffset","goxpl920_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier3_xpl920_2","goxpl920_ents_nooffset","goxpl920_ents"},extra=nil},{id="lore_marker_xpl225funerallhwadb18d193b7ba34340a8831d0e11ff1b4e",adapter="lore",level="xpl225_funerallh",placement={"goxpl225_ents_nooffset","goxpl225_ents"},owner={"gosonreadrune","goxpl225_ents_nooffset","goxpl225_ents"},extra=nil},{id="coffin_32d35ecd545e598e3e3343964f5db9dd",adapter="chest",level="xpl425_huldramineslh",placement={"gocoffin_tier2_xpl425_1","goloot","goxpl425_ents_nooffset","goxpl425_ents"},owner={"gocoffin_parent","gocoffin_tier2_xpl425_1","goloot","goxpl425_ents_nooffset","goxpl425_ents"},extra="gochestscript"},{id="artefact_b18794364cc6b6a5c08596ab8699f35b",adapter="artefact",level="peak740_summitpeak",placement={"goartifactcup03","gopeak740_ents"},owner={"goartifactscript","goartifactcup03","gopeak740_ents"},extra=nil},{id="artefact_707ae0e24dc7bc9a56c19eb7ce17b351",adapter="artefact",level="alf325_trenchadarktwr",placement={"goartifactalfheim06","goloot","goalf325_ents_nooffset","goalf325_ents"},owner={"goartifactscript","goartifactalfheim06","goloot","goalf325_ents_nooffset","goalf325_ents"},extra=nil},{id="artefact_468c195b480889e354742b876aef3a11",adapter="artefact",level="riv430_forestboartrack",placement={"goartifactmask9","goriv430_cbt"},owner={"goartifactscript","goartifactmask09","goartifactmask9","goriv430_cbt"},extra=nil},{id="wooden_chest_a8c5ea120a8cc56f28fccd66df0e2f37",adapter="chest",level="helr100_docks",placement={"gochest_common_tier4_helr100_3","gohelr100_ents"},owner={"gochest_common_parent","gochest_common_tier4_helr100_3","gohelr100_ents"},extra="gochestscript"},{id="cipher_chest_a4637747ab0a20fa55d7253b2625da13",adapter="chest",level="peak740_summitpeak",placement={"gochest_dispell_tier3_peak740_1","gopeak740_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier3_peak740_1","gopeak740_ents"},extra="gochestscript"},{id="coffin_f1fb65044d01667d716a002b1c3391d5",adapter="chest",level="xpl980_beachwaterfall",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_xpl980_3","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_xpl980_3","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},extra="gochestscript"},{id="coffin_5f33d793b402e41dfae34b6b00b0fcf1",adapter="chest",level="xpl910_islandshipwreck",placement={"gocoffin_tier3_xpl910_2","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl910_2","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},extra="gochestscript"},{id="lore_marker_xpl960beachshipwad6093995aaaf7ad4b9830d1be0e7e0684",adapter="lore",level="xpl960_beachship",placement={"golakeofnine_lightbeacon","go___lakeofnine_quest","goxpl960_ents_nooffset","goxpl960_ents"},owner={"gopsoninteractrune","goquest_lightbeacon_root","golakeofnine_lightbeacon","go___lakeofnine_quest","goxpl960_ents_nooffset","goxpl960_ents"},extra=nil},{id="artefact_6e3739ea4ac8107c495a61af774a9b03",adapter="artefact",level="alfdgn210_main",placement={"goartifactalfheim01","gorightexplorepickups","goalfdgn210_ents_nooffset","goalfdgn210_ents"},owner={"goartifactscript","goartifactalfheim01","gorightexplorepickups","goalfdgn210_ents_nooffset","goalfdgn210_ents"},extra=nil},{id="coffin_a53778e43c763a0bfa7b902a04cf9eb2",adapter="chest",level="cal170_library1",placement={"gocoffin_tier4_cal170_1","gocal170_ents_nooffset","gocal170_ents"},owner={"gocoffin_parent","gocoffin_tier4_cal170_1","gocal170_ents_nooffset","gocal170_ents"},extra="gochestscript"},{id="lore_marker_riv200dangersmainwad452dc462aab2814097a8c9a7d317c558",adapter="lore",level="riv200_dangersmain",placement={"goriv200_ents"},owner={"gosonknowledge_underbridge","goriv200_ents"},extra=nil},{id="lore_marker_riv475freyahouseextwadd328468a73cead438031e76201fbddc9",adapter="lore",level="riv475_freyahouseext",placement={"goriv475_ents"},owner={"goinvisibleink_totem_well","go____invisibleink_setup____","goriv475_ents"},extra=nil},{id="treasure_map_5d8b3d55a299888357a6893fcec99c05",adapter="pickup",level="xpl980_beachwaterfall",placement={"gotreasuremapinteract_shipwreck","goxpl980_ents_nooffset","goxpl980_ents"},owner={"gotreasuremapinteract_shipwreck","goxpl980_ents_nooffset","goxpl980_ents"},extra=nil},{id="lore_marker_xpl200funeralwad0ab993b107a42f41af27749c6749728d",adapter="lore",level="xpl200_funeral",placement={"goxpl200_ents_nooffset","goxpl200_ents"},owner={"gobeachloremarker","goxpl200_ents_nooffset","goxpl200_ents"},extra=nil},{id="legendary_chest_ede160a54530f55a7667f5a39257843c",adapter="chest",level="xpl950_beachmaze",placement={"gochest_legendary_tier4_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},extra=nil},{id="legendary_chest_8002f429448617523d189cbd93b23d4b",adapter="chest",level="hel100_calderaheldressing",placement={"gochest_legendary_tier4_hel100_1","godrainvaultsetup2","gohel100_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_hel100_1","godrainvaultsetup2","gohel100_ents"},extra=nil},{id="coffin_345de6844e1e09c6d4d6a6b4133a793c",adapter="chest",level="xpl300_stronghold",placement={"gocoffin_tier3_xpl300_1","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl300_1","goxpl300_ents_nooffset","goxpl300_ents"},extra="gochestscript"},{id="wooden_chest_9796b08ff6484677f92dc5c548be592e",adapter="chest",level="for900_exitclimb",placement={"gochest_common_tier1_for900_1","gofor900_ents"},owner={"gochest_common_parent","gochest_common_tier1_for900_1","gofor900_ents"},extra="gochestscript"},{id="realm_tear_a3857496e778be84cdb14938feb3885d",adapter="rift",level="for260_chiseldungeon",placement={"golpktrft_startfight","gofor260_cbt"},owner={"golootpocketgeo","golpktrft_startfight","gofor260_cbt"},extra=nil},{id="cipher_chest_acb38981cfa8d4a13490597c1bcc6dd8",adapter="chest",level="alf200_mazedark",placement={"gochest_dispell_tier1_alf200_1","goalf200_ents_nooffset","goalf200_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier1_alf200_1","goalf200_ents_nooffset","goalf200_ents"},extra="gochestscript"},{id="wooden_chest_1346fea0dd6e8e5cb6868dbd2aa9109c",adapter="chest",level="xpl950_beachmaze",placement={"gochest_common_tier2_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},owner={"gochest_common_parent","gochest_common_tier2_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},extra="gochestscript"},{id="lore_marker_riv085dangersentrancelhwad0359c55688ca5b48bd66cf4ae66fbed3",adapter="lore",level="riv085_dangersentrancelh",placement={"goriv085_ents"},owner={"goriv085_runeread","goriv085_ents"},extra=nil},{id="coffin_ce102339a34a1ee210fb708cef487737",adapter="chest",level="peak720_summitascenthub",placement={"gocoffin_tier4_peak720_2","gopeak720_ents_nooffset","gopeak720_ents"},owner={"gocoffin_parent","gocoffin_tier4_peak720_2","gopeak720_ents_nooffset","gopeak720_ents"},extra="gochestscript"},{id="wooden_chest_33d0f7eadfc4eef14aadaa1e9b6c6143",adapter="chest",level="xpl300_stronghold",placement={"gochest_common_tier4_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gochest_common_parent","gochest_common_tier4_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},extra="gochestscript"},{id="cipher_chest_33234eeb6c2a418623f760e0dd11d24d",adapter="chest",level="cal250_foothillslh",placement={"gochest_dispell_tier1_cal250_1","go______loot","gocal250_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier1_cal250_1","go______loot","gocal250_ents"},extra="gochestscript"},{id="cipher_chest_5b8711edc0ecbc1775d18513dfd02be8",adapter="chest",level="xpl930_beachruins",placement={"gochest_dispell_tier3_xpl930_1","goxpl930_ents_nooffset","goxpl930_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier3_xpl930_1","goxpl930_ents_nooffset","goxpl930_ents"},extra="gochestscript"},{id="lore_marker_peak140caverndarkwad3aae61a66981c34082d9e3dcb14c9a39",adapter="lore",level="peak140_caverndark",placement={"gopeak140_ents"},owner={"goinktotem","gopeak140_ents"},extra=nil},{id="artefact_6cffc9884efa77b424baf987adfdba6a",adapter="artefact",level="xpl980_beachwaterfall",placement={"goartifactshiphead_ontower","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},owner={"goartifactscript","goartifactshiphead07","goartifactshiphead_ontower","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},extra=nil},{id="legendary_chest_ff46dfab43efcfc6f0f382a33e2b571d",adapter="chest",level="peak500_chimneytop",placement={"gochest_legendary_tier4_peak500_1","gopeak500_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_peak500_1","gopeak500_ents"},extra=nil},{id="cipher_chest_87d50dbd4e3737165c04ae74fe8ffbb7",adapter="chest",level="cal750_rightwing",placement={"gochest_dispell_tier5_cal750_1","gorightwing_gameplay","gocal750_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier5_cal750_1","gorightwing_gameplay","gocal750_ents"},extra="gochestscript"},{id="artefact_379728fc47e4a966be1fc9926011184b",adapter="artefact",level="xpl980_beachwaterfall",placement={"goartifactshiphead_incubby","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},owner={"goartifactscript","goartifactshiphead03","goartifactshiphead_incubby","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},extra=nil},{id="coffin_d6137b034219becb66bc80d10fd6511f",adapter="chest",level="xpl400_huldramines",placement={"gocoffin_tier4_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},owner={"gocoffin_parent","gocoffin_tier4_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},extra="gochestscript"},{id="artefact_989065ff4bde64f5ec957da2759037cb",adapter="artefact",level="for200_house",placement={"goartifacttoy02","goloot_toys","gofor200_ents"},owner={"goartifactscript","goartifacttoy02","goloot_toys","gofor200_ents"},extra=nil},{id="coffin_3756070dc04ddc15c61d57cb6c42e5ad",adapter="chest",level="alf600_templeint",placement={"gocoffin_tier1_alf600_1","gopickups","goalf600_ents_nooffset","goalf600_ents"},owner={"gocoffin_parent","gocoffin_tier1_alf600_1","gopickups","goalf600_ents_nooffset","goalf600_ents"},extra="gochestscript"},{id="lore_marker_alf150bridgedarkwad969e45f02f76844192ec5566056fbfd4",adapter="lore",level="alf150_bridgedark",placement={"goalf150_ents_nooffset","goalf150_ents"},owner={"gosonreadrune01","goruneread_beforegroup","goalf150_ents_nooffset","goalf150_ents"},extra=nil},{id="jotnar_shrine_19c69abd2cdf4145b71903eabdaf87f8",adapter="shrine",level="cal250_foothillslh",placement={"gotriptych","go______loot","gocal250_ents"},owner={"gotriptych","go______loot","gocal250_ents"},extra=nil},{id="coffin_2b66a5509901bb0ae8186134879d62fb",adapter="chest",level="xpl980_beachwaterfall",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_xpl980_1","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_xpl980_1","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},extra="gochestscript"},{id="coffin_81be3d2815990e8e6e34f3cc239fd25f",adapter="chest",level="xpl450_huldramines",placement={"gocoffin_tier4_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},owner={"gocoffin_parent","gocoffin_tier4_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},extra="gochestscript"},{id="lore_marker_xpl125httklhwad36f99a6c8537174bbaab95fb9d956455",adapter="lore",level="xpl125_httklh",placement={"goxpl125_ents_nooffset","goxpl125_ents"},owner={"goquestloremarker","goxpl125_ents_nooffset","goxpl125_ents"},extra=nil},{id="artefact_c7f91ac1447cff68599696bbbb58e7b7",adapter="artefact",level="hel350_chiselarena",placement={"goartifactbrooch01","gohel350_ents_nooffset","gohel350_ents"},owner={"goartifactscript","goartifactbrooch01","gohel350_ents_nooffset","gohel350_ents"},extra=nil},{id="realm_tear_664c0fd312a6e88d8739f7d5af968fe3",adapter="rift",level="cal100_hub",placement={"golootpocketrift940","gocal100_cbt"},owner={"golootpocketgeo","golootpocketrift940","gocal100_cbt"},extra=nil},{id="cipher_chest_bed904beed4cc9151ff7944a557ef0bb",adapter="chest",level="cal270_stonemasonlh",placement={"gochest_dispell_tier3_cal270_1","gocal270_ents_nooffset","gocal270_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier3_cal270_1","gocal270_ents_nooffset","gocal270_ents"},extra="gochestscript"},{id="coffin_0f897d994245a437eea02861452c1e22",adapter="chest",level="xpl300_stronghold",placement={"gocoffin_tier6_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gocoffin_parent","gocoffin_tier6_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},extra="gochestscript"},{id="treasure_map_3cab9691f053fec1dc02301cf9c04021",adapter="pickup",level="riv925_freyacave",placement={"gotreasuremapinteract_shipwreck","goriv925_cbt"},owner={"gotreasuremapinteract_shipwreck","goriv925_cbt"},extra=nil},{id="wooden_chest_a23662374dca6281eb791529945c7210",adapter="chest",level="peak200_chimneylow",placement={"gochest_common_tier3_peak200_1","gopeak200_ents_nooffset","gopeak200_ents"},owner={"gochest_common_parent","gochest_common_tier3_peak200_1","gopeak200_ents_nooffset","gopeak200_ents"},extra="gochestscript"},{id="wooden_chest_3ca0e634863fd2de8454b4713f9426c5",adapter="chest",level="riv325_dangersexit",placement={"gochest_common_tier1_riv325_3","goriv325_cbt"},owner={"gochest_common_parent","gochest_common_tier1_riv325_3","goriv325_cbt"},extra="gochestscript"},{id="artefact_eb672a1647b1f7e64595e48f821670f5",adapter="artefact",level="hel100_calderaheldressing",placement={"goartifactbrooch02","gohel100_ents"},owner={"goartifactscript","goartifactbrooch02","gohel100_ents"},extra=nil},{id="coffin_d2080e7d0c12a0ccc335b9b6364a3214",adapter="chest",level="alf340_trenchbdark",placement={"gocoffin_tier1_alf340_2","goloot","goalf340_ents_nooffset","goalf340_ents"},owner={"gocoffin_parent","gocoffin_tier1_alf340_2","goloot","goalf340_ents_nooffset","goalf340_ents"},extra="gochestscript"},{id="coffin_530e877c15dc4e8af94d97edcb0d27e9",adapter="chest",level="for260_chiseldungeon",placement={"gocoffin_tier1_for260_1","gofor260_ents"},owner={"gocoffin_parent","gocoffin_tier1_for260_1","gofor260_ents"},extra="gochestscript"},{id="realm_tear_2b6da4fe76312741d21ade4905d66ff4",adapter="rift",level="stn200_lakeext",placement={"golootpocketrift_1_a","gostn200_ents_nooffset","gostn200_ents"},owner={"golootpocketgeo","golootpocketrift_1_a","gostn200_ents_nooffset","gostn200_ents"},extra=nil},{id="wooden_chest_7ca006b2b340188300a7e79f6f83391a",adapter="chest",level="helr100_docks",placement={"gochest_common_tier4_helr100_4","gohelr100_ents"},owner={"gochest_common_parent","gochest_common_tier4_helr100_4","gohelr100_ents"},extra="gochestscript"},{id="legendary_chest_9d7648ab43bf99f90b0cbd86b0a998f1",adapter="chest",level="xpl400_huldramines",placement={"gochest_legendary_tier1_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier1_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},extra=nil},{id="wooden_chest_7cf0e761c72a66b9b4b45b7e640519a7",adapter="chest",level="stn200_lakeext",placement={"gochest_common_tier3_stn200_1","gostn200_ents_nooffset","gostn200_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn200_1","gostn200_ents_nooffset","gostn200_ents"},extra="gochestscript"},{id="wooden_chest_c9b78a83ed706e2f87e723017c735303",adapter="chest",level="hel100_calderaheldressing",placement={"gochest_common_tier4_hel100_1","gohel100_ents"},owner={"gochest_common_parent","gochest_common_tier4_hel100_1","gohel100_ents"},extra="gochestscript"},{id="coffin_e7c6bb7592f8d71352a303792bc5a6a6",adapter="chest",level="xpl960_beachship",placement={"gocoffin_tier3_xpl960_2","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl960_2","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},extra="gochestscript"},{id="coffin_483ef71604ed462813b9d2190ffc90cf",adapter="chest",level="xpl920_islandclimb",placement={"gocoffin_tier6_xpl920_1","gochestpickups_loot","goxpl920_ents_nooffset","goxpl920_ents"},owner={"gocoffin_parent","gocoffin_tier6_xpl920_1","gochestpickups_loot","goxpl920_ents_nooffset","goxpl920_ents"},extra="gochestscript"},{id="lore_marker_alf440hiveextlhwad0f75539e19bc0947ba4d6f46ea0a95d2",adapter="lore",level="alf440_hiveextlh",placement={"goalf440_ents_nooffset","goalf440_ents"},owner={"gosonreadrune","goalf440_ents_nooffset","goalf440_ents"},extra=nil},{id="wooden_chest_a351d959d938ab662188c62ebb286acc",adapter="chest",level="xpl450_huldramines",placement={"gochest_common_tier1_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},owner={"gochest_common_parent","gochest_common_tier1_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},extra="gochestscript"},{id="realm_tear_6f5037ce091595b1bc2b0ab31cfaf05b",adapter="rift",level="cal100_hub",placement={"gomisc_legendary_tier3_cal100_2","go____ziplift_riftsetup","gocal100_temple","gocal100_ents"},owner={"golootpocketgeo","gomisc_legendary_tier3_cal100_2","go____ziplift_riftsetup","gocal100_temple","gocal100_ents"},extra=nil},{id="coffin_89b943bbda8f5c15788d8c5fe3dd5d42",adapter="chest",level="hel100_calderaheldressing",placement={"gocoffin_tier4_hel100_1","godrainvault_setup","gohel100_ents"},owner={"gocoffin_parent","gocoffin_tier4_hel100_1","godrainvault_setup","gohel100_ents"},extra="gochestscript"},{id="wooden_chest_4120fd9bd6ee2470fe64e0c46ea7c515",adapter="chest",level="peak300_chimneymid",placement={"gochest_common_tier3_peak300_2","gopeak300_ents"},owner={"gochest_common_parent","gochest_common_tier3_peak300_2","gopeak300_ents"},extra="gochestscript"},{id="cipher_chest_4935b4ad6d592f85492c85bd0829dcb8",adapter="chest",level="cal740_leftwing",placement={"gochest_dispell_tier5_cal740_1","goleftwing_gameplay","gocal740_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier5_cal740_1","goleftwing_gameplay","gocal740_ents"},extra="gochestscript"},{id="lore_marker_cal500runevaultwad14f472bb0d9d2e4993d0774cbc755e02",adapter="lore",level="cal500_runevault",placement={"gocal500_ents"},owner={"gosonreadrune","gowad","gocal500_ents"},extra=nil},{id="lore_marker_peak200chimneylowwad29a3fec3318213458a458abb0eb539a2",adapter="lore",level="peak200_chimneylow",placement={"gopeak200_ents_nooffset","gopeak200_ents"},owner={"gosonreadrune","gopeak200_ents_nooffset","gopeak200_ents"},extra=nil},{id="artefact_xpl200funeralwadbb9465a7407c9849bf891e0205dac801",adapter="artefact",level="xpl200_funeral",placement={"goartifacthorn05","goxpl200_ents_nooffset","goxpl200_ents"},owner={"goartifactscript","goartifacthorn05","goxpl200_ents_nooffset","goxpl200_ents"},extra=nil},{id="wooden_chest_8836735f3c50fd90d214306b51ebeb79",adapter="chest",level="alf355_chiseldungeon",placement={"gochest_common_tier1_alf355_4","gochests_01","goalf355_ents_nooffset","goalf355_ents"},owner={"gochest_common_parent","gochest_common_tier1_alf355_4","gochests_01","goalf355_ents_nooffset","goalf355_ents"},extra="gochestscript"},{id="wooden_chest_255bd08484850591a8c5077c4efd6b64",adapter="chest",level="xpl940_beachcave",placement={"gochest_common_tier2_xpl940_2","gogameplay_objects","goxpl940_ents_nooffset","goxpl940_ents"},owner={"gochest_common_parent","gochest_common_tier2_xpl940_2","gogameplay_objects","goxpl940_ents_nooffset","goxpl940_ents"},extra="gochestscript"},{id="coffin_a2ec2e348926ce92a6dbfa84d1bb3729",adapter="chest",level="stn110_chiselarena",placement={"gocoffin_tier1_stn110_1","gochests_03","gostn110_ents_nooffset","gostn110_ents"},owner={"gocoffin_parent","gocoffin_tier1_stn110_1","gochests_03","gostn110_ents_nooffset","gostn110_ents"},extra="gochestscript"},{id="wooden_chest_c75b16bed331d5ab90b8d6e7a6a742ac",adapter="chest",level="for660_templeinterior",placement={"gochest_common_tier1_for660_3","goloot","gofor660_ents"},owner={"gochest_common_parent","gochest_common_tier1_for660_3","goloot","gofor660_ents"},extra="gochestscript"},{id="lore_marker_xpl650masontrailcavewadb2f0bf0705313e4aa27b33fddd3a0665",adapter="lore",level="xpl650_masontrailcave",placement={"goxpl650_ents_nooffset","goxpl650_ents"},owner={"goquestloremarker","goquestloremarker_01","goxpl650_ents_nooffset","goxpl650_ents"},extra=nil},{id="wooden_chest_34c065eb3609a2c1366263e3f493dfa3",adapter="chest",level="for260_chiseldungeon",placement={"gochest_common_tier5_for260_2","gochests_04","gofor260_ents"},owner={"gochest_common_parent","gochest_common_tier5_for260_2","gochests_04","gofor260_ents"},extra="gochestscript"},{id="lore_marker_riv420forestboarstartwad0c671129ecb3144cbcf4a641a4160b66",adapter="lore",level="riv420_forestboarstart",placement={"goriv420_ents"},owner={"goriv420_loremarker","goriv420_ents"},extra=nil},{id="treasure_map_ce589a091d984c3581097a8700aad61d",adapter="pickup",level="xpl450_huldramines",placement={"gopasted__treasuremapinteract","goxpl450_ents_nooffset","goxpl450_ents"},owner={"gopasted__treasuremapinteract","goxpl450_ents_nooffset","goxpl450_ents"},extra=nil},{id="coffin_6fc14ea5854a3ac8af7a57a05be00c91",adapter="chest",level="xpl850_dungeonforest",placement={"gocoffin_tier4_xpl850_1","goloot","goxpl850_ents_nooffset","goxpl850_ents"},owner={"gocoffin_parent","gocoffin_tier4_xpl850_1","goloot","goxpl850_ents_nooffset","goxpl850_ents"},extra="gochestscript"},{id="coffin_f0c400642e139948e733d79ec3119f47",adapter="chest",level="xpl150_httktemple",placement={"gocoffin_tier4_xpl150_1","goxpl150_ents_nooffset","goxpl150_ents"},owner={"gocoffin_parent","gocoffin_tier4_xpl150_1","goxpl150_ents_nooffset","goxpl150_ents"},extra="gochestscript"},{id="lore_marker_xpl250funeralinteriorwadd1ddaedac0dbac478444718ac2f19211",adapter="lore",level="xpl250_funeralinterior",placement={"goxpl250_ents_nooffset","goxpl250_ents"},owner={"goquestloremarker","goloremarker","goxpl250_ents_nooffset","goxpl250_ents"},extra=nil},{id="treasure_dig_ebcc555c3dc8b13561d8afa2bd4c0ba0",adapter="dig",level="xpl300_stronghold",placement={"gotreasuremap_dig_tier3_xpl300_1","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gotreasuremap_dig_tier3_xpl300_1","goxpl300_ents_nooffset","goxpl300_ents"},extra=nil},{id="coffin_fbad02805a974b9087885a0c497e34ca",adapter="chest",level="xpl450_huldramines",placement={"gocoffin_tier3_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},extra="gochestscript"},{id="legendary_chest_91a9f92a45d2d3fdb92279b4612ab5d7",adapter="chest",level="alf370_moatscripting",placement={"gochest_legendary_tier2_alf370_1","gopickups","goalf370_ents_nooffset","goalf370_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier2_alf370_1","gopickups","goalf370_ents_nooffset","goalf370_ents"},extra=nil},{id="wooden_chest_e22d823077569012bc63ecaf45563e77",adapter="chest",level="xpl910_islandshipwreck",placement={"gochest_common_tier1_xpl910_1","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gochest_common_parent","gochest_common_tier1_xpl910_1","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},extra="gochestscript"},{id="realm_tear_cb9a35e72a6bd571c820349c901762a9",adapter="rift",level="xpl920_islandclimb",placement={"gopocketrift_loot","go______lightcrystal_pocketrift","goxpl920_ents_nooffset","goxpl920_ents"},owner={"golootpocketgeo","gopocketrift_loot","go______lightcrystal_pocketrift","goxpl920_ents_nooffset","goxpl920_ents"},extra=nil},{id="coffin_bc47cbf3655df68aa52d3948f29070ef",adapter="chest",level="foot100_base",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_foot100_1","go______posionsetup_vibratehall","gofoot100_ents"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_foot100_1","go______posionsetup_vibratehall","gofoot100_ents"},extra="gochestscript"},{id="coffin_73a23f0e4255942c300031a188e8a525",adapter="chest",level="alf325_trenchadarktwr",placement={"gocoffin_tier2_alf325_1","goloot","goalf325_ents_nooffset","goalf325_ents"},owner={"gocoffin_parent","gocoffin_tier2_alf325_1","goloot","goalf325_ents_nooffset","goalf325_ents"},extra="gochestscript"},{id="lore_marker_xpl300strongholdwad79d7700bc6e8cf47a77b5403426b5297",adapter="lore",level="xpl300_stronghold",placement={"goxpl300_ents_nooffset","goxpl300_ents"},owner={"goshipruneread","goxpl300_shipruneread","goxpl300_ents_nooffset","goxpl300_ents"},extra=nil},{id="lore_marker_xpl910islandshipwreckwad6093995aaaf7ad4b9830d1be0e7e0684",adapter="lore",level="xpl910_islandshipwreck",placement={"golakeofnine_lightbeacon","go____introcaldera_quest","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gopsoninteractrune","goquest_lightbeacon_root","golakeofnine_lightbeacon","go____introcaldera_quest","goxpl910_ents_nooffset","goxpl910_ents"},extra=nil},{id="coffin_9b316d325ff8c810a3d018399ab0a1fe",adapter="chest",level="foot200_mid",placement={"gocoffin_tier1_foot200_1","go___poisentotemchestsetup___","gofoot200_ents"},owner={"gocoffin_parent","gocoffin_tier1_foot200_1","go___poisentotemchestsetup___","gofoot200_ents"},extra="gochestscript"},{id="coffin_a1c849de7c794dae09f118bbf46d8dcb",adapter="chest",level="xpl200_funeral",placement={"gocoffin_tier1_xpl200_1","gocontainers","goxpl200_ents_nooffset","goxpl200_ents"},owner={"gocoffin_parent","gocoffin_tier1_xpl200_1","gocontainers","goxpl200_ents_nooffset","goxpl200_ents"},extra="gochestscript"},{id="artefact_33f59ee746f63f40199e5f90cad3c236",adapter="artefact",level="peak210_rollerroomlh",placement={"goartifactcup02","gopeak210_ents_nooffset","gopeak210_ents"},owner={"goartifactscript","goartifactcup02","gopeak210_ents_nooffset","gopeak210_ents"},extra=nil},{id="wooden_chest_dac0fe6519eac4b9df6b377f533a73ac",adapter="chest",level="stn300_huldracamp",placement={"gochest_common_tier3_stn300_1","gostn300_ents_nooffset","gostn300_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn300_1","gostn300_ents_nooffset","gostn300_ents"},extra="gochestscript"},{id="wooden_chest_bc78435c8826037845b826e1cca23653",adapter="chest",level="xpl970_beachtower",placement={"gochest_common_tier1_xpl970_1","gopickups","goxpl970_ents_nooffset","goxpl970_ents"},owner={"gochest_common_parent","gochest_common_tier1_xpl970_1","gopickups","goxpl970_ents_nooffset","goxpl970_ents"},extra="gochestscript"},{id="artefact_0da7cb9744da59cb80fe319d95cada55",adapter="artefact",level="riv325_dangersexit",placement={"goartifactmask06","goriv325_cbt"},owner={"goartifactscript","goartifactmask06","goriv325_cbt"},extra=nil},{id="artefact_c9b7e23040c21e2da5fe8ba4be8ad415",adapter="artefact",level="riv350_calderavista",placement={"goartifactmask07","goriv350_cbt"},owner={"goartifactscript","goartifactmask07","goriv350_cbt"},extra=nil},{id="legendary_chest_48f9e1694dc722a549f42893d5b79d9f",adapter="chest",level="alfdgn110_main",placement={"gochest_legendary_tier1_alfdgn110_1","gofloorpuzzle","goalfdgn110_ents_nooffset","goalfdgn110_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier1_alfdgn110_1","gofloorpuzzle","goalfdgn110_ents_nooffset","goalfdgn110_ents"},extra=nil},{id="wooden_chest_2d4638fc479567132f4d797b9b327c48",adapter="chest",level="xpl300_stronghold",placement={"gochest_common_tier3_xpl300_3","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl300_3","goxpl300_ents_nooffset","goxpl300_ents"},extra="gochestscript"},{id="realm_tear_ae12a2c33fd8e441bf159a5fd7ac3c22",adapter="rift",level="cal100_hub",placement={"gopocketriftdbang","goceb_v1","gocal100_ents"},owner={"golootpocketgeo","gopocketriftdbang","goceb_v1","gocal100_ents"},extra=nil},{id="coffin_f2e02def29ac042044af2ff35637b2a9",adapter="chest",level="hel300_mainbridge",placement={"gocoffin_tier1_hel300_1","gohel300_ents"},owner={"gocoffin_parent","gocoffin_tier1_hel300_1","gohel300_ents"},extra="gochestscript"},{id="legendary_chest_b97f559c471fab8850a2ae8741370020",adapter="chest",level="alfdgn210_main",placement={"gochest_legendary_tier2_alfdgn210_1","goalfdgn210_ents_nooffset","goalfdgn210_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier2_alfdgn210_1","goalfdgn210_ents_nooffset","goalfdgn210_ents"},extra=nil},{id="lore_marker_peak720summitascenthubwadda8178f1357e8d45922a657e6f760dd8",adapter="lore",level="peak720_summitascenthub",placement={"gopeak720_ents_nooffset","gopeak720_ents"},owner={"goquestloremarker","gopeak720_ents_nooffset","gopeak720_ents"},extra=nil},{id="coffin_8eed9a4a0e0b5390ea90c84406f8f8ce",adapter="chest",level="alf340_trenchbdark",placement={"gocoffin_tier1_alf340_4","goliftingblock","goalf340_ents_nooffset","goalf340_ents"},owner={"gocoffin_parent","gocoffin_tier1_alf340_4","goliftingblock","goalf340_ents_nooffset","goalf340_ents"},extra="gochestscript"},{id="wooden_chest_d122572886b8c92453a055b03706a6ce",adapter="chest",level="xpl400_huldramines",placement={"gochest_common_tier4_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},owner={"gochest_common_parent","gochest_common_tier4_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},extra="gochestscript"},{id="coffin_dafb5c49c183bb638b57c1be03863ecf",adapter="chest",level="riv225_dangerscave",placement={"gocoffin_tier1_riv225_2","goriv225_cbt"},owner={"gocoffin_parent","gocoffin_tier1_riv225_2","goriv225_cbt"},extra="gochestscript"},{id="artefact_0a43e4954d4fff46abb9ca8e34d875c0",adapter="artefact",level="riv200_dangersmain",placement={"goartifactmask05","goriv200_cbt"},owner={"goartifactscript","goartifactmask05","goriv200_cbt"},extra=nil},{id="wooden_chest_7f6a0836ac388c5b79f08b6048cb998d",adapter="chest",level="xpl600_masontrail",placement={"gochest_common_tier3_xpl600_1","go____loot","goxpl600_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl600_1","go____loot","goxpl600_ents"},extra="gochestscript"},{id="coffin_e07e5ac1b623623c121b01c2481f504f",adapter="chest",level="hel350_chiselarena",placement={"gocoffin_tier1_hel350_1","gohel350_ents_nooffset","gohel350_ents"},owner={"gocoffin_parent","gocoffin_tier1_hel350_1","gohel350_ents_nooffset","gohel350_ents"},extra="gochestscript"},{id="coffin_92217ff2537c4eca00ca2387cb7a1a42",adapter="chest",level="peak300_chimneymid",placement={"gocoffin_tier3_peak300_1","goturrentanimattachgroup","goturretbaseparent","gopeak300_ents"},owner={"gocoffin_parent","gocoffin_tier3_peak300_1","goturrentanimattachgroup","goturretbaseparent","gopeak300_ents"},extra="gochestscript"},{id="coffin_d468c7d58a26674aa3b5b16dc0e79eaf",adapter="chest",level="xpl910_islandshipwreck",placement={"gocoffin_tier3_xpl910_1","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl910_1","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},extra="gochestscript"},{id="coffin_715ae2ff1980d3bfee797f2dd1481ec8",adapter="chest",level="foot100_base",placement={"gocoffin_tier3_foot100_2","go______posionsetup_vibratehall","gofoot100_ents"},owner={"gocoffin_parent","gocoffin_tier3_foot100_2","go______posionsetup_vibratehall","gofoot100_ents"},extra="gochestscript"},{id="lore_marker_xpl400huldramineswade1701a5ddf529645b442371f82145220",adapter="lore",level="xpl400_huldramines",placement={"goxpl400_qst_nooffset","goxpl400_qst"},owner={"gooutsideruneread","goxpl400_qst_nooffset","goxpl400_qst"},extra=nil},{id="coffin_d45ead0e44bc195bc94e7ec18de2edb3",adapter="chest",level="xpl220_funerallh",placement={"gocoffin_tier1_xpl250_1","goxpl220_ents_nooffset","goxpl220_ents"},owner={"gocoffin_parent","gocoffin_tier1_xpl250_1","goxpl220_ents_nooffset","goxpl220_ents"},extra="gochestscript"},{id="lore_marker_riv475freyahouseextwad5124f330461a8e42b1659c4517e18c29",adapter="lore",level="riv475_freyahouseext",placement={"goriv475_ents"},owner={"gosonreadrune1","goriv475_ents"},extra=nil},{id="artefact_01a8ba24409b5fb49a1c18b43669fe44",adapter="artefact",level="xpl970_beachtower",placement={"goartifactshiphead02xx01xx","gospecialpickups","goxpl970_ents_nooffset","goxpl970_ents"},owner={"goartifactscript","goartifactshiphead02","goartifactshiphead02xx01xx","gospecialpickups","goxpl970_ents_nooffset","goxpl970_ents"},extra=nil},{id="legendary_chest_040af4fa440ef7ba52f8e8b317ac3200",adapter="chest",level="alf600_templeint",placement={"gochest_legendary_tier1_alf600_1","gopickups","goalf600_ents_nooffset","goalf600_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier1_alf600_1","gopickups","goalf600_ents_nooffset","goalf600_ents"},extra=nil},{id="lore_marker_cal250foothillslhwadb456381ff98fb449896acb659da524fa",adapter="lore",level="cal250_foothillslh",placement={"gocal250_ents"},owner={"goloremarker_02_readpoint","go_____infomarkers","gocal250_ents"},extra=nil},{id="legendary_chest_9f29650a4a8a5d0eb8bc43af1dbd3d68",adapter="chest",level="peak200_chimneylow",placement={"gochest_legendary_tier3_peak200_1","gopeak200_ents_nooffset","gopeak200_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier3_peak200_1","gopeak200_ents_nooffset","gopeak200_ents"},extra=nil},{id="coffin_6b028789691d219730cefc4630c393f0",adapter="chest",level="riv925_freyacave",placement={"gocoffin_tier1_riv925_1","goriv925_cbt"},owner={"gocoffin_parent","gocoffin_tier1_riv925_1","goriv925_cbt"},extra="gochestscript"},{id="wooden_chest_8fd4ea6fbc9f86102aa363311d694995",adapter="chest",level="hel300_mainbridge",placement={"gochest_common_tier4_hel300_1","gohel300_ents"},owner={"gochest_common_parent","gochest_common_tier4_hel300_1","gohel300_ents"},extra="gochestscript"},{id="coffin_edcb1025a189bc2022b512d6bebaf11a",adapter="chest",level="cal500_runevault",placement={"gocoffin_tier1_cal500_1","gotrapfloorshake","gooutertrapfloor","gowad","gocal500_ents"},owner={"gocoffin_parent","gocoffin_tier1_cal500_1","gotrapfloorshake","gooutertrapfloor","gowad","gocal500_ents"},extra="gochestscript"},{id="wooden_chest_02cb4383595ac1f75f02d048497910be",adapter="chest",level="alf355_chiseldungeon",placement={"gochest_common_tier1_alf355_2","gochests_01","goalf355_ents_nooffset","goalf355_ents"},owner={"gochest_common_parent","gochest_common_tier1_alf355_2","gochests_01","goalf355_ents_nooffset","goalf355_ents"},extra="gochestscript"},{id="treasure_dig_8d79870871fe184c47d369eabbd68f92",adapter="dig",level="xpl850_dungeonforest",placement={"gotreasure_dig_common_tier2_xpl850_1","goxpl850_ents_nooffset","goxpl850_ents"},owner={"gotreasure_dig_common_tier2_xpl850_1","goxpl850_ents_nooffset","goxpl850_ents"},extra=nil},{id="artefact_bd9a46a34b8fd4660be2129e27fa4004",adapter="artefact",level="xpl960_beachship",placement={"goartifactshiphead_ontower","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},owner={"goartifactscript","goartifactshiphead09","goartifactshiphead_ontower","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},extra=nil},{id="coffin_b9137381c8685a442887b317281334c3",adapter="chest",level="stn550_chasmclimb",placement={"gocoffin_tier3_stn150_1","gostn550_ents_nooffset","gostn550_ents"},owner={"gocoffin_parent","gocoffin_tier3_stn150_1","gostn550_ents_nooffset","gostn550_ents"},extra="gochestscript"},{id="coffin_082e60a8f756390671c4ffa499ce98a2",adapter="chest",level="alf440_hiveextlh",placement={"gocoffin_tier1_alf440_1","golootcoffin_tendrilcovered","goalf440_ents_nooffset","goalf440_ents"},owner={"gocoffin_parent","gocoffin_tier1_alf440_1","golootcoffin_tendrilcovered","goalf440_ents_nooffset","goalf440_ents"},extra="gochestscript"},{id="coffin_e2d0ecbabcb5a115e49005576bc680e0",adapter="chest",level="stn150_handunder",placement={"gocoffin_tier3_stn150_1","gostn150_ents_nooffset","gostn150_ents"},owner={"gocoffin_parent","gocoffin_tier3_stn150_1","gostn150_ents_nooffset","gostn150_ents"},extra="gochestscript"},{id="wooden_chest_f8e1e11f0be082351c02df2da90c1f5b",adapter="chest",level="xpl875_dungeonforestlh",placement={"gochest_common_tier4_xpl875_1","gochests","goxpl875_ents_nooffset","goxpl875_ents"},owner={"gochest_common_parent","gochest_common_tier4_xpl875_1","gochests","goxpl875_ents_nooffset","goxpl875_ents"},extra="gochestscript"},{id="jotnar_shrine_b124fa2d62938dc8fcf85d67432d8550",adapter="shrine",level="xpl150_httktemple",placement={"gotriptych_starkadr","goxpl150_nar_nooffset","goxpl150_nar"},owner={"gotriptych_starkadr","goxpl150_nar_nooffset","goxpl150_nar"},extra=nil},{id="wooden_chest_586cacd7a21c53dd2be423e91e59a256",adapter="chest",level="xpl450_huldramines",placement={"gochest_common_tier3_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},extra="gochestscript"},{id="treasure_map_4a07636dc59583c9bfe877849ab5a97f",adapter="pickup",level="xpl960_beachship",placement={"gotreasuremapinteract_islandarch","goxpl960_ents_nooffset","goxpl960_ents"},owner={"gotreasuremapinteract_islandarch","goxpl960_ents_nooffset","goxpl960_ents"},extra=nil},{id="lore_marker_xpl220funerallhwadeea6c57321539249a4d58ca8baa527cb",adapter="lore",level="xpl220_funerallh",placement={"goxpl220_ents_nooffset","goxpl220_ents"},owner={"goquestloremarker1","goxpl220_ents_nooffset","goxpl220_ents"},extra=nil},{id="artefact_f7fbfc3f44991b3da37871879e6de737",adapter="artefact",level="cal100_hub",placement={"goartifactshiphead08","gocal100bridge","gocalderabridge","gocalbridge_refnode","gocal100_ents"},owner={"goartifactscript","goartifactshiphead08","gocal100bridge","gocalderabridge","gocalbridge_refnode","gocal100_ents"},extra=nil},{id="cipher_chest_f2220e936a3394ddfe1443657707b770",adapter="chest",level="cal820_snakebellymid",placement={"gochest_dispell_tier5_cal750_1","goanim_swingarm","gospinnablecrane","gospincranemechanism","gocal820_ents_nooffset","gocal820_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier5_cal750_1","goanim_swingarm","gospinnablecrane","gospincranemechanism","gocal820_ents_nooffset","gocal820_ents"},extra="gochestscript"},{id="wooden_chest_53fd52ac3bb61b72dd6c99bf58b56968",adapter="chest",level="xpl400_huldramines",placement={"gochest_common_tier2_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},owner={"gochest_common_parent","gochest_common_tier2_xpl400_1","gochests","goxpl400_ents_nooffset","goxpl400_ents"},extra="gochestscript"},{id="wooden_chest_f743cadced96375893da7bd242fd68c0",adapter="chest",level="helr100_docks",placement={"gochest_common_tier4_helr100_1","gohelr100_ents"},owner={"gochest_common_parent","gochest_common_tier4_helr100_1","gohelr100_ents"},extra="gochestscript"},{id="wooden_chest_affb01a0b9017affae4a4d18ca3e61b7",adapter="chest",level="riv925_freyacave",placement={"gochest_common_tier1_riv925_4","goriv925_cbt"},owner={"gochest_common_parent","gochest_common_tier1_riv925_4","goriv925_cbt"},extra="gochestscript"},{id="realm_tear_12672293750dfc6b1381cf5159ad0615",adapter="rift",level="xpl920_islandclimb",placement={"golootpocketrift920","goxpl920_cbt_nooffset","goxpl920_cbt"},owner={"golootpocketgeo","golootpocketrift920","goxpl920_cbt_nooffset","goxpl920_cbt"},extra=nil},{id="wooden_chest_d9b5e3ceb301b036b7cb78f409810ff3",adapter="chest",level="xpl980_beachwaterfall",placement={"gochest_common_tier3_xpl980_2","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl980_2","go____loot","goxpl980_ents_nooffset","goxpl980_ents"},extra="gochestscript"},{id="lore_marker_xpl400huldramineswadf014bd94366e7b49ade008aff1769396",adapter="lore",level="xpl400_huldramines",placement={"goxpl400_qst_nooffset","goxpl400_qst"},owner={"goquestdwarvenrunes","goxpl400_qst_nooffset","goxpl400_qst"},extra=nil},{id="wooden_chest_47feaa163975e37d55a81abb7bffba4e",adapter="chest",level="xpl300_stronghold",placement={"gochest_common_tier3_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},extra="gochestscript"},{id="lore_marker_alf150bridgedarkwad76250fcb340065498ff1b75bddd20fcf",adapter="lore",level="alf150_bridgedark",placement={"goalf150_ents_nooffset","goalf150_ents"},owner={"gosonreadrune01_alt","goruneread_aftergroup","goalf150_ents_nooffset","goalf150_ents"},extra=nil},{id="coffin_906db69b1c98e210bfd711cea88cd266",adapter="chest",level="peak205_chiselarena",placement={"gocoffin_tier1_peak205_1","gopeak205_ents_nooffset","gopeak205_ents"},owner={"gocoffin_parent","gocoffin_tier1_peak205_1","gopeak205_ents_nooffset","gopeak205_ents"},extra="gochestscript"},{id="legendary_chest_11e085df4bd47deee3a3448bff9efc62",adapter="chest",level="riv475_freyahouseext",placement={"gochest_legendary_scripted","goriv475_cbt"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_scripted","goriv475_cbt"},extra=nil},{id="lore_marker_nid150calderabridgewad2eabc6ebc9dafd40b34cb41a6ffcd2d4",adapter="lore",level="nid150_calderabridge",placement={"gonid150_ents_nooffset","gonid150_ents"},owner={"goniflheimstatuec6","go____runeread","gonid150_ents_nooffset","gonid150_ents"},extra=nil},{id="treasure_map_67ec3f2c214e4fd07a7eaf0b58cf213c",adapter="pickup",level="xpl400_huldramines",placement={"gotreasuremapinteract","goxpl400_ents_nooffset","goxpl400_ents"},owner={"gotreasuremapinteract","goxpl400_ents_nooffset","goxpl400_ents"},extra=nil},{id="cipher_chest_285a8836646562d9520d7c890d4ef3b4",adapter="chest",level="xpl970_beachtower",placement={"gochest_dispell_tier3_xpl970_1","gopickups","goxpl970_ents_nooffset","goxpl970_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier3_xpl970_1","gopickups","goxpl970_ents_nooffset","goxpl970_ents"},extra="gochestscript"},{id="coffin_5bf1f9791a9a6a851a98e8e377869fbd",adapter="chest",level="xpl100_httk",placement={"gocoffin_tier4_xpl100_1","goxpl100_ents_nooffset","goxpl100_ents"},owner={"gocoffin_parent","gocoffin_tier4_xpl100_1","goxpl100_ents_nooffset","goxpl100_ents"},extra="gochestscript"},{id="lore_marker_cal250foothillslhwad8ab6b877e9062c4b9f0d0f375f8326c1",adapter="lore",level="cal250_foothillslh",placement={"gocal250_ents"},owner={"goinvisibleinktotem_01","go_____inktotem","gocal250_ents"},extra=nil},{id="lore_scroll_2242aadeda389dae8c5283057c5326ca",adapter="pickup",level="riv225_dangerscave",placement={"gotreasuremapinteract","goriv225_ents"},owner={"gotreasuremapinteract","goriv225_ents"},extra=nil},{id="artefact_0d53040849957335c6db68809206f5d1",adapter="artefact",level="alf340_trenchbdark",placement={"goartifactalfheim03","goloot","goalf340_ents_nooffset","goalf340_ents"},owner={"goartifactscript","goartifactalfheim03","goloot","goalf340_ents_nooffset","goalf340_ents"},extra=nil},{id="artefact_5bb11ed5419b42caba813598d29ca473",adapter="artefact",level="xpl950_beachmaze",placement={"goartifactshiphead04","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},owner={"goartifactscript","goartifactshiphead04","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},extra=nil},{id="coffin_b6a51db40b1e73b0e8c6b24f08b9df77",adapter="chest",level="peak200_chimneylow",placement={"gocoffin_tier3_peak200_1","gopeak200_ents_nooffset","gopeak200_ents"},owner={"gocoffin_parent","gocoffin_tier3_peak200_1","gopeak200_ents_nooffset","gopeak200_ents"},extra="gochestscript"},{id="legendary_chest_d0b93e274754785e08235285bd6b78f2",adapter="chest",level="cal500_runevault",placement={"gochest_legendary_tier4_cal500_2","gotrapfloorshake","gooutertrapfloor","gowad","gocal500_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_cal500_2","gotrapfloorshake","gooutertrapfloor","gowad","gocal500_ents"},extra=nil},{id="legendary_chest_23d3213f45e38b632ed8048e876e472d",adapter="chest",level="xpl900_islandarch",placement={"gochest_legendary_tier3_xpl900_1","go____loot","goxpl900_ents_nooffset","goxpl900_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier3_xpl900_1","go____loot","goxpl900_ents_nooffset","goxpl900_ents"},extra=nil},{id="wooden_chest_a7543637312c028edf79cc16a060097e",adapter="chest",level="xpl920_islandclimb",placement={"gochest_common_tier2_xpl920_1","gochestpickups_loot","goxpl920_ents_nooffset","goxpl920_ents"},owner={"gochest_common_parent","gochest_common_tier2_xpl920_1","gochestpickups_loot","goxpl920_ents_nooffset","goxpl920_ents"},extra="gochestscript"},{id="coffin_07ad6c3ad556b93e9108d10af5a58d8a",adapter="chest",level="riv225_dangerscave",placement={"gocoffin_tier1_riv225_1","goriv225_cbt"},owner={"gocoffin_parent","gocoffin_tier1_riv225_1","goriv225_cbt"},extra="gochestscript"},{id="wooden_chest_7bec312d23c04016fae74ca647bb7bc0",adapter="chest",level="riv975_chiselarena",placement={"gochest_common_tier1_riv975_1","gochests_06","goriv975_ents_nooffset","goriv975_ents"},owner={"gochest_common_parent","gochest_common_tier1_riv975_1","gochests_06","goriv975_ents_nooffset","goriv975_ents"},extra="gochestscript"},{id="coffin_0efeb8c8cb24d3981a15a70321c096fe",adapter="chest",level="peak780_summitexit",placement={"gocoffin_tier4_peak780_1","gopeak780_ents_nooffset","gopeak780_ents"},owner={"gocoffin_parent","gocoffin_tier4_peak780_1","gopeak780_ents_nooffset","gopeak780_ents"},extra="gochestscript"},{id="jotnar_shrine_c0d7a4d17e152054e3e3c3e2571d98b8",adapter="shrine",level="riv225_dangerscave",placement={"gotriptychbasic","goriv225_ents"},owner={"gotriptychbasic","goriv225_ents"},extra=nil},{id="coffin_d5a198ed2f341b80b8b04b9a430c5c1c",adapter="chest",level="foot250_chiselarena",placement={"gocoffin_tier1_foot250_1","go___loot","gofoot250_ents_nooffset","gofoot250_ents"},owner={"gocoffin_parent","gocoffin_tier1_foot250_1","go___loot","gofoot250_ents_nooffset","gofoot250_ents"},extra="gochestscript"},{id="wooden_chest_e04dfd6c26cc8d4dd0bbce8bccd246ff",adapter="chest",level="xpl900_islandarch",placement={"gochest_common_tier3_xpl900_1","go____loot","goxpl900_ents_nooffset","goxpl900_ents"},owner={"gochest_common_parent","gochest_common_tier3_xpl900_1","go____loot","goxpl900_ents_nooffset","goxpl900_ents"},extra="gochestscript"},{id="wooden_chest_ea3cae8ef3136ef470f6d4b3fed9c6b2",adapter="chest",level="alfdgn210_main",placement={"gochest_common_tier1_alfdgn210_1","gorightexplorepickups","goalfdgn210_ents_nooffset","goalfdgn210_ents"},owner={"gochest_common_parent","gochest_common_tier1_alfdgn210_1","gorightexplorepickups","goalfdgn210_ents_nooffset","goalfdgn210_ents"},extra="gochestscript"},{id="coffin_f1b0d53b18c6d9100c9573cf006d0b63",adapter="chest",level="peak740_summitpeak",placement={"gocoffin_tier1_peak740_1","gopeak740_ents"},owner={"gocoffin_parent","gocoffin_tier1_peak740_1","gopeak740_ents"},extra="gochestscript"},{id="lore_marker_xpl300strongholdwade361f1b4a04c074b84896263475139ab",adapter="lore",level="xpl300_stronghold",placement={"goxpl300_ents_nooffset","goxpl300_ents"},owner={"goquestloremarker","goquestloremarker_01","goxpl300_ents_nooffset","goxpl300_ents"},extra=nil},{id="realm_tear_64256db4dca56cbedc9c2ad1bb454bef",adapter="rift",level="xpl200_funeral",placement={"gomisc_legendary_tier2_xpl200_1","goxpl200_ents_nooffset","goxpl200_ents"},owner={"golootpocketgeo","gomisc_legendary_tier2_xpl200_1","goxpl200_ents_nooffset","goxpl200_ents"},extra=nil},{id="artefact_56c4354a4141de7afc7f2e8447ab8767",adapter="artefact",level="alf345_trenchbdarktwr",placement={"goartifactalfheim05","gopickups","goalf345_ents_nooffset","goalf345_ents"},owner={"goartifactscript","goartifactalfheim05","gopickups","goalf345_ents_nooffset","goalf345_ents"},extra=nil},{id="cipher_chest_a120a8e8b11b778cebccfbe5aab211e9",adapter="chest",level="xpl940_beachcave",placement={"gochest_dispell_tier1_xpl940_1","goxpl940_ents_nooffset","goxpl940_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier1_xpl940_1","goxpl940_ents_nooffset","goxpl940_ents"},extra="gochestscript"},{id="coffin_44c42ab490af3bedc34e812cb537d913",adapter="chest",level="stn400_hammerbase",placement={"gocoffin_tier3_stn150_1","gostn400_ents_nooffset","gostn400_ents"},owner={"gocoffin_parent","gocoffin_tier3_stn150_1","gostn400_ents_nooffset","gostn400_ents"},extra="gochestscript"},{id="legendary_chest_a24ac28d4ea8598d880d7bb099b8b8be",adapter="chest",level="xpl300_stronghold",placement={"gochest_legendary_tier6_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gochestscript","gochest_legendary_parent","gochestobj","gochest_legendary_locked_roots_parent","gochest_legendary_tier6_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},extra=nil},{id="artefact_f5bd8953457f9662d074d798a111abfc",adapter="artefact",level="peak780_summitexit",placement={"goartifactcup06","gopeak780_ents_nooffset","gopeak780_ents"},owner={"goartifactscript","goartifactcup06","gopeak780_ents_nooffset","gopeak780_ents"},extra=nil},{id="lore_marker_xpl225funerallhwadfb3c8f6c096b464dafa89220022f8c54",adapter="lore",level="xpl225_funerallh",placement={"goxpl225_ents_nooffset","goxpl225_ents"},owner={"goquestloremarker","goxpl225_ents_nooffset","goxpl225_ents"},extra=nil},{id="treasure_map_8b1707f94ad818100dd4a5afc67fc6c6",adapter="pickup",level="xpl940_beachcave",placement={"gopasted__treasuremapinteract","goxpl940_ents_nooffset","goxpl940_ents"},owner={"gopasted__treasuremapinteract","goxpl940_ents_nooffset","goxpl940_ents"},extra=nil},{id="jotnar_shrine_b35ee9b618a76bfdf24596944d7b11b0",adapter="shrine",level="xpl970_beachtower",placement={"gotriptych_thrym","goxpl970_ents_nooffset","goxpl970_ents"},owner={"gotriptych_thrym","goxpl970_ents_nooffset","goxpl970_ents"},extra=nil},{id="coffin_27372e7163253c3104b397c707ea53bb",adapter="chest",level="helr100_docks",placement={"gocoffin_tier4_helr100_2","gohelr100_ents"},owner={"gocoffin_parent","gocoffin_tier4_helr100_2","gohelr100_ents"},extra="gochestscript"},{id="wooden_chest_32d3304f8c18fe1f9d5564e870022cb2",adapter="chest",level="alf355_chiseldungeon",placement={"gochest_common_tier1_alf355_1","gochests_01","goalf355_ents_nooffset","goalf355_ents"},owner={"gochest_common_parent","gochest_common_tier1_alf355_1","gochests_01","goalf355_ents_nooffset","goalf355_ents"},extra="gochestscript"},{id="wooden_chest_cdd6d123984e32a1c6857daaf4212181",adapter="chest",level="stn110_chiselarena",placement={"gochest_common_tier3_stn110_2","gochests_03","gostn110_ents_nooffset","gostn110_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn110_2","gochests_03","gostn110_ents_nooffset","gostn110_ents"},extra="gochestscript"},{id="jotnar_shrine_1af4f035065fe9603505c02d9b2e1462",adapter="shrine",level="cal170_library1",placement={"gotriptych_tyr","gocal170_nar_nooffset","gocal170_nar"},owner={"gotriptych_tyr","gocal170_nar_nooffset","gocal170_nar"},extra=nil},{id="wooden_chest_c0f40c082a0434d8ba5ee63ee743fb69",adapter="chest",level="for500_forestentry",placement={"gochest_common_tier1_for500_1","gofor500_ents"},owner={"gochest_common_parent","gochest_common_tier1_for500_1","gofor500_ents"},extra="gochestscript"},{id="artefact_6f83c0ef48eda412050135a827d51a7a",adapter="artefact",level="peak200_chimneylow",placement={"goartifactcup05","gopeak200_ents_nooffset","gopeak200_ents"},owner={"goartifactscript","goartifactcup05","gopeak200_ents_nooffset","gopeak200_ents"},extra=nil},{id="coffin_96381eab3f2918f7ebb47343422a8203",adapter="chest",level="xpl300_stronghold",placement={"gocoffin_tier5_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},owner={"gocoffin_parent","gocoffin_tier5_xpl300_1","goloot_container","goxpl300_ents_nooffset","goxpl300_ents"},extra="gochestscript"},{id="legendary_chest_0a04b4de469f3b030064d6827966b213",adapter="chest",level="foot400_arena",placement={"gochest_legendary_tier1_foot400_1","go_____loot","gofoot400_ents","gofoot400_ents_offset"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier1_foot400_1","go_____loot","gofoot400_ents","gofoot400_ents_offset"},extra=nil},{id="coffin_56534d8b5b802d5d59344beffd1fe9e6",adapter="chest",level="xpl450_huldramines",placement={"gocoffin_tier2_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},owner={"gocoffin_parent","gocoffin_tier2_xpl450_1","gochests","goxpl450_ents_nooffset","goxpl450_ents"},extra="gochestscript"},{id="legendary_chest_9226bd444f0f0b95dbeb7c927c6b317b",adapter="chest",level="xpl900_islandarch",placement={"gochest_legendary_tier4_xpl900_1","go____loot","goxpl900_ents_nooffset","goxpl900_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_xpl900_1","go____loot","goxpl900_ents_nooffset","goxpl900_ents"},extra=nil},{id="legendary_chest_f714d2d845a3dd9e28808db4655e757f",adapter="chest",level="cal740_leftwing",placement={"gochest_legendary_tier5_cal740_1","goleftwing_gameplay","gocal740_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier5_cal740_1","goleftwing_gameplay","gocal740_ents"},extra=nil},{id="wooden_chest_cb10ac445973e539532db961c1af4e8a",adapter="chest",level="peak500_chimneytop",placement={"gochest_common_tier4_peak500_1","gopeak500_ents"},owner={"gochest_common_parent","gochest_common_tier4_peak500_1","gopeak500_ents"},extra="gochestscript"},{id="cipher_chest_371db5ac6ac1a1ca6bfe75a33315fe6d",adapter="chest",level="xpl950_beachmaze",placement={"gochest_dispell_tier1_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier1_xpl950_1","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},extra="gochestscript"},{id="wooden_chest_f366e563226a159bf67b76e565795e3d",adapter="chest",level="cal100_hub",placement={"gochest_common_tier1_cal100_2","gocal100_ents"},owner={"gochest_common_parent","gochest_common_tier1_cal100_2","gocal100_ents"},extra="gochestscript"},{id="wooden_chest_c99b83ff35c4c302a595c64fc926d86e",adapter="chest",level="xpl650_masontrailcave",placement={"gochest_common_tier2_xpl650_2","godesign","goxpl650_ents_nooffset","goxpl650_ents"},owner={"gochest_common_parent","gochest_common_tier2_xpl650_2","godesign","goxpl650_ents_nooffset","goxpl650_ents"},extra="gochestscript"},{id="treasure_dig_4a770cc6263ef7c83b7ea0e4130c6c59",adapter="dig",level="xpl950_beachmaze",placement={"golootdirtpatch","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},owner={"golootdirtpatch","gopickups","goxpl950_ents_nooffset","goxpl950_ents"},extra=nil},{id="coffin_dccf636343f08c57b98bf198059a985f",adapter="chest",level="riv200_dangersmain",placement={"gocoffin_tier1_riv200_3","goriv200_cbt"},owner={"gocoffin_parent","gocoffin_tier1_riv200_3","goriv200_cbt"},extra="gochestscript"},{id="legendary_chest_b9e3be9a46c248cc0ddc159643259c52",adapter="chest",level="xpl960_beachship",placement={"gochest_legendary_tier3_xpl960_1","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier3_xpl960_1","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},extra=nil},{id="coffin_3340c954018839640be00a0955892015",adapter="chest",level="riv925_freyacave",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffinroots_tier3_riv925_1","goriv925_cbt"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffinroots_tier3_riv925_1","goriv925_cbt"},extra="gochestscript"},{id="coffin_7a8d01b3f8a471a6b7ae8d058f00f12b",adapter="chest",level="foot500_top",placement={"gocoffin_tier5_foot500_1","gobramblesetups","gofoot500_ents","gofoot500_ents_offset"},owner={"gocoffin_parent","gocoffin_tier5_foot500_1","gobramblesetups","gofoot500_ents","gofoot500_ents_offset"},extra="gochestscript"},{id="realm_tear_f4600a74cbfaceabd4ba6d80a59a66bc",adapter="rift",level="xpl960_beachship",placement={"gomisc_legendary_tier3_xpl960_1","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},owner={"golootpocketgeo","gomisc_legendary_tier3_xpl960_1","go____loot","goxpl960_ents_nooffset","goxpl960_ents"},extra=nil},{id="wooden_chest_2b8135ab4e8526519563c8c391f156f9",adapter="chest",level="stn110_chiselarena",placement={"gochest_common_tier3_stn110_1","gochests_03","gostn110_ents_nooffset","gostn110_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn110_1","gochests_03","gostn110_ents_nooffset","gostn110_ents"},extra="gochestscript"},{id="artefact_85c29c2b420306564c28b5b09e22532c",adapter="artefact",level="riv200_dangersmain",placement={"goartifactmask04","godraugr_fight_group","goriv200_cbt"},owner={"goartifactscript","goartifactmask04","godraugr_fight_group","goriv200_cbt"},extra=nil},{id="cipher_chest_83a70788cdf281a83161cd7e70101b11",adapter="chest",level="peak740_summitpeak",placement={"gochest_dispell_tier4_peak740_1","gopeak740_ents"},owner={"gochest_dispell_parent","gochest_dispell_tier4_peak740_1","gopeak740_ents"},extra="gochestscript"},{id="coffin_dfca3d7720861fb51244d4e8278d5ab5",adapter="chest",level="xpl225_funerallh",placement={"gocoffin_tier1_xpl225_2","goxpl225_ents_nooffset","goxpl225_ents"},owner={"gocoffin_parent","gocoffin_tier1_xpl225_2","goxpl225_ents_nooffset","goxpl225_ents"},extra="gochestscript"},{id="artefact_hel300mainbridgewad00c124ebae0bc24f8b64cc6305246b22",adapter="artefact",level="hel300_mainbridge",placement={"goartifactbrooch03","gohel300_ents"},owner={"goartifactscript","goartifactbrooch03","gohel300_ents"},extra=nil},{id="treasure_dig_1004498996e12e1bd865e937caf21f2d",adapter="dig",level="xpl600_masontrail",placement={"gotreasure_dig_tier3_xpl600_1","goxpl600_ents"},owner={"gotreasure_dig_tier3_xpl600_1","goxpl600_ents"},extra=nil},{id="lore_marker_xpl200funeralwadf8ceaf9fdf59ef4c97b6d4398c23bb9d",adapter="lore",level="xpl200_funeral",placement={"goxpl200_ents_nooffset","goxpl200_ents"},owner={"gocastleloremarker","goxpl200_ents_nooffset","goxpl200_ents"},extra=nil},{id="coffin_6dd3b15c19d26faac0ddfecf339a50ab",adapter="chest",level="peak720_summitascenthub",placement={"gocoffin_tier1_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"},owner={"gocoffin_parent","gocoffin_tier1_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"},extra="gochestscript"},{id="wooden_chest_43a2c9ef875eebd6fff86ba2324a982f",adapter="chest",level="for660_templeinterior",placement={"gochest_common_tier1_for660_2","goloot","gofor660_ents"},owner={"gochest_common_parent","gochest_common_tier1_for660_2","goloot","gofor660_ents"},extra="gochestscript"},{id="coffin_4cb03c66896412451b9a805908c61395",adapter="chest",level="xpl980_beachwaterfall",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_xpl980_3","goelevator_pathblocker","go____vibratedlift_setup","goxpl980_ents_nooffset","goxpl980_ents"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_xpl980_3","goelevator_pathblocker","go____vibratedlift_setup","goxpl980_ents_nooffset","goxpl980_ents"},extra="gochestscript"},{id="legendary_chest_957a57b3456bd17fd24751a66dbcf01c",adapter="chest",level="hel300_mainbridge",placement={"gochest_legendary_tier4_hel300_1","gohel300_ents"},owner={"gochestscript","gochest_legendary_parent","gochest_legendary_tier4_hel300_1","gohel300_ents"},extra=nil},{id="coffin_ea9eca6feb88066fe4fc1111549e67df",adapter="chest",level="stn600_chasmroom",placement={"gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_stn600_1","goloot","gostn600_ents_nooffset","gostn600_ents"},owner={"gocoffin_parent","gochestobj","gocoffin_locked_roots_parent","gocoffin_tier3_stn600_1","goloot","gostn600_ents_nooffset","gostn600_ents"},extra="gochestscript"},{id="realm_tear_c3d17070f981647e7189e2076fbcc55c",adapter="rift",level="xpl100_httk",placement={"gomisc_legendary_tier5_xpl100_1","goxpl100_ents_nooffset","goxpl100_ents"},owner={"golootpocketgeo","gomisc_legendary_tier5_xpl100_1","goxpl100_ents_nooffset","goxpl100_ents"},extra=nil},{id="coffin_5ee94e6e2d8b3f4f14621809c749f528",adapter="chest",level="riv325_dangersexit",placement={"golootcoffin_scripted","goriv325_cbt"},owner={"gocoffin_parent","golootcoffin_scripted","goriv325_cbt"},extra="gochestscript"},{id="lore_marker_xpl425huldramineslhwad7f236d968be3c14db2ecde8780a968a0",adapter="lore",level="xpl425_huldramineslh",placement={"goxpl425_ents_nooffset","goxpl425_ents"},owner={"goquestloremarker_xpl425","goxpl425_ents_nooffset","goxpl425_ents"},extra=nil},{id="coffin_711c078a74590cb2158c1d1ea7e73389",adapter="chest",level="xpl910_islandshipwreck",placement={"gocoffin_tier3_xpl910_3","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl910_3","go____loot","goxpl910_ents_nooffset","goxpl910_ents"},extra="gochestscript"},{id="treasure_dig_4ec60e59f32086918769282570d5b976",adapter="dig",level="xpl970_beachtower",placement={"gotreasuredig_thor_tier3_cal200","gotreasuremap_digspots","goxpl970_ents_nooffset","goxpl970_ents"},owner={"gotreasuredig_thor_tier3_cal200","gotreasuremap_digspots","goxpl970_ents_nooffset","goxpl970_ents"},extra=nil},{id="treasure_dig_c49a3435a3361bfb0f23ee7a0cecc202",adapter="dig",level="riv475_freyahouseext",placement={"gotreasuremap_dig_tier3_riv475_1","goriv475_cbt"},owner={"gotreasuremap_dig_tier3_riv475_1","goriv475_cbt"},extra=nil},{id="coffin_45c3d28bfce2949e7091ea076388005c",adapter="chest",level="xpl160_httkcavel",placement={"gocoffin_tier3_xpl160_1","goxpl160_ents_nooffset","goxpl160_ents"},owner={"gocoffin_parent","gocoffin_tier3_xpl160_1","goxpl160_ents_nooffset","goxpl160_ents"},extra="gochestscript"},{id="lore_marker_xpl170httkcaverwad776651e16e0bcd4995eaa2ad3e73f56a",adapter="lore",level="xpl170_httkcaver",placement={"goxpl170_ents_nooffset","goxpl170_ents"},owner={"gocaver_loremarker01","gocaver_questlore01","goxpl170_ents_nooffset","goxpl170_ents"},extra=nil},{id="coffin_02468d124aa5c0271a90ef15db3a4a9e",adapter="chest",level="for560_wolfpit",placement={"gocoffin_tier1_for560_1","gofor560_ents_nooffset","gofor560_ents"},owner={"gocoffin_parent","gocoffin_tier1_for560_1","gofor560_ents_nooffset","gofor560_ents"},extra="gochestscript"},{id="coffin_cecd3e1ed37118dbc783f38c40ee4803",adapter="chest",level="peak140_caverndark",placement={"gocoffin_tier3_peak140_1","gopeak140_ents"},owner={"gocoffin_parent","gocoffin_tier3_peak140_1","gopeak140_ents"},extra="gochestscript"},{id="coffin_8c8f0d2bb8dc26dc1867c39ec44b8c11",adapter="chest",level="cal700_templeflip",placement={"gocoffin_tier5_cal700_1","gofliproom_gameplay","gocal700_ents"},owner={"gocoffin_parent","gocoffin_tier5_cal700_1","gofliproom_gameplay","gocal700_ents"},extra="gochestscript"},{id="coffin_e8c9695dda4a836583ad311f9b98d043",adapter="chest",level="cal700_templeflip",placement={"gocoffin_tier1_cal700_1","gofliproom_gameplay","gocal700_ents"},owner={"gocoffin_parent","gocoffin_tier1_cal700_1","gofliproom_gameplay","gocal700_ents"},extra="gochestscript"},{id="coffin_e056e03bfc0b68e1f7569b3a03f72722",adapter="chest",level="foot400_arena",placement={"gocoffin_tier1_foot400_1","go_____loot","gofoot400_ents","gofoot400_ents_offset"},owner={"gocoffin_parent","gocoffin_tier1_foot400_1","go_____loot","gofoot400_ents","gofoot400_ents_offset"},extra="gochestscript"},{id="wooden_chest_8d860a080b9f385f3a3105e035d73ab3",adapter="chest",level="peak720_summitascenthub",placement={"gochest_common_tier3_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"},owner={"gochest_common_parent","gochest_common_tier3_peak720_1","gopeak720_ents_nooffset","gopeak720_ents"},extra="gochestscript"},{id="wooden_chest_7d184e88e7aca574911c6f1addd2a686",adapter="chest",level="peak205_chiselarena",placement={"gochest_common_tier5_peak205_2","gopeak205_ents_nooffset","gopeak205_ents"},owner={"gochest_common_parent","gochest_common_tier5_peak205_2","gopeak205_ents_nooffset","gopeak205_ents"},extra="gochestscript"},{id="coffin_4721aafec0abacd3c4adb354cdf6c224",adapter="chest",level="riv200_dangersmain",placement={"gocoffin_tier1_riv200_1","goriv200_cbt"},owner={"gocoffin_parent","gocoffin_tier1_riv200_1","goriv200_cbt"},extra="gochestscript"},{id="jotnar_shrine_8a16de1ec11694c5752092bd06e16978",adapter="shrine",level="cal720_lowercenterroom",placement={"gotriptychbasic","goelevatorroom","gocal720_ents"},owner={"gotriptychbasic","goelevatorroom","gocal720_ents"},extra=nil},{id="artefact_xpl200funeralwadb6e2b2a41a1b3e4c9ff1f8e5f877039a",adapter="artefact",level="xpl200_funeral",placement={"goartifacthorn03","goxpl200_ents_nooffset","goxpl200_ents"},owner={"goartifactscript","goartifacthorn03","goxpl200_ents_nooffset","goxpl200_ents"},extra=nil},{id="lore_marker_3d2e2f04d7df6a4b9a4e30601432871f",adapter="lore",level="cal740_leftwing",placement={"gocal740_ents"},owner={"gorune_19","gorunereading","goleftwing_gameplay","gocal740_ents"},extra=nil},{id="lore_marker_cal250foothillslhwad9614e6b2dfd34f4b86e932b59f2aa621",adapter="lore",level="cal250_foothillslh",placement={"gocal250_ents"},owner={"goloremarker_01_readpoint","go_____infomarkers","gocal250_ents"},extra=nil},{id="lore_marker_ab859d0b83766845bb0b0e69023e1c31",adapter="lore",level="riv925_freyacave",placement={"goriv925_ents"},owner={"gorune_12_well","goriv925_ents"},extra=nil},{id="wooden_chest_bcbcd78c5be5d2298f527c26f48c5563",adapter="chest",level="stn800_shortcut",placement={"gochest_common_tier3_stn800_1","gostn800_ents_nooffset","gostn800_ents"},owner={"gochest_common_parent","gochest_common_tier3_stn800_1","gostn800_ents_nooffset","gostn800_ents"},extra="gochestscript"}}, runtime)
  reader:Reset(epoch)
  local timerOK, timerlib = pcall(require, "core.timer")
  local fsmOK, fsm = pcall(require, "ui.fsm")
  if timerOK and fsmOK and timerlib.Timer and fsm.runList then
    runtime.timer = timerlib.Timer.New(fsm.runList, 0.1, function(timer)
      local ok, reason = pcall(function() runtime:Tick(timer:GetElapsedTime()) end)
      if not ok and reason ~= runtime.lastPollError then
        print("[CompletionistLocations] poll_failed reason=" .. tostring(reason))
        runtime.lastPollError = reason
      end
    end)
    runtime.timer.autoreset = true
    runtime.timer:Start()
  end
  print("[CompletionistLocations] reader_enabled=" .. tostring(reader.transport ~= nil) ..
    " timer_enabled=" .. tostring(runtime.timer ~= nil) .. " clock=ui_elapsed")
  _G.CompletionistMapV105LocationState = store
  _G.CompletionistMapV105LocationRuntime = runtime
  _G.CompletionistMapV105LocationAuthorityReady = function(restore)
    return runtime:AuthorityReady(restore)
  end
  local ok, thunk = pcall(require, "core.thunk")
  if ok and type(thunk) == "table" and type(thunk.Install) == "function" then
    thunk.Install("COMPLETIONIST_COLLECTIBLE_DIRTY_V1", function(...)
      for i=1,select('#',...) do
        local value=select(i,...)
        if type(value) == "string" then
          local level=value:match("^COLLECTIBLE_DIRTY_V1\t([%w_]+)$")
          if level then if runtime.loaded then runtime.loaded:Poll(level:lower()) end; if runtime then runtime:Poll() end end
        end
      end
    end)
  end
end
-- END COMPLETIONIST V0.10.5 LOCATION STATE
-- BEGIN COMPLETIONIST V0.10.5 COLLECTIBLE LOCATIONS
-- Hides collected pins using tri-state service with save-epoch isolation.
do
  local State = _G.CompletionistMapV105LocationState
  local runtime = _G.CompletionistMapV105LocationRuntime
  local activeMap, activeSelectionContext, cleanupPending
  local constsOK, constslib = pcall(require, "ui.consts")
  local AS_ForwardCycle_NoReset = (constsOK and type(constslib) == "table" and constslib.AS_ForwardCycle_NoReset) or 10
  local AS_Forward = (constsOK and type(constslib) == "table" and constslib.AS_Forward) or 0
  local categories = {
    {Family="artefact",Filter=-105,Label="ARTEFACTS",Title="Artefact"},
    {Family="lore_marker",Filter=-106,Label="LORE MARKERS",Title="Lore Marker"},
    {Family="legendary_chest",Filter=-107,Label="LEGENDARY CHESTS",Title="Legendary Chest"},
    {Family="cipher_chest",Filter=-108,Label="CIPHER CHESTS",Title="Cipher Chest"},
    {Family="wooden_chest",Filter=-109,Label="WOODEN CHESTS",Title="Wooden Chest"},
    {Family="coffin",Filter=-110,Label="RED CHESTS",Title="Red Chest"},
    {Family="jotnar_shrine",Filter=-111,Label="JOTNAR SHRINES",Title="Jotnar Shrine"},
    {Family="realm_tear",Filter=-112,Label="REALM TEARS",Title="Realm Tear"},
    {Family="treasure_map",Filter=-113,Label="TREASURE MAPS",Title="Treasure Map"},
    {Family="treasure_dig",Filter=-114,Label="TREASURE DIG SITES",Title="Treasure Dig Site"},
    {Family="lore_scroll",Filter=-115,Label="LORE SCROLLS",Title="Lore Scroll"},
  }
  local rows = {
    {Name="Completionist_V105_Artefact_4433d222aaa45596",IdString="23695069868910587",Family="artefact",Realm="Midgard",CatalogueId="artefact_xpl200funeralwad52e9ebf8ef1b3343b5d025a73ad6fa91",Native=false},
    {Name="Completionist_V105_TreasureMap_b08d1fd606f2ac8a",IdString="105212419728126111",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_b08d1fd606f2ac8a09bf8edc6d5a55b7",Native=false},
    {Name="Completionist_V105_LegendaryChest_c14a0f2b4559d859",IdString="206061753276262059",Family="legendary_chest",Realm="Alfheim",CatalogueId="legendary_chest_c14a0f2b4559d859347854bccb307f63",Native=false},
    {Name="Completionist_V105_LoreScroll_e8415d73adfe99aa",IdString="277651290682054662",Family="lore_scroll",Realm="Midgard",CatalogueId="lore_scroll_e8415d73adfe99aa45c8e142856455da",Native=false},
    {Name="Completionist_V105_LoreMarker_f7a1b6bcc644116a",IdString="312889399141227453",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_peak180enttochimneylhwadcc54f8d5e69b0945a3674ddc65276412",Native=false},
    {Name="Completionist_V105_LegendaryChest_50480b3a40fe25c4",IdString="389414827727138963",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_50480b3a40fe25c4770f81a7261cbcb8",Native=false},
    {Name="Completionist_V105_JotnarShrine_4f54c8b2f4d92780",IdString="456674976716698334",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_4f54c8b2f4d927800573fde8aece376f",Native=false},
    {Name="Completionist_V105_LegendaryChest_36cb588e41cb27a4",IdString="608146209769870284",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_36cb588e41cb27a4668052b4529b98a6",Native=false},
    {Name="Completionist_V105_WoodenChest_a64da46f0ee1e4a1",IdString="672987839078585565",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_a64da46f0ee1e4a1c4f1b4144c88b3eb",Native=false},
    {Name="Completionist_V105_LoreMarker_58623c4993dd10c7",IdString="720614789920637316",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_peak100entrancewadeda4d87459eae64ba0a1c556edca5809",Native=false},
    {Name="Completionist_V105_Coffin_514bb8121cc05fa7",IdString="728167673848140889",Family="coffin",Realm="Midgard",CatalogueId="coffin_514bb8121cc05fa714e491ef162eed3f",Native=false},
    {Name="Completionist_V105_LegendaryChest_ae9454d54e9c9a23",IdString="760452031549773426",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_ae9454d54e9c9a23f21941b41a4038d3",Native=false},
    {Name="Completionist_V105_LegendaryChest_ace99ef5472abcba",IdString="780282921820638529",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_ace99ef5472abcbac29bd2b396a3fdf3",Native=false},
    {Name="Completionist_V105_LegendaryChest_8266c175474b43a4",IdString="803820446510823458",Family="legendary_chest",Realm="Helheim",CatalogueId="legendary_chest_8266c175474b43a4d44938a75e21329d",Native=false},
    {Name="Completionist_V105_Coffin_e0e1c7e7bc737efb",IdString="904239233954223311",Family="coffin",Realm="Midgard",CatalogueId="coffin_e0e1c7e7bc737efbfacef065908c43d0",Native=false},
    {Name="Completionist_V105_WoodenChest_8f8823453060e8ad",IdString="904672562262953259",Family="wooden_chest",Realm="Alfheim",CatalogueId="wooden_chest_8f8823453060e8adbfbf26f01baa3427",Native=false},
    {Name="Completionist_V105_LegendaryChest_5b424870484e691c",IdString="920886171396205709",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_5b424870484e691ce32d19be71a03059",Native=false},
    {Name="Completionist_V105_JotnarShrine_682f1626cae370f1",IdString="967631422696448175",Family="jotnar_shrine",Realm="Muspelheim",CatalogueId="jotnar_shrine_682f1626cae370f11b4df300ae79219d",Native=false},
    {Name="Completionist_V105_Coffin_5240a7be264002ac",IdString="1015296533863010353",Family="coffin",Realm="Midgard",CatalogueId="coffin_5240a7be264002acbff660741e1607ef",Native=false},
    {Name="Completionist_V105_CipherChest_64d0d4b3bf836bbd",IdString="1116740731509784679",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_64d0d4b3bf836bbdca27451d720152f8",Native=false},
    {Name="Completionist_V105_Coffin_524f412c218f69b5",IdString="1117734056645771403",Family="coffin",Realm="Midgard",CatalogueId="coffin_524f412c218f69b5d6fd2b4ace6be1fb",Native=false},
    {Name="Completionist_V105_WoodenChest_c3065d265dcac89c",IdString="1150436433865663118",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_c3065d265dcac89c3b807a1121f459ea",Native=false},
    {Name="Completionist_V105_LoreScroll_dc56801cbe1e7d3c",IdString="1155035322313948173",Family="lore_scroll",Realm="Midgard",CatalogueId="lore_scroll_dc56801cbe1e7d3cbd54f9150cc78a3c",Native=false},
    {Name="Completionist_V105_Coffin_00d1d9586170eb24",IdString="1172161842486147109",Family="coffin",Realm="Midgard",CatalogueId="coffin_00d1d9586170eb2458c9304285d70c2b",Native=false},
    {Name="Completionist_V105_WoodenChest_fa54db89fddd352b",IdString="1213114400533747281",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_fa54db89fddd352b2984a348dd33ada1",Native=false},
    {Name="Completionist_V105_Artefact_517ee3035529365e",IdString="1274845069989633199",Family="artefact",Realm="Midgard",CatalogueId="artefact_xpl250funeralinteriorwad4813767722fa414b9a3d4972dc8874e7",Native=false},
    {Name="Completionist_V105_Artefact_28b7fe1349cdc49d",IdString="1478308866203895146",Family="artefact",Realm="Midgard",CatalogueId="artefact_28b7fe1349cdc49da573c6a0657f0a9d",Native=false},
    {Name="Completionist_V105_Artefact_a0588a9442f0118b",IdString="1499535588063813006",Family="artefact",Realm="Midgard",CatalogueId="artefact_a0588a9442f0118bdce0cda751b8605d",Native=false},
    {Name="Completionist_V105_LoreScroll_62cc5c222fbe7d84",IdString="1506083851272810978",Family="lore_scroll",Realm="Midgard",CatalogueId="lore_scroll_62cc5c222fbe7d849e83705cfe13638c",Native=false},
    {Name="Completionist_V105_Coffin_d1bfdaff128036c4",IdString="1582478172104808911",Family="coffin",Realm="Helheim",CatalogueId="coffin_d1bfdaff128036c426e567b41358c072",Native=false},
    {Name="Completionist_V105_Coffin_78d857a21516770d",IdString="1582902355940785276",Family="coffin",Realm="Midgard",CatalogueId="coffin_78d857a21516770d19e10a59f5a76335",Native=false},
    {Name="Completionist_V105_Coffin_575a07cc7dca64c5",IdString="1589134221045242360",Family="coffin",Realm="Midgard",CatalogueId="coffin_575a07cc7dca64c540088be3f4139842",Native=false},
    {Name="Completionist_V105_RealmTear_d9d5fe53b4d7bd0c",IdString="1682005078191602699",Family="realm_tear",Realm="Alfheim",CatalogueId="realm_tear_d9d5fe53b4d7bd0c88376c7647f5537e",Native=false},
    {Name="Completionist_V105_LegendaryChest_d63295f244f33021",IdString="1693194758902969801",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_d63295f244f330219b003c913c0dab69",Native=false},
    {Name="Completionist_V105_JotnarShrine_e49959e54f3f1da0",IdString="1693723344438900385",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_e49959e54f3f1da0632c3ac2a01d7ec7",Native=false},
    {Name="Completionist_V105_Artefact_48edaa8b407e24be",IdString="1720402854901855292",Family="artefact",Realm="Alfheim",CatalogueId="artefact_48edaa8b407e24bed474bebea8ea3821",Native=false},
    {Name="Completionist_V105_WoodenChest_d753ce063ba2187a",IdString="1764282009312743944",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_d753ce063ba2187aaf6ce654558de5c6",Native=false},
    {Name="Completionist_V105_TreasureDig_9680b8bc8eff19d4",IdString="1845284538174277111",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_9680b8bc8eff19d4c84b439b0e5a841b",Native=false},
    {Name="Completionist_V105_Coffin_265ee0bf74ea46d9",IdString="1866205773127050962",Family="coffin",Realm="Helheim",CatalogueId="coffin_265ee0bf74ea46d94e2271778008959e",Native=false},
    {Name="Completionist_V105_Coffin_f7c85deadc9605c7",IdString="1874473181713338494",Family="coffin",Realm="Midgard",CatalogueId="coffin_f7c85deadc9605c7a4dde328c9d916b1",Native=false},
    {Name="Completionist_V105_Coffin_7261934c1430c94f",IdString="1938908515971364579",Family="coffin",Realm="Midgard",CatalogueId="coffin_7261934c1430c94f92e2ba079fed8c3c",Native=false},
    {Name="Completionist_V105_Artefact_8916f55c4511b74b",IdString="1996989203693317892",Family="artefact",Realm="Midgard",CatalogueId="artefact_8916f55c4511b74ba8601ba7ef3d86bb",Native=false},
    {Name="Completionist_V105_WoodenChest_765e2894cba2c865",IdString="2078970864927127173",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_765e2894cba2c865774bff371c57a91d",Native=false},
    {Name="Completionist_V105_RealmTear_1c939364d61323b0",IdString="2111304345749207790",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_1c939364d61323b0c9db30a25da5b0f0",Native=false},
    {Name="Completionist_V105_Coffin_68e0db213e0e075b",IdString="2121508997441722872",Family="coffin",Realm="Midgard",CatalogueId="coffin_68e0db213e0e075b272fe88aa8d49f54",Native=false},
    {Name="Completionist_V105_WoodenChest_844dbdd31fe6dc2f",IdString="2288266491930001185",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_844dbdd31fe6dc2fb08087399b65f67b",Native=false},
    {Name="Completionist_V105_Coffin_793530dd17ca8921",IdString="2321122296339978145",Family="coffin",Realm="Helheim",CatalogueId="coffin_793530dd17ca89215ba5d26f7357b8aa",Native=false},
    {Name="Completionist_V105_WoodenChest_471003f756043c70",IdString="2325106996584184398",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_471003f756043c7046d03da4a1c65372",Native=false},
    {Name="Completionist_V105_WoodenChest_b6c25a3f68363166",IdString="2618759818775287347",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_b6c25a3f683631668b90e34378276b82",Native=false},
    {Name="Completionist_V105_TreasureDig_a46f12e366ccfd55",IdString="2644693964722988686",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_a46f12e366ccfd55f7a945383f1231d0",Native=false},
    {Name="Completionist_V105_Coffin_2b80e842d4595859",IdString="2698606770269336930",Family="coffin",Realm="Midgard",CatalogueId="coffin_2b80e842d459585947380fe4c7415e0f",Native=false},
    {Name="Completionist_V105_TreasureMap_f48eb59997ca3572",IdString="2806682106002213983",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_f48eb59997ca3572363316461a106067",Native=false},
    {Name="Completionist_V105_Coffin_49c66a6e387cfdaa",IdString="2845858377913824502",Family="coffin",Realm="Midgard",CatalogueId="coffin_49c66a6e387cfdaaa98e4b2afdf7b1d3",Native=false},
    {Name="Completionist_V105_WoodenChest_cbb47d1bd72b1697",IdString="2897173350066791395",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_cbb47d1bd72b169725ff3d03a4af9282",Native=false},
    {Name="Completionist_V105_Coffin_c289f1218e664d7e",IdString="2902978218138735040",Family="coffin",Realm="Helheim",CatalogueId="coffin_c289f1218e664d7edf073b93a0cc55f8",Native=false},
    {Name="Completionist_V105_Coffin_3dceee4444defddd",IdString="2928390580985866017",Family="coffin",Realm="Midgard",CatalogueId="coffin_3dceee4444defddd165bf4929207c58f",Native=false},
    {Name="Completionist_V105_TreasureDig_5f6d01b68cdf70a9",IdString="2941828083749778966",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_5f6d01b68cdf70a9815dc6fa7c3a839f",Native=false},
    {Name="Completionist_V105_Coffin_c439b69d88a1f219",IdString="2959004466392337677",Family="coffin",Realm="Midgard",CatalogueId="coffin_c439b69d88a1f2195464c303b8d65e30",Native=false},
    {Name="Completionist_V105_Coffin_742ff8d25ea20efe",IdString="2971917432865589140",Family="coffin",Realm="Alfheim",CatalogueId="coffin_742ff8d25ea20efe745ec677e3c21d45",Native=false},
    {Name="Completionist_V105_WoodenChest_ef35baf6c74c4cd4",IdString="2985169777776370056",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_ef35baf6c74c4cd48702005838cd186e",Native=false},
    {Name="Completionist_V105_Coffin_dbc446d3cdc8af11",IdString="3018243692626006871",Family="coffin",Realm="Midgard",CatalogueId="coffin_dbc446d3cdc8af11b26294ada4bf2c9c",Native=false},
    {Name="Completionist_V105_LegendaryChest_5618d560426940a0",IdString="3038799246648823762",Family="legendary_chest",Realm="Helheim",CatalogueId="legendary_chest_5618d560426940a02e5b39a340c0c209",Native=false},
    {Name="Completionist_V105_LegendaryChest_890a24d24d2864a1",IdString="3050104318088014511",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_890a24d24d2864a1567af691c615870f",Native=false},
    {Name="Completionist_V105_Coffin_def02bc17b1bb024",IdString="3120165318010084774",Family="coffin",Realm="Midgard",CatalogueId="coffin_def02bc17b1bb0246e28fded510dccf2",Native=false},
    {Name="Completionist_V105_Coffin_f1f9d33e14c532dc",IdString="3154793460439605120",Family="coffin",Realm="Midgard",CatalogueId="coffin_f1f9d33e14c532dcec5e55b7e735ca19",Native=false},
    {Name="Completionist_V105_Coffin_744b86cb488721d7",IdString="3174362946958311252",Family="coffin",Realm="Midgard",CatalogueId="coffin_744b86cb488721d7190188084d7dc635",Native=false},
    {Name="Completionist_V105_Coffin_07014abc15905dbf",IdString="3202554956474069103",Family="coffin",Realm="Midgard",CatalogueId="coffin_07014abc15905dbf2b905d543b85abfe",Native=false},
    {Name="Completionist_V105_Coffin_66d5de24a634f6ac",IdString="3241282520466007640",Family="coffin",Realm="Midgard",CatalogueId="coffin_66d5de24a634f6acd7490fe2f02bc871",Native=false},
    {Name="Completionist_V105_WoodenChest_66a6a9d412a0ec0f",IdString="3243480075684979677",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_66a6a9d412a0ec0fadc2deca89c8dbf2",Native=false},
    {Name="Completionist_V105_Artefact_fda837834b361579",IdString="3260889764149724739",Family="artefact",Realm="Midgard",CatalogueId="artefact_fda837834b361579d4a29194810c3d09",Native=false},
    {Name="Completionist_V105_RealmTear_64b7ac07cbf1db2d",IdString="3268247236645321633",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_64b7ac07cbf1db2d7956e3298e23970f",Native=false},
    {Name="Completionist_V105_WoodenChest_794573030ab6d881",IdString="3291294474519983048",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_794573030ab6d881e84137e829ac9ae8",Native=false},
    {Name="Nif_400_RealmTear02",IdString="3341150848859935551",Family="realm_tear",Realm="Niflheim",CatalogueId="realm_tear_80a81219135f07ea1c0eb1948748fc58",Native=true},
    {Name="Nif_400_RealmTear03",IdString="3341150848859936558",Family="realm_tear",Realm="Niflheim",CatalogueId="realm_tear_ad3009f9f80b31ab80419fd380e60c1c",Native=true},
    {Name="Nif_400_RealmTear01",IdString="3341150848859938572",Family="realm_tear",Realm="Niflheim",CatalogueId="realm_tear_10374be1dacc7b5afc9b38ff1c50b3f5",Native=true},
    {Name="Completionist_V105_WoodenChest_75ca91755fa5f614",IdString="3356872871657380795",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_75ca91755fa5f614d3fadf9a08438fb2",Native=false},
    {Name="Completionist_V105_Artefact_4a3d314942f187f6",IdString="3378638826978703445",Family="artefact",Realm="Midgard",CatalogueId="artefact_4a3d314942f187f69ee5b78302e118fe",Native=false},
    {Name="Completionist_V105_WoodenChest_693971af27e4bc2e",IdString="3381629582231572592",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_693971af27e4bc2ec41d2f726a42bcbb",Native=false},
    {Name="Completionist_V105_WoodenChest_c29bba3fbdf1a9d6",IdString="3406073643227593153",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_c29bba3fbdf1a9d6e75049d29457decf",Native=false},
    {Name="Completionist_V105_Coffin_aaaf95f673179f03",IdString="3469593511969082325",Family="coffin",Realm="Midgard",CatalogueId="coffin_aaaf95f673179f035c1e67f568f08107",Native=false},
    {Name="Completionist_V105_Artefact_b687eed5a7323941",IdString="3551841059084183783",Family="artefact",Realm="Helheim",CatalogueId="artefact_hel300mainbridgewadb5b33ffb0d723f44a135047d5a839e32",Native=false},
    {Name="Completionist_V105_Artefact_fa511e0a422421b7",IdString="3594272996327770753",Family="artefact",Realm="Midgard",CatalogueId="artefact_fa511e0a422421b7acc01fa5829c4fe3",Native=false},
    {Name="Completionist_V105_Artefact_52a49a788270deb2",IdString="3667610346576331725",Family="artefact",Realm="Helheim",CatalogueId="artefact_hel300mainbridgewade4b6326ae64d514490a45593d471478f",Native=false},
    {Name="Completionist_V105_WoodenChest_d7eadb5de53b3584",IdString="3684359240241343315",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_d7eadb5de53b3584728f114bdd9a26d2",Native=false},
    {Name="Completionist_V105_WoodenChest_5a8b57e2e6ed25b4",IdString="3730477686924285803",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_5a8b57e2e6ed25b4d95144d451fbfb5d",Native=false},
    {Name="Completionist_V105_WoodenChest_6930ffe1cf86b6c7",IdString="4031069635388561554",Family="wooden_chest",Realm="Alfheim",CatalogueId="wooden_chest_6930ffe1cf86b6c7c705abebba9774c6",Native=false},
    {Name="Completionist_V105_JotnarShrine_5abb17c179c16ed7",IdString="4032257799872450397",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_5abb17c179c16ed72287fc2740a46f9a",Native=false},
    {Name="Completionist_V105_LegendaryChest_d6fb0fd64364453c",IdString="4078701640522036384",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_d6fb0fd64364453cc3e334a2454e0b75",Native=false},
    {Name="Completionist_V105_TreasureMap_adf20b36ad0f86b6",IdString="4093708539490706002",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_adf20b36ad0f86b68901b8e49aeeb498",Native=false},
    {Name="Completionist_V105_WoodenChest_d9336ed2d59cb4a9",IdString="4100214657138657725",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_d9336ed2d59cb4a9961eedd85044b193",Native=false},
    {Name="Completionist_V105_WoodenChest_b4def36d6cf62538",IdString="4131353046050770616",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_b4def36d6cf6253887e2d62acb8e931f",Native=false},
    {Name="Completionist_V105_Coffin_8f470545b16b1e42",IdString="4216360945202093346",Family="coffin",Realm="Midgard",CatalogueId="coffin_8f470545b16b1e425d2fd5f47525bff1",Native=false},
    {Name="Completionist_V105_WoodenChest_779f83a51f7aa40a",IdString="4217532664179186461",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_779f83a51f7aa40a5c86866d652cb766",Native=false},
    {Name="Completionist_V105_Coffin_cd8cfd54dfd050d5",IdString="4254367841395826991",Family="coffin",Realm="Midgard",CatalogueId="coffin_cd8cfd54dfd050d5d4b60bd7ff08eb21",Native=false},
    {Name="Completionist_V105_Coffin_85531ced605effb9",IdString="4281882421820219996",Family="coffin",Realm="Alfheim",CatalogueId="coffin_85531ced605effb9af1dad9009031dfd",Native=false},
    {Name="Completionist_V105_RealmTear_75c3365cbb3042f7",IdString="4371636652659690298",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_75c3365cbb3042f761a82660c314147e",Native=false},
    {Name="Completionist_V105_LoreMarker_962a88f5930ae3e1",IdString="4407163078771905213",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_riv475freyahouseextwad9a50243a697a924481d49d5c44c980ac",Native=false},
    {Name="Completionist_V105_Artefact_77c9c323358e80ea",IdString="4432983435772397906",Family="artefact",Realm="Midgard",CatalogueId="artefact_xpl200funeralwad2768cb29f445634bb075f7a858cabcc3",Native=false},
    {Name="Completionist_V105_WoodenChest_c7b27bc28ec7f67e",IdString="4453309799178519275",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_c7b27bc28ec7f67ef792e16997dbb5b4",Native=false},
    {Name="Completionist_V105_WoodenChest_21ce00568c4f2f02",IdString="4492343747989302670",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_21ce00568c4f2f02e51a4fe20ea80030",Native=false},
    {Name="Completionist_V105_Coffin_ccc3e6b52c7ac6cc",IdString="4510464020848693225",Family="coffin",Realm="Midgard",CatalogueId="coffin_ccc3e6b52c7ac6ccd3a6ac24aced6cfc",Native=false},
    {Name="Completionist_V105_WoodenChest_1adba8510701fc2e",IdString="4558957153205886219",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_1adba8510701fc2e921940af402eb450",Native=false},
    {Name="Completionist_V105_WoodenChest_5db52378a823a4c8",IdString="4574032048565886001",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_5db52378a823a4c80828e0c927521dd3",Native=false},
    {Name="Completionist_V105_WoodenChest_bd68b87e6f2fa142",IdString="4599771606348111614",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_bd68b87e6f2fa142ead9dbf282303da4",Native=false},
    {Name="Completionist_V105_WoodenChest_32d12c1505dcc729",IdString="4621790634674832338",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_32d12c1505dcc72956b8b8cb27f928d1",Native=false},
    {Name="Completionist_V105_WoodenChest_0e36e52e4173d490",IdString="4627612461503358292",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_0e36e52e4173d490a9b3f8868c7782a0",Native=false},
    {Name="Completionist_V105_Coffin_abc058fb6e88938d",IdString="4687719467230337124",Family="coffin",Realm="Midgard",CatalogueId="coffin_abc058fb6e88938d0a43c94f13a7bffd",Native=false},
    {Name="Completionist_V105_JotnarShrine_6e55a7d7704af68c",IdString="4712100013729515184",Family="jotnar_shrine",Realm="Alfheim",CatalogueId="jotnar_shrine_6e55a7d7704af68ce4b82e5edecf81a7",Native=false},
    {Name="Completionist_V105_RealmTear_af0e22716b928bcf",IdString="4740673325003632316",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_af0e22716b928bcf52889387ffc91c4f",Native=false},
    {Name="Completionist_V105_LegendaryChest_0e27df5f4bc5f254",IdString="4811525431502043739",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_0e27df5f4bc5f2545a43178d0115312b",Native=false},
    {Name="Completionist_V105_LegendaryChest_9c0dc602456a00fa",IdString="4826513597218833620",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_9c0dc602456a00fa44bca1a3b599cf67",Native=false},
    {Name="Completionist_V105_Artefact_5bf15dbc48613f5b",IdString="4868596165348435032",Family="artefact",Realm="Alfheim",CatalogueId="artefact_5bf15dbc48613f5b548fd2a673d8f7bc",Native=false},
    {Name="Completionist_V105_LegendaryChest_d6d6acfe444f2ad1",IdString="4945522954595613969",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_d6d6acfe444f2ad10b49cea2ba85a1eb",Native=false},
    {Name="Completionist_V105_Artefact_6fa420df406be3d0",IdString="5026016083580783366",Family="artefact",Realm="Midgard",CatalogueId="artefact_6fa420df406be3d033b7eea35a4d10fe",Native=false},
    {Name="Completionist_V105_RealmTear_71588ab9681c6184",IdString="5091985008960953550",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_71588ab9681c6184279e7384fdafbbdd",Native=false},
    {Name="Completionist_V105_LegendaryChest_7a71d104452e16e3",IdString="5102749551782179183",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_7a71d104452e16e39a25bb8a14e47343",Native=false},
    {Name="Completionist_V105_Coffin_ebcc7fde6edd3347",IdString="5143638330687155434",Family="coffin",Realm="Midgard",CatalogueId="coffin_ebcc7fde6edd3347424493e2700fae89",Native=false},
    {Name="Completionist_V105_WoodenChest_6b0d3d9e239100c7",IdString="5195029476584204234",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_6b0d3d9e239100c717236687da581bef",Native=false},
    {Name="Completionist_V105_LoreMarker_7760357cff933461",IdString="5211561046045789489",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl940beachcavewad6093995aaaf7ad4b9830d1be0e7e0684",Native=false},
    {Name="Completionist_V105_LoreMarker_c542141ca5c047b7",IdString="5258986495229597168",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl950beachmazewad6093995aaaf7ad4b9830d1be0e7e0684",Native=false},
    {Name="Completionist_V105_Artefact_8f38e202a2e88355",IdString="5283284295348337800",Family="artefact",Realm="Midgard",CatalogueId="artefact_xpl250funeralinteriorwad3f176e49e0a0cd4f8cf59ada5fe9c2d8",Native=false},
    {Name="Completionist_V105_TreasureDig_8c965bccff326f50",IdString="5315899180149510764",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_8c965bccff326f509c02f9321af9a223",Native=false},
    {Name="Completionist_V105_Artefact_ab662cc14c4a2132",IdString="5324116740207041582",Family="artefact",Realm="Midgard",CatalogueId="artefact_ab662cc14c4a21327111dea1a34b96c3",Native=false},
    {Name="Completionist_V105_CipherChest_368ccc0e6d6636bc",IdString="5358201464668457122",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_368ccc0e6d6636bc0c74043536071ef1",Native=false},
    {Name="Completionist_V105_LoreScroll_0a8de84c5e82fd19",IdString="5365820570768227974",Family="lore_scroll",Realm="Midgard",CatalogueId="lore_scroll_0a8de84c5e82fd19ccc618bce5ef6f84",Native=false},
    {Name="Completionist_V105_WoodenChest_acf22956026eaf9e",IdString="5366343551153534594",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_acf22956026eaf9efd34a12ef5ca22e2",Native=false},
    {Name="Completionist_V105_WoodenChest_5156a959c5b5a08a",IdString="5415011515676509531",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_5156a959c5b5a08a49303486b7d998cd",Native=false},
    {Name="Completionist_V105_WoodenChest_0e0ac7e313b7a704",IdString="5456886560585263281",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_0e0ac7e313b7a70479ce4799c063e1b6",Native=false},
    {Name="Completionist_V105_WoodenChest_f666f4ec08b715cf",IdString="5470041343658449215",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_f666f4ec08b715cf7e0862fa5d4d2a37",Native=false},
    {Name="Completionist_V105_WoodenChest_dbe63347daadc350",IdString="5471221910155837998",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_dbe63347daadc35034b614654d2e35a1",Native=false},
    {Name="Completionist_V105_TreasureMap_aef0891f1c3ee6d1",IdString="5486873055133138369",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_aef0891f1c3ee6d1f88f86b1601052f4",Native=false},
    {Name="Completionist_V105_Artefact_fae85e594ef79ee2",IdString="5493928461004445771",Family="artefact",Realm="Midgard",CatalogueId="artefact_fae85e594ef79ee2e204719767dd5287",Native=false},
    {Name="Completionist_V105_TreasureDig_70214d5859cc48c2",IdString="5547886093336663838",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_70214d5859cc48c2bfddd06fb252a8ba",Native=false},
    {Name="Completionist_V105_WoodenChest_0bb016e6a10fa429",IdString="5657521002942609185",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_0bb016e6a10fa429fd92e7431244acf3",Native=false},
    {Name="Completionist_V105_LegendaryChest_510bd86441ac6a7b",IdString="5685387399560665208",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_510bd86441ac6a7b71d4f59321c2a08f",Native=false},
    {Name="Completionist_V105_WoodenChest_9cf64f1857fba5b1",IdString="5687816805388569297",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_9cf64f1857fba5b156c819bb82eff1f8",Native=false},
    {Name="Completionist_V105_WoodenChest_78a1535551a9f6fc",IdString="5715507521215707688",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_78a1535551a9f6fc3d428be55e683d98",Native=false},
    {Name="Completionist_V105_WoodenChest_6415bc87e3cee7dc",IdString="5730442690641018310",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_6415bc87e3cee7dc64ff87227be631dc",Native=false},
    {Name="Completionist_V105_WoodenChest_dfa557277d10a7a7",IdString="5767563532690962775",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_dfa557277d10a7a70b656a4620c56fda",Native=false},
    {Name="Completionist_V105_Coffin_1ec665d11dec0d49",IdString="5769728597416727240",Family="coffin",Realm="Midgard",CatalogueId="coffin_1ec665d11dec0d4959f2fa6fe571a6cf",Native=false},
    {Name="Completionist_V105_WoodenChest_3c854063b4cea276",IdString="5819541653726242590",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_3c854063b4cea27669211d35562b7a9e",Native=false},
    {Name="Completionist_V105_JotnarShrine_23d6030ef079b748",IdString="5893766451221687860",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_23d6030ef079b748c4574a940bf2047b",Native=false},
    {Name="Completionist_V105_WoodenChest_47d4448bcb8d2e3a",IdString="5915452098487883148",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_47d4448bcb8d2e3a3fde0f69672e1f1e",Native=false},
    {Name="Completionist_V105_LegendaryChest_8aabd22a44df8f25",IdString="5930555372538439876",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_8aabd22a44df8f25a955fe8e04fc0d95",Native=false},
    {Name="Completionist_V105_LoreMarker_8c8a95764e8ffd5f",IdString="5957605786924736144",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_peak500chimneytopwad1d9b928f5f7eab4082f9c52e2f066780",Native=false},
    {Name="Completionist_V105_TreasureDig_33fd783f7b353537",IdString="5962309619570701808",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_33fd783f7b353537d922042c2a967396",Native=false},
    {Name="Completionist_V105_Coffin_5abb61ed22d5ef4e",IdString="5967208019755070304",Family="coffin",Realm="Midgard",CatalogueId="coffin_5abb61ed22d5ef4e63d0fb21411fc797",Native=false},
    {Name="Completionist_V105_WoodenChest_c34cd12e6f6d9025",IdString="5979391067127300424",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_c34cd12e6f6d9025df3fdc4fbe29433c",Native=false},
    {Name="Completionist_V105_WoodenChest_05777956466a1786",IdString="6036799601514452313",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_05777956466a17869155000961f9c0e4",Native=false},
    {Name="Completionist_V105_WoodenChest_45cff077ae20b76b",IdString="6051724976377784478",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_45cff077ae20b76b69ca0926566ce5c6",Native=false},
    {Name="Completionist_V105_LoreMarker_310675fe00b171f1",IdString="6059208049024602289",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_stn200lakeextwad64309dc36de48d438409f5abb85cfc92",Native=false},
    {Name="Completionist_V105_Artefact_b52df62545c16741",IdString="6073073730646805082",Family="artefact",Realm="Midgard",CatalogueId="artefact_b52df62545c16741e6f2278f9e2ccc32",Native=false},
    {Name="Completionist_V105_Coffin_fe52241f85fb3089",IdString="6139557936930978132",Family="coffin",Realm="Midgard",CatalogueId="coffin_fe52241f85fb3089b8210f793b4a34ee",Native=false},
    {Name="Completionist_V105_Artefact_7d8a35dc4d6aabf8",IdString="6167977466251322879",Family="artefact",Realm="Midgard",CatalogueId="artefact_7d8a35dc4d6aabf8065e1ead0c470fcc",Native=false},
    {Name="Completionist_V105_Coffin_f79832e35e68cfc2",IdString="6183390267637605944",Family="coffin",Realm="Midgard",CatalogueId="coffin_f79832e35e68cfc2d8a11e290165fa89",Native=false},
    {Name="Completionist_V105_WoodenChest_a1d6fa6a5055273e",IdString="6301896856685622882",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_a1d6fa6a5055273efa2aea64e3208312",Native=false},
    {Name="Completionist_V105_TreasureMap_4011675d69434ff5",IdString="6385402651517889149",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_4011675d69434ff50662d79d43b08305",Native=false},
    {Name="Completionist_V105_LoreMarker_2b12247d18b0ec34",IdString="6432720865897957710",Family="lore_marker",Realm="Alfheim",CatalogueId="lore_marker_alf690lakelightlhwade723fb1f62e1ef4a94d19a5eeeef0673",Native=false},
    {Name="Completionist_V105_Artefact_cf7627ad486711d9",IdString="6434528714935078961",Family="artefact",Realm="Midgard",CatalogueId="artefact_cf7627ad486711d9eab3339782e5a147",Native=false},
    {Name="Completionist_V105_Coffin_f9f584304bafcd2f",IdString="6578053001065291649",Family="coffin",Realm="Midgard",CatalogueId="coffin_f9f584304bafcd2f50ab0db9d2694940",Native=false},
    {Name="Completionist_V105_Coffin_573b543d74f93b4b",IdString="6679401160149856745",Family="coffin",Realm="Midgard",CatalogueId="coffin_573b543d74f93b4bd85cffdce6da424d",Native=false},
    {Name="Completionist_V105_RealmTear_885f79d8699b58e6",IdString="6682769191479601523",Family="realm_tear",Realm="Alfheim",CatalogueId="realm_tear_885f79d8699b58e655739f1b924bf442",Native=false},
    {Name="Completionist_V105_WoodenChest_268d53a0272891cc",IdString="6688589674907191862",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_268d53a0272891ccecb31702393e1819",Native=false},
    {Name="Completionist_V105_WoodenChest_b14a7e0ad20f015d",IdString="6704271894478891113",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_b14a7e0ad20f015dd563b19abc1a54ca",Native=false},
    {Name="Completionist_V105_Coffin_4c894a4cd00f5770",IdString="6740180414757112677",Family="coffin",Realm="Midgard",CatalogueId="coffin_4c894a4cd00f5770ebcf2c0c5de8e2b1",Native=false},
    {Name="Completionist_V105_JotnarShrine_7dadb7c3e8c5fdc6",IdString="6760836821525127516",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_7dadb7c3e8c5fdc6259b311fe6ac74ba",Native=false},
    {Name="Completionist_V105_RealmTear_b24fe2ba5298d202",IdString="6802768016357948324",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_b24fe2ba5298d202f41bda97b2a00845",Native=false},
    {Name="Completionist_V105_TreasureMap_82e41ccaf3093e62",IdString="6872319765145221247",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_82e41ccaf3093e62880d64a18227112c",Native=false},
    {Name="Completionist_V105_Coffin_5540f9ba7ecad39b",IdString="6905133284890116429",Family="coffin",Realm="Midgard",CatalogueId="coffin_5540f9ba7ecad39bfe9f2b5817e16adf",Native=false},
    {Name="Completionist_V105_WoodenChest_2d23433148d8f06d",IdString="6917002572681874036",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_2d23433148d8f06d05b59b34549fd974",Native=false},
    {Name="Completionist_V105_WoodenChest_87235278fe5f92c1",IdString="6925491189371926963",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_87235278fe5f92c19968896762202b95",Native=false},
    {Name="Completionist_V105_Coffin_cacfc0416ffa2a6d",IdString="7006794470586629380",Family="coffin",Realm="Midgard",CatalogueId="coffin_cacfc0416ffa2a6daaa23c90fca91ff5",Native=false},
    {Name="Completionist_V105_WoodenChest_ac18175339972ea5",IdString="7102098287210211031",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_ac18175339972ea504597b184294626a",Native=false},
    {Name="Completionist_V105_WoodenChest_3fe0ed11f8da36cf",IdString="7197093796534931814",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_3fe0ed11f8da36cf4d6a8534da039235",Native=false},
    {Name="Completionist_V105_LoreMarker_5e32ed2a4a8522ea",IdString="7261690770444712996",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_d988f2795775914592a04b62df2726d9",Native=false},
    {Name="Completionist_V105_WoodenChest_f588ff33e1919a60",IdString="7283161575799438433",Family="wooden_chest",Realm="Alfheim",CatalogueId="wooden_chest_f588ff33e1919a60d2adb07232f79621",Native=false},
    {Name="Completionist_V105_Coffin_42f17c39434a78c6",IdString="7335693459659735919",Family="coffin",Realm="Alfheim",CatalogueId="coffin_42f17c39434a78c652e5235614526d0a",Native=false},
    {Name="Completionist_V105_LegendaryChest_3c05899e46a61901",IdString="7340065545806597137",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_3c05899e46a619015d4cfb995fb61be0",Native=false},
    {Name="Completionist_V105_Coffin_b24c6a682bdd5571",IdString="7348814976696889315",Family="coffin",Realm="Midgard",CatalogueId="coffin_b24c6a682bdd5571637905ce2e305c2f",Native=false},
    {Name="Completionist_V105_Coffin_104119f1ce4acbac",IdString="7381688026490078044",Family="coffin",Realm="Midgard",CatalogueId="coffin_104119f1ce4acbac9a77408da2d7777f",Native=false},
    {Name="Completionist_V105_WoodenChest_27794e7010aee156",IdString="7437399305651850723",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_27794e7010aee1564fa9c0d13927ce5b",Native=false},
    {Name="Completionist_V105_Coffin_912c5430d4eba71f",IdString="7449401991441945291",Family="coffin",Realm="Midgard",CatalogueId="coffin_912c5430d4eba71f2aa2b42a05c68d40",Native=false},
    {Name="Completionist_V105_LegendaryChest_529343984fc31350",IdString="7470890464655174870",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_529343984fc313504ac20da874d05c01",Native=false},
    {Name="Completionist_V105_LoreMarker_6182d5026add68a4",IdString="7531900270327042804",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl225funerallhwadb18d193b7ba34340a8831d0e11ff1b4e",Native=false},
    {Name="Completionist_V105_Coffin_32d35ecd545e598e",IdString="7552554445944985107",Family="coffin",Realm="Midgard",CatalogueId="coffin_32d35ecd545e598e3e3343964f5db9dd",Native=false},
    {Name="Completionist_V105_Artefact_b18794364cc6b6a5",IdString="7612050573113394390",Family="artefact",Realm="Midgard",CatalogueId="artefact_b18794364cc6b6a5c08596ab8699f35b",Native=false},
    {Name="Completionist_V105_Artefact_707ae0e24dc7bc9a",IdString="7643182924730552414",Family="artefact",Realm="Alfheim",CatalogueId="artefact_707ae0e24dc7bc9a56c19eb7ce17b351",Native=false},
    {Name="Completionist_V105_Artefact_468c195b480889e3",IdString="7809233514741755245",Family="artefact",Realm="Midgard",CatalogueId="artefact_468c195b480889e354742b876aef3a11",Native=false},
    {Name="Completionist_V105_WoodenChest_a8c5ea120a8cc56f",IdString="7828043794708852801",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_a8c5ea120a8cc56f28fccd66df0e2f37",Native=false},
    {Name="Completionist_V105_CipherChest_a4637747ab0a20fa",IdString="7884725344013140638",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_a4637747ab0a20fa55d7253b2625da13",Native=false},
    {Name="Completionist_V105_Coffin_f1fb65044d01667d",IdString="7932731302585033931",Family="coffin",Realm="Midgard",CatalogueId="coffin_f1fb65044d01667d716a002b1c3391d5",Native=false},
    {Name="Completionist_V105_Coffin_5f33d793b402e41d",IdString="7959824581302621946",Family="coffin",Realm="Midgard",CatalogueId="coffin_5f33d793b402e41dfae34b6b00b0fcf1",Native=false},
    {Name="Completionist_V105_LoreMarker_0573e1f56d1ebe8a",IdString="8157445671412690985",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl960beachshipwad6093995aaaf7ad4b9830d1be0e7e0684",Native=false},
    {Name="Completionist_V105_Artefact_6e3739ea4ac8107c",IdString="8190535954004273570",Family="artefact",Realm="Alfheim",CatalogueId="artefact_6e3739ea4ac8107c495a61af774a9b03",Native=false},
    {Name="Completionist_V105_Coffin_a53778e43c763a0b",IdString="8200992111883541544",Family="coffin",Realm="Midgard",CatalogueId="coffin_a53778e43c763a0bfa7b902a04cf9eb2",Native=false},
    {Name="Completionist_V105_LoreMarker_31d0f5ead24b82ee",IdString="8255462511628488557",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_riv200dangersmainwad452dc462aab2814097a8c9a7d317c558",Native=false},
    {Name="Completionist_V105_LoreMarker_b0d206baaa663c3c",IdString="8307176619290676125",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_riv475freyahouseextwadd328468a73cead438031e76201fbddc9",Native=false},
    {Name="Completionist_V105_TreasureMap_5d8b3d55a2998883",IdString="8549495852340503411",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_5d8b3d55a299888357a6893fcec99c05",Native=false},
    {Name="Completionist_V105_LoreMarker_7e4c94962fc59e5a",IdString="8635098517508742600",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl200funeralwad0ab993b107a42f41af27749c6749728d",Native=false},
    {Name="Completionist_V105_LegendaryChest_ede160a54530f55a",IdString="8673349486412494372",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_ede160a54530f55a7667f5a39257843c",Native=false},
    {Name="Completionist_V105_LegendaryChest_8002f42944861752",IdString="8720988159086689325",Family="legendary_chest",Realm="Helheim",CatalogueId="legendary_chest_8002f429448617523d189cbd93b23d4b",Native=false},
    {Name="Completionist_V105_Coffin_345de6844e1e09c6",IdString="8721755919578839505",Family="coffin",Realm="Midgard",CatalogueId="coffin_345de6844e1e09c6d4d6a6b4133a793c",Native=false},
    {Name="Completionist_V105_WoodenChest_9796b08ff6484677",IdString="8808431443328646619",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_9796b08ff6484677f92dc5c548be592e",Native=false},
    {Name="Completionist_V105_RealmTear_a3857496e778be84",IdString="8901107628249475091",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_a3857496e778be84cdb14938feb3885d",Native=false},
    {Name="Completionist_V105_CipherChest_acb38981cfa8d4a1",IdString="8928858095756421834",Family="cipher_chest",Realm="Alfheim",CatalogueId="cipher_chest_acb38981cfa8d4a13490597c1bcc6dd8",Native=false},
    {Name="Completionist_V105_WoodenChest_1346fea0dd6e8e5c",IdString="8944417639109164822",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_1346fea0dd6e8e5cb6868dbd2aa9109c",Native=false},
    {Name="Completionist_V105_LoreMarker_70886d705057eb7b",IdString="8950395361809985169",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_riv085dangersentrancelhwad0359c55688ca5b48bd66cf4ae66fbed3",Native=false},
    {Name="Completionist_V105_Coffin_ce102339a34a1ee2",IdString="9062751936627179735",Family="coffin",Realm="Midgard",CatalogueId="coffin_ce102339a34a1ee210fb708cef487737",Native=false},
    {Name="Completionist_V105_WoodenChest_33d0f7eadfc4eef1",IdString="9095497977983451549",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_33d0f7eadfc4eef14aadaa1e9b6c6143",Native=false},
    {Name="Completionist_V105_CipherChest_33234eeb6c2a4186",IdString="-9184855299138647786",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_33234eeb6c2a418623f760e0dd11d24d",Native=false},
    {Name="Completionist_V105_CipherChest_5b8711edc0ecbc17",IdString="-9122465861918523624",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_5b8711edc0ecbc1775d18513dfd02be8",Native=false},
    {Name="Completionist_V105_LoreMarker_563e7eae8f688718",IdString="-9091148596687295086",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_peak140caverndarkwad3aae61a66981c34082d9e3dcb14c9a39",Native=false},
    {Name="Completionist_V105_Artefact_6cffc9884efa77b4",IdString="-9070875427387779334",Family="artefact",Realm="Midgard",CatalogueId="artefact_6cffc9884efa77b424baf987adfdba6a",Native=false},
    {Name="Completionist_V105_LegendaryChest_ff46dfab43efcfc6",IdString="-9065733824517835722",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_ff46dfab43efcfc6f0f382a33e2b571d",Native=false},
    {Name="Completionist_V105_CipherChest_87d50dbd4e373716",IdString="-9038778399192754493",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_87d50dbd4e3737165c04ae74fe8ffbb7",Native=false},
    {Name="Completionist_V105_Artefact_379728fc47e4a966",IdString="-9038193863196282718",Family="artefact",Realm="Midgard",CatalogueId="artefact_379728fc47e4a966be1fc9926011184b",Native=false},
    {Name="Completionist_V105_Coffin_d6137b034219becb",IdString="-9034044242117201799",Family="coffin",Realm="Midgard",CatalogueId="coffin_d6137b034219becb66bc80d10fd6511f",Native=false},
    {Name="Completionist_V105_Artefact_989065ff4bde64f5",IdString="-9006833879678683563",Family="artefact",Realm="Midgard",CatalogueId="artefact_989065ff4bde64f5ec957da2759037cb",Native=false},
    {Name="Completionist_V105_Coffin_3756070dc04ddc15",IdString="-8940907073927652221",Family="coffin",Realm="Alfheim",CatalogueId="coffin_3756070dc04ddc15c61d57cb6c42e5ad",Native=false},
    {Name="Completionist_V105_LoreMarker_1482575055c47c88",IdString="-8851350287921470577",Family="lore_marker",Realm="Alfheim",CatalogueId="lore_marker_alf150bridgedarkwad969e45f02f76844192ec5566056fbfd4",Native=false},
    {Name="Completionist_V105_JotnarShrine_19c69abd2cdf4145",IdString="-8848699473772394826",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_19c69abd2cdf4145b71903eabdaf87f8",Native=false},
    {Name="Completionist_V105_Coffin_2b66a5509901bb0a",IdString="-8836651331763768060",Family="coffin",Realm="Midgard",CatalogueId="coffin_2b66a5509901bb0ae8186134879d62fb",Native=false},
    {Name="Completionist_V105_Coffin_81be3d2815990e8e",IdString="-8830258053756562889",Family="coffin",Realm="Midgard",CatalogueId="coffin_81be3d2815990e8e6e34f3cc239fd25f",Native=false},
    {Name="Completionist_V105_LoreMarker_dbdf056ef737c4e5",IdString="-8825496189525824873",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl125httklhwad36f99a6c8537174bbaab95fb9d956455",Native=false},
    {Name="Completionist_V105_Artefact_c7f91ac1447cff68",IdString="-8823140129122526810",Family="artefact",Realm="Helheim",CatalogueId="artefact_c7f91ac1447cff68599696bbbb58e7b7",Native=false},
    {Name="Completionist_V105_RealmTear_664c0fd312a6e88d",IdString="-8821945975485878164",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_664c0fd312a6e88d8739f7d5af968fe3",Native=false},
    {Name="Completionist_V105_CipherChest_bed904beed4cc915",IdString="-8807646146305314321",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_bed904beed4cc9151ff7944a557ef0bb",Native=false},
    {Name="Completionist_V105_Coffin_0f897d994245a437",IdString="-8768158786820161342",Family="coffin",Realm="Midgard",CatalogueId="coffin_0f897d994245a437eea02861452c1e22",Native=false},
    {Name="Completionist_V105_TreasureMap_3cab9691f053fec1",IdString="-8767247849816357899",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_3cab9691f053fec1dc02301cf9c04021",Native=false},
    {Name="Completionist_V105_WoodenChest_a23662374dca6281",IdString="-8712114853642030466",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_a23662374dca6281eb791529945c7210",Native=false},
    {Name="Completionist_V105_WoodenChest_3ca0e634863fd2de",IdString="-8703449109309579865",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_3ca0e634863fd2de8454b4713f9426c5",Native=false},
    {Name="Completionist_V105_Artefact_eb672a1647b1f7e6",IdString="-8555672394249542480",Family="artefact",Realm="Helheim",CatalogueId="artefact_eb672a1647b1f7e64595e48f821670f5",Native=false},
    {Name="Completionist_V105_Coffin_d2080e7d0c12a0cc",IdString="-8469643326533813368",Family="coffin",Realm="Alfheim",CatalogueId="coffin_d2080e7d0c12a0ccc335b9b6364a3214",Native=false},
    {Name="Completionist_V105_Coffin_530e877c15dc4e8a",IdString="-8382950482857518861",Family="coffin",Realm="Midgard",CatalogueId="coffin_530e877c15dc4e8af94d97edcb0d27e9",Native=false},
    {Name="Completionist_V105_RealmTear_2b6da4fe76312741",IdString="-8204045437213932286",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_2b6da4fe76312741d21ade4905d66ff4",Native=false},
    {Name="Completionist_V105_WoodenChest_7ca006b2b3401883",IdString="-8182455258295244896",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_7ca006b2b340188300a7e79f6f83391a",Native=false},
    {Name="Completionist_V105_LegendaryChest_9d7648ab43bf99f9",IdString="-8160017110931143525",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_9d7648ab43bf99f90b0cbd86b0a998f1",Native=false},
    {Name="Completionist_V105_WoodenChest_7cf0e761c72a66b9",IdString="-8158433129144712100",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_7cf0e761c72a66b9b4b45b7e640519a7",Native=false},
    {Name="Completionist_V105_WoodenChest_c9b78a83ed706e2f",IdString="-8059834427956489536",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_c9b78a83ed706e2f87e723017c735303",Native=false},
    {Name="Completionist_V105_Coffin_e7c6bb7592f8d713",IdString="-8045201685618977893",Family="coffin",Realm="Midgard",CatalogueId="coffin_e7c6bb7592f8d71352a303792bc5a6a6",Native=false},
    {Name="Completionist_V105_Coffin_483ef71604ed4628",IdString="-7845165817787876415",Family="coffin",Realm="Midgard",CatalogueId="coffin_483ef71604ed462813b9d2190ffc90cf",Native=false},
    {Name="Completionist_V105_LoreMarker_daca08d60fe4fe42",IdString="-7824505605282974654",Family="lore_marker",Realm="Alfheim",CatalogueId="lore_marker_alf440hiveextlhwad0f75539e19bc0947ba4d6f46ea0a95d2",Native=false},
    {Name="Completionist_V105_WoodenChest_a351d959d938ab66",IdString="-7593879730062821437",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_a351d959d938ab662188c62ebb286acc",Native=false},
    {Name="Completionist_V105_RealmTear_6f5037ce091595b1",IdString="-7581038497687747113",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_6f5037ce091595b1bc2b0ab31cfaf05b",Native=false},
    {Name="Completionist_V105_Coffin_89b943bbda8f5c15",IdString="-7541562783040503652",Family="coffin",Realm="Helheim",CatalogueId="coffin_89b943bbda8f5c15788d8c5fe3dd5d42",Native=false},
    {Name="Completionist_V105_WoodenChest_4120fd9bd6ee2470",IdString="-7441288059112608923",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_4120fd9bd6ee2470fe64e0c46ea7c515",Native=false},
    {Name="Completionist_V105_CipherChest_4935b4ad6d592f85",IdString="-7382394590927493041",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_4935b4ad6d592f85492c85bd0829dcb8",Native=false},
    {Name="Completionist_V105_LoreMarker_215bf892d1160907",IdString="-7376499913159325315",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_cal500runevaultwad14f472bb0d9d2e4993d0774cbc755e02",Native=false},
    {Name="Completionist_V105_LoreMarker_c2352b11746d4948",IdString="-7287005435847288945",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_peak200chimneylowwad29a3fec3318213458a458abb0eb539a2",Native=false},
    {Name="Completionist_V105_Artefact_b6fe724fd23a1d56",IdString="-7128827464451496660",Family="artefact",Realm="Midgard",CatalogueId="artefact_xpl200funeralwadbb9465a7407c9849bf891e0205dac801",Native=false},
    {Name="Completionist_V105_WoodenChest_8836735f3c50fd90",IdString="-7122063545665070407",Family="wooden_chest",Realm="Alfheim",CatalogueId="wooden_chest_8836735f3c50fd90d214306b51ebeb79",Native=false},
    {Name="Completionist_V105_WoodenChest_255bd08484850591",IdString="-7020831037067263699",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_255bd08484850591a8c5077c4efd6b64",Native=false},
    {Name="Completionist_V105_Coffin_a2ec2e348926ce92",IdString="-7014112355252120799",Family="coffin",Realm="Midgard",CatalogueId="coffin_a2ec2e348926ce92a6dbfa84d1bb3729",Native=false},
    {Name="Completionist_V105_WoodenChest_c75b16bed331d5ab",IdString="-6994655372513312550",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_c75b16bed331d5ab90b8d6e7a6a742ac",Native=false},
    {Name="Completionist_V105_LoreMarker_92f3e2d5fdc81965",IdString="-6962091264869698760",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl650masontrailcavewadb2f0bf0705313e4aa27b33fddd3a0665",Native=false},
    {Name="Completionist_V105_WoodenChest_34c065eb3609a2c1",IdString="-6950380314317574631",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_34c065eb3609a2c1366263e3f493dfa3",Native=false},
    {Name="Completionist_V105_LoreMarker_c9bd68d8c8f29448",IdString="-6934038613090089674",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_riv420forestboarstartwad0c671129ecb3144cbcf4a641a4160b66",Native=false},
    {Name="Completionist_V105_TreasureMap_ce589a091d984c35",IdString="-6919458657896122586",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_ce589a091d984c3581097a8700aad61d",Native=false},
    {Name="Completionist_V105_Coffin_6fc14ea5854a3ac8",IdString="-6775064606606101889",Family="coffin",Realm="Midgard",CatalogueId="coffin_6fc14ea5854a3ac8af7a57a05be00c91",Native=false},
    {Name="Completionist_V105_Coffin_f0c400642e139948",IdString="-6708974415550478611",Family="coffin",Realm="Midgard",CatalogueId="coffin_f0c400642e139948e733d79ec3119f47",Native=false},
    {Name="Completionist_V105_LoreMarker_381293c55583674a",IdString="-6704901999548302987",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl250funeralinteriorwadd1ddaedac0dbac478444718ac2f19211",Native=false},
    {Name="Completionist_V105_TreasureDig_ebcc555c3dc8b135",IdString="-6664774531602829219",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_ebcc555c3dc8b13561d8afa2bd4c0ba0",Native=false},
    {Name="Completionist_V105_Coffin_fbad02805a974b90",IdString="-6643800005937273140",Family="coffin",Realm="Midgard",CatalogueId="coffin_fbad02805a974b9087885a0c497e34ca",Native=false},
    {Name="Completionist_V105_LegendaryChest_91a9f92a45d2d3fd",IdString="-6568181882954774468",Family="legendary_chest",Realm="Alfheim",CatalogueId="legendary_chest_91a9f92a45d2d3fdb92279b4612ab5d7",Native=false},
    {Name="Completionist_V105_WoodenChest_e22d823077569012",IdString="-6556292200057794580",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_e22d823077569012bc63ecaf45563e77",Native=false},
    {Name="Completionist_V105_RealmTear_cb9a35e72a6bd571",IdString="-6476772071679788341",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_cb9a35e72a6bd571c820349c901762a9",Native=false},
    {Name="Completionist_V105_Coffin_bc47cbf3655df68a",IdString="-6355357592497746960",Family="coffin",Realm="Midgard",CatalogueId="coffin_bc47cbf3655df68aa52d3948f29070ef",Native=false},
    {Name="Completionist_V105_Coffin_73a23f0e4255942c",IdString="-6320748266200228344",Family="coffin",Realm="Alfheim",CatalogueId="coffin_73a23f0e4255942c300031a188e8a525",Native=false},
    {Name="Completionist_V105_LoreMarker_5608cc76fea4a6fa",IdString="-6217814866534045987",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl300strongholdwad79d7700bc6e8cf47a77b5403426b5297",Native=false},
    {Name="Completionist_V105_LoreMarker_3f79943767db41e2",IdString="-6215880668304825321",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl910islandshipwreckwad6093995aaaf7ad4b9830d1be0e7e0684",Native=false},
    {Name="Completionist_V105_Coffin_9b316d325ff8c810",IdString="-6169733413306181765",Family="coffin",Realm="Midgard",CatalogueId="coffin_9b316d325ff8c810a3d018399ab0a1fe",Native=false},
    {Name="Completionist_V105_Coffin_a1c849de7c794dae",IdString="-6108520046829715129",Family="coffin",Realm="Midgard",CatalogueId="coffin_a1c849de7c794dae09f118bbf46d8dcb",Native=false},
    {Name="Completionist_V105_Artefact_33f59ee746f63f40",IdString="-6057610252048753924",Family="artefact",Realm="Midgard",CatalogueId="artefact_33f59ee746f63f40199e5f90cad3c236",Native=false},
    {Name="Completionist_V105_WoodenChest_dac0fe6519eac4b9",IdString="-6035971906397030337",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_dac0fe6519eac4b9df6b377f533a73ac",Native=false},
    {Name="Completionist_V105_WoodenChest_bc78435c88260378",IdString="-6025451959267707894",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_bc78435c8826037845b826e1cca23653",Native=false},
    {Name="Completionist_V105_Artefact_0da7cb9744da59cb",IdString="-6006389905446679856",Family="artefact",Realm="Midgard",CatalogueId="artefact_0da7cb9744da59cb80fe319d95cada55",Native=false},
    {Name="Completionist_V105_Artefact_c9b7e23040c21e2d",IdString="-5995590521664354398",Family="artefact",Realm="Midgard",CatalogueId="artefact_c9b7e23040c21e2da5fe8ba4be8ad415",Native=false},
    {Name="Completionist_V105_LegendaryChest_48f9e1694dc722a5",IdString="-5922952290131585206",Family="legendary_chest",Realm="Alfheim",CatalogueId="legendary_chest_48f9e1694dc722a549f42893d5b79d9f",Native=false},
    {Name="Completionist_V105_WoodenChest_2d4638fc47956713",IdString="-5871823178803930870",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_2d4638fc479567132f4d797b9b327c48",Native=false},
    {Name="Completionist_V105_RealmTear_ae12a2c33fd8e441",IdString="-5859608082122379287",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_ae12a2c33fd8e441bf159a5fd7ac3c22",Native=false},
    {Name="Completionist_V105_Coffin_f2e02def29ac0420",IdString="-5828530275555553381",Family="coffin",Realm="Helheim",CatalogueId="coffin_f2e02def29ac042044af2ff35637b2a9",Native=false},
    {Name="Completionist_V105_LegendaryChest_b97f559c471fab88",IdString="-5805589232851956206",Family="legendary_chest",Realm="Alfheim",CatalogueId="legendary_chest_b97f559c471fab8850a2ae8741370020",Native=false},
    {Name="Completionist_V105_LoreMarker_5542da794fd84aef",IdString="-5798597909276125984",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_peak720summitascenthubwadda8178f1357e8d45922a657e6f760dd8",Native=false},
    {Name="Completionist_V105_Coffin_8eed9a4a0e0b5390",IdString="-5797225999771955022",Family="coffin",Realm="Alfheim",CatalogueId="coffin_8eed9a4a0e0b5390ea90c84406f8f8ce",Native=false},
    {Name="Completionist_V105_WoodenChest_d122572886b8c924",IdString="-5765432517399145484",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_d122572886b8c92453a055b03706a6ce",Native=false},
    {Name="Completionist_V105_Coffin_dafb5c49c183bb63",IdString="-5710993096331134200",Family="coffin",Realm="Midgard",CatalogueId="coffin_dafb5c49c183bb638b57c1be03863ecf",Native=false},
    {Name="Completionist_V105_Artefact_0a43e4954d4fff46",IdString="-5615900820913256670",Family="artefact",Realm="Midgard",CatalogueId="artefact_0a43e4954d4fff46abb9ca8e34d875c0",Native=false},
    {Name="Completionist_V105_WoodenChest_7f6a0836ac388c5b",IdString="-5598517248481418638",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_7f6a0836ac388c5b79f08b6048cb998d",Native=false},
    {Name="Completionist_V105_Coffin_e07e5ac1b623623c",IdString="-5587733643998413659",Family="coffin",Realm="Helheim",CatalogueId="coffin_e07e5ac1b623623c121b01c2481f504f",Native=false},
    {Name="Completionist_V105_Coffin_92217ff2537c4eca",IdString="-5572852238233935784",Family="coffin",Realm="Midgard",CatalogueId="coffin_92217ff2537c4eca00ca2387cb7a1a42",Native=false},
    {Name="Completionist_V105_Coffin_d468c7d58a26674a",IdString="-5550335823946139063",Family="coffin",Realm="Midgard",CatalogueId="coffin_d468c7d58a26674aa3b5b16dc0e79eaf",Native=false},
    {Name="Completionist_V105_Coffin_715ae2ff1980d3bf",IdString="-5545290682339400712",Family="coffin",Realm="Midgard",CatalogueId="coffin_715ae2ff1980d3bfee797f2dd1481ec8",Native=false},
    {Name="Completionist_V105_LoreMarker_6d26b2825393dfb7",IdString="-5466167646453154819",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl400huldramineswade1701a5ddf529645b442371f82145220",Native=false},
    {Name="Completionist_V105_Coffin_d45ead0e44bc195b",IdString="-5427129773533365199",Family="coffin",Realm="Midgard",CatalogueId="coffin_d45ead0e44bc195bc94e7ec18de2edb3",Native=false},
    {Name="Completionist_V105_LoreMarker_1b1459b433be2549",IdString="-5374813378942080735",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_riv475freyahouseextwad5124f330461a8e42b1659c4517e18c29",Native=false},
    {Name="Completionist_V105_Artefact_01a8ba24409b5fb4",IdString="-5261914935659853799",Family="artefact",Realm="Midgard",CatalogueId="artefact_01a8ba24409b5fb49a1c18b43669fe44",Native=false},
    {Name="Completionist_V105_LegendaryChest_040af4fa440ef7ba",IdString="-5253959066884539260",Family="legendary_chest",Realm="Alfheim",CatalogueId="legendary_chest_040af4fa440ef7ba52f8e8b317ac3200",Native=false},
    {Name="Completionist_V105_LoreMarker_91a1de27cf22bbaf",IdString="-5206435462399599842",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_cal250foothillslhwadb456381ff98fb449896acb659da524fa",Native=false},
    {Name="Completionist_V105_LegendaryChest_9f29650a4a8a5d0e",IdString="-5206399165729113931",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_9f29650a4a8a5d0eb8bc43af1dbd3d68",Native=false},
    {Name="Completionist_V105_Coffin_6b028789691d2197",IdString="-5183368259720100440",Family="coffin",Realm="Midgard",CatalogueId="coffin_6b028789691d219730cefc4630c393f0",Native=false},
    {Name="Completionist_V105_WoodenChest_8fd4ea6fbc9f8610",IdString="-5169610089192963429",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_8fd4ea6fbc9f86102aa363311d694995",Native=false},
    {Name="Completionist_V105_Coffin_edcb1025a189bc20",IdString="-5143745017078834644",Family="coffin",Realm="Midgard",CatalogueId="coffin_edcb1025a189bc2022b512d6bebaf11a",Native=false},
    {Name="Completionist_V105_WoodenChest_02cb4383595ac1f7",IdString="-5140417074999203173",Family="wooden_chest",Realm="Alfheim",CatalogueId="wooden_chest_02cb4383595ac1f75f02d048497910be",Native=false},
    {Name="Completionist_V105_TreasureDig_8d79870871fe184c",IdString="-5104807035476446794",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_8d79870871fe184c47d369eabbd68f92",Native=false},
    {Name="Completionist_V105_Artefact_bd9a46a34b8fd466",IdString="-4974720098235180566",Family="artefact",Realm="Midgard",CatalogueId="artefact_bd9a46a34b8fd4660be2129e27fa4004",Native=false},
    {Name="Completionist_V105_Coffin_b9137381c8685a44",IdString="-4958085237690472995",Family="coffin",Realm="Midgard",CatalogueId="coffin_b9137381c8685a442887b317281334c3",Native=false},
    {Name="Completionist_V105_Coffin_082e60a8f7563906",IdString="-4952195526472945565",Family="coffin",Realm="Alfheim",CatalogueId="coffin_082e60a8f756390671c4ffa499ce98a2",Native=false},
    {Name="Completionist_V105_Coffin_e2d0ecbabcb5a115",IdString="-4887557130580967875",Family="coffin",Realm="Midgard",CatalogueId="coffin_e2d0ecbabcb5a115e49005576bc680e0",Native=false},
    {Name="Completionist_V105_WoodenChest_f8e1e11f0be08235",IdString="-4852191029162596534",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_f8e1e11f0be082351c02df2da90c1f5b",Native=false},
    {Name="Completionist_V105_JotnarShrine_b124fa2d62938dc8",IdString="-4848152687018735976",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_b124fa2d62938dc8fcf85d67432d8550",Native=false},
    {Name="Completionist_V105_WoodenChest_586cacd7a21c53dd",IdString="-4819666325958850330",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_586cacd7a21c53dd2be423e91e59a256",Native=false},
    {Name="Completionist_V105_TreasureMap_4a07636dc59583c9",IdString="-4750212192490779455",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_4a07636dc59583c9bfe877849ab5a97f",Native=false},
    {Name="Completionist_V105_LoreMarker_28e4de3c4adfaac1",IdString="-4728868598416067902",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl220funerallhwadeea6c57321539249a4d58ca8baa527cb",Native=false},
    {Name="Completionist_V105_Artefact_f7fbfc3f44991b3d",IdString="-4677907358439003615",Family="artefact",Realm="Midgard",CatalogueId="artefact_f7fbfc3f44991b3da37871879e6de737",Native=false},
    {Name="Completionist_V105_CipherChest_f2220e936a3394dd",IdString="-4625549274083029423",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_f2220e936a3394ddfe1443657707b770",Native=false},
    {Name="Completionist_V105_WoodenChest_53fd52ac3bb61b72",IdString="-4570371958305437032",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_53fd52ac3bb61b72dd6c99bf58b56968",Native=false},
    {Name="Completionist_V105_WoodenChest_f743cadced963758",IdString="-4552130101762786257",Family="wooden_chest",Realm="Helheim",CatalogueId="wooden_chest_f743cadced96375893da7bd242fd68c0",Native=false},
    {Name="Completionist_V105_WoodenChest_affb01a0b9017aff",IdString="-4523787552059654527",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_affb01a0b9017affae4a4d18ca3e61b7",Native=false},
    {Name="Completionist_V105_RealmTear_12672293750dfc6b",IdString="-4492472488809996361",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_12672293750dfc6b1381cf5159ad0615",Native=false},
    {Name="Completionist_V105_WoodenChest_d9b5e3ceb301b036",IdString="-4472140490613338261",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_d9b5e3ceb301b036b7cb78f409810ff3",Native=false},
    {Name="Completionist_V105_LoreMarker_d1e8be6b516f1d4c",IdString="-4458911381451975939",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl400huldramineswadf014bd94366e7b49ade008aff1769396",Native=false},
    {Name="Completionist_V105_WoodenChest_47feaa163975e37d",IdString="-4396729422146487646",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_47feaa163975e37d55a81abb7bffba4e",Native=false},
    {Name="Completionist_V105_LoreMarker_ce898f8d2a9e7668",IdString="-4334036183614285986",Family="lore_marker",Realm="Alfheim",CatalogueId="lore_marker_alf150bridgedarkwad76250fcb340065498ff1b75bddd20fcf",Native=false},
    {Name="Completionist_V105_Coffin_906db69b1c98e210",IdString="-4280566831420738904",Family="coffin",Realm="Midgard",CatalogueId="coffin_906db69b1c98e210bfd711cea88cd266",Native=false},
    {Name="Completionist_V105_LegendaryChest_11e085df4bd47dee",IdString="-4100763194894190907",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_11e085df4bd47deee3a3448bff9efc62",Native=false},
    {Name="Completionist_V105_LoreMarker_6fe6d341c0e08884",IdString="-4079875281744767029",Family="lore_marker",Realm="Niflheim",CatalogueId="lore_marker_nid150calderabridgewad2eabc6ebc9dafd40b34cb41a6ffcd2d4",Native=false},
    {Name="Completionist_V105_TreasureMap_67ec3f2c214e4fd0",IdString="-4065877508138818264",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_67ec3f2c214e4fd07a7eaf0b58cf213c",Native=false},
    {Name="Completionist_V105_CipherChest_285a8836646562d9",IdString="-4060991314335209153",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_285a8836646562d9520d7c890d4ef3b4",Native=false},
    {Name="Completionist_V105_Coffin_5bf1f9791a9a6a85",IdString="-3997239115386565825",Family="coffin",Realm="Midgard",CatalogueId="coffin_5bf1f9791a9a6a851a98e8e377869fbd",Native=false},
    {Name="Completionist_V105_LoreMarker_355580f7b3ac815c",IdString="-3962526961703439862",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_cal250foothillslhwad8ab6b877e9062c4b9f0d0f375f8326c1",Native=false},
    {Name="Completionist_V105_LoreScroll_2242aadeda389dae",IdString="-3925820918896097493",Family="lore_scroll",Realm="Midgard",CatalogueId="lore_scroll_2242aadeda389dae8c5283057c5326ca",Native=false},
    {Name="Completionist_V105_Artefact_0d53040849957335",IdString="-3874750750620801726",Family="artefact",Realm="Alfheim",CatalogueId="artefact_0d53040849957335c6db68809206f5d1",Native=false},
    {Name="Completionist_V105_Artefact_5bb11ed5419b42ca",IdString="-3861438053197792891",Family="artefact",Realm="Midgard",CatalogueId="artefact_5bb11ed5419b42caba813598d29ca473",Native=false},
    {Name="Completionist_V105_Coffin_b6a51db40b1e73b0",IdString="-3851773636138635459",Family="coffin",Realm="Midgard",CatalogueId="coffin_b6a51db40b1e73b0e8c6b24f08b9df77",Native=false},
    {Name="Completionist_V105_LegendaryChest_d0b93e274754785e",IdString="-3654690568362615274",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_d0b93e274754785e08235285bd6b78f2",Native=false},
    {Name="Completionist_V105_LegendaryChest_23d3213f45e38b63",IdString="-3639338260243983857",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_23d3213f45e38b632ed8048e876e472d",Native=false},
    {Name="Completionist_V105_WoodenChest_a7543637312c028e",IdString="-3629138509240265240",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_a7543637312c028edf79cc16a060097e",Native=false},
    {Name="Completionist_V105_Coffin_07ad6c3ad556b93e",IdString="-3625597237973120300",Family="coffin",Realm="Midgard",CatalogueId="coffin_07ad6c3ad556b93e9108d10af5a58d8a",Native=false},
    {Name="Completionist_V105_WoodenChest_7bec312d23c04016",IdString="-3614661162362032951",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_7bec312d23c04016fae74ca647bb7bc0",Native=false},
    {Name="Completionist_V105_Coffin_0efeb8c8cb24d398",IdString="-3589846249052360598",Family="coffin",Realm="Midgard",CatalogueId="coffin_0efeb8c8cb24d3981a15a70321c096fe",Native=false},
    {Name="Completionist_V105_JotnarShrine_c0d7a4d17e152054",IdString="-3403687470601663591",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_c0d7a4d17e152054e3e3c3e2571d98b8",Native=false},
    {Name="Completionist_V105_Coffin_d5a198ed2f341b80",IdString="-3345973756670133741",Family="coffin",Realm="Midgard",CatalogueId="coffin_d5a198ed2f341b80b8b04b9a430c5c1c",Native=false},
    {Name="Completionist_V105_WoodenChest_e04dfd6c26cc8d4d",IdString="-3218224663951353625",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_e04dfd6c26cc8d4dd0bbce8bccd246ff",Native=false},
    {Name="Completionist_V105_WoodenChest_ea3cae8ef3136ef4",IdString="-3188083620953163936",Family="wooden_chest",Realm="Alfheim",CatalogueId="wooden_chest_ea3cae8ef3136ef470f6d4b3fed9c6b2",Native=false},
    {Name="Completionist_V105_Coffin_f1b0d53b18c6d910",IdString="-3113924839161123231",Family="coffin",Realm="Midgard",CatalogueId="coffin_f1b0d53b18c6d9100c9573cf006d0b63",Native=false},
    {Name="Completionist_V105_LoreMarker_bf6ec8603b6528f3",IdString="-3070112878869451879",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl300strongholdwade361f1b4a04c074b84896263475139ab",Native=false},
    {Name="Completionist_V105_RealmTear_64256db4dca56cbe",IdString="-3054322094557212978",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_64256db4dca56cbedc9c2ad1bb454bef",Native=false},
    {Name="Completionist_V105_Artefact_56c4354a4141de7a",IdString="-3008424777413423672",Family="artefact",Realm="Alfheim",CatalogueId="artefact_56c4354a4141de7afc7f2e8447ab8767",Native=false},
    {Name="Completionist_V105_CipherChest_a120a8e8b11b778c",IdString="-2908327625113639631",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_a120a8e8b11b778cebccfbe5aab211e9",Native=false},
    {Name="Completionist_V105_Coffin_44c42ab490af3bed",IdString="-2905154313104291799",Family="coffin",Realm="Midgard",CatalogueId="coffin_44c42ab490af3bedc34e812cb537d913",Native=false},
    {Name="Completionist_V105_LegendaryChest_a24ac28d4ea8598d",IdString="-2903274633715395540",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_a24ac28d4ea8598d880d7bb099b8b8be",Native=false},
    {Name="Completionist_V105_Artefact_f5bd8953457f9662",IdString="-2891585445722996815",Family="artefact",Realm="Midgard",CatalogueId="artefact_f5bd8953457f9662d074d798a111abfc",Native=false},
    {Name="Completionist_V105_LoreMarker_4f9343aac517362a",IdString="-2825229752875529329",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl225funerallhwadfb3c8f6c096b464dafa89220022f8c54",Native=false},
    {Name="Completionist_V105_TreasureMap_8b1707f94ad81810",IdString="-2723485509653121599",Family="treasure_map",Realm="Midgard",CatalogueId="treasure_map_8b1707f94ad818100dd4a5afc67fc6c6",Native=false},
    {Name="Completionist_V105_JotnarShrine_b35ee9b618a76bfd",IdString="-2703501761946152375",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_b35ee9b618a76bfdf24596944d7b11b0",Native=false},
    {Name="Completionist_V105_Coffin_27372e7163253c31",IdString="-2656326019589572525",Family="coffin",Realm="Helheim",CatalogueId="coffin_27372e7163253c3104b397c707ea53bb",Native=false},
    {Name="Completionist_V105_WoodenChest_32d3304f8c18fe1f",IdString="-2597784998102421553",Family="wooden_chest",Realm="Alfheim",CatalogueId="wooden_chest_32d3304f8c18fe1f9d5564e870022cb2",Native=false},
    {Name="Completionist_V105_WoodenChest_cdd6d123984e32a1",IdString="-2470837915979523554",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_cdd6d123984e32a1c6857daaf4212181",Native=false},
    {Name="Completionist_V105_JotnarShrine_1af4f035065fe960",IdString="-2465010874497660691",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_1af4f035065fe9603505c02d9b2e1462",Native=false},
    {Name="Completionist_V105_WoodenChest_c0f40c082a0434d8",IdString="-2362518680182023781",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_c0f40c082a0434d8ba5ee63ee743fb69",Native=false},
    {Name="Completionist_V105_Artefact_6f83c0ef48eda412",IdString="-2199748012402474676",Family="artefact",Realm="Midgard",CatalogueId="artefact_6f83c0ef48eda412050135a827d51a7a",Native=false},
    {Name="Completionist_V105_Coffin_96381eab3f2918f7",IdString="-2183373477064341078",Family="coffin",Realm="Midgard",CatalogueId="coffin_96381eab3f2918f7ebb47343422a8203",Native=false},
    {Name="Completionist_V105_LegendaryChest_0a04b4de469f3b03",IdString="-2176166598629371476",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_0a04b4de469f3b030064d6827966b213",Native=false},
    {Name="Completionist_V105_Coffin_56534d8b5b802d5d",IdString="-2094951282706791485",Family="coffin",Realm="Midgard",CatalogueId="coffin_56534d8b5b802d5d59344beffd1fe9e6",Native=false},
    {Name="Completionist_V105_LegendaryChest_9226bd444f0f0b95",IdString="-1937228073994400438",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_9226bd444f0f0b95dbeb7c927c6b317b",Native=false},
    {Name="Completionist_V105_LegendaryChest_f714d2d845a3dd9e",IdString="-1882056294429297798",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_f714d2d845a3dd9e28808db4655e757f",Native=false},
    {Name="Completionist_V105_WoodenChest_cb10ac445973e539",IdString="-1842566167621139438",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_cb10ac445973e539532db961c1af4e8a",Native=false},
    {Name="Completionist_V105_CipherChest_371db5ac6ac1a1ca",IdString="-1744502317305118373",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_371db5ac6ac1a1ca6bfe75a33315fe6d",Native=false},
    {Name="Completionist_V105_WoodenChest_f366e563226a159b",IdString="-1701624960958618376",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_f366e563226a159bf67b76e565795e3d",Native=false},
    {Name="Completionist_V105_WoodenChest_c99b83ff35c4c302",IdString="-1683844269136190683",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_c99b83ff35c4c302a595c64fc926d86e",Native=false},
    {Name="Completionist_V105_TreasureDig_4a770cc6263ef7c8",IdString="-1477170105643639988",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_4a770cc6263ef7c83b7ea0e4130c6c59",Native=false},
    {Name="Completionist_V105_Coffin_dccf636343f08c57",IdString="-1408125570402505955",Family="coffin",Realm="Midgard",CatalogueId="coffin_dccf636343f08c57b98bf198059a985f",Native=false},
    {Name="Completionist_V105_LegendaryChest_b9e3be9a46c248cc",IdString="-1343166338528862020",Family="legendary_chest",Realm="Midgard",CatalogueId="legendary_chest_b9e3be9a46c248cc0ddc159643259c52",Native=false},
    {Name="Completionist_V105_Coffin_3340c95401883964",IdString="-1305963614150974240",Family="coffin",Realm="Midgard",CatalogueId="coffin_3340c954018839640be00a0955892015",Native=false},
    {Name="Completionist_V105_Coffin_7a8d01b3f8a471a6",IdString="-1298630826637556666",Family="coffin",Realm="Midgard",CatalogueId="coffin_7a8d01b3f8a471a6b7ae8d058f00f12b",Native=false},
    {Name="Completionist_V105_RealmTear_f4600a74cbfaceab",IdString="-1117082438611961954",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_f4600a74cbfaceabd4ba6d80a59a66bc",Native=false},
    {Name="Completionist_V105_WoodenChest_2b8135ab4e852651",IdString="-1048521074081226468",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_2b8135ab4e8526519563c8c391f156f9",Native=false},
    {Name="Completionist_V105_Artefact_85c29c2b42030656",IdString="-1041552554350891902",Family="artefact",Realm="Midgard",CatalogueId="artefact_85c29c2b420306564c28b5b09e22532c",Native=false},
    {Name="Completionist_V105_CipherChest_83a70788cdf281a8",IdString="-1003521713860716624",Family="cipher_chest",Realm="Midgard",CatalogueId="cipher_chest_83a70788cdf281a83161cd7e70101b11",Native=false},
    {Name="Completionist_V105_Coffin_dfca3d7720861fb5",IdString="-996715238000915415",Family="coffin",Realm="Midgard",CatalogueId="coffin_dfca3d7720861fb51244d4e8278d5ab5",Native=false},
    {Name="Completionist_V105_Artefact_0bcf15d773e2e35e",IdString="-948881683251325081",Family="artefact",Realm="Helheim",CatalogueId="artefact_hel300mainbridgewad00c124ebae0bc24f8b64cc6305246b22",Native=false},
    {Name="Completionist_V105_TreasureDig_1004498996e12e1b",IdString="-897093656720119905",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_1004498996e12e1bd865e937caf21f2d",Native=false},
    {Name="Completionist_V105_LoreMarker_f45e83afc1a3e197",IdString="-867651210084953586",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl200funeralwadf8ceaf9fdf59ef4c97b6d4398c23bb9d",Native=false},
    {Name="Completionist_V105_Coffin_6dd3b15c19d26faa",IdString="-865298406056239395",Family="coffin",Realm="Midgard",CatalogueId="coffin_6dd3b15c19d26faac0ddfecf339a50ab",Native=false},
    {Name="Completionist_V105_WoodenChest_43a2c9ef875eebd6",IdString="-852413048453688747",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_43a2c9ef875eebd6fff86ba2324a982f",Native=false},
    {Name="Completionist_V105_Coffin_4cb03c6689641245",IdString="-841714862522455856",Family="coffin",Realm="Midgard",CatalogueId="coffin_4cb03c66896412451b9a805908c61395",Native=false},
    {Name="Completionist_V105_LegendaryChest_957a57b3456bd17f",IdString="-817888565120354013",Family="legendary_chest",Realm="Helheim",CatalogueId="legendary_chest_957a57b3456bd17fd24751a66dbcf01c",Native=false},
    {Name="Completionist_V105_Coffin_ea9eca6feb88066f",IdString="-787661187982761375",Family="coffin",Realm="Midgard",CatalogueId="coffin_ea9eca6feb88066fe4fc1111549e67df",Native=false},
    {Name="Completionist_V105_RealmTear_c3d17070f981647e",IdString="-731728806288062009",Family="realm_tear",Realm="Midgard",CatalogueId="realm_tear_c3d17070f981647e7189e2076fbcc55c",Native=false},
    {Name="Completionist_V105_Coffin_5ee94e6e2d8b3f4f",IdString="-715906782878663188",Family="coffin",Realm="Midgard",CatalogueId="coffin_5ee94e6e2d8b3f4f14621809c749f528",Native=false},
    {Name="Completionist_V105_LoreMarker_5f40faeb8c99419d",IdString="-715491940518690903",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl425huldramineslhwad7f236d968be3c14db2ecde8780a968a0",Native=false},
    {Name="Completionist_V105_Coffin_711c078a74590cb2",IdString="-627812059006470155",Family="coffin",Realm="Midgard",CatalogueId="coffin_711c078a74590cb2158c1d1ea7e73389",Native=false},
    {Name="Completionist_V105_TreasureDig_4ec60e59f3208691",IdString="-623701506868062659",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_4ec60e59f32086918769282570d5b976",Native=false},
    {Name="Completionist_V105_TreasureDig_c49a3435a3361bfb",IdString="-607711772100173543",Family="treasure_dig",Realm="Midgard",CatalogueId="treasure_dig_c49a3435a3361bfb0f23ee7a0cecc202",Native=false},
    {Name="Completionist_V105_Coffin_45c3d28bfce2949e",IdString="-596674743411873540",Family="coffin",Realm="Midgard",CatalogueId="coffin_45c3d28bfce2949e7091ea076388005c",Native=false},
    {Name="Completionist_V105_LoreMarker_12f9ec93f4351d0f",IdString="-574768956344372773",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_xpl170httkcaverwad776651e16e0bcd4995eaa2ad3e73f56a",Native=false},
    {Name="Completionist_V105_Coffin_02468d124aa5c027",IdString="-498550042982856759",Family="coffin",Realm="Midgard",CatalogueId="coffin_02468d124aa5c0271a90ef15db3a4a9e",Native=false},
    {Name="Completionist_V105_Coffin_cecd3e1ed37118db",IdString="-430471420393370279",Family="coffin",Realm="Midgard",CatalogueId="coffin_cecd3e1ed37118dbc783f38c40ee4803",Native=false},
    {Name="Completionist_V105_Coffin_8c8f0d2bb8dc26dc",IdString="-421942001115425257",Family="coffin",Realm="Midgard",CatalogueId="coffin_8c8f0d2bb8dc26dc1867c39ec44b8c11",Native=false},
    {Name="Completionist_V105_Coffin_e8c9695dda4a8365",IdString="-409322120926686459",Family="coffin",Realm="Midgard",CatalogueId="coffin_e8c9695dda4a836583ad311f9b98d043",Native=false},
    {Name="Completionist_V105_Coffin_e056e03bfc0b68e1",IdString="-400694198277394304",Family="coffin",Realm="Midgard",CatalogueId="coffin_e056e03bfc0b68e1f7569b3a03f72722",Native=false},
    {Name="Completionist_V105_WoodenChest_8d860a080b9f385f",IdString="-367408801454487083",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_8d860a080b9f385f3a3105e035d73ab3",Native=false},
    {Name="Completionist_V105_WoodenChest_7d184e88e7aca574",IdString="-342537859538620296",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_7d184e88e7aca574911c6f1addd2a686",Native=false},
    {Name="Completionist_V105_Coffin_4721aafec0abacd3",IdString="-327507519671973788",Family="coffin",Realm="Midgard",CatalogueId="coffin_4721aafec0abacd3c4adb354cdf6c224",Native=false},
    {Name="Completionist_V105_JotnarShrine_8a16de1ec11694c5",IdString="-316697092469146210",Family="jotnar_shrine",Realm="Midgard",CatalogueId="jotnar_shrine_8a16de1ec11694c5752092bd06e16978",Native=false},
    {Name="Completionist_V105_Artefact_26636871da7f3e4d",IdString="-203646067557816941",Family="artefact",Realm="Midgard",CatalogueId="artefact_xpl200funeralwadb6e2b2a41a1b3e4c9ff1f8e5f877039a",Native=false},
    {Name="Completionist_V105_LoreMarker_bacefa2fe0d034fb",IdString="-188502632123189576",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_3d2e2f04d7df6a4b9a4e30601432871f",Native=false},
    {Name="Completionist_V105_LoreMarker_656b3266238c8d8f",IdString="-158701527096751563",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_cal250foothillslhwad9614e6b2dfd34f4b86e932b59f2aa621",Native=false},
    {Name="Completionist_V105_LoreMarker_f02c634460af2de5",IdString="-18980505124935982",Family="lore_marker",Realm="Midgard",CatalogueId="lore_marker_ab859d0b83766845bb0b0e69023e1c31",Native=false},
    {Name="Completionist_V105_WoodenChest_bcbcd78c5be5d229",IdString="-9251458826966510",Family="wooden_chest",Realm="Midgard",CatalogueId="wooden_chest_bcbcd78c5be5d2298f527c26f48c5563",Native=false},
  }
  local byName, byFamily, byCatalogue, nativeIds = {}, {}, {}, {}
  for _, category in ipairs(categories) do
    byFamily[category.Family] = category
    completionistFilterLabels[category.Filter] = category.Label
  end
  for _, row in ipairs(rows) do
    byName[row.Name] = row
    if row.CatalogueId then byCatalogue[row.CatalogueId] = row end
    if row.Native then nativeIds[row.IdString] = true end
  end

  local digQuests = {
    ["treasure_dig_5f6d01b68cdf70a9815dc6fa7c3a839f"] = "Quest_TreasureMap_BlackBreath",
    ["treasure_dig_c49a3435a3361bfb0f23ee7a0cecc202"] = "Quest_TreasureMap_TurtleHouse",
    ["treasure_dig_33fd783f7b353537d922042c2a967396"] = "Quest_TreasureMap_VF",
    ["treasure_dig_ebcc555c3dc8b13561d8afa2bd4c0ba0"] = "Quest_TreasureMap_Stronghold",
    ["treasure_dig_1004498996e12e1bd865e937caf21f2d"] = "Quest_TreasureMap_ValkyrieArena",
    ["treasure_dig_70214d5859cc48c2bfddd06fb252a8ba"] = "Quest_TreasureMap_Oarsmen",
    ["treasure_dig_8d79870871fe184c47d369eabbd68f92"] = "Quest_TreasureMap_ForestDungeon",
    ["treasure_dig_a46f12e366ccfd55f7a945383f1231d0"] = "Quest_TreasureMap_IslandArch",
    ["treasure_dig_9680b8bc8eff19d4c84b439b0e5a841b"] = "Quest_TreasureMap_Shipwreck",
    ["treasure_dig_8c965bccff326f509c02f9321af9a223"] = "Quest_TreasureMap_IslandClimb",
    ["treasure_dig_4a770cc6263ef7c83b7ea0e4130c6c59"] = "Quest_TreasureMap01",
    ["treasure_dig_4ec60e59f32086918769282570d5b976"] = "Quest_TreasureMap_ThorStatue",
  }

  local mapQuests = {
    ["treasure_map_4011675d69434ff50662d79d43b08305"] = "Quest_TreasureMap_IslandClimb_Parent",
    ["treasure_map_f48eb59997ca3572363316461a106067"] = "Quest_TreasureMap_ValkyrieArena_Parent",
    ["treasure_map_3cab9691f053fec1dc02301cf9c04021"] = "Quest_TreasureMap_TurtleHouse_Parent",
    ["treasure_map_82e41ccaf3093e62880d64a18227112c"] = "Quest_TreasureMap_Oarsmen_Parent",
    ["treasure_map_67ec3f2c214e4fd07a7eaf0b58cf213c"] = "Quest_TreasureMap01_Parent",
    ["treasure_map_ce589a091d984c3581097a8700aad61d"] = "Quest_TreasureMap_ThorStatue_Parent",
    ["treasure_map_b08d1fd606f2ac8a09bf8edc6d5a55b7"] = "Quest_TreasureMap_BlackBreath_Parent",
    ["treasure_map_adf20b36ad0f86b68901b8e49aeeb498"] = "Quest_TreasureMap_ForestDungeon_Parent",
    ["treasure_map_8b1707f94ad818100dd4a5afc67fc6c6"] = "Quest_TreasureMap_Stronghold_Parent",
    ["treasure_map_4a07636dc59583c9bfe877849ab5a97f"] = "Quest_TreasureMap_IslandArch_Parent",
    ["treasure_map_aef0891f1c3ee6d1f88f86b1601052f4"] = "Quest_TreasureMap_VF_Parent",
    ["treasure_map_5d8b3d55a299888357a6893fcec99c05"] = "Quest_TreasureMap_Shipwreck_Parent",
  }

  local shrineResources = {
    ["jotnar_shrine_4f54c8b2f4d927800573fde8aece376f"] = "Tryptich_Skadi",
    ["jotnar_shrine_682f1626cae370f11b4df300ae79219d"] = "Tryptich_Surtr",
    ["jotnar_shrine_6e55a7d7704af68ce4b82e5edecf81a7"] = "Tryptich_Groa",
    ["jotnar_shrine_7dadb7c3e8c5fdc6259b311fe6ac74ba"] = "Tryptich_Solargram",
    ["jotnar_shrine_b124fa2d62938dc8fcf85d67432d8550"] = "Tryptich_Starkadr",
    ["jotnar_shrine_b35ee9b618a76bfdf24596944d7b11b0"] = "Tryptich_Thrym",
    ["jotnar_shrine_e49959e54f3f1da0632c3ac2a01d7ec7"] = "Tryptich_Thamur",
    ["jotnar_shrine_1af4f035065fe9603505c02d9b2e1462"] = "Tryptich_Tyr",
    ["jotnar_shrine_23d6030ef079b748c4574a940bf2047b"] = "Tryptich_Tyr",
    ["jotnar_shrine_5abb17c179c16ed72287fc2740a46f9a"] = "Tryptich_Ymir",
    ["jotnar_shrine_8a16de1ec11694c5752092bd06e16978"] = "Tryptich_Bergelmir",
    ["jotnar_shrine_c0d7a4d17e152054e3e3c3e2571d98b8"] = "Tryptich_Hrungnir",
    ["jotnar_shrine_19c69abd2cdf4145b71903eabdaf87f8"] = "Tryptich_Jormungandr",
  }

  local scrollResources = {
    ["lore_scroll_dc56801cbe1e7d3cbd54f9150cc78a3c"] = "ForestChisel_Lore",
    ["lore_scroll_62cc5c222fbe7d849e83705cfe13638c"] = "SerpentScroll_Lore",
    ["lore_scroll_0a8de84c5e82fd19ccc618bce5ef6f84"] = "JotunheimScroll_Lore",
    ["lore_scroll_2242aadeda389dae8c5283057c5326ca"] = "SvartleheimScroll_Lore",
    ["lore_scroll_e8415d73adfe99aa45c8e142856455da"] = "ShipwreckIsland_Lore",
  }

  local loreResources = {
    ["lore_marker_alf150bridgedarkwad76250fcb340065498ff1b75bddd20fcf"] = "ALF_100_Lore_01",
    ["lore_marker_alf150bridgedarkwad969e45f02f76844192ec5566056fbfd4"] = "ALF_100_Lore_01",
    ["lore_marker_alf440hiveextlhwad0f75539e19bc0947ba4d6f46ea0a95d2"] = "ALF_390_Lore_01",
    ["lore_marker_alf690lakelightlhwade723fb1f62e1ef4a94d19a5eeeef0673"] = "ALF_690_Lore_01",
    ["lore_marker_cal250foothillslhwadb456381ff98fb449896acb659da524fa"] = "CAL_250_Lore_02",
    ["lore_marker_cal250foothillslhwad8ab6b877e9062c4b9f0d0f375f8326c1"] = "CAL_250_Lore_03",
    ["lore_marker_cal250foothillslhwad9614e6b2dfd34f4b86e932b59f2aa621"] = "CAL_250_Lore_01",
    ["lore_marker_xpl910islandshipwreckwad6093995aaaf7ad4b9830d1be0e7e0684"] = "CAL_100_Lore_01",
    ["lore_marker_xpl940beachcavewad6093995aaaf7ad4b9830d1be0e7e0684"] = "CAL_100_Lore_01",
    ["lore_marker_xpl950beachmazewad6093995aaaf7ad4b9830d1be0e7e0684"] = "CAL_100_Lore_01",
    ["lore_marker_xpl960beachshipwad6093995aaaf7ad4b9830d1be0e7e0684"] = "CAL_100_Lore_01",
    ["lore_marker_cal500runevaultwad14f472bb0d9d2e4993d0774cbc755e02"] = "CAL_500_Lore_01",
    ["lore_marker_3d2e2f04d7df6a4b9a4e30601432871f"] = "CAL_740_Lore_01",
    ["lore_marker_d988f2795775914592a04b62df2726d9"] = "CAL_750_Lore_01",
    ["lore_marker_xpl125httklhwad36f99a6c8537174bbaab95fb9d956455"] = "HTTK_125_Lore_01",
    ["lore_marker_xpl170httkcaverwad776651e16e0bcd4995eaa2ad3e73f56a"] = "HTTK_170_Lore_01",
    ["lore_marker_xpl400huldramineswade1701a5ddf529645b442371f82145220"] = "Xpl450_DeathHere",
    ["lore_marker_xpl400huldramineswadf014bd94366e7b49ade008aff1769396"] = "Xpl450_InnMenn",
    ["lore_marker_xpl425huldramineslhwad7f236d968be3c14db2ecde8780a968a0"] = "Xpl425_LoreMarker",
    ["lore_marker_xpl300strongholdwad79d7700bc6e8cf47a77b5403426b5297"] = "Xpl300_FalseLeader",
    ["lore_marker_xpl300strongholdwade361f1b4a04c074b84896263475139ab"] = "Xpl300_LoreMarker",
    ["lore_marker_xpl650masontrailcavewadb2f0bf0705313e4aa27b33fddd3a0665"] = "Xpl650_LoreMarker",
    ["lore_marker_peak100entrancewadeda4d87459eae64ba0a1c556edca5809"] = "PP_100_Lore_01",
    ["lore_marker_peak140caverndarkwad3aae61a66981c34082d9e3dcb14c9a39"] = "PP_140_Lore_01",
    ["lore_marker_peak180enttochimneylhwadcc54f8d5e69b0945a3674ddc65276412"] = "PP_180_Lore_02",
    ["lore_marker_peak200chimneylowwad29a3fec3318213458a458abb0eb539a2"] = "PP_300_Lore_01",
    ["lore_marker_peak500chimneytopwad1d9b928f5f7eab4082f9c52e2f066780"] = "PP_500_Lore_01",
    ["lore_marker_peak720summitascenthubwadda8178f1357e8d45922a657e6f760dd8"] = "PP_720_Lore_01",
    ["lore_marker_riv085dangersentrancelhwad0359c55688ca5b48bd66cf4ae66fbed3"] = "RIV_100_Lore_01",
    ["lore_marker_riv200dangersmainwad452dc462aab2814097a8c9a7d317c558"] = "RIV_200_Lore_01",
    ["lore_marker_riv420forestboarstartwad0c671129ecb3144cbcf4a641a4160b66"] = "RIV_420_Lore_01",
    ["lore_marker_riv475freyahouseextwad5124f330461a8e42b1659c4517e18c29"] = "RIV_475_Lore_01",
    ["lore_marker_riv475freyahouseextwad9a50243a697a924481d49d5c44c980ac"] = "RIV_475_Lore_02",
    ["lore_marker_riv475freyahouseextwadd328468a73cead438031e76201fbddc9"] = "RIV_475_Lore_03",
    ["lore_marker_ab859d0b83766845bb0b0e69023e1c31"] = "RIV_925_Lore_01",
    ["lore_marker_stn200lakeextwad64309dc36de48d438409f5abb85cfc92"] = "SM_200_Lore_01",
    ["lore_marker_xpl200funeralwadf8ceaf9fdf59ef4c97b6d4398c23bb9d"] = "VF_200_Lore_03",
    ["lore_marker_xpl200funeralwad0ab993b107a42f41af27749c6749728d"] = "VF_200_Lore_02",
    ["lore_marker_xpl220funerallhwadeea6c57321539249a4d58ca8baa527cb"] = "VF_220_Lore_01",
    ["lore_marker_xpl225funerallhwadb18d193b7ba34340a8831d0e11ff1b4e"] = "XPL_200_Lore_01",
    ["lore_marker_xpl225funerallhwadfb3c8f6c096b464dafa89220022f8c54"] = "VF_225_Lore_01",
    ["lore_marker_xpl250funeralinteriorwadd1ddaedac0dbac478444718ac2f19211"] = "VF_250_Lore_01",
    ["lore_marker_nid150calderabridgewad2eabc6ebc9dafd40b34cb41a6ffcd2d4"] = "NIF_150_Lore_01",
  }

  local riftQuests = {
    ["realm_tear_10374be1dacc7b5afc9b38ff1c50b3f5"] = "RegionSummary_NID_PocketRift_Parent",
    ["realm_tear_80a81219135f07ea1c0eb1948748fc58"] = "RegionSummary_NID_PocketRift_Parent",
    ["realm_tear_ad3009f9f80b31ab80419fd380e60c1c"] = "RegionSummary_NID_PocketRift_Parent",
    ["realm_tear_885f79d8699b58e655739f1b924bf442"] = "RegionSummary_ALF_PocketRift_Parent",
    ["realm_tear_d9d5fe53b4d7bd0c88376c7647f5537e"] = "RegionSummary_ALF_PocketRift_Parent",
    ["realm_tear_c3d17070f981647e7189e2076fbcc55c"] = "RegionSummary_HTTK_PocketRift_Parent",
    ["realm_tear_75c3365cbb3042f761a82660c314147e"] = "RegionSummary_CALT_PocketRift_Parent",
    ["realm_tear_12672293750dfc6b1381cf5159ad0615"] = "RegionSummary_ISL_PocketRift_Parent",
    ["realm_tear_cb9a35e72a6bd571c820349c901762a9"] = "RegionSummary_ISL_PocketRift_Parent",
    ["realm_tear_1c939364d61323b0c9db30a25da5b0f0"] = "RegionSummary_FOO_PocketRift_Parent",
    ["realm_tear_a3857496e778be84cdb14938feb3885d"] = "RegionSummary_FOO_PocketRift_Parent",
    ["realm_tear_64256db4dca56cbedc9c2ad1bb454bef"] = "RegionSummary_RP_PocketRift_Parent",
    ["realm_tear_f4600a74cbfaceabd4ba6d80a59a66bc"] = "RegionSummary_RP_PocketRift_Parent",
    ["realm_tear_64b7ac07cbf1db2d7956e3298e23970f"] = "RegionSummary_CALS_PocketRift_Parent",
    ["realm_tear_664c0fd312a6e88d8739f7d5af968fe3"] = "RegionSummary_CALS_PocketRift_Parent",
    ["realm_tear_6f5037ce091595b1bc2b0ab31cfaf05b"] = "RegionSummary_CALS_PocketRift_Parent",
    ["realm_tear_71588ab9681c6184279e7384fdafbbdd"] = "RegionSummary_CALS_PocketRift_Parent",
    ["realm_tear_ae12a2c33fd8e441bf159a5fd7ac3c22"] = "RegionSummary_CALS_PocketRift_Parent",
    ["realm_tear_af0e22716b928bcf52889387ffc91c4f"] = "RegionSummary_CALS_PocketRift_Parent",
    ["realm_tear_2b6da4fe76312741d21ade4905d66ff4"] = "RegionSummary_MID_PocketRift_Parent",
    ["realm_tear_b24fe2ba5298d202f41bda97b2a00845"] = "RegionSummary_MID_PocketRift_Parent",
  }

  local artefactResources = {
    ["artefact_707ae0e24dc7bc9a56c19eb7ce17b351"] = "AlfheimArtifact01",
    ["artefact_56c4354a4141de7afc7f2e8447ab8767"] = "AlfheimArtifact02",
    ["artefact_5bf15dbc48613f5b548fd2a673d8f7bc"] = "AlfheimArtifact03",
    ["artefact_6e3739ea4ac8107c495a61af774a9b03"] = "AlfheimArtifact04",
    ["artefact_0d53040849957335c6db68809206f5d1"] = "AlfheimArtifact05",
    ["artefact_eb672a1647b1f7e64595e48f821670f5"] = "BroochRay",
    ["artefact_hel300mainbridgewad00c124ebae0bc24f8b64cc6305246b22"] = "BroochRuby",
    ["artefact_hel300mainbridgewadb5b33ffb0d723f44a135047d5a839e32"] = "BroochRuby",
    ["artefact_hel300mainbridgewade4b6326ae64d514490a45593d471478f"] = "BroochRuby",
    ["artefact_c7f91ac1447cff68599696bbbb58e7b7"] = "BroochAnimal",
    ["artefact_7d8a35dc4d6aabf8065e1ead0c470fcc"] = "ShipGoldHook2",
    ["artefact_5bb11ed5419b42caba813598d29ca473"] = "ShipTongue",
    ["artefact_01a8ba24409b5fb49a1c18b43669fe44"] = "ShipSeaHorse",
    ["artefact_379728fc47e4a966be1fc9926011184b"] = "ShipHook",
    ["artefact_6cffc9884efa77b424baf987adfdba6a"] = "ShipHook",
    ["artefact_4a3d314942f187f69ee5b78302e118fe"] = "ShipHook2",
    ["artefact_f7fbfc3f44991b3da37871879e6de737"] = "ShipHook2",
    ["artefact_989065ff4bde64f5ec957da2759037cb"] = "LostToyTroll",
    ["artefact_c9b7e23040c21e2da5fe8ba4be8ad415"] = "NorseMaskGoat",
    ["artefact_bd9a46a34b8fd4660be2129e27fa4004"] = "ShipGoldHook",
    ["artefact_a0588a9442f0118bdce0cda751b8605d"] = "LostToyBoat",
    ["artefact_ab662cc14c4a21327111dea1a34b96c3"] = "LostToyHorse",
    ["artefact_8916f55c4511b74ba8601ba7ef3d86bb"] = "LostToySpearGuy",
    ["artefact_fda837834b361579d4a29194810c3d09"] = "ShipDragon",
    ["artefact_fae85e594ef79ee2e204719767dd5287"] = "CupDragon",
    ["artefact_6f83c0ef48eda412050135a827d51a7a"] = "CupPintGlass",
    ["artefact_33f59ee746f63f40199e5f90cad3c236"] = "CupHandle",
    ["artefact_b52df62545c16741e6f2278f9e2ccc32"] = "CupGoblet",
    ["artefact_b18794364cc6b6a5c08596ab8699f35b"] = "CupFeet",
    ["artefact_f5bd8953457f9662d074d798a111abfc"] = "CupHolyGrail",
    ["artefact_0a43e4954d4fff46abb9ca8e34d875c0"] = "NorseMaskFlatBeard",
    ["artefact_85c29c2b420306564c28b5b09e22532c"] = "NorseMaskReptile",
    ["artefact_0da7cb9744da59cb80fe319d95cada55"] = "NorseMaskCurlyBeard",
    ["artefact_6fa420df406be3d033b7eea35a4d10fe"] = "NorseMaskTiki",
    ["artefact_468c195b480889e354742b876aef3a11"] = "NorseMaskMustache",
    ["artefact_28b7fe1349cdc49da573c6a0657f0a9d"] = "NorseMaskStoneFace",
    ["artefact_cf7627ad486711d9eab3339782e5a147"] = "NorseMaskStraightBeard",
    ["artefact_fa511e0a422421b7acc01fa5829c4fe3"] = "NorseMaskGhoul",
    ["artefact_xpl200funeralwad2768cb29f445634bb075f7a858cabcc3"] = "HornUShape",
    ["artefact_xpl200funeralwad52e9ebf8ef1b3343b5d025a73ad6fa91"] = "HornUShape",
    ["artefact_xpl200funeralwadb6e2b2a41a1b3e4c9ff1f8e5f877039a"] = "HornUShape",
    ["artefact_xpl200funeralwadbb9465a7407c9849bf891e0205dac801"] = "HornUShape",
    ["artefact_xpl250funeralinteriorwad3f176e49e0a0cd4f8cf59ada5fe9c2d8"] = "HornHorse",
    ["artefact_xpl250funeralinteriorwad4813767722fa414b9a3d4972dc8874e7"] = "HornHorse",
  }

  local function isDirectlyCollected(row)
    if type(game) ~= "table" then return false end
    local cid = row.CatalogueId
    if not cid then return false end
    local fam = row.Family

    if fam == "treasure_dig" then
      local q = digQuests[cid]
      if q and type(game.QuestManager) == "table" and type(game.QuestManager.GetQuestState) == "function" then
        local ok, st = pcall(game.QuestManager.GetQuestState, q)
        if ok and st == "Complete" then return true end
        local ok2, pst = pcall(game.QuestManager.GetQuestState, q .. "_Parent")
        if ok2 and pst == "Complete" then return true end
      end
    elseif fam == "treasure_map" then
      local mq = mapQuests[cid]
      if mq and type(game.QuestManager) == "table" and type(game.QuestManager.GetQuestState) == "function" then
        local ok, st = pcall(game.QuestManager.GetQuestState, mq)
        if ok and st and st ~= "" and st ~= "Inactive" then return true end
      end
    elseif fam == "jotnar_shrine" then
      local sr = shrineResources[cid]
      if sr and type(game.Wallets) == "table" then
        if type(game.Wallets.HasResource) == "function" then
          local ok, res = pcall(game.Wallets.HasResource, "HERO", sr)
          if ok and res == true then return true end
          local ok2, res2 = pcall(game.Wallets.HasResource, "HERO_SAVEONLY", sr)
          if ok2 and res2 == true then return true end
        end
        if type(game.Wallets.GetResourceValue) == "function" then
          local ok, val = pcall(game.Wallets.GetResourceValue, "HERO", sr)
          if ok and type(val) == "number" and val > 0 then return true end
          local ok2, val2 = pcall(game.Wallets.GetResourceValue, "HERO_SAVEONLY", sr)
          if ok2 and type(val2) == "number" and val2 > 0 then return true end
        end
      end
    elseif fam == "lore_marker" then
      local lr = loreResources[cid]
      if lr and type(game.Wallets) == "table" then
        if type(game.Wallets.HasResource) == "function" then
          local ok, res = pcall(game.Wallets.HasResource, "HERO", lr)
          if ok and res == true then return true end
          local ok2, res2 = pcall(game.Wallets.HasResource, "HERO_SAVEONLY", lr)
          if ok2 and res2 == true then return true end
        end
        if type(game.Wallets.GetResourceValue) == "function" then
          local ok, val = pcall(game.Wallets.GetResourceValue, "HERO", lr)
          if ok and type(val) == "number" and val > 0 then return true end
          local ok2, val2 = pcall(game.Wallets.GetResourceValue, "HERO_SAVEONLY", lr)
          if ok2 and type(val2) == "number" and val2 > 0 then return true end
        end
      end
    elseif fam == "lore_scroll" then
      local scr = scrollResources[cid]
      if scr and type(game.Wallets) == "table" then
        if type(game.Wallets.HasResource) == "function" then
          local ok, res = pcall(game.Wallets.HasResource, "HERO", scr)
          if ok and res == true then return true end
          local ok2, res2 = pcall(game.Wallets.HasResource, "HERO_SAVEONLY", scr)
          if ok2 and res2 == true then return true end
        end
        if type(game.Wallets.GetResourceValue) == "function" then
          local ok, val = pcall(game.Wallets.GetResourceValue, "HERO", scr)
          if ok and type(val) == "number" and val > 0 then return true end
          local ok2, val2 = pcall(game.Wallets.GetResourceValue, "HERO_SAVEONLY", scr)
          if ok2 and type(val2) == "number" and val2 > 0 then return true end
        end
      end
    elseif fam == "realm_tear" then
      local rq = riftQuests[cid]
      if rq and type(game.QuestManager) == "table" and type(game.QuestManager.GetQuestState) == "function" then
        local ok, st = pcall(game.QuestManager.GetQuestState, rq)
        if ok and st == "Complete" then return true end
      end
      if type(game.QuestManager) == "table" and type(game.QuestManager.GetQuestState) == "function" then
        local ok, lst = pcall(game.QuestManager.GetQuestState, "Quest_Labor_RiftPockets_Silver")
        if ok and lst == "Complete" then return true end
      end
      if (cid == "realm_tear_10374be1dacc7b5afc9b38ff1c50b3f5" or
          cid == "realm_tear_80a81219135f07ea1c0eb1948748fc58" or
          cid == "realm_tear_ad3009f9f80b31ab80419fd380e60c1c") and
         type(game.Wallets) == "table" then
        if type(game.Wallets.GetResourceValue) == "function" then
          local ok, val = pcall(game.Wallets.GetResourceValue, "HERO", "NiflheimTrophyTracker")
          if ok and type(val) == "number" and val > 0 then return true end
          local ok2, val2 = pcall(game.Wallets.GetResourceValue, "HERO_SAVEONLY", "NiflheimTrophyTracker")
          if ok2 and type(val2) == "number" and val2 > 0 then return true end
        end
        if type(game.Wallets.HasResource) == "function" then
          local ok, res = pcall(game.Wallets.HasResource, "HERO", "NiflheimTrophyTracker")
          if ok and res == true then return true end
          local ok2, res2 = pcall(game.Wallets.HasResource, "HERO_SAVEONLY", "NiflheimTrophyTracker")
          if ok2 and res2 == true then return true end
        end
      end
    elseif fam == "artefact" then
      local ar = artefactResources[cid]
      if ar and type(game.Wallets) == "table" then
        local threshold = 1
        if ar == "HornUShape" then threshold = 4
        elseif ar == "BroochRuby" then threshold = 3
        elseif ar == "HornHorse" or ar == "ShipHook" or ar == "ShipHook2" then threshold = 2 end

        if type(game.Wallets.GetResourceValue) == "function" then
          local ok, val = pcall(game.Wallets.GetResourceValue, "HERO", ar)
          if ok and type(val) == "number" and val >= threshold then return true end
          local ok2, val2 = pcall(game.Wallets.GetResourceValue, "HERO_SAVEONLY", ar)
          if ok2 and type(val2) == "number" and val2 >= threshold then return true end
        end
        if threshold == 1 and type(game.Wallets.HasResource) == "function" then
          local ok, res = pcall(game.Wallets.HasResource, "HERO", ar)
          if ok and res == true then return true end
          local ok2, res2 = pcall(game.Wallets.HasResource, "HERO_SAVEONLY", ar)
          if ok2 and res2 == true then return true end
        end
      end
      if type(game.QuestManager) == "table" and type(game.QuestManager.GetQuestState) == "function" then
        local questMap = {
          Alfheim = "Quest_Artifacts_Alfheim",
          Brooch = "Quest_Artifacts_Brooches",
          Cup = "Quest_Artifacts_OrnateCups",
          Horn = "Quest_Artifacts_VikingHorns",
          Mask = "Quest_Artifacts_NorseMasks",
          Ship = "Quest_Artifacts_ShipHeads",
          Toy = "Quest_Artifacts_LostToys",
        }
        if ar then
          for prefix, qName in pairs(questMap) do
            if ar:find("^" .. prefix) or (prefix == "Ship" and ar:find("^Ship")) or (prefix == "Toy" and ar:find("^LostToy")) or (prefix == "Mask" and ar:find("^NorseMask")) then
              local ok, st = pcall(game.QuestManager.GetQuestState, qName)
              if ok and st == "Complete" then return true end
              local ok2, st2 = pcall(game.QuestManager.GetQuestState, qName .. "_Parent")
              if ok2 and st2 == "Complete" then return true end
            end
          end
        end
      end
    end
    return false
  end

  local function syncDirectObservations(rt, epoch)
    if rt == nil or rt.store == nil then return end
    epoch = epoch or rt.store:Epoch()
    local before = rt.store:Revision()
    for _, row in ipairs(rows) do
      if row.CatalogueId and rt.store:Get(row.CatalogueId) ~= "collected" and isDirectlyCollected(row) then
        rt.store:Observe(row.CatalogueId, "collected", epoch)
      end
    end
    if rt.store:Revision() ~= before then rt:Changed() end
  end

  local targetRow = nil

  local function updateHighlights(self)
    local target = self or activeMap
    if target == nil or type(UI) ~= "table" or type(UI.Anim) ~= "function" then return end
    for name, icon in pairs(target.completionistMapV105LocationIcons or {}) do
      local row = byName[name]
      if targetRow ~= nil and targetRow == row then
        pcall(UI.Anim, icon, AS_ForwardCycle_NoReset, "", 1)
      else
        pcall(UI.Anim, icon, AS_Forward, "", 0, 0)
      end
    end
    local nornirTargetName = (type(_G.CompletionistMapV105GetNornirTargetName) == "function") and
      _G.CompletionistMapV105GetNornirTargetName() or nil
    for name, icon in pairs(target.completionistMapV105NornirIdTestIcons or {}) do
      if nornirTargetName ~= nil and nornirTargetName == name then
        pcall(UI.Anim, icon, AS_ForwardCycle_NoReset, "", 1)
      else
        pcall(UI.Anim, icon, AS_Forward, "", 0, 0)
      end
    end
    local ravenTargetName = (type(_G.CompletionistMapV105GetRavenTargetName) == "function") and
      _G.CompletionistMapV105GetRavenTargetName() or nil
    for name, icon in pairs(target.completionistMapV105RavenIcons or {}) do
      if ravenTargetName ~= nil and ravenTargetName == name then
        pcall(UI.Anim, icon, AS_ForwardCycle_NoReset, "", 1)
      else
        pcall(UI.Anim, icon, AS_Forward, "", 0, 0)
      end
    end
  end

  local function hideTarget()
    if targetRow == nil then return true end
    local ok, result = pcall(game.Compass.HideMarker, targetRow.Name)
    if not ok or result == false then return false end
    targetRow = nil
    cleanupPending = nil
    updateHighlights(activeMap)
    return true
  end

  _G.CompletionistMapV105ReleaseLocationCompass = function()
    local ok = hideTarget()
    if activeMap and type(activeMap.UpdateMapMarkerHighlights) == "function" then
      pcall(activeMap.UpdateMapMarkerHighlights, activeMap)
    end
    return ok
  end
  _G.CompletionistMapV105HasLocationCompassTarget = function()
    return targetRow ~= nil
  end
  _G.CompletionistMapV105GetLocationTargetName = function()
    return targetRow and targetRow.Name or nil
  end
  _G.CompletionistMapV105UpdateHighlights = updateHighlights


  local function hideCollectedTarget()
    if targetRow ~= nil and (cleanupPending or (State and State:Get(targetRow.CatalogueId) == "collected") or isDirectlyCollected(targetRow)) then
      cleanupPending = true
      hideTarget()
    end
  end

  if runtime then
    runtime.cleanup = hideCollectedTarget
    runtime.directObserver = syncDirectObservations
  end

  if _G.CompletionistMapV105PersistentShowAll == nil then
    _G.CompletionistMapV105PersistentShowAll = true
  end
  if _G.CompletionistMapV105PersistentShowCategories == nil then
    _G.CompletionistMapV105PersistentShowCategories = true
  end

  _G.CompletionistMapV105ShowAll = function(val)
    if val ~= nil then _G.CompletionistMapV105PersistentShowAll = (val == true) end
    return _G.CompletionistMapV105PersistentShowAll
  end

  _G.CompletionistMapV105ShowCategories = function(val)
    if val ~= nil then _G.CompletionistMapV105PersistentShowCategories = (val == true) end
    return _G.CompletionistMapV105PersistentShowCategories
  end

  local function filter(self)
    return self.filterButtonMapping and self.filterButtonMapping[self.filterIndex] or 1
  end

  local function visible(self, row)
    if State and row.CatalogueId and State:Get(row.CatalogueId) == "collected" then return false end
    if isDirectlyCollected(row) then return false end
    if self.isOpenedForFastTravel or self.currRealmName ~= row.Realm then return false end
    local kind = filter(self)
    if kind == 1 then
      return _G.CompletionistMapV105ShowAll()
    elseif kind == -101 or kind == byFamily[row.Family].Filter then
      return _G.CompletionistMapV105ShowCategories()
    end
    return false
  end

  local function clearSelection(self, icon)
    if icon == nil or self.mapIconCollision == icon then self.mapIconCollision = nil end
    self.completionistMapV105LocationSelected = nil
    self.currMarkerID = nil
    if activeSelectionContext then
      pcall(function() self:SetReticleInfo(activeSelectionContext, "", "") end)
      pcall(function() self:UpdateFooterButtonPrompt(activeSelectionContext.menu, false, false) end)
    end
  end

  local function recycle(self)
    for _, icon in pairs(self.completionistMapV105LocationIcons or {}) do
      if type(UI) == "table" and type(UI.Anim) == "function" then
        pcall(UI.Anim, icon, AS_Forward, "", 0, 0)
      end
      pcall(Map.RecycleIcon, icon)
      if self.mapIconCollision == icon then self.mapIconCollision = nil end
    end
    self.completionistMapV105LocationIcons = {}
    self.completionistMapV105LocationSelected = nil
    self.completionistMapV105LocationVisibility = nil
  end

  local function visibilityKey(self)
    local rev = State and State:Revision() or 0
    return tostring(self.currRealmName) .. ":" .. tostring(filter(self)) ..
      ":" .. tostring(self.isOpenedForFastTravel == true) .. ":" .. tostring(rev) ..
      ":" .. tostring(_G.CompletionistMapV105ShowAll()) .. ":" .. tostring(_G.CompletionistMapV105ShowCategories())
  end

  local function sync(self)
    if self == nil then return end
    activeMap = self
    local icons = self.completionistMapV105LocationIcons or {}
    self.completionistMapV105LocationIcons = icons
    for name, icon in pairs(icons) do
      if byName[name] == nil or not visible(self, byName[name]) then
        pcall(Map.RecycleIcon, icon)
        if self.completionistMapV105LocationSelected == byName[name] then
          clearSelection(self, icon)
        elseif self.mapIconCollision == icon then
          self.mapIconCollision = nil
        end
        icons[name] = nil
      end
    end
    for _, row in ipairs(rows) do
      if visible(self, row) and icons[row.Name] == nil then
        local ok, icon = pcall(function()
          local info = game.Map.GetMarkerInfo(row.Name)
          if type(info) ~= "table" or tostring(info.Id) ~= row.IdString then return nil end
          local found, region = Map.FindRegionFromMarker(info.Id)
          if found ~= true or region == nil then return nil end
          return Map.CreateMarkerIcon(info.Id, region, "")
        end)
        if ok and icon ~= nil then
          icons[row.Name] = icon
          pcall(function()
            icon:Show()
            if type(UI) == "table" and type(UI.SetIsClickable) == "function" then
              UI.SetIsClickable(icon)
            end
          end)
        else
          print("[CompletionistLocations] create_failed name=" .. row.Name)
        end
      end
    end
    updateHighlights(self)
    self.completionistMapV105LocationVisibility = visibilityKey(self)
  end


  _G.CompletionistMapV105LocationStateChanged = function(boundary)
    if boundary then
      if targetRow then cleanupPending = true end
      if activeMap then clearSelection(activeMap) end
    end
    hideCollectedTarget()
    sync(activeMap)
  end

  local createPins = CompletionistMapV100_CreateMapPin
  CompletionistMapV100_CreateMapPin = function(self, ...)
    if syncDirectObservations and runtime then
      pcall(syncDirectObservations, runtime, State and State:Epoch() or 0)
    end
    local result = createPins(self, ...)
    if runtime then runtime:Poll() end
    sync(self)
    return result
  end

  -- Reuse the three authored Niflheim rift IDs. The location layer owns their
  -- icons in normal map mode, so native enumeration must not draw a second copy.
  local getRealmInfo = MapOn.GetRealmMarkerInfo
  MapOn.GetRealmMarkerInfo = function(self, ...)
    local result = getRealmInfo(self, ...)
    if not self.isOpenedForFastTravel then
      local remaining = {}
      for _, info in ipairs(self.realmMarkerInfo or {}) do
        if nativeIds[tostring(info.Id)] then
          if info.iconGO ~= nil then Map.RecycleIcon(info.iconGO); info.iconGO = nil end
        else
          remaining[#remaining + 1] = info
        end
      end
      self.realmMarkerInfo = remaining
      self:UpdateFilterButtonMapping()
    end
    return result
  end

  local updateMapping = MapOn.UpdateFilterButtonMapping
  MapOn.UpdateFilterButtonMapping = function(self, ...)
    local selected = filter(self)
    local result = updateMapping(self, ...)
    local present, families = {}, {}
    for _, kind in ipairs(self.filterButtonMapping) do present[kind] = true end
    for _, row in ipairs(rows) do
      if row.Realm == self.currRealmName then families[row.Family] = true end
    end
    local function add(kind)
      if not present[kind] then
        self.filterButtonMapping[#self.filterButtonMapping + 1] = kind
        present[kind] = true
      end
    end
    if next(families) ~= nil then add(-101) end
    for _, category in ipairs(categories) do
      if families[category.Family] then add(category.Filter) end
    end
    for index, kind in ipairs(self.filterButtonMapping) do
      if kind == selected then
        self.filterIndex = index
        if kind > 0 then self.markerIncludeFlags = markerFilters[kind].markerIncludeFlags end
        break
      end
    end
    self:UpdateFilterUI()
    return result
  end

  local nextFilter = MapOn.Menu_Next_Filter
  MapOn.Menu_Next_Filter = function(self, ...)
    local result = nextFilter(self, ...)
    sync(self)
    return result
  end

  -- Realm entry calls these after rebuilding the filter list. Keep a restored
  -- family filter from repopulating the game's stock markers on that path.
  for _, method in ipairs({"GetAlwaysOnMarkers", "GetMarkers"}) do
    local previous = MapOn[method]
    MapOn[method] = function(self, ...)
      if not self.isOpenedForFastTravel and filter(self) < 0 then
        self:ClearMarkers(true)
        return
      end
      return previous(self, ...)
    end
  end

  local update = MapOn.Update
  MapOn.Update = function(self, ...)
    local result = update(self, ...)
    if runtime then runtime:Poll() end
    hideCollectedTarget()
    if self.completionistMapV105LocationVisibility ~= visibilityKey(self) then sync(self) end
    return result
  end

  for _, method in ipairs({"SubmenuExit", "Exit"}) do
    local previous = MapOn[method]
    MapOn[method] = function(self, ...)
      recycle(self)
      if activeMap == self then activeMap = nil; activeSelectionContext = nil end
      return previous(self, ...)
    end
  end

  local previousClearIcons = MapOn.ClearIcons
  MapOn.ClearIcons = function(self, ...)
    recycle(self)
    if activeMap == self then activeMap = nil; activeSelectionContext = nil end
    return previousClearIcons(self, ...)
  end

  _G.CompletionistMapV105ToggleMarkers = function(map)
    local target = map or activeMap
    if target == nil or target.isOpenedForFastTravel then return false end
    local kind = filter(target)
    if kind == 1 then
      _G.CompletionistMapV105ShowAll(not _G.CompletionistMapV105ShowAll())
    else
      _G.CompletionistMapV105ShowCategories(not _G.CompletionistMapV105ShowCategories())
    end
    pcall(function() Audio.PlaySound("SND_UX_Pause_Menu_Map_Region_Hover_Tick") end)
    sync(target)
    if type(_G.CompletionistMapV105ResyncRavens) == "function" then
      pcall(_G.CompletionistMapV105ResyncRavens, target)
    end
    if type(_G.CompletionistMapV105ResyncNornir) == "function" then
      pcall(_G.CompletionistMapV105ResyncNornir, target)
    end
    local menu = target.menu or (activeSelectionContext and activeSelectionContext.menu)
    if menu and type(target.UpdateFooterButtonPrompt) == "function" then
      pcall(target.UpdateFooterButtonPrompt, target, menu, false, false)
    end
    return true
  end

  local previousDown = MapOn.EVT_Down_Release
  MapOn.EVT_Down_Release = function(self, ...)
    local target = self or activeMap
    if target and not target.isOpenedForFastTravel then
      return _G.CompletionistMapV105ToggleMarkers(target)
    end
    if previousDown then return previousDown(self, ...) end
  end

  local previousFooterPrompt = MapOn.UpdateFooterButtonPrompt
  MapOn.UpdateFooterButtonPrompt = function(self, currMenu, showConfirmFastTravel, showGoToJournal)
    if previousFooterPrompt then
      previousFooterPrompt(self, currMenu, showConfirmFastTravel, showGoToJournal)
    end
    if currMenu and type(currMenu.UpdateFooterButton) == "function" then
      if self.isOpenedForFastTravel then
        currMenu:UpdateFooterButton("ActiveMarkers", false)
      else
        local kind = filter(self)
        local shouldShowToggle = (kind == 1 or kind == -101 or kind < -104)
        if shouldShowToggle then
          local isShowing
          if kind == 1 then
            isShowing = _G.CompletionistMapV105ShowAll()
          else
            isShowing = _G.CompletionistMapV105ShowCategories()
          end
          local toggleText = isShowing and "[DownButton] Hide Markers" or "[DownButton] Show Markers"
          currMenu:UpdateFooterButton("ActiveMarkers", true, toggleText)
        else
          currMenu:UpdateFooterButton("ActiveMarkers", false)
        end
      end
      if type(currMenu.UpdateFooterButtonText) == "function" then
        currMenu:UpdateFooterButtonText()
      end
    end
  end

  local function selection(self)
    local row = self.completionistMapV105LocationSelected
    if row == nil then return nil end
    local icon = (self.completionistMapV105LocationIcons or {})[row.Name]
    if icon == nil or not visible(self, row) or (self.currMarkerID ~= nil and tostring(self.currMarkerID) ~= row.IdString) then
      self.completionistMapV105LocationSelected = nil
      return nil
    end
    return row
  end

  local refreshCompassPromptUI

  local collision = MapOn.MapCollisionChangeHandler
  MapOn.MapCollisionChangeHandler = function(self, currState, hits, realmName)
    activeSelectionContext = currState
    self.completionistMapV105LocationSelected = nil
    local result = collision(self, currState, hits, realmName)
    local icons = self.completionistMapV105LocationIcons or {}
    for _, hit in ipairs(hits or {}) do
      for name, icon in pairs(icons) do
        if hit == icon then
          local row = byName[name]
          if row and visible(self, row) then
            self.completionistMapV105LocationSelected = row
            self.currMarkerID = row.IdString
            self.mapIconCollision = icon
            local caption = "Collectible location"
            if State and row.CatalogueId then
              local s = State:Get(row.CatalogueId)
              if s == "remaining" then caption = "Not collected" end
            end
            pcall(function() self:SetReticleInfo(currState, byFamily[row.Family].Title, caption) end)
            if refreshCompassPromptUI then
              refreshCompassPromptUI(self, currState and currState.menu)
            end
            return result
          end
        end
      end
    end
    return result
  end

  local previousMouseClick = MapOn.MouseClickHandler
  MapOn.MouseClickHandler = function(self, currState, ...)
    local sender = (type(UI) == "table" and type(UI.GetEventSenderGameObject) == "function") and UI.GetEventSenderGameObject() or nil

    if sender ~= nil and not self.isOpenedForFastTravel then
      if type(self.goFilterButtons) == "table" then
        for key, button in ipairs(self.goFilterButtons) do
          if sender == button then
            local first = self.completionistMapV100FilterWindowFirst or 1
            local desired = first + key - 1
            if desired <= #(self.filterButtonMapping or {}) then
              self:Menu_Next_Filter(desired - self.filterIndex)
            end
            return
          end
        end
      end
    end

    if not self.isOpenedForFastTravel then
      local clickedRow = nil
      local clickedIcon = nil
      if sender ~= nil then
        for name, icon in pairs(self.completionistMapV105LocationIcons or {}) do
          if sender == icon and self.mapIconCollision == icon then
            clickedRow = byName[name]
            clickedIcon = icon
            break
          end
        end
      end

      if clickedRow ~= nil and clickedIcon ~= nil and visible(self, clickedRow) then
        self.completionistMapV105LocationSelected = clickedRow
        self.currMarkerID = clickedRow.IdString
        self.mapIconCollision = clickedIcon
        self.clickedMarkerInfo = nil
        self.clickedPlayer = false
        local caption = "Collectible location"
        if State and clickedRow.CatalogueId then
          local s = State:Get(clickedRow.CatalogueId)
          if s == "remaining" then caption = "Not collected" end
        end
        pcall(function() self:SetReticleInfo(currState, byFamily[clickedRow.Family].Title, caption) end)
        if refreshCompassPromptUI then
          refreshCompassPromptUI(self, currState and currState.menu)
        end
        pcall(function() Audio.PlaySound("SND_UX_Pause_Menu_Map_Region_Hover_Tick") end)
        return
      end

      if sender ~= nil then
        self.completionistMapV105LocationSelected = nil
      else
        if self.mapIconCollision == nil and not self.testEnvironment then
          return
        end
      end
    end

    if previousMouseClick then return previousMouseClick(self, currState, ...) end
  end

  local previousUpdateHighlights = MapOn.UpdateMapMarkerHighlights
  MapOn.UpdateMapMarkerHighlights = function(self, ...)
    if previousUpdateHighlights then previousUpdateHighlights(self, ...) end
    updateHighlights(self)
  end

  local previousTrackingState = MapOn.GetMapMarkerTrackingState
  MapOn.GetMapMarkerTrackingState = function(self, markerID, ...)
    local state = previousTrackingState and previousTrackingState(self, markerID, ...)
    local trackedVal = (type(questConsts) == "table" and questConsts.TRACKING_STATE_TRACKED) or 1
    local noneVal = (type(questConsts) == "table" and questConsts.TRACKING_STATE_NONE) or 0
    if (state == nil or state == noneVal) and
        self.currShownMarkerID ~= nil and markerID ~= nil and
        tostring(markerID) == tostring(self.currShownMarkerID) then
      return trackedVal
    end
    return state
  end

  local previousEnter = MapOn.Enter
  MapOn.Enter = function(self, ...)
    local res = previousEnter and previousEnter(self, ...)
    if self.currShownMarkerID == nil and type(enabledShowOnCompassMarkerFlags) == "table" and
        type(game.Compass) == "table" and type(game.Compass.FindMarkersByIconClass) == "function" then
      local ok, stockMarkers = pcall(game.Compass.FindMarkersByIconClass, enabledShowOnCompassMarkerFlags)
      if ok and type(stockMarkers) == "table" and #stockMarkers > 0 then
        self.currShownMarkerID = stockMarkers[1]
      end
    end
    if type(self.UpdateMapMarkerHighlights) == "function" then
      pcall(self.UpdateMapMarkerHighlights, self)
    end
    return res
  end

  local previousSubmenuEnter = MapOn.SubmenuEnter
  MapOn.SubmenuEnter = function(self, ...)
    local res = previousSubmenuEnter and previousSubmenuEnter(self, ...)
    if self.currShownMarkerID == nil and type(enabledShowOnCompassMarkerFlags) == "table" and
        type(game.Compass) == "table" and type(game.Compass.FindMarkersByIconClass) == "function" then
      local ok, stockMarkers = pcall(game.Compass.FindMarkersByIconClass, enabledShowOnCompassMarkerFlags)
      if ok and type(stockMarkers) == "table" and #stockMarkers > 0 then
        self.currShownMarkerID = stockMarkers[1]
      end
    end
    if type(self.UpdateMapMarkerHighlights) == "function" then
      pcall(self.UpdateMapMarkerHighlights, self)
    end
    return res
  end

  local previousPrompt = MapOn.GetShowOnCompassPrompt
  MapOn.GetShowOnCompassPrompt = function(self, ...)
    local row = selection(self)
    if row == nil then
      local isNornir = (self.completionistMapV105NornirSelected ~= nil)
      local isRaven = (self.completionistMapV105SelectedRaven ~= nil)
      if not isNornir and not isRaven then
        if self.currMarkerID ~= nil and self.currShownMarkerID ~= nil and
            self.currMarkerID ~= self.currShownMarkerID and
            tostring(self.currMarkerID) == tostring(self.currShownMarkerID) then
          self.currShownMarkerID = self.currMarkerID
        end
      end
      local show, label = previousPrompt(self, ...)
      if not isNornir and not isRaven then
        local hasCustomTarget = (targetRow ~= nil) or
            (_G.CompletionistMapV105TrackedCatalogueId ~= nil) or
            (type(_G.CompletionistMapV105HasRavenCompassTarget) == "function" and _G.CompletionistMapV105HasRavenCompassTarget()) or
            (type(_G.CompletionistMapV105HasNornirCompassTarget) == "function" and _G.CompletionistMapV105HasNornirCompassTarget())
        if show and hasCustomTarget and label == "[AdvanceButton] " .. util.GetLAMSMsg(lamsConsts.AddToCompass) then
          label = "[AdvanceButton] " .. util.GetLAMSMsg(lamsConsts.ReplaceInCompass)
        end
      end
      return show, label
    end
    if self.isOpenedForFastTravel or not game.Compass.HaveCompass() or
        self.currRealmName ~= mapUtil.GetPlayerRealm() or
        tutorialUtil.CurrentlyShowingStep() then return false, nil end
    local label = lamsConsts.AddToCompass
    if targetRow == row then
      label = lamsConsts.RemoveFromCompass
    elseif targetRow ~= nil or self.currShownMarkerID ~= nil or
        _G.CompletionistMapV105TrackedCatalogueId ~= nil or
        _G.CompletionistMapV105HasNornirCompassTarget() then
      label = lamsConsts.ReplaceInCompass
    end
    return true, "[AdvanceButton] " .. util.GetLAMSMsg(label)
  end

  refreshCompassPromptUI = function(self, menu)
    local targetMap = self or activeMap
    if targetMap == nil then return end
    local targetMenu = menu or targetMap.menu or (activeSelectionContext and activeSelectionContext.menu)
    local show, text = targetMap:GetShowOnCompassPrompt(targetMenu)
    if show and text then
      if type(util) == "table" and type(util.GetUiObjByName) == "function" then
        pcall(function()
          local goMapCursorText = util.GetUiObjByName("MapCursorInfo")
          if goMapCursorText ~= nil then
            goMapCursorText:Show()
            local top = goMapCursorText:FindSingleGOByName("CursorInfo_Top")
            if top ~= nil then
              local handle = util.GetTextHandle(top, "CursorAction_Text")
              if handle ~= nil then
                if type(UI) == "table" and type(UI.SetTextIsClickable) == "function" then
                  UI.SetTextIsClickable(handle)
                end
                if type(UI) == "table" and type(UI.SetText) == "function" then
                  UI.SetText(handle, text)
                end
              end
              top:Show()
            end
          end
        end)
      end
      if targetMenu and type(targetMenu.UpdateFooterButton) == "function" then
        pcall(function()
          targetMenu:UpdateFooterButton("ShowOnCompass", true, text)
          if type(targetMenu.UpdateFooterButtonText) == "function" then
            targetMenu:UpdateFooterButtonText()
          end
        end)
      end
    end
    if targetMenu and type(targetMap.UpdateFooterButtonPrompt) == "function" then
      pcall(targetMap.UpdateFooterButtonPrompt, targetMap, targetMenu, false, false)
    end
  end

  local previousShow = MapOn.ShowOnCompass
  MapOn.ShowOnCompass = function(self, ...)
    local row = selection(self)
    if row == nil then
      local isNornir = (self.completionistMapV105NornirSelected ~= nil)
      local isRaven = (self.completionistMapV105SelectedRaven ~= nil)
      if not isNornir and not isRaven then
        if self.currMarkerID ~= nil and self.currShownMarkerID ~= nil and
            self.currMarkerID ~= self.currShownMarkerID and
            tostring(self.currMarkerID) == tostring(self.currShownMarkerID) then
          self.currShownMarkerID = self.currMarkerID
        end
        local hasCustomTarget = (targetRow ~= nil) or
            (_G.CompletionistMapV105TrackedCatalogueId ~= nil) or
            (type(_G.CompletionistMapV105HasRavenCompassTarget) == "function" and _G.CompletionistMapV105HasRavenCompassTarget()) or
            (type(_G.CompletionistMapV105HasNornirCompassTarget) == "function" and _G.CompletionistMapV105HasNornirCompassTarget())
        if hasCustomTarget then
          if type(_G.CompletionistMapV105ReleaseRavenCompass) == "function" then
            pcall(_G.CompletionistMapV105ReleaseRavenCompass)
          end
          if type(_G.CompletionistMapV105ReleaseNornirCompass) == "function" then
            pcall(_G.CompletionistMapV105ReleaseNornirCompass)
          end
          hideTarget()
        end
      else
        if not hideTarget() then return false end
      end
      local res = previousShow and previousShow(self, ...)
      updateHighlights(self)
      local currState = select(1, ...)
      if refreshCompassPromptUI then
        refreshCompassPromptUI(self, currState and currState.menu)
      end
      return res
    end
    if self.isOpenedForFastTravel or not game.Compass.HaveCompass() or
        self.currRealmName ~= mapUtil.GetPlayerRealm() or
        tutorialUtil.CurrentlyShowingStep() then return false end
    if targetRow == row then
      if not hideTarget() then return false end
      pcall(function() Audio.PlaySound("SND_UX_Pause_Menu_Map_RemoveFromCompass") end)
    else
      if type(_G.CompletionistMapV105ReleaseRavenCompass) == "function" then
        if _G.CompletionistMapV105ReleaseRavenCompass() == false then return false end
      end
      if type(_G.CompletionistMapV105ReleaseNornirCompass) == "function" then
        if _G.CompletionistMapV105ReleaseNornirCompass() == false then return false end
      end
      if not hideTarget() then return false end
      if self.currShownMarkerID ~= nil then
        pcall(game.Compass.HideMarker, self.currShownMarkerID)
        self.currShownMarkerID = nil
      end
      local stockMarkers = (type(enabledShowOnCompassMarkerFlags) == "table" and
          type(game.Compass) == "table" and
          type(game.Compass.FindMarkersByIconClass) == "function") and
          game.Compass.FindMarkersByIconClass(enabledShowOnCompassMarkerFlags) or nil
      if type(stockMarkers) == "table" then
        for _, id in ipairs(stockMarkers) do
          pcall(game.Compass.HideMarker, id)
        end
      end
      pcall(function() self:UpdateMapMarkerHighlights() end)
      local familyClasses = {
        ["artefact"] = "CompletionistArtefact",
        ["cipher_chest"] = "CompletionistCipherChest",
        ["coffin"] = "CompletionistCoffin",
        ["jotnar_shrine"] = "CompletionistJotnarShrine",
        ["legendary_chest"] = "CompletionistLegendaryChest",
        ["lore_marker"] = "CompletionistLoreMarker",
        ["lore_scroll"] = "CompletionistLoreScroll",
        ["nornir_bell"] = "CompletionistNornirBell",
        ["nornir_chest"] = "CompletionistNornirChest",
        ["nornir_mechanism"] = "CompletionistNornirMechanism",
        ["nornir_seal"] = "CompletionistNornirSeal",
        ["realm_tear"] = "CompletionistRealmTear",
        ["treasure_dig"] = "CompletionistTreasureDig",
        ["treasure_map"] = "CompletionistTreasureMap",
        ["wooden_chest"] = "CompletionistWoodenChest",
      }
      local compassClass = (row.Family and familyClasses[row.Family]) or "SIDE"
      local ok, result = pcall(game.Compass.ShowMarker, row.Name, compassClass)
      if not ok or result == false then
        ok, result = pcall(game.Compass.ShowMarker, row.Name, "SIDE")
      end
      if not ok or result == false then return false end
      targetRow = row
      if _G.CompletionistMapV100Target then _G.CompletionistMapV100Target.active = false end
      pcall(function() Audio.PlaySound("SND_UX_Pause_Menu_Map_AddToCompass") end)
    end
    updateHighlights(self)
    local currState = select(1, ...)
    if refreshCompassPromptUI then
      refreshCompassPromptUI(self, currState and currState.menu)
    end
    return true
  end


  -- Expose state publisher for trusted event adapters (active outside map).
  _G.CompletionistMapV105PublishLocationState = function(id, state, epoch)
    if State == nil then return false end
    if runtime then return runtime:Observe(id, state, epoch) end
    local accepted = State:Observe(id, state, epoch)
    if accepted then _G.CompletionistMapV105LocationStateChanged() end
    return accepted
  end

  local controller = _G.CompletionistMapV105Nornir
  local beginEpoch = controller.BeginEpoch
  controller.BeginEpoch = function(self, ...)
    local accepted = beginEpoch(self, ...)
    if accepted then
      local epoch = self.service.epoch
      if runtime then runtime:BeginEpoch(epoch)
      elseif State and epoch > State:Epoch() then
        State:BeginEpoch(epoch)
        _G.CompletionistMapV105LocationStateChanged(true)
      end
    end
    return accepted
  end
  local mode = State and "hide_collected" or "all_known_locations"
  print("[CompletionistLocations] installed rows=" .. tostring(#rows) ..
    " categories=" .. tostring(#categories) .. " art=stock_blue_quest mode=" .. mode)
end
-- END COMPLETIONIST V0.10.5 COLLECTIBLE LOCATIONS
