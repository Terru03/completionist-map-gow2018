<#
.SYNOPSIS
    Universal 1-Click Uninstaller for God of War (2018) Completionist Map Mod.
.DESCRIPTION
    Restores original stock files from completionist_backup and cleans up added mod files.
#>
param(
    [string]$TargetDir = ""
)

$ErrorActionPreference = "Stop"

function Find-GodOfWar {
    if ($TargetDir -and (Test-Path (Join-Path $TargetDir "GoW.exe"))) {
        return (Resolve-Path $TargetDir).Path
    }
    $scriptDir = Split-Path -Parent $PSScriptRoot
    if (Test-Path (Join-Path $scriptDir "GoW.exe")) {
        return $scriptDir
    }
    $currDir = (Get-Location).Path
    if (Test-Path (Join-Path $currDir "GoW.exe")) {
        return $currDir
    }
    $regPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 1593500",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 1593500"
    )
    foreach ($reg in $regPaths) {
        if (Test-Path $reg) {
            $loc = (Get-ItemProperty $reg -ErrorAction SilentlyContinue).InstallLocation
            if ($loc -and (Test-Path (Join-Path $loc "GoW.exe"))) {
                return $loc
            }
        }
    }
    $steamReg = Get-ItemProperty "HKCU:\SOFTWARE\Valve\Steam" -ErrorAction SilentlyContinue
    if ($steamReg -and $steamReg.SteamPath) {
        $vdf = Join-Path $steamReg.SteamPath "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            $content = Get-Content $vdf -Raw -ErrorAction SilentlyContinue
            $matches = [regex]::Matches($content, '"path"\s+"([^"]+)"')
            foreach ($m in $matches) {
                $libPath = $m.Groups[1].Value.Replace('\\', '\')
                $testPath = Join-Path $libPath "steamapps\common\GodOfWar"
                if (Test-Path (Join-Path $testPath "GoW.exe")) {
                    return $testPath
                }
            }
        }
    }
    $drives = Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Root
    $subpaths = @(
        "Program Files (x86)\Steam\steamapps\common\GodOfWar",
        "Program Files\Steam\steamapps\common\GodOfWar",
        "SteamLibrary\steamapps\common\GodOfWar",
        "Steam\steamapps\common\GodOfWar",
        "Games\GodOfWar",
        "Epic Games\GodOfWar"
    )
    foreach ($d in $drives) {
        foreach ($sub in $subpaths) {
            $candidate = Join-Path $d $sub
            if (Test-Path (Join-Path $candidate "GoW.exe")) {
                return $candidate
            }
        }
    }
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Select your God of War game folder to uninstall mod"
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        if (Test-Path (Join-Path $dialog.SelectedPath "GoW.exe")) {
            return $dialog.SelectedPath
        }
    }
    return $null
}

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  God of War (2018) - Completionist Map Mod Uninstaller " -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

$gowProc = Get-Process "GoW" -ErrorAction SilentlyContinue
if ($gowProc) {
    Write-Host "WARNING: God of War is currently running!" -ForegroundColor Red
    Write-Host "Please close the game before uninstalling the mod." -ForegroundColor Yellow
    exit 1
}

$game = Find-GodOfWar
if (-not $game) {
    Write-Host "ERROR: God of War installation folder could not be found." -ForegroundColor Red
    exit 1
}

$backupDir = Join-Path $game "completionist_backup"
$backupManifest = Join-Path $backupDir "backup_manifest.json"

if (-not (Test-Path $backupManifest)) {
    Write-Host "ERROR: No backup found in: $backupDir" -ForegroundColor Red
    Write-Host "Cannot restore automatically without backup manifest." -ForegroundColor Yellow
    exit 1
}

$manifest = Get-Content $backupManifest -Raw | ConvertFrom-Json
Write-Host "[*] Restoring original stock game files from backup..." -ForegroundColor Cyan

foreach ($rel in $manifest.files.PSObject.Properties.Name) {
    $src = Join-Path $backupDir $rel
    $dest = Join-Path $game $rel
    if (Test-Path $src) {
        Copy-Item -Path $src -Destination $dest -Force
        Write-Host "  Restored: $rel" -ForegroundColor Gray
    }
}

# Clean added files
$addedFiles = @(
    "exec\patch\pc_le\completionist_v105_family_art.texpack",
    "exec\patch\pc_le\completionist_v105_family_art.texpack.toc",
    "mods\completionist-map\native\collectible-base-dxgi.dll",
    "mods\completionist-map\native\raven-native-bridge-manifest.json",
    "mods\completionist-map\native\raven-native-bridge.log"
)
foreach ($rel in $addedFiles) {
    $target = Join-Path $game $rel
    if (Test-Path $target) {
        Remove-Item -Path $target -Force -ErrorAction SilentlyContinue
        Write-Host "  Removed mod file: $rel" -ForegroundColor Gray
    }
}

# Clean boot-options.json
$bootPath = Join-Path $game "exec\boot-options.json"
if (Test-Path $bootPath) {
    try {
        $boot = Get-Content $bootPath -Raw | ConvertFrom-Json
        $entry = "../../patch/pc_le/completionist_v105_family_art"
        $packs = [System.Collections.ArrayList]@($boot.'patch-texpacks')
        if ($packs.Contains($entry)) {
            $packs.Remove($entry)
            $boot.'patch-texpacks' = $packs
            $boot | ConvertTo-Json -Depth 5 | Set-Content -Path $bootPath -Encoding UTF8
            Write-Host "  Cleaned texpack entry from boot-options.json" -ForegroundColor Gray
        }
    } catch {}
}

# Remove backup directory
Remove-Item -Path $backupDir -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host "         UNINSTALLATION COMPLETED SUCCESSFULLY!         " -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host "Original stock files have been restored." -ForegroundColor Cyan
Write-Host "All mod-added files have been cleaned up." -ForegroundColor Cyan
exit 0
