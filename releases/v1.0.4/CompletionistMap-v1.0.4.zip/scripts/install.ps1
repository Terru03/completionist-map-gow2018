<#
.SYNOPSIS
    Universal 1-Click Installer for God of War (2018) Completionist Map Mod.
.DESCRIPTION
    Auto-detects God of War install folder across Steam, Epic Games, custom drives,
    or user prompt. Safely backs up stock game files before copying mod files.
#>
param(
    [string]$TargetDir = ""
)

$ErrorActionPreference = "Stop"

function Find-GodOfWar {
    # 1. TargetDir parameter
    if ($TargetDir -and (Test-Path (Join-Path $TargetDir "GoW.exe"))) {
        return (Resolve-Path $TargetDir).Path
    }
    # 2. Parent directory of script / current directory (if extracted directly into game folder)
    $scriptDir = Split-Path -Parent $PSScriptRoot
    if (Test-Path (Join-Path $scriptDir "GoW.exe")) {
        return $scriptDir
    }
    $currDir = (Get-Location).Path
    if (Test-Path (Join-Path $currDir "GoW.exe")) {
        return $currDir
    }
    # 3. Steam Registry (32-bit & 64-bit)
    $regPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 1593500",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 1593500"
    )
    foreach ($reg in $regPaths) {
        if (Test-Path $reg) {
            $loc = (Get-ItemProperty $reg -ErrorAction SilentlyContinue).InstallLocation
            if ($loc -and (Test-Path (Join-Path $loc "GoW.exe"))) {
                return $loc
            }
        }
    }
    # 4. Steam libraryfolders.vdf parser
    $steamReg = Get-ItemProperty "HKCU:\SOFTWARE\Valve\Steam" -ErrorAction SilentlyContinue
    if ($steamReg -and $steamReg.SteamPath) {
        $vdf = Join-Path $steamReg.SteamPath "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            $content = Get-Content $vdf -Raw -ErrorAction SilentlyContinue
            $matches = [regex]::Matches($content, '"path"\s+"([^"]+)"')
            foreach ($m in $matches) {
                $libPath = $m.Groups[1].Value.Replace('\\', '\')
                $testPath = Join-Path $libPath "steamapps\common\GodOfWar"
                if (Test-Path (Join-Path $testPath "GoW.exe")) {
                    return $testPath
                }
            }
        }
    }
    # 5. Epic Games Manifests
    $epicDir = "C:\ProgramData\Epic\EpicGamesLauncher\Data\Manifests"
    if (Test-Path $epicDir) {
        Get-ChildItem $epicDir -Filter "*.item" -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $json = Get-Content $_.FullName -Raw | ConvertFrom-Json
                if ($json.DisplayName -match "God of War" -and (Test-Path (Join-Path $json.InstallLocation "GoW.exe"))) {
                    return $json.InstallLocation
                }
            } catch {}
        }
    }
    # 6. Common Library Paths across drives C: through H:
    $drives = Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Root
    $subpaths = @(
        "Program Files (x86)\Steam\steamapps\common\GodOfWar",
        "Program Files\Steam\steamapps\common\GodOfWar",
        "SteamLibrary\steamapps\common\GodOfWar",
        "Steam\steamapps\common\GodOfWar",
        "Games\GodOfWar",
        "Epic Games\GodOfWar"
    )
    foreach ($d in $drives) {
        foreach ($sub in $subpaths) {
            $candidate = Join-Path $d $sub
            if (Test-Path (Join-Path $candidate "GoW.exe")) {
                return $candidate
            }
        }
    }
    # 7. Interactive Folder Browser fallback
    Write-Host "God of War installation directory not detected automatically." -ForegroundColor Yellow
    Write-Host "Please select your God of War game directory in the window (where GoW.exe is located)..." -ForegroundColor Cyan
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Select your God of War game folder (contains GoW.exe)"
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        if (Test-Path (Join-Path $dialog.SelectedPath "GoW.exe")) {
            return $dialog.SelectedPath
        } else {
            Write-Host "ERROR: The selected folder does not contain GoW.exe!" -ForegroundColor Red
        }
    }
    return $null
}

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "   God of War (2018) - Completionist Map Mod Installer  " -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# Check if GoW is running
$gowProc = Get-Process "GoW" -ErrorAction SilentlyContinue
if ($gowProc) {
    Write-Host "WARNING: God of War is currently running!" -ForegroundColor Red
    Write-Host "Please close the game before proceeding with installation." -ForegroundColor Yellow
    Write-Host "Press any key to retry after closing the game..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    $gowProc = Get-Process "GoW" -ErrorAction SilentlyContinue
    if ($gowProc) {
        Write-Host "God of War is still running. Aborting installation." -ForegroundColor Red
        exit 1
    }
}

$game = Find-GodOfWar
if (-not $game) {
    Write-Host "ERROR: God of War installation folder could not be found." -ForegroundColor Red
    Write-Host "Please place the installer folder directly inside your God of War game folder and run Install.bat again." -ForegroundColor Yellow
    exit 1
}

Write-Host "[+] Detected God of War at: $game" -ForegroundColor Green

$sourceRoot = Split-Path -Parent $PSScriptRoot
$manifestPath = Join-Path $sourceRoot "manifest.json"
if (-not (Test-Path $manifestPath)) {
    Write-Host "ERROR: manifest.json missing from installer package." -ForegroundColor Red
    exit 1
}
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json

# Check all inputs before game files change.
if ($manifest.supported_exe_sha256 -notmatch '^[0-9a-f]{64}$') {
    Write-Host "ERROR: Package has no valid supported EXE hash." -ForegroundColor Red
    exit 1
}
$exeHash = (Get-FileHash -LiteralPath (Join-Path $game "GoW.exe") -Algorithm SHA256).Hash.ToLowerInvariant()
if ($exeHash -ne $manifest.supported_exe_sha256) {
    Write-Host "ERROR: Unsupported GoW.exe. No game files changed." -ForegroundColor Red
    Write-Host "Supported: Steam 1.0.13 (1.0.475.7534), SHA256 $($manifest.supported_exe_sha256)"
    Write-Host "Found SHA256: $exeHash"
    exit 1
}
if (-not $manifest.files -or @($manifest.files.PSObject.Properties).Count -eq 0) {
    Write-Host "ERROR: Package file list empty." -ForegroundColor Red
    exit 1
}
foreach ($file in $manifest.files.PSObject.Properties) {
    $rel = $file.Name
    if ([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|[\\/])\.\.([\\/]|$)|:') {
        Write-Host "ERROR: Invalid package path: $rel" -ForegroundColor Red
        exit 1
    }
    $src = Join-Path $sourceRoot $rel
    if (-not (Test-Path -LiteralPath $src -PathType Leaf)) {
        Write-Host "ERROR: Package file missing: $rel. No game files changed." -ForegroundColor Red
        exit 1
    }
    $expected = $file.Value.sha256
    $actual = (Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($expected -notmatch '^[0-9a-f]{64}$' -or $actual -ne $expected) {
        Write-Host "ERROR: Package hash mismatch: $rel. Extract fresh ZIP; no game files changed." -ForegroundColor Red
        exit 1
    }
}
$bootPath = Join-Path $game "exec\boot-options.json"
$preparedBoot = $null
try {
    $boot = Get-Content -LiteralPath $bootPath -Raw | ConvertFrom-Json
    if ($boot -isnot [PSCustomObject]) { throw "Expected JSON object." }
    $entry = "../../patch/pc_le/completionist_v105_family_art"
    $packs = @($boot.'patch-texpacks' | Where-Object { $_ })
    if ($entry -notin $packs) {
        $boot | Add-Member -MemberType NoteProperty -Name 'patch-texpacks' -Value @($packs + $entry) -Force
        $preparedBoot = $boot | ConvertTo-Json -Depth 32
    }
} catch {
    Write-Host "ERROR: Cannot read boot-options.json: $_. No game files changed." -ForegroundColor Red
    exit 1
}

# Keep stock backup.
$backupDir = Join-Path $game "completionist_backup"
$backupManifest = Join-Path $backupDir "backup_manifest.json"
if (-not (Test-Path $backupDir)) {
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
}

$backedUp = @{}
if (Test-Path $backupManifest) {
    Write-Host "[i] Existing stock backup found in completionist_backup. Preserving original backup." -ForegroundColor Yellow
} else {
    Write-Host "[*] Creating safe backup of stock game files..." -ForegroundColor Cyan
    foreach ($rel in $manifest.files.PSObject.Properties.Name) {
        $target = Join-Path $game $rel
        if (Test-Path $target) {
            $dest = Join-Path $backupDir $rel
            $destParent = Split-Path -Parent $dest
            if (-not (Test-Path $destParent)) {
                New-Item -ItemType Directory -Force -Path $destParent | Out-Null
            }
            Copy-Item -Path $target -Destination $dest -Force
            $backedUp[$rel] = (Get-FileHash -Path $target -Algorithm SHA256).Hash.ToLower()
        }
    }
    # Also backup boot-options.json
    $bootPath = Join-Path $game "exec\boot-options.json"
    if (Test-Path $bootPath) {
        $destBoot = Join-Path $backupDir "exec\boot-options.json"
        $destBootParent = Split-Path -Parent $destBoot
        if (-not (Test-Path $destBootParent)) { New-Item -ItemType Directory -Force -Path $destBootParent | Out-Null }
        Copy-Item -Path $bootPath -Destination $destBoot -Force
        $backedUp["exec/boot-options.json"] = (Get-FileHash -Path $bootPath -Algorithm SHA256).Hash.ToLower()
    }

    $backupInfo = @{
        "created_at" = (Get-Date).ToString("o")
        "files" = $backedUp
    }
    $backupInfo | ConvertTo-Json -Depth 5 | Set-Content -Path $backupManifest -Encoding UTF8
    Write-Host "[+] Backed up $(($backedUp.Keys).Count) stock files to completionist_backup." -ForegroundColor Green
}

# Copy mod files
Write-Host "[*] Installing Completionist Map mod files..." -ForegroundColor Cyan
$installCount = 0
foreach ($rel in $manifest.files.PSObject.Properties.Name) {
    $src = Join-Path $sourceRoot $rel
    if (-not (Test-Path $src)) {
        Write-Host "ERROR: Package file missing: $rel" -ForegroundColor Red
        exit 1
    }
    $dest = Join-Path $game $rel
    $destParent = Split-Path -Parent $dest
    if (-not (Test-Path $destParent)) {
        New-Item -ItemType Directory -Force -Path $destParent | Out-Null
    }
    Copy-Item -Path $src -Destination $dest -Force
    $installCount++
}

# Add art pack with no UTF-8 BOM.
if ($null -ne $preparedBoot) {
    [IO.File]::WriteAllText($bootPath, $preparedBoot, (New-Object Text.UTF8Encoding($false)))
    Write-Host "[+] Artwork patch texpack registered in boot-options.json" -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host "           INSTALLATION COMPLETED SUCCESSFULLY!         " -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host " Features active:" -ForegroundColor Cyan
Write-Host "  * 498 non-Raven markers across 15 custom marker families"
Write-Host "  * Odin's Ravens with native authority & tracking"
Write-Host "  * Chest state persistence across restarts (wooden chests, etc.)"
Write-Host "  * Custom map markers & compass HUD icons with distance meters"
Write-Host "  * In-map [Down Arrow] toggle button (Hide / Show Markers)"
Write-Host "  * Original stock files backed up to: completionist_backup"
Write-Host ""
Write-Host "You can now launch God of War!" -ForegroundColor Cyan
exit 0
