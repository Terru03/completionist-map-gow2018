================================================================================
           GOD OF WAR (2018) PC - COMPLETIONIST MAP MOD v1.0.4
================================================================================

551 marker records across 16 custom collectible families, including Odin's Ravens,
integrated with your in-game Map & Compass.

--------------------------------------------------------------------------------
1. FEATURES
--------------------------------------------------------------------------------
- 16 custom collectible families (551 marker records total):
    * Odin's Ravens
    * Nornir Chests
    * Nornir Seals
    * Nornir Bells
    * Nornir Mechanisms
    * Legendary Chests
    * Cipher Chests
    * Wooden Chests
    * Red / Coffin Chests
    * Artefacts
    * Jotnar Shrines
    * Lore Markers
    * Lore Scrolls
    * Realm Tears
    * Treasure Maps
    * Treasure Dig Sites
- Odin's Ravens use native completion authority within the same mod.
- No duplicate native markers: Valkyries, the Valkyrie Queen, Mystic Gateways
  and Shops remain handled by the base game's own map/compass systems.
- Custom Map Marker Artwork: Unique, lore-friendly icon for every collectible type.
- Custom Compass HUD Artwork: Full compass icons and distance tracking in 3D world.
- On-Screen Toggle: Press [Down Arrow] anytime on the map to Show/Hide markers.
  Your choice persists across map opens.
- Single Reticle Lock: Press [Enter] / [E] to pin any marker to the compass HUD.
- Read-only completion checks use live objects and native saved-state authority.

--------------------------------------------------------------------------------
2. REQUIREMENTS
--------------------------------------------------------------------------------
- Windows 10 or Windows 11, 64-bit.
- Supported GoW.exe: Steam 1.0.13, file version 1.0.475.7534.
  SHA256: caebcb027980d7eac9203d190f9ee649eebc549f8defce138e2114dc91f40452
  Other EXE builds not supported. Installer checks hash before any game write.
- GoW Script Loader & Gameplay Tweaks 0.22 (version.dll) installed first.
- No other mod may replace dxgi.dll or these map files.

--------------------------------------------------------------------------------
3. INSTALLATION
--------------------------------------------------------------------------------
OPTION A: Automated 1-Click Installer (Recommended)
1. Extract this zip file anywhere.
2. Double-click "Install.bat".
   The installer automatically detects your God of War folder (Steam/Epic),
   backs up your original stock files, and installs the mod.
3. Launch God of War and open your map!

OPTION B: Mod Managers (Vortex / MO2)
1. Drag and drop this zip file into Vortex / Mod Organizer 2.
2. Enable and Deploy.
3. In exec/boot-options.json, add this string to existing "patch-texpacks" array:
   "../../patch/pc_le/completionist_v105_family_art"
   Keep all other entries. Back up JSON before edit.
4. Vortex/MO2 bypass installer checks. Use only supported EXE hash above.

OPTION C: Manual Installation
1. Copy the contents of this zip (dxgi.dll, exec\, mods\) into your God of War
   game folder (where GoW.exe is located).
2. Ensure GoW Script Loader 0.22 is installed.
3. Register art texpack in boot-options.json as in Option B.
4. Manual copy bypasses installer checks. Use only supported EXE hash above.

--------------------------------------------------------------------------------
4. UNINSTALLATION
--------------------------------------------------------------------------------
- If you used the installer: Double-click "Uninstall.bat".
  It will restore your original stock files from backup and clean up mod files.
- If you installed via Vortex / MO2: Disable and Undeploy in your mod manager.
- If manual: Restore your backed-up files or verify file integrity via Steam/Epic.
- Vortex/manual: remove only mod's art texpack entry from boot-options.json.

--------------------------------------------------------------------------------
5. UPDATES IN v1.0.4
--------------------------------------------------------------------------------
- Fixes opened wooden and red/coffin chest pins staying Not collected when
  the live scene omits outer catalogue ancestors. Checks the full inner owner
  path against the exact accepted placement before reading the opened state.
- The Discord tester confirmed red/common chest pins disappear after opening
  and killed Ravens are tracked correctly. The author relayed success on Oct 8.
- Promotes the tested chest fix as v1.0.4 with the same runtime and installer
  files. See CHANGELOG.txt for the explicit release changes and test scope.
- Fixes an early Windows compatibility-layer call that could crash in ntdll
  before the game window, loader log, or native bridge log appeared.
- Keeps compatibility arguments until normal graphics initialization, then
  forwards them to Windows DXGI. Includes the v1.0.1/v1.0.2 gameplay fixes below.
- The reporting player confirmed that the game now starts successfully.
- Real-Time 3D In-World Compass Clearing: Collecting any tracked collectible
  (Artefacts, Realm Tears, Chests, Shrines, Digs, Lore Runes/Scrolls) now
  instantly clears the active waypoint pin from the Compass HUD in 3D gameplay
  without requiring a save reload or reopening the map.
- Full Artefact Direct Authority: Mapped all 45 Artefacts to native wallet resources
  and set quests, ensuring collected artefacts disappear from the map immediately.
- Realm Tear Completion Authority: Dual-layer live loaded observation and
  persistent unloaded authority for all 21 Realm Tears.
- DXGI functions resolved by name, not Windows-version-dependent ordinals.
- Missing optional Windows 11 export no longer blocks graphics factories.
- Unsupported EXE or bad native DLL pair logged; native patches stay disabled.
  This fallback keeps graphics alive, but cannot make unsupported mod data safe.
  Do not use full mod on unsupported EXE.
- Installer checks EXE, all payload hashes, and boot JSON before any write.
- For crash report, include GoW.exe SHA256, Windows version, loader_log.txt,
  and mods/completionist-map/native/raven-native-bridge.log.

================================================================================
Created with care for the God of War PC community. Enjoy your 100% journey!
================================================================================
