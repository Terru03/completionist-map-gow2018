@echo off
setlocal
cd /d "%~dp0"
echo ========================================================
echo   God of War (2018) - Completionist Map Mod Uninstaller
echo ========================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\uninstall.ps1" %*
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Uninstallation did not finish successfully (exit code %ERRORLEVEL%).
    pause
    exit /b %ERRORLEVEL%
)
echo.
pause
